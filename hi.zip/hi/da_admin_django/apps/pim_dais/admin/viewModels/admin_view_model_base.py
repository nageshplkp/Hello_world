# ======================================================================
# This is the app specific configuration for the AdminViewModels
# ======================================================================
from __future__ import unicode_literals
from apps.admin_view_model_base import *
from ...app_config import AppConfig


class AdminViewModelBase(AdminViewModelBase):
    class Media:
        css = {
            'all': ('pim_dais/css/styles.css',)
        }


class AdminTabularInlineViewModelBase(AdminTabularInlineViewModelBase):
    pass


class AdminClientSideFormViewModelBase(AdminClientSideFormViewModelBase):
    pass


class AdminClientSideFormViewModelBase(AdminClientSideFormViewModelBase):
    class Media:
        js = (
            '%s/js/form.js' % AppConfig.name,
        )
