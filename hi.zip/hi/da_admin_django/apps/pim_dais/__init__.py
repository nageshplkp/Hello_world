from core.helpers import *

default_app_config = get_folder_path_as_module(__file__) + '.app_config.AppConfig'
