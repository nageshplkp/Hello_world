from __future__ import unicode_literals
from gen.dats_tss_frequency import *


class InlineHelper(InlineHelper):
    pass
