from __future__ import unicode_literals
from gen.dats_series_tss_meta import *


class InlineHelper(InlineHelper):
    pass
