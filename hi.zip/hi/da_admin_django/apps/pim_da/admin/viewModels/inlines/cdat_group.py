from __future__ import unicode_literals
from gen.cdat_group import *


class InlineHelper(InlineHelper):
    from cdat_measure import CdatMeasureAdminTabularInlineViewModel

    def get_inlines(self):
        return [
            InlineHelper.CdatMeasureAdminTabularInlineViewModel,
        ]
