from __future__ import unicode_literals
from gen.dats_series import *


class InlineHelper(InlineHelper):
    pass
