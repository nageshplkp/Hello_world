from __future__ import unicode_literals
from gen.dats_tss_type import *


class InlineHelper(InlineHelper):
    pass
