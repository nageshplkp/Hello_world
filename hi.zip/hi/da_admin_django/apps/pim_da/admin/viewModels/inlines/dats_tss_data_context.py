from __future__ import unicode_literals
from gen.dats_tss_data_context import *


class InlineHelper(InlineHelper):
    pass
