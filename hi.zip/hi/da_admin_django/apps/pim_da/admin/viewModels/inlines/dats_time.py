from __future__ import unicode_literals
from gen.dats_time import *


class InlineHelper(InlineHelper):
    pass
