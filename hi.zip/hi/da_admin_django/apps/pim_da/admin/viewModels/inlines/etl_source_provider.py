from __future__ import unicode_literals
from gen.etl_source_provider import *


class InlineHelper(InlineHelper):
    pass
