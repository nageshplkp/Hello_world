from __future__ import unicode_literals
from gen.dats_tss_is_default_series import *


class InlineHelper(InlineHelper):
    pass
