# ======================================================================
# This is the application wide configuration for the AdminViewModels
# ======================================================================
from __future__ import unicode_literals
from core.django.admin import *


class AdminViewModelBase(AdminViewModelBase):
    # enable_inlines = True
    # enable_delete = True
    pass


class AdminTabularInlineViewModelBase(AdminTabularInlineViewModelBase):
    pass


class AdminClientSideFormViewModelBase(AdminClientSideFormViewModelBase):
    pass
