
database = {
    'conn_variable': 'ORAFND_DBP',
    'engine': 'Oracle'
}
