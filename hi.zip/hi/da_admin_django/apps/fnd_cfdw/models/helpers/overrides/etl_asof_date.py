from __future__ import unicode_literals
from django.db import models as md


class ModelFieldHelper():
    def asof_date_key(self):
        if self.foreign_fields.__contains__('asof_date_key'):
            self.foreign_fields.remove('asof_date_key')
        return md.IntegerField(verbose_name=u'Asof Date Key', db_column='ASOF_DATE_KEY', db_index=True, help_text='', editable=True)
