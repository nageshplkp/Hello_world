from __future__ import unicode_literals

class EtlSourceAdminViewModel(object):
    enable_inlines = True
