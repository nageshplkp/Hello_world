from __future__ import unicode_literals


class EtlSourceProviderAdminViewModel(object):
    enable_inlines = True

    search_fields = ['source_provider_code', 'source_provider_name', 'source_provider_descr', 'pimco_contact_email', 'provider_contact_email', 'provider_contact_phone']
