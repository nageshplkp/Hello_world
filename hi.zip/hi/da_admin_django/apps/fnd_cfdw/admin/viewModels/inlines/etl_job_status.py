from __future__ import unicode_literals
from gen.etl_job_status import *


class InlineHelper(InlineHelper):
    pass
