from __future__ import unicode_literals
from gen.etl_run_stats_monitor import *


class InlineHelper(InlineHelper):
    pass
