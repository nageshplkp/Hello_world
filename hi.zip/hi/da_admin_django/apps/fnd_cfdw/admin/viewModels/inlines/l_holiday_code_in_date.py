from __future__ import unicode_literals
from gen.l_holiday_code_in_date import *


class InlineHelper(InlineHelper):
    pass
