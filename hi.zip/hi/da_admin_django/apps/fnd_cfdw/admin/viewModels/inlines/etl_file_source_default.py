from __future__ import unicode_literals
from gen.etl_file_source_default import *


class InlineHelper(InlineHelper):
    pass
