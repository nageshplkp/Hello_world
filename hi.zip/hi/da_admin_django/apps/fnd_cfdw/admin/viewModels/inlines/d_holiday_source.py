from __future__ import unicode_literals
from gen.d_holiday_source import *


class InlineHelper(InlineHelper):
    pass
