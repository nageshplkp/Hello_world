from __future__ import unicode_literals
from gen.etl_haver_src_in_instrmnt import *


class InlineHelper(InlineHelper):
    pass
