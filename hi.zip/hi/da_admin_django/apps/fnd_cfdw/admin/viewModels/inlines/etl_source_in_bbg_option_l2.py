from __future__ import unicode_literals
from gen.etl_source_in_bbg_option_l2 import *


class InlineHelper(InlineHelper):
    pass
