from __future__ import unicode_literals
from gen.etl_bbg_yellow_key import *


class InlineHelper(InlineHelper):
    pass
