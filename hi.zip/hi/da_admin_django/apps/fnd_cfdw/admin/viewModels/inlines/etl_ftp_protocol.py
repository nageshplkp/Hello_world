from __future__ import unicode_literals
from gen.etl_ftp_protocol import *


class InlineHelper(InlineHelper):
    pass
