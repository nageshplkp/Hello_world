from __future__ import unicode_literals
from gen.etl_source_provider import *


class InlineHelper(InlineHelper):
    from etl_source import EtlSourceAdminTabularInlineViewModel

    def get_inlines(self):
        return [
            InlineHelper.EtlSourceAdminTabularInlineViewModel,
        ]
