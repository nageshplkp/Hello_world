from __future__ import unicode_literals
from gen.etl_bbg_program import *


class InlineHelper(InlineHelper):
    pass
