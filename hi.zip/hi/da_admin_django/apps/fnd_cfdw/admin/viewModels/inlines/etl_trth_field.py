from __future__ import unicode_literals
from gen.etl_trth_field import *


class InlineHelper(InlineHelper):
    pass
