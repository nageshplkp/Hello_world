# coding=utf-8

from __future__ import unicode_literals
from datetime import datetime

from ..app_config import AppConfig
from model_base import *
from helpers.upload_zip import ModelFieldHelper


class UploadZip(ModelBase):

    file = ModelFieldHelper().file()
    response = ModelFieldHelper().response()
    status = ModelFieldHelper().status()

    # help_texts = {'field_name': 'Help text for field'}
    # verbose_names = {'field_name': 'Displayed name for field'}

    def get_unicode(self):
        return unicode('')

    def log_insert(self, by):
        self.log_update(by)

    def log_update(self, by):
        pass

    class Meta:
        abstract = False
        app_label = AppConfig.name
        managed = False
        # permissions = ()
        verbose_name = 'Upload ZIP File'
        verbose_name_plural = 'Upload ZIP File'
