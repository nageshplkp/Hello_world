# coding=utf-8

from __future__ import unicode_literals
from core.django.models import *
from core.helpers import OverridableBase


class ModelFieldHelper(OverridableBase):
    editable_fields = ['file', 'status', 'response']
    foreign_fields = []
    indexed_fields = []
    list_display_fields = []
    readonly_fields = ['status', 'response']

    def file(self):
        return FileField(verbose_name=u'File', help_text='', editable=True)

    def response(self):
        return TextField(verbose_name=u'Response', blank=True, help_text='', editable=True)

    def status(self):
        return TextField(verbose_name=u'Status', blank=True, help_text='', editable=True)
