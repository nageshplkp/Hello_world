# coding=utf-8

from __future__ import unicode_literals
from core.django.models import *
from core.helpers import OverridableBase


class ModelFieldHelper(OverridableBase):
    editable_fields = ['deal_name', 'status', 'response']
    foreign_fields = []
    indexed_fields = []
    list_display_fields = []
    readonly_fields = ['status', 'response']

    def deal_name(self):
        return CharField(verbose_name=u'Deal Name', max_length=200, help_text='', editable=True)

    def response(self):
        return TextField(verbose_name=u'Response', blank=True, help_text='', editable=True)

    def status(self):
        return TextField(verbose_name=u'Status', blank=True, help_text='', editable=True)
