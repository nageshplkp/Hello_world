# coding=utf-8

from __future__ import unicode_literals
from datetime import date
from core.django.models import *
from core.helpers import OverridableBase


class ModelFieldHelper(OverridableBase):
    editable_fields = ['file', ('month', 'year'), 'status', 'response']
    foreign_fields = []
    indexed_fields = []
    list_display_fields = []
    readonly_fields = ['status', 'response']

    __months = (
        ('01', 'January'),
        ('02', 'February'),
        ('03', 'March'),
        ('04', 'April'),
        ('05', 'May'),
        ('06', 'June'),
        ('07', 'July'),
        ('08', 'August'),
        ('09', 'September'),
        ('10', 'October'),
        ('11', 'November'),
        ('12', 'December'),
    )

    __years = ((o, o) for o in range(date.today().year, 1970, -1))

    def file(self):
        return FileField(verbose_name=u'File', help_text='', editable=True)

    def month(self):
        return IntegerField(verbose_name=u'Month', choices=ModelFieldHelper.__months, help_text='', editable=True)

    def response(self):
        return TextField(verbose_name=u'Response', blank=True, help_text='', editable=True)

    def status(self):
        return TextField(verbose_name=u'Status', blank=True, help_text='', editable=True)

    def year(self):
        return IntegerField(verbose_name=u'Year', choices=ModelFieldHelper.__years, help_text='', editable=True)
