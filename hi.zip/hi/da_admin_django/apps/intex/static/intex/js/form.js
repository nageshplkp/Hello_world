var Intex;
(function (Intex) {
    var Form = /** @class */ (function (_super) {
        __extends(Form, _super);
        function Form(el) {
            var _this = _super.call(this, el) || this;
            _this.actionGetDeal = function (inputValues, errors) {
                var form = _this.form;
                var dealName = _this.dealName;
                if (dealName === '') {
                    alert('Unable to get deal name.');
                }
                else {
                    $.ajax(_this.buildAjaxPostSettings(Form.serviceBaseUrl + '/deal/' + dealName, {}));
                    return true;
                }
                return false;
            };
            _this.actionGetPrePrice = function (inputValues, errors) {
                var form = _this.form;
                var dealName = _this.dealName;
                var password = _this.password;
                if (dealName === '') {
                    alert('Unable to get deal name.');
                }
                else if (password === '') {
                    alert('Unable to get password.');
                }
                else {
                    $.ajax(_this.buildAjaxPostSettings(Form.serviceBaseUrl + '/deal/' + dealName, { 'password': password }));
                    return true;
                }
                return false;
            };
            _this.actionUpload = function (expectedExtension) {
                var form = _this.form;
                var files = _this.files;
                if (files.length <= 0) {
                    alert('Unable to get files.');
                }
                else {
                    var formData = _this.toFormData(files[0], expectedExtension);
                    if (formData === null) {
                        return false;
                    }
                    $.ajax(_this.buildAjaxPostSettings(Form.serviceBaseUrl + '/upload/', formData));
                    return true;
                }
                return false;
            };
            _this.actionUploadCdu = function (inputValues, errors) {
                var form = _this.form;
                var files = _this.files;
                var month = _this.month;
                var year = _this.year;
                if (files.length <= 0) {
                    alert('Unable to get files.');
                }
                else if (month === '') {
                    alert('Unable to get month.');
                }
                else if (year === '') {
                    alert('Unable to get year.');
                }
                else {
                    var formData = _this.toFormData(files[0], 'cdu');
                    if (formData === null) {
                        return false;
                    }
                    $.ajax(_this.buildAjaxPostSettings(Form.serviceBaseUrl + '/upload/' + year + '/' + month, formData));
                    return true;
                }
                return false;
            };
            _this.printHttpResponse = function (data) {
                var html = Prism.highlight(JSON.stringify(data, null, 4), Prism.languages.json);
                _this.httpResponseControl.html('<pre><code class="language-json">' + html + '</code></pre>');
                _this.printHttpResponseStatus(data.status, data.body.message);
            };
            _this.printHttpResponseStatus = function (status, message) {
                var html = Prism.highlight(JSON.stringify({ status: status, message: message }, null, 4), Prism.languages.json);
                _this.httpResponseStatusControl.html('<pre><code class="language-json">' + html + '</code></pre>');
            };
            _this.submitButton = $(el);
            var form = _this.submitButton.closest('form');
            _this.form = form;
            _this.httpResponseControl = form.find('div.field-response div.controls span.readonly').html('');
            _this.httpResponseStatusControl = form.find('div.field-status div.controls span.readonly').html('');
            var action = form.attr('id').toLowerCase().split('_')[0];
            switch (action) {
                case 'getdeal':
                    _this.action = _this.actionGetDeal;
                    break;
                case 'getpreprice':
                    _this.action = _this.actionGetPrePrice;
                    break;
                case 'uploadcdi':
                    _this.action = function (inputValues, errors) { return _this.actionUpload('cdi'); };
                    break;
                case 'uploadcdu':
                    _this.action = _this.actionUploadCdu;
                    break;
                case 'uploadzip':
                    _this.action = function (inputValues, errors) { return _this.actionUpload('zip'); };
                    break;
            }
            return _this;
        }
        Form.prototype.setAjaxSettingsCallback = function (settings) {
            var _this = this;
            settings.success = function (data, status, xhr) { return _this.printHttpResponse(data); };
            settings.error = function (xhr, status, errorThrown) { return xhr.responseJSON ?
                _this.printHttpResponse(xhr.responseJSON) :
                _this.printHttpResponseStatus(status, errorThrown); };
            settings.complete = function () { return _this.toggleFormDisable(false); };
        };
        Form.prototype.submit = function () {
            this.httpResponseControl.html('');
            this.httpResponseStatusControl.html('');
            _super.prototype.submit.call(this);
        };
        Object.defineProperty(Form.prototype, "dealName", {
            get: function () {
                return this.form.find('div.controls input#id_deal_name').val();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Form.prototype, "files", {
            get: function () {
                return this.form.find('div.controls input#id_file').prop('files');
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Form.prototype, "month", {
            get: function () {
                return this.form.find('div.controls input#id_month').val();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Form.prototype, "password", {
            get: function () {
                return this.form.find('div.controls input#id_password').val();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Form.prototype, "year", {
            get: function () {
                return this.form.find('div.controls input#id_year').val();
            },
            enumerable: true,
            configurable: true
        });
        Form.serviceBaseUrlDefault = 'http://ptp-dev';
        Form.servicePath = '/workshop/service/da/intex';
        Form.serviceBaseUrl = null;
        return Form;
    }(Django.AdminForm));
    Intex.Form = Form;
})(Intex || (Intex = {}));
Intex.Form.serviceBaseUrl = (location.hostname.toLowerCase().startsWith('ptp-dev')
    ? location.origin : Intex.Form.serviceBaseUrlDefault)
    + Intex.Form.servicePath;
var intexForm = null;
function form_submit(el) {
    if (intexForm === null) {
        intexForm = new Intex.Form(el);
    }
    intexForm.submit();
}
