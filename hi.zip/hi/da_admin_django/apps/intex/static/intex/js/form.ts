module Django {
    export abstract class AdminForm {
        protected action: (inputValues: Object, errors: Array<string>) => boolean;
        protected actionName: string;
        protected form: any;
        protected inputs: Object;
        protected submitButton: any;

        constructor(el: Element) { }

        protected buildAjaxGetSettings = (url: string): any => { return null; };

        protected buildAjaxPostSettings = (url: string, data: {} | FormData): any => { return null; }

        protected abstract setAjaxSettingsCallback(settings: Object): void;

        protected toFormData = (file: File, expectedExtension: string): FormData => { return null; }

        protected toggleFormDisable = (disable: boolean): void => { }

        public submit(): void { }
    }
}

var $: any;
var jQuery: any;
var Prism: any;
interface InputInfo {
    id: string;
    label: string;
    isRequired: boolean;
    $: any;
}
interface ResponseData {
    status: string;
    message?: string|Array<string>;
    body?: any;
}
/* DELETE FROM HERE AND UP FROM THE GENERATED CODE */
/* =============================================== */

module Intex {
    export class Form extends Django.AdminForm {
        static serviceBaseUrlDefault: string = 'http://ptp-dev';
        static servicePath: string = '/workshop/service/da/intex';
        static serviceBaseUrl: string = null;

        private httpResponseControl;
        private httpResponseStatusControl;

        constructor(el: Element) {
            super(el);

            this.submitButton = $(el);
            var form = this.submitButton.closest('form');
            this.form = form;

            this.httpResponseControl = form.find('div.field-response div.controls span.readonly').html('');
            this.httpResponseStatusControl = form.find('div.field-status div.controls span.readonly').html('');

            var action: string = form.attr('id').toLowerCase().split('_')[0];
            switch (action) {
                case 'getdeal':
                    this.action = this.actionGetDeal;
                    break;
                case 'getpreprice':
                    this.action = this.actionGetPrePrice;
                    break;
                case 'uploadcdi':
                    this.action = (inputValues: Object, errors: Array<string>) => this.actionUpload('cdi');
                    break;
                case 'uploadcdu':
                    this.action = this.actionUploadCdu;
                    break;
                case 'uploadzip':
                    this.action = (inputValues: Object, errors: Array<string>) => this.actionUpload('zip');
                    break;
            }
        }

        private actionGetDeal = (inputValues: Object, errors: Array<string>): boolean => {
            var form = this.form;
            var dealName = this.dealName;

            if (dealName === '') {
                alert('Unable to get deal name.');
            } else {
                $.ajax(this.buildAjaxPostSettings(Form.serviceBaseUrl + '/deal/' + dealName, {}));
                return true;
            }

            return false;
        }

        private actionGetPrePrice = (inputValues: Object, errors: Array<string>): boolean => {
            var form = this.form;
            var dealName = this.dealName;
            var password = this.password;

            if (dealName === '') {
                alert('Unable to get deal name.');
            } else if (password === '') {
                alert('Unable to get password.');
            } else {
                $.ajax(this.buildAjaxPostSettings(Form.serviceBaseUrl + '/deal/' + dealName, {'password': password}));
                return true;
            }

            return false;
        }

        private actionUpload = (expectedExtension: string): boolean => {
            var form = this.form;
            var files = this.files;

            if (files.length <= 0) {
                alert('Unable to get files.');
            } else {
                var formData = this.toFormData(files[0], expectedExtension);
                if (formData === null) { return false; }

                $.ajax(this.buildAjaxPostSettings(Form.serviceBaseUrl + '/upload/', formData));
                return true;
            }

            return false;
        }

        private actionUploadCdu = (inputValues: Object, errors: Array<string>): boolean => {
            var form = this.form;
            var files = this.files;
            var month = this.month;
            var year = this.year;

            if (files.length <= 0) {
                alert('Unable to get files.');
            } else if (month === '') {
                alert('Unable to get month.');
            } else if (year === '') {
                alert('Unable to get year.');
            } else {
                var formData = this.toFormData(files[0], 'cdu');
                if (formData === null) { return false; }

                $.ajax(this.buildAjaxPostSettings(Form.serviceBaseUrl + '/upload/' + year + '/' + month, formData));
                return true;
            }

            return false;
        }

        private printHttpResponse = (data: ResponseData): void => {
            var html = Prism.highlight(JSON.stringify(data, null, 4), Prism.languages.json);
            this.httpResponseControl.html('<pre><code class="language-json">' + html + '</code></pre>')

            this.printHttpResponseStatus(data.status, data.body.message);
        }

        private printHttpResponseStatus = (status: string, message: any): void => {
            var html = Prism.highlight(JSON.stringify({ status: status, message: message }, null, 4), Prism.languages.json);
            this.httpResponseStatusControl.html('<pre><code class="language-json">' + html + '</code></pre>')
        }

        protected setAjaxSettingsCallback(settings: any): void {
            settings.success = (data, status, xhr) => this.printHttpResponse(data);
            settings.error = (xhr, status, errorThrown) => xhr.responseJSON ?
                this.printHttpResponse(xhr.responseJSON) :
                this.printHttpResponseStatus(status, errorThrown);
            settings.complete = () => this.toggleFormDisable(false);

        }

        public submit(): void {
            this.httpResponseControl.html('');
            this.httpResponseStatusControl.html('');
            super.submit();
        }

        private get dealName(): string {
            return this.form.find('div.controls input#id_deal_name').val();
        }

        private get files(): File[] {
            return this.form.find('div.controls input#id_file').prop('files');
        }

        private get month(): string {
            return this.form.find('div.controls input#id_month').val();
        }

        private get password(): string {
            return this.form.find('div.controls input#id_password').val();
        }

        private get year(): string {
            return this.form.find('div.controls input#id_year').val();
        }
    }
}
Intex.Form.serviceBaseUrl = (location.hostname.toLowerCase().startsWith('ptp-dev')
    ? location.origin : Intex.Form.serviceBaseUrlDefault)
    + Intex.Form.servicePath;

var intexForm: Intex.Form = null;

function form_submit(el: Element): void {
    if (intexForm === null) {
        intexForm = new Intex.Form(el);
    }

    intexForm.submit();
}
