# coding=utf-8

from __future__ import unicode_literals
from django.contrib import admin

from admin_view_model_base import AdminClientSideFormViewModelBase
from ...models.get_deal import GetDeal as Model
from ...models.helpers.get_deal import ModelFieldHelper


class GetDealAdminViewModel(AdminClientSideFormViewModelBase):
    fields = None
    fieldsets = (
        (None, {
            'fields': [o for o in ModelFieldHelper.editable_fields if o not in ModelFieldHelper.readonly_fields]
        }),
        ('Status', {
            # 'classes': ('collapse',),
            'fields': ModelFieldHelper.readonly_fields
        }),
    )
    readonly_fields = ModelFieldHelper.readonly_fields


admin.site.register(Model, GetDealAdminViewModel)
