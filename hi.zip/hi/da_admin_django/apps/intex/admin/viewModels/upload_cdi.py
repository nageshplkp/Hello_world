# coding=utf-8

from __future__ import unicode_literals
from django.contrib import admin

from admin_view_model_base import AdminClientSideFormViewModelBase
from ...models.upload_cdi import UploadCdi as Model
from ...models.helpers.upload_cdi import ModelFieldHelper


class UploadCdiAdminViewModel(AdminClientSideFormViewModelBase):
    fields = None
    fieldsets = (
        (None, {
            'fields': [o for o in ModelFieldHelper.editable_fields if o not in ModelFieldHelper.readonly_fields]
        }),
        ('Status', {
            # 'classes': ('collapse',),
            'fields': ModelFieldHelper.readonly_fields
        }),
    )
    readonly_fields = ModelFieldHelper.readonly_fields


admin.site.register(Model, UploadCdiAdminViewModel)
