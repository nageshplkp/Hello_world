# coding=utf-8

from __future__ import unicode_literals
from django.contrib import admin

from admin_view_model_base import AdminClientSideFormViewModelBase
from ...models.request_status import RequestStatus as Model
from ...models.helpers.request_status import ModelFieldHelper


class RequestStatusAdminViewModel(AdminClientSideFormViewModelBase):
    fields = None
    fieldsets = (
        (None, {
            'fields': ModelFieldHelper.editable_fields
        }),
        ('Status', {
            # 'classes': ('collapse',),
            'fields': ModelFieldHelper.readonly_fields
        }),
    )
    readonly_fields = ModelFieldHelper.readonly_fields


admin.site.register(Model, RequestStatusAdminViewModel)
