from __future__ import unicode_literals
from datetime import datetime
from core.django.admin.admin_view_model_base import *
from etl.enum.pim_da.gen.bt_status import BtStatusEnum


class BtRequestAdminViewModel():
    list_display = ['bt_request_id', 'bbg_program_code', 'bbg_interface_code', 'bt_requestor_code', 'bt_status_code',
                    'request_date', 'status_date', 'time_pending', 'retry_count', 'requestor_login']
    list_display_links = ()
    list_filter = (('bt_status_code__bt_status_code', filters.MultiSelectFieldListFilter),)
    ordering = ('-status_date',)

    def time_pending(self, obj):
        rpt_time = datetime.now()

        diff = rpt_time - obj.status_date
        return '{}:{}:{}'.format(
            (diff.days * 24 + diff.seconds // 3600),
            ((diff.seconds % 3600) // 60),
            (diff.seconds % 60))

    time_pending.short_description = 'Time Pending'

    def has_add_permission(self, request):
        return False
