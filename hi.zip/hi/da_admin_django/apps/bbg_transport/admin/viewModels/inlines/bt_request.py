from __future__ import unicode_literals
from gen.bt_request import *


class InlineHelper(InlineHelper):
    pass
