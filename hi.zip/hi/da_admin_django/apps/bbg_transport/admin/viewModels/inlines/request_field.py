
from __future__ import unicode_literals
from core.helpers import OverridableBase
from ..admin_view_model_base import AdminTabularInlineViewModelBase
from ....models.request_field import RequestField as Model
from ....models.helpers.request_field import ModelFieldHelper


modelFieldHelper = ModelFieldHelper()


class RequestFieldAdminTabularInlineViewModel(AdminTabularInlineViewModelBase):
    model = Model
    fields = modelFieldHelper.editable_fields
    raw_id_fields = modelFieldHelper.foreign_fields
    readonly_fields = modelFieldHelper.readonly_fields
