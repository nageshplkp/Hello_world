# coding=utf-8

from __future__ import unicode_literals
from django.contrib import admin

from admin_view_model_base import AdminClientSideFormViewModelBase
from ...models.error_report import ErrorReport as Model
from ...models.helpers.error_report import ModelFieldHelper


class ErrorReportAdminViewModel(AdminClientSideFormViewModelBase):
    fields = None
    fieldsets = (
        (None, {
            'fields': ModelFieldHelper.editable_fields
        }),
        ('Status', {
            # 'classes': ('collapse',),
            'fields': ModelFieldHelper.readonly_fields
        }),
    )
    readonly_fields = ModelFieldHelper.readonly_fields


admin.site.register(Model, ErrorReportAdminViewModel)
