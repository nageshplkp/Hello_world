# coding=utf-8

from __future__ import unicode_literals
from django.contrib import admin

from admin_view_model_base import AdminClientSideFormViewModelBase
from ...models.request import Request as Model
from ...models.helpers.request import ModelFieldHelper
from inlines.request_data_item import RequestDataItemAdminTabularInlineViewModel
from inlines.request_field import RequestFieldAdminTabularInlineViewModel
from inlines.request_option import RequestOptionAdminTabularInlineViewModel


class RequestAdminViewModel(AdminClientSideFormViewModelBase):
    fields = None
    fieldsets = (
        (None, {
            'fields': ModelFieldHelper.editable_fields
        }),
        ('Status', {
            # 'classes': ('collapse',),
            'fields': ModelFieldHelper.readonly_fields
        }),
    )
    readonly_fields = ModelFieldHelper.readonly_fields
    inlines = [
        RequestDataItemAdminTabularInlineViewModel,
        RequestFieldAdminTabularInlineViewModel,
        RequestOptionAdminTabularInlineViewModel
    ]


admin.site.register(Model, RequestAdminViewModel)
