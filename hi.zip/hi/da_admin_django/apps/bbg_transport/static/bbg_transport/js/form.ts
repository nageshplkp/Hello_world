module Django {
    export abstract class AdminForm {
        protected action: (inputValues: Object, errors: Array<string>) => boolean;
        protected actionName: string;
        protected form: any;
        protected inputs: Object;
        protected submitButton: any;

        constructor(el: Element) { }

        protected buildAjaxGetSettings = (url: string): any => { return null; };

        protected buildAjaxPostSettings = (url: string, data: {} | FormData): any => { return null; }

        protected abstract setAjaxSettingsCallback(settings: Object): void;

        protected toFormData = (file: File, expectedExtension: string): FormData => { return null; }

        protected toggleFormDisable = (disable: boolean): void => { }

        public submit(): void { }
    }
}

var $: any;
var jQuery: any;
var Prism: any;
interface InputInfo {
    id: string;
    label: string;
    isRequired: boolean;
    $: any;
}
interface ResponseData {
    status: string;
    message?: string|Array<string>;
    body?: any;
}
/* DELETE FROM HERE AND UP FROM THE GENERATED CODE */
/* =============================================== */

module BbgTransport {
    export class Form extends Django.AdminForm {
        static serviceBaseUrlDefault: string = 'http://ptp-dev';
        static servicePath: string = '/workshop/service/da/bbg_transport';
        static serviceBaseUrl: string = null;

        private httpResponseControl;
        private httpResponseStatusControl;

        constructor(el: Element) {
            super(el);

            var form = this.form;
            this.httpResponseControl = form.find('div.field-http_response div.controls span.readonly').html('');
            this.httpResponseStatusControl = form.find('div.field-http_response_status div.controls span.readonly').html('');

            switch (this.actionName) {
                case 'errorreport':
                    this.action = this.actionErrorReport;
                    break;
                case 'requeststatus':
                    this.action = this.actionRequestStatus;
                    break;
            }
        }

        private actionErrorReport = (inputValues: Object, errors: Array<string>): boolean => {
            if (errors.length > 0) {
                this.printHttpResponseStatus('Validation Error', errors)
                return false;
            }

            var fromDate = new Date(inputValues['from_date']);
            var fromM = '' + (fromDate.getMonth() + 1);
            var fromD = '' + fromDate.getDate();

            var toDate = new Date(inputValues['to_date'] + ' 00:00:00');
            var toM = '' + (toDate.getMonth() + 1);
            var toD = '' + toDate.getDate();

            var url = [
                Form.serviceBaseUrl,
                '/report_error/',
                fromDate.getFullYear(),
                (fromM.length < 2 ? '0' : '') + fromM,
                (fromD.length < 2 ? '0' : '') + fromD,
                '/',
                toDate.getFullYear(),
                (toM.length < 2 ? '0' : '') + toM,
                (toD.length < 2 ? '0' : '') + toD
            ].join('');

            window.open(url, '_blank');
            this.toggleFormDisable(false)
            return true;
        }

        private actionRequestStatus = (inputValues: Object, errors: Array<string>): boolean => {
            if (errors.length > 0) {
                this.printHttpResponseStatus('Validation Error', errors)
                return false;
            }

            var action = inputValues['action'];
            switch (action) {
                case 'check_status':
                case 'response':
                    break;
                default:
                    return false;
            }

            var requestId = inputValues['request_id'];
            $.ajax(this.buildAjaxGetSettings(Form.serviceBaseUrl + '/' + action + '/' + requestId));
            return true;
        }

        private printHttpResponse = (data: ResponseData): void => {
            var html = Prism.highlight(JSON.stringify(data, null, 4), Prism.languages.json);
            this.httpResponseControl.html('<pre><code class="language-json">' + html + '</code></pre>')

            this.printHttpResponseStatus(data.status, data.body.message);
        }

        private printHttpResponseStatus = (status: string, message: any): void => {
            var html = Prism.highlight(JSON.stringify({ status: status, message: message }, null, 4), Prism.languages.json);
            this.httpResponseStatusControl.html('<pre><code class="language-json">' + html + '</code></pre>')
        }

        protected setAjaxSettingsCallback(settings: any): void {
            settings.success = (data, status, xhr) => this.printHttpResponse(data);
            settings.error = (xhr, status, errorThrown) => xhr.responseJSON ?
                this.printHttpResponse(xhr.responseJSON) :
                this.printHttpResponseStatus(status, errorThrown);
            settings.complete = () => this.toggleFormDisable(false);

        }

        public submit(): void {
            this.httpResponseControl.html('');
            this.httpResponseStatusControl.html('');
            super.submit();
        }
    }
}
BbgTransport.Form.serviceBaseUrl = (location.hostname.toLowerCase().startsWith('ptp-dev')
    ? location.origin : BbgTransport.Form.serviceBaseUrlDefault)
    + BbgTransport.Form.servicePath;

var bbgTransportForm: BbgTransport.Form = null;

function form_submit(el: Element): void {
    if (bbgTransportForm === null) {
        bbgTransportForm = new BbgTransport.Form(el);
    }

    bbgTransportForm.submit();
}
