var BbgTransport;
(function (BbgTransport) {
    var Form = /** @class */ (function (_super) {
        __extends(Form, _super);
        function Form(el) {
            var _this = _super.call(this, el) || this;
            _this.actionErrorReport = function (inputValues, errors) {
                if (errors.length > 0) {
                    _this.printHttpResponseStatus('Validation Error', errors);
                    return false;
                }
                var fromDate = new Date(inputValues['from_date']);
                var fromM = '' + (fromDate.getMonth() + 1);
                var fromD = '' + fromDate.getDate();
                var toDate = new Date(inputValues['to_date'] + ' 00:00:00');
                var toM = '' + (toDate.getMonth() + 1);
                var toD = '' + toDate.getDate();
                var url = [
                    Form.serviceBaseUrl,
                    '/report_error/',
                    fromDate.getFullYear(),
                    (fromM.length < 2 ? '0' : '') + fromM,
                    (fromD.length < 2 ? '0' : '') + fromD,
                    '/',
                    toDate.getFullYear(),
                    (toM.length < 2 ? '0' : '') + toM,
                    (toD.length < 2 ? '0' : '') + toD
                ].join('');
                window.open(url, '_blank');
                _this.toggleFormDisable(false);
                return true;
            };
            _this.actionRequestStatus = function (inputValues, errors) {
                if (errors.length > 0) {
                    _this.printHttpResponseStatus('Validation Error', errors);
                    return false;
                }
                var action = inputValues['action'];
                switch (action) {
                    case 'check_status':
                    case 'response':
                        break;
                    default:
                        return false;
                }
                var requestId = inputValues['request_id'];
                $.ajax(_this.buildAjaxGetSettings(Form.serviceBaseUrl + '/' + action + '/' + requestId));
                return true;
            };
            _this.printHttpResponse = function (data) {
                var html = Prism.highlight(JSON.stringify(data, null, 4), Prism.languages.json);
                _this.httpResponseControl.html('<pre><code class="language-json">' + html + '</code></pre>');
                _this.printHttpResponseStatus(data.status, data.body.message);
            };
            _this.printHttpResponseStatus = function (status, message) {
                var html = Prism.highlight(JSON.stringify({ status: status, message: message }, null, 4), Prism.languages.json);
                _this.httpResponseStatusControl.html('<pre><code class="language-json">' + html + '</code></pre>');
            };
            var form = _this.form;
            _this.httpResponseControl = form.find('div.field-http_response div.controls span.readonly').html('');
            _this.httpResponseStatusControl = form.find('div.field-http_response_status div.controls span.readonly').html('');
            switch (_this.actionName) {
                case 'errorreport':
                    _this.action = _this.actionErrorReport;
                    break;
                case 'requeststatus':
                    _this.action = _this.actionRequestStatus;
                    break;
            }
            return _this;
        }
        Form.prototype.setAjaxSettingsCallback = function (settings) {
            var _this = this;
            settings.success = function (data, status, xhr) { return _this.printHttpResponse(data); };
            settings.error = function (xhr, status, errorThrown) { return xhr.responseJSON ?
                _this.printHttpResponse(xhr.responseJSON) :
                _this.printHttpResponseStatus(status, errorThrown); };
            settings.complete = function () { return _this.toggleFormDisable(false); };
        };
        Form.prototype.submit = function () {
            this.httpResponseControl.html('');
            this.httpResponseStatusControl.html('');
            _super.prototype.submit.call(this);
        };
        Form.serviceBaseUrlDefault = 'http://ptp-dev';
        Form.servicePath = '/workshop/service/da/bbg_transport';
        Form.serviceBaseUrl = null;
        return Form;
    }(Django.AdminForm));
    BbgTransport.Form = Form;
})(BbgTransport || (BbgTransport = {}));
BbgTransport.Form.serviceBaseUrl = (location.hostname.toLowerCase().startsWith('ptp-dev')
    ? location.origin : BbgTransport.Form.serviceBaseUrlDefault)
    + BbgTransport.Form.servicePath;
var bbgTransportForm = null;
function form_submit(el) {
    if (bbgTransportForm === null) {
        bbgTransportForm = new BbgTransport.Form(el);
    }
    bbgTransportForm.submit();
}
