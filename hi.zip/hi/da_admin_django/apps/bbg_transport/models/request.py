# coding=utf-8

from __future__ import unicode_literals

from ..app_config import AppConfig
from model_base import *
from helpers.request import ModelFieldHelper


modelFieldHelper = ModelFieldHelper()


class Request(ModelBase):
    request_id = modelFieldHelper.request_id()
    # callback_uri = modelFieldHelper.callback_uri()
    interface_code = modelFieldHelper.interface_code()
    program_code = modelFieldHelper.program_code()
    request_description = modelFieldHelper.request_description()
    requestor_code = modelFieldHelper.requestor_code()
    response_format_code = modelFieldHelper.response_format_code()

    response = modelFieldHelper.response()
    status = modelFieldHelper.status()

    # help_texts = {'field_name': 'Help text for field'}
    # verbose_names = {'field_name': 'Displayed name for field'}

    def get_unicode(self):
        return u''

    def log_insert(self, by):
        self.log_update(by)

    def log_update(self, by):
        pass

    class Meta:
        abstract = False
        app_label = AppConfig.name
        managed = False
        # permissions = ()
        verbose_name = modelFieldHelper.verbose_name()
        verbose_name_plural = modelFieldHelper.verbose_name_plural()
