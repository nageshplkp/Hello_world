# coding=utf-8

from __future__ import unicode_literals

from ..app_config import AppConfig
from model_base import *
from helpers.request_status import ModelFieldHelper


modelFieldHelper = ModelFieldHelper()


class RequestStatus(ModelBase):
    action = modelFieldHelper.action()
    http_response = modelFieldHelper.http_response()
    http_response_status = modelFieldHelper.http_response_status()
    request_id = modelFieldHelper.request_id()

    # help_texts = {'field_name': 'Help text for field'}
    # verbose_names = {'field_name': 'Displayed name for field'}

    def get_unicode(self):
        return u''

    def log_insert(self, by):
        self.log_update(by)

    def log_update(self, by):
        pass

    class Meta:
        abstract = False
        app_label = AppConfig.name
        managed = False
        # permissions = ()
        verbose_name = modelFieldHelper.verbose_name
        verbose_name_plural = modelFieldHelper.verbose_name_plural
