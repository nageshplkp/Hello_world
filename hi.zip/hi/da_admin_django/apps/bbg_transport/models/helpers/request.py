# coding=utf-8

from __future__ import unicode_literals
from core.django.models import *
from core.helpers import OverridableBase

class ModelFieldHelper(OverridableBase):
    # editable_fields = ['request_description', 'requestor_code', 'program_code', 'interface_code', 'response_format_code', 'callback_uri']
    editable_fields = ['request_description', 'requestor_code', 'program_code', 'interface_code', 'response_format_code']
    foreign_fields = []
    indexed_fields = []
    list_display_fields = []
    readonly_fields = ['status', 'response']

    # interface_code_choices = (
    #     ('DL', 'DL'),
    # )
    #
    # program_code_choices = (
    #     ('GETDATA', 'GETDATA'),
    #     ('GETHISTORY', 'GETHISTORY'),
    # )
    #
    # response_format_code_choices = (
    #     ('HORIZONTAL', 'HORIZONTAL'),
    #     ('VERTICAL', 'VERTICAL'),
    # )

    def verbose_name(self):
        return 'Request'

    def verbose_name_plural(self):
        return self.verbose_name()

    def request_id(self):
        return AutoField(verbose_name=u'Request Id', primary_key=True, help_text='', editable=False)

    # def callback_uri(self):
    #     return CharField(verbose_name=u'Callback Uri', null=True, blank=True, max_length=2000, help_text='', editable=True)

    def interface_code(self):
        # return CharField(verbose_name=u'Interface Code', max_length=10, choices=self.interface_code_choices, help_text='', editable=True)
        if not self.foreign_fields.__contains__('bbg_interface_code'):
            self.foreign_fields.append('bbg_interface_code')
        return ForeignKey(verbose_name=u'Interface Code', to='BbgInterface', to_field='bbg_interface_code', related_name='%(app_label)s_Request_bbg_interface_code', on_delete=PROTECT, limit_choices_to={}, max_length=10, help_text='', editable=True)

    def program_code(self):
        # return CharField(verbose_name=u'Program Code', max_length=20, choices=self.program_code_choices, help_text='', editable=True)
        if not self.foreign_fields.__contains__('bbg_program_code'):
            self.foreign_fields.append('bbg_program_code')
        return ForeignKey(verbose_name=u'Program Code', to='BbgProgram', to_field='bbg_program_code', related_name='%(app_label)s_Request_bbg_program_code', on_delete=PROTECT, limit_choices_to={}, max_length=20, help_text='', editable=True)

    def request_description(self):
        return CharField(verbose_name=u'Request Description', max_length=250, help_text='', editable=True)

    def requestor_code(self):
        return CharField(verbose_name=u'Requestor Code', max_length=50, help_text='', editable=True)

    def response_format_code(self):
        # return CharField(verbose_name=u'Response Format Code', max_length=20, choices=self.response_format_code_choices, help_text='', editable=True)
        if not self.foreign_fields.__contains__('response_format_code'):
            self.foreign_fields.append('response_format_code')
        return ForeignKey(verbose_name=u'Response Format Code', to='BtFormat', to_field='bt_format_code', related_name='%(app_label)s_Request_response_format_code', on_delete=PROTECT, limit_choices_to={}, max_length=20, help_text='', editable=True)

    def response(self):
        return TextField(verbose_name=u'Response', blank=True, help_text='', editable=True)

    def status(self):
        return TextField(verbose_name=u'Status', blank=True, help_text='', editable=True)
