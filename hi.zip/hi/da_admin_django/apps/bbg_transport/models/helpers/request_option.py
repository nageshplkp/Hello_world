# coding=utf-8

from __future__ import unicode_literals
from core.django.models import *
from core.helpers import OverridableBase


class ModelFieldHelper(OverridableBase):
    editable_fields = ['option_name', 'option_value']
    foreign_fields = []
    indexed_fields = []
    list_display_fields = []
    readonly_fields = []

    def verbose_name(self):
        return 'Request Option'

    def verbose_name_plural(self):
        return self.verbose_name()

    def request_id(self):
        if not self.foreign_fields.__contains__('request_id'):
            self.foreign_fields.append('request_id')
        return ForeignKey(verbose_name=u'Request Id', to='Request', to_field='request_id', related_name='%(app_label)s_RequestOption_request_id', on_delete=PROTECT, limit_choices_to={}, db_index=True, max_length=20, help_text='', editable=True)

    def option_name(self):
        return CharField(verbose_name=u'Option Name', max_length=100, help_text='', editable=True)

    def option_value(self):
        return CharField(verbose_name=u'Option Value', max_length=100, help_text='', editable=True)
