# coding=utf-8

from __future__ import unicode_literals
from core.django.models import *
from core.helpers import OverridableBase


class ModelFieldHelper(OverridableBase):
    editable_fields = ['request_id', 'action']
    foreign_fields = []
    indexed_fields = []
    list_display_fields = []
    readonly_fields = ['http_response_status', 'http_response']
    verbose_name = 'Request Status'
    verbose_name_plural = 'Request Status'

    action_choices = (
        ('check_status', 'STATUS'),
        ('response', 'RESPONSE'),
    )

    def action(self):
        return CharField(verbose_name=u'Action', max_length=10, choices=self.action_choices, help_text='', editable=True)

    def http_response(self):
        return TextField(verbose_name=u'Response', blank=True, help_text='', editable=True)

    def http_response_status(self):
        return TextField(verbose_name=u'Status', blank=True, help_text='', editable=True)

    def request_id(self):
        return IntegerField(verbose_name=u'Request Id', help_text='', editable=True)
