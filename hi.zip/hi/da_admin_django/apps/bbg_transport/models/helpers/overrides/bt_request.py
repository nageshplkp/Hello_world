from __future__ import unicode_literals
from core.django.models import *


class ModelFieldHelper():

    def bbg_program_code(self):
        if self.foreign_fields.__contains__('bbg_program_code'):
            self.foreign_fields.remove('bbg_program_code')
        return CharField(verbose_name=u'Bbg Program Code', db_column='BBG_PROGRAM_CODE', max_length=20, help_text='', editable=True)

    def bbg_interface_code(self):
        if self.foreign_fields.__contains__('bbg_interface_code'):
            self.foreign_fields.remove('bbg_interface_code')
        return CharField(verbose_name=u'Bbg Interface Code', db_column='BBG_INTERFACE_CODE', max_length=10, help_text='', editable=True)

    def bt_requestor_code(self):
        if self.foreign_fields.__contains__('bt_requestor_code'):
            self.foreign_fields.remove('bt_requestor_code')
        return CharField(verbose_name=u'Bt Requestor Code', db_column='BT_REQUESTOR_CODE', max_length=50, help_text='', editable=True)

    def response_format_code(self):
        if self.foreign_fields.__contains__('response_format_code'):
            self.foreign_fields.remove('response_format_code')
        return CharField(verbose_name=u'Response Format Code', db_column='RESPONSE_FORMAT_CODE', max_length=20, help_text='', editable=True)

    def lookback_bt_request_id(self):
        if self.foreign_fields.__contains__('lookback_bt_request_id'):
            self.foreign_fields.remove('lookback_bt_request_id')
        return IntegerField(verbose_name=u'Lookback Bt Request Id', db_column='LOOKBACK_BT_REQUEST_ID', db_index=True, null=True, blank=True, help_text='', editable=True)
