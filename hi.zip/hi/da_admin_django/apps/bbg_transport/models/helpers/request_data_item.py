# coding=utf-8

from __future__ import unicode_literals
from core.django.models import *
from core.helpers import OverridableBase


class ModelFieldHelper(OverridableBase):
    editable_fields = ['yellow_key', 'ticker', 'bbg_query', 'isin', 'cusip', 'bb_id', 'tag']
    foreign_fields = []
    indexed_fields = []
    list_display_fields = []
    readonly_fields = []

    def verbose_name(self):
        return 'Request Data Item'

    def verbose_name_plural(self):
        return self.verbose_name()

    def request_id(self):
        if not self.foreign_fields.__contains__('request_id'):
            self.foreign_fields.append('request_id')
        return ForeignKey(verbose_name=u'Request Id', to='Request', to_field='request_id', related_name='%(app_label)s_RequestDataItem_request_id', on_delete=PROTECT, limit_choices_to={}, db_index=True, max_length=20, help_text='', editable=True)

    def bb_id(self):
        return CharField(verbose_name=u'BBG ID', null=True, blank=True, max_length=100, help_text='Bloomberg ID', editable=True)

    def bbg_query(self):
        return CharField(verbose_name=u'BBG Query', null=True, blank=True, max_length=100, help_text='Custom BBG '
                                                                                                   'Security Indentification query (Macro, Index, etc)', editable=True)
    def cusip(self):
        return CharField(verbose_name=u'Cusip', null=True, blank=True, max_length=20, help_text='', editable=True)

    def isin(self):
        return CharField(verbose_name=u'Cusip', null=True, blank=True, max_length=20, help_text='', editable=True)

    def tag(self):
        return CharField(verbose_name=u'Tag', null=True, blank=True, max_length=1000, help_text='Requestor defined comments', editable=True)

    def ticker(self):
        return CharField(verbose_name=u'Ticker', null=True, blank=True, max_length=100, help_text='BBG Ticker (Requires Yellow Key)', editable=True)

    def yellow_key(self):
        return CharField(verbose_name=u'BBG Yellow Key', null=True, blank=True, max_length=100, help_text='', editable=True)
