# coding=utf-8

from __future__ import unicode_literals
from core.django.models import *
from core.helpers import OverridableBase


class ModelFieldHelper(OverridableBase):
    editable_fields = ['from_date', 'to_date']
    foreign_fields = []
    indexed_fields = []
    list_display_fields = []
    readonly_fields = ['http_response_status', 'http_response']
    verbose_name = 'Error Report'
    verbose_name_plural = 'Error Report'

    def from_date(self):
        return DateField(verbose_name=u'From Date', help_text='', editable=True)

    def http_response(self):
        return TextField(verbose_name=u'Response', blank=True, help_text='', editable=True)

    def http_response_status(self):
        return TextField(verbose_name=u'Status', blank=True, help_text='', editable=True)

    def to_date(self):
        return DateField(verbose_name=u'To Date', help_text='', editable=True)
