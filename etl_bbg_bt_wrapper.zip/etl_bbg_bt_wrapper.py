#!/usr/bin/env python
import os
import shutil
import sys
import logging
import copy
import pandas
import csv
import re
import json

from stdnum import isin, cusip
from stdnum.gb import sedol

from promise import Promise

from ff_dais.common.utils import decorator
from etl.bbg_transport.dto import RequestDataItem, RequestItem, RequestOptionItem
from etl.core.util import uri_post, uri_get, sanitize_cmd_line

from datetime import datetime
from dateutil.parser import parse
from etl.core import util
from etl.core import da_config
from etl.core.timed import timed
from etl.core.db import ora_xxx
from etl.repo import OraFndRepo
from etl.repo import OraPimRepo
from etl.repo.fnd_cfdw import *
from etl.repo.pim_da import *

__app__ = sys.modules['__main__']


def excluded(d, keys):
    return {key: val for key, val in d.items() if key not in keys}


class BbgTransportClient(object):

    # region private methods
    def __init__(self, logger=None, ctx=None, config=None):

        self.log = logger or logging.getLogger("ff_dais.{}".format(
            os.path.splitext(os.path.basename(__file__))[0]))

        try:

            self.start_time = datetime.now()
            self.end_time = None

            self.ctx = ctx if ctx is not None else dict()
            self.config = dict()
            self.config.update(config or dict())

            # Try command line argument first --audit-id
            self.etl_audit_id = self.ctx.get('etl_audit_id')

            self.bt_error_status = ['BBGERROR', 'BTERROR']
            self.bt_complete_status = ['BBGERROR', 'BTERROR', 'SUCCESS']
            cfg_section = self.config.get('dais_bbg_trasnport')
            self.base_url = cfg_section.get('base_url')
            self.requestor_code = self.config.get('requestor_code')
            self.vertical = self.config.get('vertical')
            self.timeout = int(cfg_section.get('timeout', 1800))
            self.interval = int(cfg_section.get('interval', 60))

            self.use_local_data = os.environ.get('USE_LOCAL_DATA', 0)
            self.use_local_data = bool(int(self.use_local_data))
            self.ctx['use_local_data'] = self.use_local_data

            self.use_bt_output_file = ctx.get('use_bt_output_file', False)

        except Exception as e:
            self.log.critical(
                "Unable to initialize %s: %s", self.__class__.__name__, e)
            raise

    def __enter__(self):
        # make a database connection and return it
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources
        # try:
        #     if self.connection is not None:
        #         self.connection.release()
        # finally:
        #     self.connection = None

        # Release resources
        if self.config is not None:
            self.config = None

        if self.ctx is not None:
            self.ctx = None

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("%s completed at %s",
                      self.__class__.__name__, self.end_time)
        self.log = None
    # endregion

    # region internal methods

    @staticmethod
    def aggregate_errors(body):
        errors = '\n'.join(
            [i.get('error_text') for i in body.get('response_file_info')
             if bool(i.get('is_error_response')) is True])
        error_type = ' Transport' if body.get('request_status') == ' BTERROR' else ''
        return error_type, errors

    @decorator.timeout
    def wait_for_response(self, url, **kw):

        self.log.info('requesting url: %s, with params:%s ', url, kw)
        response = uri_get(url)
        self.log.info('response: %s', response)

        if response and isinstance(response, dict):
            request_status = response['request_status']
        else:
            request_status = response
            raise Exception(
                "Service call:HTTP GET - {} failed with status: {}".format(
                    url, request_status))

        if request_status in self.bt_complete_status:
            if request_status != 'SUCCESS':
                raise Exception(
                    "Service call:HTTP GET - {} failed with status:{}".format(
                        url, request_status))
            else:
                return response

        return None

    @staticmethod
    def transform_weight_data(data):

        data['SECURITY'] = data.pop('INDX_MWEIGHT_TKR_EXCH1')
        data.pop('INDX_MWEIGHT')

        return data

    def get_local_data(
            self, headers, fields, items,
            description='Get data', program_code='GETDATA',
            interface_code='DL', response_format='HORIZONTAL',
            source_code=None, req_type=None, contains_tag=False, level=1):

        if not self.use_local_data:
            return self.get_data(
                headers=headers, fields=fields, items=items,
                description=description, program_code=program_code,
                interface_code=interface_code, response_format=response_format)

        cfg_section = self.config.get('dais_bbg_sec', {})
        archive_dir = cfg_section['archive_dir_{}'.format(os.name)]

        file_name = "{}.{}.{}.{}{}.json".format(
            source_code, response_format, req_type, level,
            '.TAG' if contains_tag else ''
        )

        full_path = os.path.join(archive_dir, file_name)

        with open(full_path, 'r') as fs:
            lines = fs.readlines()
            data_string = ''.join(lines)
            response = json.loads(data_string)
            return response

    @timed()
    def get_data(
            self, headers, fields, items,
            description='Get data', program_code='GETDATA',
            interface_code='DL', response_format='HORIZONTAL'):

        data_items = map(lambda i: RequestDataItem(
            bbg_query=i.get('bbg_query'), tag=i.get('tag')), items)

        request_options = map(
            lambda key: RequestOptionItem(
                option_name=key, option_value=headers[key]), headers.keys())

        request = RequestItem(request_description=description,
                              requestor_code=self.requestor_code,
                              program_code=program_code,
                              interface_code=interface_code,
                              response_format_code=response_format,
                              request_data_items=data_items,
                              request_options=request_options,
                              request_fields=fields
                              )

        payload = request.to_json()

        url = "{}{}".format(self.base_url, 'request_data')
        self.log.info('POST: %s, \r\n\t%s', url, payload)
        response = uri_post(url, payload)
        self.log.info('response: %s \r\nresponse:\t%s', url, response)

        if response is None:
            raise Exception("Response is empty")
        elif response and isinstance(response, dict):
            request_status = response['request_status']
        else:
            request_status = response
            raise Exception(
                "Service call:HTTP GET - {} failed with status: {}".format(
                    url, request_status))

        if request_status in self.bt_complete_status:
            if request_status != 'SUCCESS':
                raise Exception(
                    "Service call:HTTP GET - {} failed!".format(url))

        if request_status in self.bt_error_status:
            error_type, errors = self.aggregate_errors(response)
            raise Exception(
                "Bloomberg{} Returned an Error: {}".format(
                    error_type, errors))

        status_uri = response['progression_url']
        response = self.wait_for_response(
            status_uri, interval=self.interval, timeout=self.timeout)

        if not response:
            raise Exception("Timed out while checking for status")
        else:
            status = response['request_status']

            if status in self.bt_error_status:
                msg = "Service call:HTTP GET - {} failed!\r\n".format(url)
                msg = "{}With Response: {}".format(msg, response)
                raise Exception(msg)

            if self.use_bt_output_file:
                return response

            status_uri = response['progression_url']
            response = self.wait_for_response(
                status_uri, interval=self.interval, timeout=self.timeout)

            if not response:
                raise Exception("Timed out while checking for status")

            # data = response['data']

        return response
    # endregion


class BbgEtlFlowBase(object):

    ticker_rex = re.compile(
        r'^(([a-z]{2,4}):(?![a-z/\d]+\.))?([a-z/\d]{1,4}|\d{1,3}(?=\.)|\d{4,})'
        r'((?:\.|\s)([a-z]{2}))?$', re.I)

    def get_id_type(self, identifier):

        def try_get_cusip_with_checksum(input_id):
            try:
                cusip_check_digit = cusip.calc_check_digit(input_id)
                cusip_identifier = "{}{}".format(input_id, cusip_check_digit)
                return "Cusip" if cusip.is_valid(cusip_identifier) else ""
            except ValueError:
                logging.warn("Invalid cusip: %s", input_id)
                return ""

        def try_get_sedol_with_checksum(input_id):
            try:
                sedol_check_digit = sedol.calc_check_digit(input_id)
                sedol_identifier = "{}{}".format(input_id, sedol_check_digit)
                return "Sedol" if sedol.is_valid(sedol_identifier) else ""
            except ValueError:
                logging.warn("Invalid sedol: %s", input_id)
                return ""

        length = len(identifier)
        if length == 12 and isin.is_valid(identifier):
            return "Isin"
        elif length == 9 and cusip.is_valid(identifier):
            return "Cusip"
        elif length == 8 and try_get_cusip_with_checksum(identifier):
            check_digit = cusip.calc_check_digit(identifier)
            full_identifier = "{}{}".format(identifier, check_digit)
            return "Cusip" if cusip.is_valid(full_identifier) else "Unknown"
        elif length == 7 and sedol.is_valid(identifier):
            return "Sedol"
        elif length == 6 and try_get_sedol_with_checksum(identifier):
            check_digit = sedol.calc_check_digit(identifier)
            full_identifier = "{}{}".format(identifier, check_digit)
            return "Sedol" if sedol.is_valid(full_identifier) else "Unknown"
        else:
            m = self.ticker_rex.search(str(identifier))
            if m and m.groups():
                return "Ticker"
        return "Unknown"

    @timed()
    def combine(self, *values):
        data = dict()
        for v in values:
            data.update(**v)

        return data

    @staticmethod
    def header_dict_from_bbg_source(src):
        hdr = dict()
        hdr['COMPRESS'] = src.compress_code
        hdr['FIRMNAME'] = src.firm_code
        hdr['PROGRAMFLAG'] = src.program_flag
        hdr['PROGRAMNAME'] = src.bbg_program_code
        hdr['USERNUMBER'] = src.user_number
        return hdr

    @staticmethod
    def header_dict_from_bbg_options(opts):
        hdr = dict()
        for opt in (opts or []):
            hdr[opt.bbg_option_code] = opt.option_value
        return hdr

    @timed()
    def build_headers(self, source, options):
        src_headers = self.header_dict_from_bbg_source(source)
        opt_headers = self.header_dict_from_bbg_options(options)
        headers = dict()
        headers.update(src_headers)
        headers.update(opt_headers)
        return headers


class BbgEtlSourceLevel1MetadataFlow(BbgEtlFlowBase):

    # region private methods
    def __init__(self, logger=None, ctx=None, config=None):

        self.log = logger or logging.getLogger("ff_dais.{}".format(
            os.path.splitext(os.path.basename(__file__))[0]))

        try:

            self.start_time = datetime.now()
            self.end_time = None

            self.ctx = ctx if ctx is not None else dict()
            self.config = dict(config or dict())

            # Try command line argument first --audit-id
            self.etl_audit_id = self.ctx.get('etl_audit_id')

        except Exception as e:
            self.log.critical(
                "Unable to initialize %s: %s", self.__class__.__name__, e)
            raise

    def __enter__(self):
        # make a database connection and return it
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources
        # try:
        #     if self.connection is not None:
        #         self.connection.release()
        # finally:
        #     self.connection = None

        # Release resources
        if self.config is not None:
            self.config = None

        if self.ctx is not None:
            self.ctx = None

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("%s completed at %s",
                      self.__class__.__name__, self.end_time)
        self.log = None
    # endregion

    # region internal methods
    @Promise.promisify
    @timed()
    def read_etl_source(self, **ctx):

        source_code = ctx.get('source_code', None)
        self.log.info("querying etl_source with source_code: %s", source_code)
        db = ctx.get('ora_fnd_db', OraFndRepo().db)
        etl_source_repo = EtlSourceRepo(db)
        etl_src = etl_source_repo.get_by_source_code(source_code)

        if etl_src is None:
            raise ValueError("Unable to find EtlSource record"
                             " with source_code: {}".format(source_code))

        ctx['etl_source'] = etl_src
        return ctx

    @Promise.promisify
    @timed()
    def read_etl_bbg_source(self, **ctx):

        source_code = ctx.get('source_code', None)
        self.log.info("querying etl_source with source_code: %s", source_code)
        db = ctx.get('ora_fnd_db', OraFndRepo().db)
        repo = EtlBbgSourceRepo(db)
        etl_bbg_src = repo.get_by_source_code(source_code)

        if etl_bbg_src is None:
            raise ValueError("Unable to find EtlBbgSource record"
                             " with source_code: {}".format(source_code))

        ctx['etl_bbg_source'] = etl_bbg_src
        return ctx

    @Promise.promisify
    @timed()
    def read_etl_source_in_instruments_l1(self, **ctx):

        source_code = ctx.get('source_code', None)
        self.log.info(
            "querying etl_source_in_bbg_instruments for source_code: %s",
            source_code)

        db = ctx.get('ora_fnd_db', OraFndRepo().db)
        repo = EtlSourceinBbgInstrmntRepo(db)
        instruments = repo.list_by_source_code_ordered(source_code)
        self.log.info(
            "found: %i etl_source_in_bbg_instruments for source_code: %s",
            len(instruments), source_code)

        ctx['etl_source_in_instruments_l1'] = instruments

        tags = map(lambda i: i.requestor_tag, instruments)
        contains_tag = any(tags)
        ctx['contains_tag'] = contains_tag

        return ctx

    @Promise.promisify
    @timed()
    def read_etl_source_in_mnemonics_l1(self, **ctx):

        source_code = ctx.get('source_code', None)
        self.log.info(
            "querying etl_source_in_bbg_mnemonics_l1 for source_code: %s",
            source_code)
        db = ctx.get('ora_fnd_db', OraFndRepo().db)
        repo = EtlSourceinBbgMnemonicRepo(db)
        mnemonics = repo.list_by_source_code_ordered(source_code)
        self.log.info(
            "found: %i etl_source_in_bbg_mnemonics_l1 for source_code: %s ",
            len(mnemonics), source_code)
        ctx['etl_source_in_bbg_mnemonics_l1'] = mnemonics
        return ctx

    @Promise.promisify
    @timed()
    def read_bbg_mnemonics_l1(self, **ctx):

        source_code = ctx.get('source_code', None)
        self.log.info(
            "querying bbg_mnemonics_l1 for source_code: %s", source_code)
        db = ctx.get('ora_fnd_db', OraFndRepo().db)
        repo = EtlBbgMnemonicRepo(db)
        mnemonics = repo.list_by_source_code_l1_ordered(source_code)
        self.log.info("found: %i bbg_mnemonics_l1 for source_code: %s",
                      len(mnemonics), source_code)
        ctx['bbg_mnemonics_l1'] = mnemonics
        return ctx

    @Promise.promisify
    @timed()
    def read_etl_source_in_options_l1(self, **ctx):

        source_code = ctx.get('source_code', None)
        self.log.info(
            "querying etl_source_in_options_l1 for source_code:%s", source_code)
        db = ctx.get('ora_fnd_db', OraFndRepo().db)
        repo = EtlSourceinBbgOptionRepo(db)
        options = repo.list_by_source_code(source_code)
        self.log.info("found:%i etl_source_in_options_l1(s) for source_code: %s",
                      len(options), source_code)

        ctx['etl_source_in_options_l1'] = options
        return ctx

    @timed()
    def read_bulk_format_mnemonic(self, **ctx):

        source_code = ctx.get('source_code', None)
        self.log.info(
            "querying bbg_mnemonic_in_bulk_format for source_code: %s",
            source_code)

        bbg_mnemonics_l1 = ctx.get('bbg_mnemonics_l1', [])
        mnemonics = [
            m.bbg_mnemonic_code for m in bbg_mnemonics_l1 if m.is_bulk_format]

        if len(mnemonics):
            db = ctx.get('ora_pim_db', OraPimRepo().db)
            repo = BbgMnemonicinBulkFormatRepo(db)
            bulk_mnemonics = repo.list_by_bulk_format_mnemonics(mnemonics)
            self.log.info(
                "found:%i etl_source_in_options_l2(s) for source_code: %s",
                len(bulk_mnemonics), source_code)

            ctx['bulk_format_mnemonics'] = bulk_mnemonics

        return ctx

    @timed()
    def is_bulk_workflow(self, **ctx):

        source_code = ctx.get('source_code', None)
        bbg_mnemonics_l1 = ctx.get('bbg_mnemonics_l1', [])
        bm = [m.bbg_mnemonic_code for m in bbg_mnemonics_l1 if m.is_bulk_format]

        if len(bm) > 1:
            msg = "Cannot handle multiple bulk mnemonics"
            ":{}, for source:{}".format(bm, source_code)
            raise Exception(msg)

        ctx['is_bulk_workflow'] = len(bm) == 1

        return ctx

    # endregion

    # region public methods
    @timed()
    def run(self, **ctx):

        # noinspection PyProtectedMember
        self.log.debug("%s::%s: %s",
                       self.__class__.__name__,
                       sys._getframe().f_code.co_name, ctx)

        source_code = ctx.get('source_code', None)

        if not source_code:
            raise ValueError("EtlSource.source_code is required, "
                             "param: source_code ")
        ctx['ora_fnd_db'] = OraFndRepo().db

        results = Promise.all([
            self.read_etl_source(**ctx),
            self.read_etl_bbg_source(**ctx),
            self.read_etl_source_in_instruments_l1(**ctx),
            self.read_etl_source_in_mnemonics_l1(**ctx),
            self.read_bbg_mnemonics_l1(**ctx),
            self.read_etl_source_in_options_l1(**ctx),
        ]).then(
            lambda res: self.combine(*res)
        ).then(
            lambda res: self.read_bulk_format_mnemonic(**res)
        ).then(
            lambda res: self.is_bulk_workflow(**res)
        ).get()

        self.log.info(
            "{}: {} completed successfully".format(
                self.__class__.__name__, self.etl_audit_id
            )
        )

        return results
    # endregion


# noinspection PyProtectedMember
class BbgEtlSourceLevel1Flow(BbgTransportClient, BbgEtlFlowBase):

    # region internal methods

    @timed()
    def retrieve_level1_data(self, **ctx):

        etl_bbg_src = ctx.get('etl_bbg_source')
        instruments = ctx.get('etl_source_in_instruments_l1')
        options = ctx.get('etl_source_in_options_l1')
        mnemonics = ctx.get('etl_source_in_bbg_mnemonics_l1')

        fields = map(lambda m: m.bbg_mnemonic_code, mnemonics)
        items = map(lambda i: dict(
            bbg_query=i.bbq_query, tag=i.requestor_tag), instruments)

        headers = self.build_headers(etl_bbg_src, options)
        use_bt_output_file = ctx.get('use_bt_output_file', False)

        response = self.get_data(
            headers=headers, fields=fields, items=items,
            response_format='VERTICAL' if self.vertical else 'HORIZONTAL'
        )

        # contains_tag = ctx.get('contains_tag')
        # response = self.get_local_data(
        #     headers=headers, fields=fields, items=items,
        #     response_format='VERTICAL' if self.vertical else 'HORIZONTAL',
        #     source_code=etl_bbg_src.source_code, req_type='SECURITY',
        #     level=1, contains_tag=contains_tag
        # )

        if use_bt_output_file:
            l1_data = response
        else:
            l1_data = response['data']

            response_file_info = response.get('response_file_info')
            run_dates = map(
                lambda rfi: parse(rfi.get('bbg_time_finished')),
                response_file_info)
            run_date = max(run_dates)

            times_started = map(
                lambda rfi: parse(rfi.get('bbg_time_started')),
                response_file_info)
            time_started = min(times_started)

            ctx['run_date'] = run_date
            ctx['time_started'] = time_started

        ctx['l1_headers'] = headers
        ctx['l1_data'] = l1_data
        return ctx

    @timed()
    def retrieve_sec_type(self, **ctx):

        is_bulk_workflow = ctx.get('is_bulk_workflow', False)
        etl_bbg_src = ctx.get('etl_bbg_source')
        use_bt_output_file = ctx.get('use_bt_output_file', False)
        # skip steps for retrieving additional bulk data
        if not is_bulk_workflow or use_bt_output_file:
            return ctx

        instruments = ctx.get('etl_source_in_instruments_l1')

        items = map(lambda i: dict(bbg_query=i.bbq_query),  instruments)

        fields = ['SECURITY_TYP', 'SECURITY_TYP2']
        headers = self.header_dict_from_bbg_source(etl_bbg_src)

        response = self.get_data(
            headers=headers, fields=fields, items=items
        )

        # body = get_variable_data_sec_type_UKX()
        index_type = list(response['data'])

        sec_type_rows = []
        for row in index_type:
            if int(row.get('ROW_STATUS', -1)) == 0:
                row['SECURITY_TYP'] = str(row["SECURITY_TYP"]).replace(
                    ' ' + str(row["SECURITY_TYP2"]), '').strip()
                sec_type_rows.append(row)

        sec_type = sec_type_rows[0].get('SECURITY_TYP', '')
        sec_type = (' ' + sec_type).rstrip(' ')

        ctx['l1_sec_type'] = sec_type

        return ctx

    @timed()
    def retrieve_asof_date(self, **ctx):

        is_bulk_workflow = ctx.get('is_bulk_workflow', False)
        etl_bbg_src = ctx.get('etl_bbg_source')
        use_bt_output_file = ctx.get('use_bt_output_file', False)
        # skip steps for retrieving additional bulk data
        if not is_bulk_workflow or use_bt_output_file:
            return ctx

        instruments = ctx.get('etl_source_in_instruments_l1')

        items = map(lambda item: dict(bbg_query=item.bbq_query),  instruments)
        fields = ['PX_CLOSE_DT']
        headers = self.header_dict_from_bbg_source(etl_bbg_src)

        response = self.get_data(
            headers=headers, fields=fields, items=items
        )

        # response = get_data_dump_asof_date(
        #     source_code = etl_bbg_src.source_code, headers=headers,
        #     fields=fields, items=items
        # )
        
        asof_date_data = list(response['data'])

        asof_date = asof_date_data[0].get('PX_CLOSE_DT')
        ctx['l1_asof_date'] = asof_date

        return ctx

    @staticmethod
    def extract_sec_column_name_if_bulk(**ctx):

        is_bulk_workflow = ctx.get('is_bulk_workflow', False)
        use_bt_output_file = ctx.get('use_bt_output_file', False)
        # skip steps for retrieving additional bulk data
        if not is_bulk_workflow or use_bt_output_file:
            ctx['sec_column_name'] = 'SECURITY'
            return ctx

        bulk_format_mnemonics = ctx.get('bulk_format_mnemonics')
        bulk_mnemonic = filter(
            lambda bm: bm.is_sec_id == 1, bulk_format_mnemonics)[0]
        sec_column_name = "{}{}".format(
            bulk_mnemonic.mnemonic, bulk_mnemonic.column_display_order)

        ctx['sec_column_name'] = sec_column_name

        return ctx

    @timed()
    def transform_if_bulk(self, **ctx):
        is_bulk_workflow = ctx.get('is_bulk_workflow', False)
        use_bt_output_file = ctx.get('use_bt_output_file', False)
        # skip steps for retrieving additional bulk data
        if not is_bulk_workflow or use_bt_output_file:
            return ctx

        bulk_format_mnemonics = ctx.get('bulk_format_mnemonics')
        bulk_format_mnemonic = bulk_format_mnemonics[0].bulk_format_mnemonic
        ctx = self.extract_sec_column_name_if_bulk(**ctx)
        sec_column_name = ctx.get('sec_column_name')

        l1_data = ctx['l1_data']
        l1_sec_type = ctx['l1_sec_type']
        asof_date = ctx['l1_asof_date']

        for data in l1_data:
            data['SECURITY'] = "{} {}".format(
                data[sec_column_name], l1_sec_type.strip())
            data[bulk_format_mnemonic + '_PX_CLOSE_DT'] = asof_date

        ctx['l1_data'] = l1_data
        return ctx
    # endregion

    # region public methods
    @timed()
    def run(self, **ctx):

        # noinspection PyProtectedMember
        self.log.debug(
            "%s::%s: %s", self.__class__.__name__,
            sys._getframe().f_code.co_name, ctx)

        results = Promise.all([
            self.retrieve_level1_data(**ctx),
            self.retrieve_sec_type(**ctx),
            self.retrieve_asof_date(**ctx),
        ]).then(
            lambda res: self.combine(*res)
        ).then(
            lambda res: self.transform_if_bulk(**res)
        ).get()

        self.log.info(
            "{}: {} completed successfully:".format(
                self.__class__.__name__, self.etl_audit_id
            )
        )

        return results
    # endregion


class BbgEtlSourceLevel2MetadataFlow(BbgEtlFlowBase):

    # region private methods
    def __init__(self, logger=None, ctx=None, config=None):

        self.log = logger or logging.getLogger("ff_dais.{}".format(
            os.path.splitext(os.path.basename(__file__))[0]))

        try:

            self.start_time = datetime.now()
            self.end_time = None

            self.ctx = ctx if ctx is not None else dict()
            self.config = dict(config or dict())

            # Try command line argument first --audit-id
            self.etl_audit_id = self.ctx.get('etl_audit_id')

        except Exception as e:
            self.log.critical(
                "Unable to initialize %s: %s", self.__class__.__name__, e)
            raise

    def __enter__(self):
        # make a database connection and return it
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources
        # try:
        #     if self.connection is not None:
        #         self.connection.release()
        # finally:
        #     self.connection = None

        # Release resources
        if self.config is not None:
            self.config = None

        if self.ctx is not None:
            self.ctx = None

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("%s completed at %s",
                      self.__class__.__name__, self.end_time)
        self.log = None
    # endregion

    # region internal methods
    @Promise.promisify
    @timed()
    def read_etl_source_in_mnemonics_l2(self, **ctx):

        source_code = ctx.get('source_code', None)
        self.log.info(
            "querying etl_source_in_bbg_mnemonics_l2 for source_code: %s",
            source_code)
        db = ctx.get('ora_fnd_db', OraFndRepo().db)
        repo = EtlSourceinBbgMnemonicL2Repo(db)
        mnemonics = repo.list_by_source_code_ordered(source_code)
        self.log.info(
            "found: %i etl_source_in_bbg_mnemonics_l2 for source_code: %s ",
            len(mnemonics), source_code)

        ctx['etl_source_in_bbg_mnemonics_l2'] = mnemonics
        return ctx

    @Promise.promisify
    @timed()
    def read_bbg_mnemonics_l2(self, **ctx):

        source_code = ctx.get('source_code', None)
        self.log.info(
            "querying bbg_mnemonics_l2 for source_code: %s", source_code)
        db = ctx.get('ora_fnd_db', OraFndRepo().db)
        repo = EtlBbgMnemonicRepo(db)
        mnemonics = repo.list_by_source_code_l2_ordered(source_code)
        self.log.info("found: %i bbg_mnemonics_l2 for source_code: %s",
                      len(mnemonics), source_code)
        ctx['bbg_mnemonics_l2'] = mnemonics
        return ctx

    @Promise.promisify
    @timed()
    def read_etl_source_in_options_l2(self, **ctx):

        source_code = ctx.get('source_code', None)
        self.log.info(
            "querying etl_source_in_options_l2 for source_code:%s", source_code)
        db = ctx.get('ora_fnd_db', OraFndRepo().db)
        repo = EtlSourceinBbgOptionL2Repo(db)
        options = repo.list_by_source_code(source_code)
        self.log.info("found:%i etl_source_in_options_l2(s) for source_code: %s",
                      len(options), source_code)

        ctx['etl_source_in_options_l2'] = options
        return ctx

    @timed()
    def validate(self, **ctx):
        source_code = ctx.get('source_code', None)
        etl_source_in_mnemonics_l2 = ctx.get('etl_source_in_bbg_mnemonics_l2', [])
        bulk_mnemonics_l2 = ctx.get('bulk_format_mnemonics_l2', [])

        bulk_mnemonics = [
            m.bbg_mnemonic_code for m in bulk_mnemonics_l2 if m.is_bulk_format]

        if len(bulk_mnemonics) > 0:
            msg = "Cannot handle bulk mnemonics in level2"
            ":{}, for source:{}".format(bulk_mnemonics, source_code)
            raise Exception(msg)

        ctx['has_level2'] = len(etl_source_in_mnemonics_l2) > 0

        return ctx
    # endregion

    # region public methods
    @timed()
    def run(self, **ctx):

        # noinspection PyProtectedMember
        self.log.debug("%s::%s: %s",
                       self.__class__.__name__,
                       sys._getframe().f_code.co_name, ctx)

        source_code = ctx.get('source_code', None)

        if not source_code:
            raise ValueError("EtlSource.source_code is required, "
                             "param: source_code ")
        ctx['ora_fnd_db'] = OraFndRepo().db

        results = Promise.all([
            self.read_etl_source_in_mnemonics_l2(**ctx),
            self.read_bbg_mnemonics_l2(**ctx),
            self.read_etl_source_in_options_l2(**ctx)
        ]).then(
            lambda res: self.combine(*res)
        ).then(
            lambda res: self.validate(**res)
        ).get()

        self.log.info(
            "{}: {} completed successfully".format(
                self.__class__.__name__, self.etl_audit_id
            )
        )

        return results
    # endregion


class BbgEtlSourceLevel2Flow(BbgTransportClient, BbgEtlFlowBase):

    # region internal methods
    @timed()
    def retrieve_level2_data(self, **ctx):

        has_level2 = ctx.get('has_level2', False)
        use_bt_output_file = ctx.get('use_bt_output_file', False)

        # Skip this step if level2 is not configured
        if not has_level2:
            # noinspection PyProtectedMember
            self.log.debug("Skipping - %s::%s: %s",
                           self.__class__.__name__,
                           sys._getframe().f_code.co_name, ctx)
            return ctx

        if use_bt_output_file:
            raise AssertionError(
                "'use_bt_output_file' is not supported for 2 level sources"
                "Please remove --use_bt_output_file cmd line argument.")

        l1_sec_type = ctx.get('l1_sec_type')
        etl_bbg_src = ctx.get('etl_bbg_source')
        instruments = ctx.get('l1_data')
        options = ctx.get('etl_source_in_options_l2')
        mnemonics = ctx.get('etl_source_in_bbg_mnemonics_l2')

        fields = map(lambda m: m.bbg_mnemonic_code, mnemonics)

        sec_column_name = ctx.get('sec_column_name')

        if "Equity" in l1_sec_type:
            items = map(
                lambda i: dict(bbg_query="{}{} | {}".format(
                    i[sec_column_name],
                    l1_sec_type,
                    self.get_id_type(i[sec_column_name]))), instruments)
        else:
            items = map(
                lambda i: dict(bbg_query="{} | {}".format(
                    i[sec_column_name], self.get_id_type(i[sec_column_name]))
                ), instruments)

        headers = self.build_headers(etl_bbg_src, options)

        response = self.get_data(
            headers=headers, fields=fields, items=items
        )
        # body = get_variable_data_sec_UKX()
        l2_data = response['data']
        # l2_data = get_variable_data_sec_UKX()
        response_file_info = response.get('response_file_info')
        run_dates = map(
            lambda rfi: parse(rfi.get('bbg_time_finished')), response_file_info)
        run_date = max(run_dates)

        times_started = map(
            lambda rfi: parse(rfi.get('bbg_time_started')), response_file_info)
        time_started = min(times_started)

        ctx['run_date'] = run_date
        ctx['time_started'] = time_started

        ctx['l2_headers'] = headers
        ctx['l2_data'] = l2_data

        return ctx

    # endregion

    # region public methods
    @timed()
    def run(self, **ctx):

        # noinspection PyProtectedMember
        self.log.debug("%s::%s: %s",
                       self.__class__.__name__,
                       sys._getframe().f_code.co_name, ctx)

        source_code = ctx.get('source_code', None)

        if not source_code:
            raise ValueError("EtlSource.source_code is required, "
                             "param: source_code ")

        results = Promise.all([
            self.retrieve_level2_data(**ctx)
        ]).then(
            lambda res: self.combine(*res)
        ).get()

        self.log.info(
            "{}: {} completed successfully with results: {}".format(
                self.__class__.__name__, self.etl_audit_id, results
            )
        )

        return results
    # endregion


class BbgEtlSourceOutputFlow(BbgEtlFlowBase):

    # region private methods
    def __init__(self, logger=None, ctx=None, config=None):

        self.log = logger or logging.getLogger("ff_dais.{}".format(
            os.path.splitext(os.path.basename(__file__))[0]))

        try:

            self.start_time = datetime.now()
            self.end_time = None

            self.ctx = ctx if ctx is not None else dict()
            self.config = dict()
            self.config.update(config or dict())

            # Try command line argument first --audit-id
            self.etl_audit_id = self.ctx.get('etl_audit_id')

        except Exception as e:
            self.log.critical(
                "Unable to initialize %s: %s", self.__class__.__name__, e)
            raise

    def __enter__(self):
        # make a database connection and return it
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources
        # try:
        #     if self.connection is not None:
        #         self.connection.release()
        # finally:
        #     self.connection = None

        # Release resources
        if self.config is not None:
            self.config = None

        if self.ctx is not None:
            self.ctx = None

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("%s completed at %s",
                      self.__class__.__name__, self.end_time)
        self.log = None
    # endregion

    @staticmethod
    def merge_single_level_data(**ctx):

        etl_bbg_src = ctx.get('etl_bbg_source')
        mnemonics = ctx.get('etl_source_in_bbg_mnemonics_l1')
        data_items = ctx.get('l1_data')
        is_vertical = ctx.get('vertical')
        contains_tag = ctx.get('contains_tag')

        today = datetime.today()

        if is_vertical:
            additional_columns = []
            ordered_columns = ['SECURITY', 'ROW_STATUS',
                               'NUM_OF_FIELDS', 'MNEMONIC', 'VALUE']
            columns = additional_columns + ordered_columns
            columns = (['REQUESTOR_TAG'] if contains_tag else []) + columns
        else:
            for data in data_items:
                data['RETURN_STATUS'] = data.pop('ROW_STATUS')
                data['RUNDATE'] = ctx.get('run_date', today).strftime('%Y-%m-%d')
                data['TIMESTARTED'] = ctx.get('time_started', today).strftime('%Y-%m-%d %H:%M:%S')
                data['USERNUMBER'] = etl_bbg_src.user_number

            additional_columns = [
                'SECURITY', 'RETURN_STATUS', 'NUM_OF_FIELDS',
                'RUNDATE', 'TIMESTARTED', 'USERNUMBER']

            # this should already be ordered in db resultset
            ordered_columns = map(
                lambda m: m.override_column_name or m.bbg_mnemonic_code,
                sorted(mnemonics, key=lambda m: m.row_display_order))
            
            columns = additional_columns + ordered_columns
            columns = columns + ['REQUESTOR_TAG'] if contains_tag else columns

        data_frame = pandas.DataFrame(data_items)
        data_frame = data_frame.reindex(columns=columns)

        ctx['data_frame'] = data_frame

        return ctx

    @staticmethod
    def merge_single_level_bulk_data(**ctx):

        bulk_format_mnemonics = ctx.get('bulk_format_mnemonics')
        l1_data = ctx.get('l1_data')
        idx_data_frame = pandas.DataFrame(l1_data)
        bulk_mnemonic = bulk_format_mnemonics[0].bulk_format_mnemonic
        contains_tag = ctx.get('contains_tag')

        ordered_columns = map(
            lambda m: "{}{}".format(m.mnemonic, m.column_display_order),
            sorted(bulk_format_mnemonics, key=lambda m: m.column_display_order))

        columns = ['SECURITY', bulk_mnemonic] + ordered_columns + \
                  [bulk_mnemonic + '_PX_CLOSE_DT']

        columns = columns + ['REQUESTOR_TAG'] if contains_tag else columns

        data_frame = idx_data_frame.reindex(columns=columns)
        ctx['data_frame'] = data_frame

        return ctx

    @staticmethod
    def merge_dual_level_data(**ctx):

        merge_column = 'SECURITY'
        mnemonics = ctx.get('etl_source_in_bbg_mnemonics_l2')
        bulk_format_mnemonics = ctx.get('bulk_format_mnemonics')
        l1_data = ctx.get('l1_data')
        l2_data = ctx.get('l2_data')
        contains_tag = ctx.get('contains_tag')
        idx_data_frame = pandas.DataFrame(l1_data)
        bulk_mnemonic = bulk_format_mnemonics[0].bulk_format_mnemonic

        ordered_columns = map(
            lambda m: "{}{}".format(m.mnemonic, m.column_display_order),
            sorted(bulk_format_mnemonics, key=lambda m: m.column_display_order))

        columns = ['SECURITY', bulk_mnemonic] + ordered_columns + \
                  [bulk_mnemonic + '_PX_CLOSE_DT']

        columns = columns + ['REQUESTOR_TAG'] if contains_tag else columns
        idx_data_frame = idx_data_frame.reindex(columns=columns)

        for data in l2_data:
            data['RETURN_STATUS'] = data.pop('ROW_STATUS')

        sec_data_frame = pandas.DataFrame(l2_data)

        additional_columns = ['SECURITY', 'RETURN_STATUS']
        # this should already be ordered in db resultset
        ordered_columns = map(
            lambda m: m.override_column_name or m.bbg_mnemonic_code,
            sorted(mnemonics, key=lambda m: m.row_display_order))

        columns = additional_columns + ordered_columns
        sec_data_frame = sec_data_frame.reindex(columns=columns)

        data_frame = idx_data_frame.set_index(
            merge_column
        ).join(
            sec_data_frame.set_index(merge_column, drop=False), how='left'
        )

        ctx['data_frame'] = data_frame
        return ctx

    # region internal methods
    @timed()
    def prepare_data(self, **ctx):

        is_bulk_workflow = ctx.get('is_bulk_workflow', False)
        has_level2 = ctx.get('has_level2', False)
        use_bt_output_file = ctx.get('use_bt_output_file', False)

        if not use_bt_output_file:
            if not is_bulk_workflow and not has_level2:
                ctx = self.merge_single_level_data(**ctx)
            elif is_bulk_workflow and not has_level2:
                ctx = self.merge_single_level_bulk_data(**ctx)
            elif is_bulk_workflow and has_level2:
                ctx = self.merge_dual_level_data(**ctx)
            else:
                # [TODO] add details on invalid configuration
                raise Exception("Invalid configuration")

        return ctx

    @timed()
    def save_data(self, **ctx):

        etl_src = ctx.get('etl_source')
        data_frame = ctx.get('data_frame')
        csv_file = self.config.get('outfile')
        use_bt_output_file = ctx.get('use_bt_output_file', False)

        if not os.path.exists(etl_src.local_file_folder):
            os.makedirs(etl_src.local_file_folder)

        folder = etl_src.local_file_folder
        # output_path = os.path.normpath(os.path.join(folder, csv_file))
        output_path = os.path.join(folder, csv_file)

        d, f = os.path.split(output_path)

        if d and not os.path.exists(d):
            os.makedirs(d)

        ctx['output_path'] = output_path

        if os.path.exists(output_path):

            backup_path = os.path.join(
                d, '{}.{}'.format(datetime.now().strftime('%Y%m%dT%H%M%S'), f)
            )
            ctx['backup_path'] = backup_path
            os.rename(output_path, backup_path)

        if use_bt_output_file:
            response = ctx.get('l1_data')
            source_path = response.get('win_file_path') \
                if os.name == "nt" else response.get('win_file_path')
            shutil.copyfile(source_path, output_path)
        else:
            data_frame.to_csv(
                output_path, sep=',', header=True,
                quoting=csv.QUOTE_NONNUMERIC, index=False)

        self.log.info("saved to: %s", output_path)

        return ctx

    # endregion

    # region public methods
    @timed()
    def run(self, **ctx):

        # noinspection PyProtectedMember
        self.log.debug("%s::%s: %s",
                       self.__class__.__name__,
                       sys._getframe().f_code.co_name, ctx)

        source_code = ctx.get('source_code', None)

        if not source_code:
            raise ValueError("EtlSource.source_code is required, "
                             "param: source_code ")

        promise = Promise.resolve(ctx)
        results = promise.then(
            lambda res: self.prepare_data(**res)
        ).then(
            lambda res: self.save_data(**res)
        ).get()

        self.log.info("{}: {} completed successfully.".format(
            self.__class__.__name__, self.etl_audit_id))

        return results
    # endregion


class BbgDataFeedFlow(object):
    """
    """

    # region private methods
    def __init__(self, logger=None, options=None):

        self.log = logger or logging.getLogger("{}".format(
            os.path.splitext(os.path.basename(__file__))[0]))

        try:

            self.start_time = datetime.now()
            self.end_time = None

            self.options = copy.deepcopy(
                vars(options) if options is not None else dict())
            self.default_config = da_config.get_etl_cfg()
            self.config = copy.deepcopy(self.default_config)
            self.config.update(self.options)

            level_name = self.config.get('log_level')
            if not level_name:
                level_name = self.config.get('dais').get('log_level', 'INFO')

            level = logging.getLevelName(level_name)
            os.environ['PYPIMCO_LOG_LEVEL_OVERRIDE'] = level_name
            from core.log import log_config
            log_config.init_logging(None, True)
            self.log.setLevel(level)

            formatter = logging.Formatter(
                '%(asctime)s %(threadName)s:%(thread)d %(name)s %(levelname)s %(message)s')

            logger = logging.getLogger('')
            for handler in logger.handlers:
                handler.setFormatter(formatter)

            # Try command line argument first --audit-id
            self.etl_audit_id = self.options.get('etl_audit_id')

            # Use environment variable param if command line
            # for audit id is not set
            if not self.etl_audit_id:
                # Capture etl audit id. This id is created by etl wrapper script
                # and saved to the ETL_AUDIT_ID environment variable
                self.etl_audit_id = os.environ.get('ETL_AUDIT_ID')

            # make sure audit id type is int
            self.etl_audit_id = int(self.etl_audit_id)
            self.log.info("ETL_AUDIT_ID: %s", self.etl_audit_id)

            # Try command line argument first --audit-id
            self.etl_source_code = self.options.get('source_code')

            # Use environment variable param if command line
            # for etl source code is not set
            if self.etl_source_code is None:
                # Capture etl source code. Created by etl wrapper script
                # and saved to the ETL_SOURCE_CODE environment variable
                self.etl_source_code = os.environ.get('ETL_SOURCE_CODE')

            self.outfile = self.options.get('outfile')
            self.requestor_code = self.options.get('requestor_code')
            self.vertical = self.options.get('vertical')

            self.use_bt_output_file = self.options.get('use_bt_output_file')

            self.use_local_data = self.options.get('use_local_data')
            if self.use_local_data is None:
                self.use_local_data = os.environ.get('USE_LOCAL_DATA', 0)

            self.use_local_data = bool(int(self.use_local_data))
            self.dais_own = None
            self.cfdw_own = None

            self.ctx = util.struct(
                use_local_data=self.use_local_data, **self.options)

            self.log.info("Agent started at %s", self.start_time)

        except Exception as e:
            self.log.critical(
                "Unable to initialize BbgRequestFlow: %s", e)
            raise

    def __enter__(self):
        # make a database connection and return it
        self.dais_own = ora_xxx('DAIS_OWN', 'ORAPIM_DBP')
        # make a database connection and return it
        self.cfdw_own = ora_xxx('CFDW_OWN', 'ORAFND_DBP')

        self.ctx = util.struct(dais_own=self.dais_own,
                               cfdw_own=self.cfdw_own, **self.ctx)

        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources
        try:
            if self.dais_own is not None:
                self.dais_own.release()

            if self.cfdw_own is not None:
                self.cfdw_own.release()
        finally:
            self.dais_own = None
            self.cfdw_own = None

        # Release resources
        if self.config is not None:
            self.config = None

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("Agent completed at %s", self.end_time)
        self.log = None
    # endregion

    # region public methods
    @timed()
    def validate(self):
        """
        Executes validation logic upon start up of the driver.
        """
        if not self.etl_audit_id:
            raise ValueError(
                'Required audit job id not found in '
                'environment var:ETL_AUDIT_ID or cmd line params.')

        if not self.etl_source_code:
            raise ValueError(
                'Required --etl-source-code cmd line argument was not found.')

        if not self.outfile:
            raise ValueError(
                'Required --outfile cmd line argument was not found.')

        if not self.requestor_code:
            raise ValueError(
                'Required --requestor-code cmd line argument was not found.')

    @timed()
    def flow_completed(self, **kw):
        self.log.info(
            "{}: {} completed successfully.".format(
                self.__class__.__name__, self.etl_audit_id
            )
        )
        return kw

    @timed()
    def run(self):
        """
        Delegates processing to BbgIndexFlow instance.
        """
        try:
            ctx = self.ctx
            ctx = util.struct(**ctx)

            level1_meta_data_flow = BbgEtlSourceLevel1MetadataFlow(
                logger=self.log, ctx=self.ctx, config=self.config)

            level1_flow = BbgEtlSourceLevel1Flow(
                logger=self.log, ctx=self.ctx, config=self.config)

            level2_meta_data_flow = BbgEtlSourceLevel2MetadataFlow(
                logger=self.log, ctx=self.ctx, config=self.config)

            level2_flow = BbgEtlSourceLevel2Flow(
                logger=self.log, ctx=self.ctx, config=self.config)

            output_flow = BbgEtlSourceOutputFlow(
                logger=self.log, ctx=self.ctx, config=self.config)

            promise = Promise.resolve(ctx)

            promise.then(
                lambda res: level1_meta_data_flow.run(**res)
            ).then(
                lambda res: level1_flow.run(**res)
            ).then(
                lambda res: level2_meta_data_flow.run(**res)
            ).then(
                lambda res: level2_flow.run(**res)
            ).then(
                lambda res: output_flow.run(**res)
            ).then(
                lambda res: self.flow_completed(**res)
            ).get()

            self.log.debug("Workflow completed")

        except Exception as e:
            self.log.critical(
                "{}: {} completed with error: {}".format(
                    os.path.splitext(os.path.basename(__file__))[0],
                    self.etl_audit_id, e), exc_info=1
            )
            raise
    # endregion


USAGE = [
    'Bloomberg data feed agent',
    [['-l', '--log-level', '--log_level'],
        {'help': 'DEBUG, INFO, WARN, ERROR, CRITICAL',
         'choices': ['DEBUG', 'INFO', 'WARN', 'ERROR', 'CRITICAL']}],
    [['-e', '--etl-audit-id', '--etl_audit_id'],
        {'help': 'Etl audit id for etl jobs max-len(10)', 'type': int}],
    [['-o', '--outfile'],
        {'help': 'Etl output file name', 'required': True}],
    [['-v', '--vertical'],
        {'help': 'Etl output file format(VERTICAL if specified), '
         'works ONLY with single level non bulk requests',
         'action': 'store_true', 'default': False}],
    [['-c', '--requestor-code', '--requestor_code'],
        {'help': 'User token for bt API calls', 'required': True}],
    [['-s', '--source-code', '--source_code'],
        {'help': 'Etl source code for etl source', 'required': True}],
    [['-b', '--use-bt-output-file', '--use_bt_output_file'],
     {'help': 'Use bt output file, without modification, works ONLY for single'
      'level requests',  'action': 'store_true', 'default': False}]

]


# noinspection PyBroadException
def main():
    """
    Delegates all processing to Agent instance.
    """
    logger = logging.getLogger("{}".format(
        os.path.splitext(os.path.basename(__file__))[0]))

    try:
        cmd_line = sanitize_cmd_line(copy.copy(sys.argv))
        logging.info(cmd_line)
        args = util.parse_args(*USAGE)
        with BbgDataFeedFlow(logger=logger, options=args) as agent:
            agent.validate()
            agent.run()

    except Exception as ex:
        logger.critical(
            "critical error in {}::".format(
                os.path.splitext(os.path.basename(__file__))[0]), exc_info=1)
        logger.critical("Agent exited with error: %s", ex)
        return -1
    else:
        logger.info("Agent completed successfully.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
