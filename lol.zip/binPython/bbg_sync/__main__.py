import bbg_sync

bbg_sync.bbg_sync()
