import logging
import os
from os import path

from bbg_sync.request import BbgSyncRequest
from bbg_sync.request_file import BbgSyncRequestFile
from etl.core import da_config
from etl.core.util import struct
from etl.repo.pim_da import BbgSyncRequestRepo

PENDING_CODES = ['RUNNING', 'OVERRIDING']


def bbg_sync():
    _cfg = da_config.get_etl_cfg()
    cfg = struct(_cfg['bbg_sync'])
    if 'bbg_sync.getsnap' in _cfg:
        cfg.getsnap = struct(_cfg['bbg_sync.getsnap'])
    _exit_in_prod(cfg)
    for req_file in filter_reqs(cfg.da_bbg_new):
        BbgSyncRequestFile(req_file, cfg).submit()
    for req in BbgSyncRequestRepo.instance.list_by_bbg_sync_status_codes(PENDING_CODES):
        BbgSyncRequest(req, cfg).accept()


def _exit_in_prod(cfg):
    if cfg.da_bbg_new == cfg.ims_bbg_new:
        logging.info('%s: da_bbg_new = ims_bbg_new => assume prod; exit', cfg.da_bbg_new)
        exit()


def filter_reqs(input_path):
    return filter(
        lambda x: path.splitext(x)[1] == '.req',
        os.listdir(input_path)
    )
