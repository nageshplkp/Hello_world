"""File delivery proxy for Bloomberg ETL"""
import itertools
from os import path
from datetime import datetime
import logging
import re

from etl.core import file_util
from etl.core.util import struct
from etl.repo.pim_da import BbgSyncRequestRepo

MAXFILENAMELEN = 25


class BbgSyncRequest(object):
    def __init__(self, request, cfg=None):
        self.request = request
        self.cfg = struct(cfg)

    # NOTE: Consider "Chain-of-responsibility pattern"
    def accept(self):
        return self._accept_response() or \
               self._accept_err() or \
               self._accept_override_response() or \
               self._accept_override_err() or \
               self._submit_ims() or \
               self._timeout() or \
               False

    def _accept_response(self):
        return self._accept(self.request.response_file_name, 'SUCCEEDED')

    def _accept_err(self):
        return self._accept(self.request.err_file_name, 'FAILED')

    def _accept_override_response(self):
        return self._accept_override(self.request.response_file_name, 'SUCCEEDED')

    def _accept_override_err(self):
        return self._accept_override(self.request.err_file_name, 'FAILED')

    def _accept_override(self, filename, status):
        ov_name = self.ov_name(filename, self.request.etl_audit_id)
        src = path.join(self.cfg.ims_bbg_old, ov_name)
        if self.request.bbg_sync_status_code != 'OVERRIDING' or not self._got_file(src):
            return False
        dst = path.join(self.cfg.da_bbg_old, ov_name)
        logging.info('cp %s %s', src, dst)
        file_util.force_copy(src, dst)
        with open(dst, 'r') as dstf:
            txt = dstf.read()
        reply_pattern = r'(REPLYFILENAME\s*=\s*)\S+'
        reply_replace = r'\g<1>' + filename
        new_txt = re.sub(reply_pattern, reply_replace, txt)
        src, dst = dst, path.join(self.cfg.da_bbg_old, filename)
        logging.info('%s: restoring from override %s', dst, src)
        with open(dst, 'w') as dstf:
            dstf.write(new_txt)
        self.request.bbg_sync_status_code = status
        BbgSyncRequestRepo.instance.save(self.request)
        return True

    def _submit_ims(self):
        status = 'OVERRIDING'
        da_src = path.join(self.cfg.da_bbg_old, self.request.req_file_name)
        progname = grep(da_src, 'PROGRAMNAME')
        ims_src = path.join(self.cfg.ims_bbg_old, self.request.req_file_name)
        wait_time = self.cfg.bbg_max_wait_in_mins
        if 'getsnap' in progname and 'getsnap' in self.cfg:
            wait_time = self.cfg.getsnap.bbg_max_wait_in_mins
        if (self.request.bbg_sync_status_code == status or self._is_pending(wait_time) or
                path.isfile(ims_src)):
            return False
        filename = self._make_override_copy()
        src = path.join(self.cfg.da_bbg_old, filename)
        dst = path.join(self.cfg.ims_bbg_new, filename)
        self.request.bbg_sync_status_code = status
        BbgSyncRequestRepo.instance.save(self.request)
        logging.info('cp %s %s', src, dst)
        file_util.force_copy(src, dst)
        return True

    def _timeout(self):
        if self._is_pending():
            return False
        status = 'TIMEOUT'
        self.request.bbg_sync_status_code = status
        BbgSyncRequestRepo.instance.save(self.request)
        return True

    def _accept(self, filename, status):
        src = path.join(self.cfg.ims_bbg_old, filename)
        if not self._got_file(src):
            return False
        dst = path.join(self.cfg.da_bbg_old, filename)
        logging.info('cp %s %s', src, dst)
        file_util.force_copy(src, dst)
        self.request.bbg_sync_status_code = status
        BbgSyncRequestRepo.instance.save(self.request)
        return True

    def _make_override_copy(self):
        src = path.join(self.cfg.da_bbg_old, self.request.req_file_name)
        with open(src, 'r') as srcf:
            req_txt = srcf.read()
        reply_pattern = r'(REPLYFILENAME\s*=\s*)\S+'
        reply_replace = r'\g<1>' + self.ov_replyname
        new_txt = re.sub(reply_pattern, reply_replace, req_txt)
        dst = path.join(self.cfg.da_bbg_old, self.ov_reqname)
        logging.info('%s: CREATING REQUEST OVERRIDE!!', dst)
        with open(dst, 'w') as dstf:
            dstf.write(new_txt)
        return self.ov_reqname

    def _got_file(self, filename):
        return path.isfile(filename) and self._is_fresh(filename)

    def _is_fresh(self, file_path):
        timestamp = datetime.fromtimestamp(path.getmtime(file_path))
        bbg_max_stale_in_mins = int(self.cfg.bbg_max_stale_in_mins)
        return (bbg_max_stale_in_mins == 0 or
                not self._is_expired(timestamp, bbg_max_stale_in_mins))

    def _is_pending(self, wait_in_mins=None):
        wait_in_mins = int(self.cfg.bbg_max_wait_in_mins if wait_in_mins is None else wait_in_mins)
        return not self._is_expired(self.request.row_update_date, wait_in_mins)

    @staticmethod
    def _is_expired(timestamp, expiry_minutes):
        age_in_minutes = (datetime.now() - timestamp).total_seconds() / 60
        return 0 < expiry_minutes < age_in_minutes

    @property
    def ov_reqname(self):
        return self.ov_name(self.request.req_file_name,
                            self.request.etl_audit_id)

    @property
    def ov_replyname(self):
        return self.ov_name(self.request.response_file_name,
                            self.request.etl_audit_id)

    @staticmethod
    def ov_name(fname, audit_id):
        root, ext = path.splitext(fname)
        sfx = '_' + str(audit_id) + ext
        remaining = MAXFILENAMELEN - len(sfx)
        nm = root[-remaining:] + sfx
        return re.sub(r'^[^A-Z0-9]+', r'', nm, flags=re.IGNORECASE)


def grep(filepath, patt):
    rgx = re.compile(patt)
    with open(filepath, 'r') as f:
        return next(itertools.ifilter(rgx.match, f), None)
