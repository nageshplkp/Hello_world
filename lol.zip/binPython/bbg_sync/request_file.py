"""File delivery proxy for Bloomberg ETL"""
import logging
import re
import shutil
from os import environ
from os import path

from etl.repo.pim_da import BbgSyncRequestRepo

ENV_AUDIT_ID = 'ETL_AUDIT_ID'
DEFAULT_AUDIT_ID = 999999999


class BbgSyncRequestFile(object):
    def __init__(self, filename, cfg=None):
        self.name = filename
        self.cfg = cfg

        self.src = path.join(self.cfg.da_bbg_new, filename)
        self.dst = path.join(self.cfg.da_bbg_old, filename)
        self.request = None

    def submit(self):
        self.request = self.load()
        if self._is_valid() and not self._is_pending():
            self.request.bbg_sync_status_code = 'RUNNING'
            BbgSyncRequestRepo.instance.save(self.request)
            logging.info('mv %s %s', self.src, self.dst)
            shutil.move(self.src, self.dst)

    def load(self):
        if not path.isfile(self.src):
            return None

        def replace_ext(s, ext):
            return s and (path.splitext(s)[0] + ext)
        req = BbgSyncRequestRepo.instance.get_by_req_file_name(self.name) or \
            BbgSyncRequestRepo.instance.model(req_file_name=self.name)
        replyname = self._get_replyfilename()
        req.etl_audit_id = environ.get(ENV_AUDIT_ID, DEFAULT_AUDIT_ID)
        req.response_file_name = replyname
        req.err_file_name = replace_ext(replyname, '.err')
        logging.info("%s: will be expecting %s", self.name, replyname)
        return req

    def _is_valid(self):
        return self.request and self.request.response_file_name

    def _is_pending(self):
        pending = self.request.bbg_sync_status_code in ('RUNNING', 'OVERRIDING')
        if pending:
            logging.info('%s: request already pending', self.name)
        return pending

    def _get_replyfilename(self):
        filename = path.join(self.cfg.da_bbg_new, self.name)
        with open(filename, "r") as reqf:
            match = re.search(r'REPLYFILENAME\s*=\s*(\S+)', reqf.read())
            return match.group(1) if match else match
