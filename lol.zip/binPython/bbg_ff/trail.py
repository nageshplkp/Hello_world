import getpass
import pandas
import numpy as np
from core.db.sql_db import SqlDb
from etl.core.db import get_db_creds
from etl.repo import OraPimRepo
from collections import defaultdict
from sqlalchemy.inspection import inspect
_repo = OraPimRepo()
_cred = get_db_creds(_repo.server, _repo.vendor)
sql_db = SqlDb(_cred.server, _cred.vendor, user=_cred.get('user'), password=_cred.get('passwd'))
_USERNAME = getpass.getuser()

sql = """
            SELECT 
                *
            FROM 
                "DA_OWN".dats_bbg_batch_series
        """
df1 = pandas.DataFrame(sql_db.query_as_df(sql))
df2 = pandas.DataFrame(sql_db.query_as_df(sql))
ne = (df1 != df2).stack()
le = ne[ne]

# change index
# changed.index.names = ['id', 'col']

#to display index and what has been changed.
difference_locations = np.where(df1 != df2)

changed_from = df1.values[difference_locations]
changed_to = df2.values[difference_locations]
print changed_from
print changed_to
# pandas.DataFrame({'from': changed_from, 'to': changed_to}, index=changed.index)
