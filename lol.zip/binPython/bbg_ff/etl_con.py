from etl.repo.fnd_cfdw.etl_app_config import EtlAppConfigRepo


rows = EtlAppConfigRepo()

print(rows.list_by_app_code("DATS_BATCH"))
for i in rows.list_by_app_code("DATS_BATCH"):
    print(vars(i))