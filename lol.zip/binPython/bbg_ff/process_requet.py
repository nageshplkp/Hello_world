from etl.repo.pim_da.dats_bbg_batch_series import DatsBbgBatchSeriesRepo
import pandas as pd
from sqlalchemy.inspection import inspect
from collections import defaultdict
rows = DatsBbgBatchSeriesRepo()
row = rows.list_by_cdc()
import numpy as np
lame = [u.__dict__ for u in row]


def query_to_dict(rset):
    result = defaultdict(list)
    for obj in rset:
        instance = inspect(obj)
        for key, x in instance.attrs.items():
            result[key].append(x.value)
    return result

data = query_to_dict(row)
df1 = pd.DataFrame(data)
df2 = pd.DataFrame(data)

ne = (df1 != df2).stack()
print(ne)
le = ne[ne]
print(le)
# change index
# changed.index.names = ['id', 'col']

#to display index and what has been changed.
difference_locations = np.where(df1 != df2)

