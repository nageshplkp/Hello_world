import csv
import pandas as pd


# def validate_csv(csv_file):
#     df = pd.read_csv(csv_file)
#     values = []
#     for i in df["REQUESTOR_TAG"]:
#         if i.startswith("##") and i.endswith("##"):
#             i = i[2:-2]
#         values.append(i)
#     df["REQUESTOR_TAG"] = values
#     df.to_csv(csv_file, index=False, quoting=csv.QUOTE_ALL)
# validate_csv(r'C:\Users\pachimat\Desktop\test\test_2.csv')

from etl.bbg_transport.parser import BtParser
uy = BtParser('GETHISTORY', 'VERTICAL')
uy.parse_files(r'C:\Users\pachimat\Desktop\test\20180604.P.102.0.txt', r'C:\Users\pachimat\Desktop\test\test_2.csv')
