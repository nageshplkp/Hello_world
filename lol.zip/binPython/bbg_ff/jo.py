import getpass
import pandas
from core.db.sql_db import SqlDb
from etl.core.db import get_db_creds
from etl.repo import OraPimRepo
from collections import defaultdict
from sqlalchemy.inspection import inspect
_src_repo = OraPimRepo()
_src_cred = get_db_creds(_src_repo.server, _src_repo.vendor)
sql_db = SqlDb(_src_cred.server, _src_cred.vendor, user=_src_cred.get('user'), password=_src_cred.get('passwd'))
_USERNAME = getpass.getuser()

src_sql = """
SELECT
   MEASURE_CODE || '-' || PIMCO_TICKER SERIES_CODE
 , TO_CHAR(ASOF_DATE, 'YYYYMMDD') ASOF
 , SERIES_VALUE
FROM
   PM_OWN.VDW_F_TS_SERIES_INTERNAL
WHERE
   1 = 1
   AND PROVIDER_CODE = 'BBG'
   AND TICKER = 'RRSWM10'
   AND MEASURE_CODE = 'PRICE'
   and rownum < 15
ORDER BY
   ASOF_DATE
"""
src_data = sql_db.query_as_df(src_sql)
# print src_data

_tgt_repo = OraPimRepo()
_tgt_cred = get_db_creds(_tgt_repo.server, _tgt_repo.vendor)
sql_db = SqlDb(_tgt_cred.server, _tgt_cred.vendor, user=_tgt_cred.get('user'), password=_tgt_cred.get('passwd'))
_USERNAME = getpass.getuser()

tgt_sql = """
SELECT
   MEASURE_CODE || '-' || PIMCO_TICKER SERIES_CODE
 , TO_CHAR(ASOF_DATE, 'YYYYMMDD') ASOF
 , SERIES_VALUE
FROM
   PM_OWN.VDW_F_TS_SERIES_INTERNAL
WHERE
   1 = 1
   AND PROVIDER_CODE = 'BBG'
   AND TICKER = 'RRSWM10'
   AND MEASURE_CODE = 'PRICE'
   and rownum < 10
ORDER BY
   ASOF_DATE
"""

tgt_data = sql_db.query_as_df(tgt_sql)
# print tgt_data

src_len = len(src_data)
tgt_len = len(tgt_data['SERIES_CODE'])

print('Length of source is {src_len}').format(src_len=src_len)
print('Length of target is {tgt_len}').format(tgt_len=tgt_len)

if src_len == tgt_len:
   print('Both have same length')
else:
   print('Both do not have same length')
   pass #Place holder for error handling

joined_data = src_data.merge(tgt_data, how ='outer', on=['SERIES_CODE','ASOF'], suffixes=('_SRC', '_TGT'))

only_in_src = joined_data.notnull()
print(only_in_src)
# filtered_df = df[df['name'].notnull()]