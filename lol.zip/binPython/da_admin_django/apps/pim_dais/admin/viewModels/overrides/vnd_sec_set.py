from core.django.admin.filters import *
from ....models.vnd_sec_set import *

null_indicator_cells = [
    FieldNames.sec_identity_id,
    FieldNames.bb_id
]


class VndSecSetAdminViewModel(object):
    list_filter = (('sec_identity_id', NullListFilter),('bb_id', NullListFilter),)

    def suit_cell_attributes(self, obj, column):
        if column in null_indicator_cells:
            value = getattr(obj, column)
            if value is None or value == '':
                return {'class': 'warning'}

    class Media:
        js = (
            'pim_dais/js/vnd-sec-set.js',
        )
