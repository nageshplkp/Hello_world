from core.django.admin import filters
from ....models.vnd_file_inst import *

status_cells = [
    FieldNames.is_raw_pre_done,
    FieldNames.is_raw_core_done,
    FieldNames.is_raw_post_done,
    FieldNames.is_fmt_pre_done,
    FieldNames.is_fmt_core_done,
    FieldNames.is_fmt_post_done,
    FieldNames.is_nrm_pre_done,
    FieldNames.is_nrm_core_done,
    FieldNames.is_nrm_post_done,
    FieldNames.is_enr_pre_done,
    FieldNames.is_enr_core_done,
    FieldNames.is_enr_post_done,
    FieldNames.is_pub_pre_done,
    FieldNames.is_pub_core_done,
    FieldNames.is_pub_post_done
]


class VndFileInstAdminViewModel():
    list_filter = (('vnd_file_inst_status_code__vnd_file_inst_status_name', filters.MultiSelectFieldListFilter),
                   ('asof_date', filters.DateFieldListFilter),)

    ordering = ('-row_update_date','vnd_file_inst_status_code',)

    def suit_cell_attributes(self, obj, column):
        if column in status_cells:
            css_class = {
                2: 'warning',
                1: 'success',
                0: '',
                -1: 'error',
            }.get(getattr(obj, column))

            if css_class:
                return {'class': css_class}

    class Media:
        js = (
            'pim_dais/js/vnd-file-inst.js',
        )
