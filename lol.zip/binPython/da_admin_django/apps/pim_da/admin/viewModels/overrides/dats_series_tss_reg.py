from __future__ import unicode_literals


class DatsSeriesTssRegAdminViewModel():
    list_display_get_value_func = {
        'request_payload': '_fix_payload',
        'response_payload': '_fix_payload'
    }

    def _fix_payload(self, value):
        return u'{%s}' % value\
            .strip()\
            .replace(u'Approval:\n{', u'"Approval": {')\
            .replace(u'}\nRegistration\n{', u'}, "Registration": {')\
            .replace(u'}\nRegistration: \n{', u'}, "Registration": {')
