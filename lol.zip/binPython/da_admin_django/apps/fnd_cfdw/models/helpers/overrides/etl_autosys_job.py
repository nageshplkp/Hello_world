from __future__ import unicode_literals
from ...model_base import *
from ..etl_autosys_job import FieldNames


class ModelFieldHelper():
    def box_name(self):
        key_name = FieldNames.box_name

        if not self.foreign_fields.__contains__(key_name):
            self.foreign_fields.append(key_name)
        return ForeignKey(verbose_name=u'Box Name', db_column='BOX_NAME', to='EtlAutosysJob', to_field='job_name_orig', related_name='%(app_label)s_EtlAutosysJob_job_name_orig', on_delete=self.foreign_fields_on_delete.get(key_name, DEFAULT_ON_DELETE_ACTION), limit_choices_to={}, null=True, blank=True, max_length=50, help_text='', editable=True)
