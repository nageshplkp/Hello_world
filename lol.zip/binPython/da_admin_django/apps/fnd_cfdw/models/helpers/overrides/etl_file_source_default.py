from __future__ import unicode_literals
from ...model_base import *
from ..etl_file_source_default import FieldNames


class ModelFieldHelper():
    def file_source_code(self):
        key_name = FieldNames.file_source_code

        if not self.foreign_fields.__contains__(key_name):
            self.foreign_fields.append(key_name)
        return OneToOneField(verbose_name=u'File Source Code', db_column='FILE_SOURCE_CODE', to='EtlSource', to_field='source_code', related_name='%(app_label)s_EtlFileSourceDefault_file_source_code', on_delete=PROTECT, limit_choices_to={}, db_index=True, primary_key=True, max_length=20, help_text='', editable=True)
