from __future__ import unicode_literals
from ....models.etl_source import *


class EtlSourceAdminViewModel():
    inlines_to_load_overrides = {
        'EtlSourceEtlSourceAdminTabularInlineViewModelDaSourceCode': {'index': 0},
        'EtlFileSourceAdminTabularInlineViewModel': {'index': 1},
        'EtlFileSourceDefaultAdminTabularInlineViewModel': {'index': 2},
        'EtlEmailSourceAdminTabularInlineViewModel': {'index': 3},
        'EtlHttpSourceAdminTabularInlineViewModel': {'index': 4},
        'EtlBbgSourceAdminTabularInlineViewModel': {'index': 5},
        'EtlExportSourceAdminTabularInlineViewModel': {'index': 6},
        'EtlHolidayCodeinEtlSourceAdminTabularInlineViewModel': {'index': 7},
        'EtlFileAdminTabularInlineViewModel': {'index': 8},
        'EtlAutosysJobinEtlSourceAdminTabularInlineViewModel': {'index': 9},
    }

    search_fields = [
        FieldNames.source_code,
        FieldNames.source_descr,
        FieldNames.local_file_folder,
        FieldNames.file_names,
        FieldNames.output_file_folder
    ]
