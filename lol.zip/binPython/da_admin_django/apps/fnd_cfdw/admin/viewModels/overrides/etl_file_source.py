from __future__ import unicode_literals


class EtlFileSourceAdminViewModel():
    inlines_to_load_overrides = {
        'EtlFileSourceDefaultAdminTabularInlineViewModel': {'exclude': True}
    }
