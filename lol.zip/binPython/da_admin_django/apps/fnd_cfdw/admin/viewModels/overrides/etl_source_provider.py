from __future__ import unicode_literals
from ....models.etl_source_provider import *


class EtlSourceProviderAdminViewModel():
    search_fields = [
        FieldNames.source_provider_code,
        FieldNames.source_provider_name,
        FieldNames.source_provider_descr,
        FieldNames.pimco_contact_email,
        FieldNames.provider_contact_email,
        FieldNames.provider_contact_phone
    ]
