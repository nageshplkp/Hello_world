
database = {
    'conn_variable': 'ORACOR_DBP',
    'engine': 'Oracle'
}
