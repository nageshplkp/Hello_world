# coding=utf-8

from __future__ import unicode_literals
from core.helpers import OverridableBase
from ..model_base import *


class FieldNames():
    request_id='request_id'
    interface_code='interface_code'
    program_code='program_code'
    request_description='request_description'
    requestor_code='requestor_code'
    response_format_code='response_format_code'


class ModelFieldHelper(OverridableBase):
    model_verbose_name = 'Create Request'
    model_verbose_plural = 'Create Request'

    # field_help_texts = {'field_name': 'Help text for field'}
    field_help_texts = {}
    # field_verbose_names = {'field_name': 'Displayed name for field'}
    field_verbose_names = {}
    # foreign_fields_on_delete = {'field_name': on_delete_action}
    # https://docs.djangoproject.com/en/2.0/ref/models/fields/#django.db.models.ForeignKey.on_delete
    foreign_fields_on_delete = {}

    foreign_fields = []
    # form_fields = [FieldNames.request_description, FieldNames.requestor_code, FieldNames.program_code, FieldNames.interface_code, FieldNames.response_format_code, FieldNames.callback_uri]
    form_fields = [FieldNames.request_description, FieldNames.requestor_code, FieldNames.program_code, FieldNames.interface_code, FieldNames.response_format_code]
    indexed_fields = []
    list_display_fields = []
    raw_id_fields = foreign_fields
    readonly_fields = []
    to_string_fields = []

    def get_unicode(self, modelInstance):
        return ' - '.join([unicode(getattr(modelInstance, o))
                           for o in self.to_string_fields
                           if o not in self.foreign_fields])

    def request_id(self):
        return AutoField(verbose_name=u'Request Id', primary_key=True, help_text='', editable=False)

    # def callback_uri(self):
    #     return CharField(verbose_name=u'Callback Uri', null=True, blank=True, max_length=2000, help_text='', editable=True)

    def interface_code(self):
        if not self.foreign_fields.__contains__('interface_code'):
            self.foreign_fields.append('interface_code')
        return ForeignKey(verbose_name=u'Interface Code', to='BbgInterface', to_field='bbg_interface_code', related_name='%(app_label)s_Request_bbg_interface_code', on_delete=PROTECT, limit_choices_to={}, max_length=10, help_text='', editable=True)

    def program_code(self):
        if not self.foreign_fields.__contains__('program_code'):
            self.foreign_fields.append('program_code')
        return ForeignKey(verbose_name=u'Program Code', to='BbgProgram', to_field='bbg_program_code', related_name='%(app_label)s_Request_bbg_program_code', on_delete=PROTECT, limit_choices_to={}, max_length=20, help_text='', editable=True)

    def request_description(self):
        return CharField(verbose_name=u'Request Description', max_length=250, help_text='', editable=True)

    def requestor_code(self):
        return CharField(verbose_name=u'Requestor Code', max_length=50, help_text='', editable=True)

    def response_format_code(self):
        if not self.foreign_fields.__contains__('response_format_code'):
            self.foreign_fields.append('response_format_code')
        return ForeignKey(verbose_name=u'Response Format Code', to='BtFormat', to_field='bt_format_code', related_name='%(app_label)s_Request_response_format_code', on_delete=PROTECT, limit_choices_to={}, max_length=20, help_text='', editable=True)
