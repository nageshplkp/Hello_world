# coding=utf-8

from __future__ import unicode_literals
from core.helpers import OverridableBase
from ..model_base import *


class FieldNames():
    request_id='request_id'
    action='action'


class ModelFieldHelper(OverridableBase):
    model_verbose_name = 'Check Request Status'
    model_verbose_plural = 'Check Request Status'

    # field_help_texts = {'field_name': 'Help text for field'}
    field_help_texts = {}
    # field_verbose_names = {'field_name': 'Displayed name for field'}
    field_verbose_names = {}
    # foreign_fields_on_delete = {'field_name': on_delete_action}
    # https://docs.djangoproject.com/en/2.0/ref/models/fields/#django.db.models.ForeignKey.on_delete
    foreign_fields_on_delete = {}

    foreign_fields = []
    form_fields = [FieldNames.action]
    indexed_fields = []
    list_display_fields = [FieldNames.action]
    raw_id_fields = foreign_fields
    readonly_fields = []
    to_string_fields = []

    def get_unicode(self, modelInstance):
        return ' - '.join([unicode(getattr(modelInstance, o))
                           for o in self.to_string_fields
                           if o not in self.foreign_fields])

    action_choices = (
        ('check_status', 'STATUS'),
        ('response', 'RESPONSE'),
    )

    def action(self):
        return CharField(verbose_name=u'Action', max_length=10, choices=self.action_choices, help_text='', editable=True)

    def request_id(self):
        key_name = FieldNames.request_id

        if model_exists(self, 'create_request'):
            if not self.foreign_fields.__contains__(key_name):
                self.foreign_fields.append(key_name)
            return ForeignKey(verbose_name=u'Request Id', to='CreateRequest', to_field='request_id', related_name='%(app_label)s_CheckRequestStatus_request_id', on_delete=self.foreign_fields_on_delete.get(key_name, DEFAULT_ON_DELETE_ACTION), limit_choices_to={}, help_text='', editable=True)
        else:
            if self.foreign_fields.__contains__(key_name):
                self.foreign_fields.remove(key_name)
            return IntegerField(verbose_name=u'Request Id', help_text='', editable=True)
