from __future__ import unicode_literals
from core.django.models import *


class ModelFieldHelper():

    def request_description(self):
        field = CodeHighlightField(verbose_name=u'Request Description', db_column='REQUEST_DESCRIPTION', null=True, blank=True, max_length=250, help_text='', editable=True)
        field.code_mode = 'json'
        return field
