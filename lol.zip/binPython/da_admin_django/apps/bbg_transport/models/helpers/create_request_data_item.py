# coding=utf-8

from __future__ import unicode_literals
from core.helpers import OverridableBase
from ..model_base import *


class FieldNames():
    request_id='request_id'
    bb_id='bb_id'
    bbg_query='bbg_query'
    cusip='cusip'
    isin='isin'
    tag='tag'
    ticker='ticker'
    yellow_key='yellow_key'


class ModelFieldHelper(OverridableBase):
    model_verbose_name = 'Request Data Item'
    model_verbose_plural = 'Request Data Item'

    # field_help_texts = {'field_name': 'Help text for field'}
    field_help_texts = {}
    # field_verbose_names = {'field_name': 'Displayed name for field'}
    field_verbose_names = {}
    # foreign_fields_on_delete = {'field_name': on_delete_action}
    # https://docs.djangoproject.com/en/2.0/ref/models/fields/#django.db.models.ForeignKey.on_delete
    foreign_fields_on_delete = {}

    foreign_fields = []
    form_fields = [FieldNames.yellow_key, FieldNames.ticker, FieldNames.bbg_query, FieldNames.isin, FieldNames.cusip, FieldNames.bb_id, FieldNames.tag]
    indexed_fields = []
    list_display_fields = [FieldNames.yellow_key, FieldNames.ticker, FieldNames.bbg_query, FieldNames.isin, FieldNames.cusip, FieldNames.bb_id, FieldNames.tag]
    raw_id_fields = foreign_fields
    readonly_fields = []
    to_string_fields = []

    def get_unicode(self, modelInstance):
        return ' - '.join([unicode(getattr(modelInstance, o))
                           for o in self.to_string_fields
                           if o not in self.foreign_fields])

    def request_id(self):
        key_name = FieldNames.request_id

        if model_exists(self, 'create_request'):
            if not self.foreign_fields.__contains__(key_name):
                self.foreign_fields.append(key_name)
            return ForeignKey(verbose_name=u'Request Id', to='CreateRequest', to_field='request_id', related_name='%(app_label)s_CreateRequestDataItem_request_id', on_delete=self.foreign_fields_on_delete.get(key_name, DEFAULT_ON_DELETE_ACTION), limit_choices_to={}, help_text='', editable=True)
        else:
            if self.foreign_fields.__contains__(key_name):
                self.foreign_fields.remove(key_name)
            return IntegerField(verbose_name=u'Request Id', help_text='', editable=True)

    def bb_id(self):
        return CharField(verbose_name=u'BBG ID', null=True, blank=True, max_length=100, help_text='Bloomberg ID', editable=True)

    def bbg_query(self):
        return CharField(verbose_name=u'BBG Query', null=True, blank=True, max_length=100, help_text='Custom BBG '
                                                                                                   'Security Indentification query (Macro, Index, etc)', editable=True)
    def cusip(self):
        return CharField(verbose_name=u'Cusip', null=True, blank=True, max_length=20, help_text='', editable=True)

    def isin(self):
        return CharField(verbose_name=u'Isin', null=True, blank=True, max_length=20, help_text='', editable=True)

    def tag(self):
        return CharField(verbose_name=u'Tag', null=True, blank=True, max_length=1000, help_text='Requestor defined comments', editable=True)

    def ticker(self):
        return CharField(verbose_name=u'Ticker', null=True, blank=True, max_length=100, help_text='BBG Ticker (Requires Yellow Key)', editable=True)

    def yellow_key(self):
        return CharField(verbose_name=u'BBG Yellow Key', null=True, blank=True, max_length=100, help_text='', editable=True)
