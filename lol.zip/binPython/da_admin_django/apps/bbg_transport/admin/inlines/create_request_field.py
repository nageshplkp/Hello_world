from __future__ import unicode_literals
from ..admin_view_model_base import AdminTabularInlineViewModelBase
from ...models.create_request_field import CreateRequestField as Model, modelFieldHelper


class CreateRequestFieldAdminTabularInlineViewModel(AdminTabularInlineViewModelBase):
    enable_add = True

    model = Model
    fields = modelFieldHelper.list_display_fields
    raw_id_fields = modelFieldHelper.raw_id_fields
    readonly_fields = modelFieldHelper.readonly_fields
