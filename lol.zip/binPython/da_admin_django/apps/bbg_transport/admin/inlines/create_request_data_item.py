from __future__ import unicode_literals
from ..admin_view_model_base import AdminTabularInlineViewModelBase
from ...models.create_request_data_item import CreateRequestDataItem as Model, modelFieldHelper


class CreateRequestDataItemAdminTabularInlineViewModel(AdminTabularInlineViewModelBase):
    enable_add = True

    model = Model
    fields = modelFieldHelper.list_display_fields
    raw_id_fields = modelFieldHelper.raw_id_fields
    readonly_fields = modelFieldHelper.readonly_fields
