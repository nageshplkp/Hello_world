from __future__ import unicode_literals
from core.helpers import OverridableBase


class InlineHelper(OverridableBase):
    from create_request_data_item import CreateRequestDataItemAdminTabularInlineViewModel
    from create_request_field import CreateRequestFieldAdminTabularInlineViewModel
    from create_request_option import CreateRequestOptionAdminTabularInlineViewModel

    def get_inlines(self):
        return [
            InlineHelper.CreateRequestDataItemAdminTabularInlineViewModel,
            InlineHelper.CreateRequestFieldAdminTabularInlineViewModel,
            InlineHelper.CreateRequestOptionAdminTabularInlineViewModel
        ]
