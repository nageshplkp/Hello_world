from __future__ import unicode_literals
from datetime import datetime
from ...admin_view_model_base import *
from ....models.bt_request import *

class BtRequestAdminViewModel():
    list_display = [
        FieldNames.bt_request_id,
        FieldNames.bbg_program_code,
        FieldNames.bbg_interface_code,
        FieldNames.bt_requestor_code,
        FieldNames.bt_status_code,
        FieldNames.request_date,
        FieldNames.status_date,
        'time_pending',
        FieldNames.retry_count,
        FieldNames.requestor_login,
        FieldNames.request_object_data
    ]

    list_display_links = ()
    list_filter = (('bt_status_code__bt_status_code', filters.MultiSelectFieldListFilter),
                   ('status_date', filters.DateFieldListFilter),)
    ordering = ('-status_date',)

    def time_pending(self, obj):
        rpt_time = datetime.now()

        diff = rpt_time - obj.status_date
        return '{}:{}:{}'.format(
            (diff.days * 24 + diff.seconds // 3600),
            ((diff.seconds % 3600) // 60),
            (diff.seconds % 60))

    time_pending.short_description = 'Time Pending'

    class Media:
        js = (
            '%s/js/bt_request.js' % AppConfig.name,
        )
