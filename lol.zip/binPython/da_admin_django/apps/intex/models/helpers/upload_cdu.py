# coding=utf-8

from __future__ import unicode_literals
from datetime import date
from core.django.models import *
from core.helpers import OverridableBase


class FieldNames():
    file='file'
    month='month'
    year='year'


class ModelFieldHelper(OverridableBase):
    model_verbose_name = 'Upload CDU File'
    model_verbose_plural = 'Upload CDU File'

    # field_help_texts = {'field_name': 'Help text for field'}
    field_help_texts = {}
    # field_verbose_names = {'field_name': 'Displayed name for field'}
    field_verbose_names = {}

    foreign_fields = []
    form_fields = [FieldNames.file, (FieldNames.month, FieldNames.year)]
    indexed_fields = []
    list_display_fields = []
    raw_id_fields = foreign_fields
    readonly_fields = []
    to_string_fields = []

    def get_unicode(self, modelInstance):
        return ' - '.join([unicode(getattr(modelInstance, o))
                           for o in self.to_string_fields
                           if o not in self.foreign_fields])

    __months = (
        ('01', 'January'),
        ('02', 'February'),
        ('03', 'March'),
        ('04', 'April'),
        ('05', 'May'),
        ('06', 'June'),
        ('07', 'July'),
        ('08', 'August'),
        ('09', 'September'),
        ('10', 'October'),
        ('11', 'November'),
        ('12', 'December'),
    )

    __years = ((o, o) for o in range(date.today().year, 1970, -1))

    def file(self):
        return FileField(verbose_name=u'File', help_text='', editable=True)

    def month(self):
        return IntegerField(verbose_name=u'Month', choices=ModelFieldHelper.__months, help_text='', editable=True)

    def year(self):
        return IntegerField(verbose_name=u'Year', choices=ModelFieldHelper.__years, help_text='', editable=True)
