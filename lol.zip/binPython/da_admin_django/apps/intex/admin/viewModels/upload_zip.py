from __future__ import unicode_literals
from ..admin_view_model_base import *
from ...models.upload_zip import UploadZip as Model, modelFieldHelper


class UploadZipAdminViewModel(AdminClientSideFormViewModelBase):
    fields = None
    fieldsets = (
        (None, {
            'classes': ('suit-tab', 'suit-tab-general'),
            'fields': [o for o in modelFieldHelper.form_fields if o not in modelFieldHelper.readonly_fields]
        }),
        ('HTTP Status', {
            'classes': ('suit-tab', 'suit-tab-http_status'),
            'fields': Model.http_status_fields
        }),
    )
    raw_id_fields = modelFieldHelper.raw_id_fields
    readonly_fields = modelFieldHelper.readonly_fields + Model.http_status_fields
    suit_form_tabs = (('general', 'General'), ('http_status', 'HTTP Status'))


admin.site.register(Model, UploadZipAdminViewModel)
