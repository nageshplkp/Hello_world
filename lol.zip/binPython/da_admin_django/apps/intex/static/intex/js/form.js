var intex;
(function (intex) {
    var Form = /** @class */ (function (_super) {
        __extends(Form, _super);
        function Form(el) {
            var _this = _super.call(this, el) || this;
            _this.actionGetDeal = function (inputValues, errors) {
                var dealName = inputValues['deal_name'];
                _this.ajaxPost(Form.serviceBaseUrl + '/deal/' + dealName, {});
                return true;
            };
            _this.actionGetPrePrice = function (inputValues, errors) {
                var dealName = inputValues['deal_name'];
                var password = inputValues['password'];
                _this.ajaxPost(Form.serviceBaseUrl + '/deal/' + dealName, { 'password': password });
                return true;
            };
            _this.actionUpload = function (inputValues, errors, expectedExtension) {
                var files = _this.files;
                if (files.length <= 0) {
                    errors.push('Unable to get a file to upload.');
                }
                else {
                    var formData = _this.toFormData(files[0], expectedExtension);
                    if (formData === null) {
                        return false;
                    }
                    _this.ajaxPost(Form.serviceBaseUrl + '/upload/', formData);
                    return true;
                }
                return false;
            };
            _this.actionUploadCdu = function (inputValues, errors) {
                var expectedExtension = 'cdu';
                var files = _this.files;
                if (files.length <= 0) {
                    errors.push('Unable to get a file to upload.');
                }
                else {
                    var formData = _this.toFormData(files[0], expectedExtension);
                    if (formData === null) {
                        return false;
                    }
                    var month = inputValues['month'];
                    var year = inputValues['year'];
                    _this.ajaxPost(Form.serviceBaseUrl + '/upload/' + year + '/' + month, formData);
                    return true;
                }
                return false;
            };
            switch (_this.actionName) {
                case 'getdeal':
                    _this.actionToExecute = _this.actionGetDeal;
                    break;
                case 'getpreprice':
                    _this.actionToExecute = _this.actionGetPrePrice;
                    break;
                case 'uploadcdi':
                    _this.actionToExecute = function (inputValues, errors) { return _this.actionUpload(inputValues, errors, 'cdi'); };
                    break;
                case 'uploadcdu':
                    _this.actionToExecute = _this.actionUploadCdu;
                    break;
                case 'uploadzip':
                    _this.actionToExecute = function (inputValues, errors) { return _this.actionUpload(inputValues, errors, 'zip'); };
                    break;
            }
            return _this;
        }
        Object.defineProperty(Form.prototype, "files", {
            get: function () {
                return this.form.find('div.controls input#id_file').prop('files');
            },
            enumerable: true,
            configurable: true
        });
        Form.serviceBaseUrlDefault = 'http://ptp-dev';
        Form.servicePath = '/workshop/service/da/intex';
        Form.serviceBaseUrl = (location.hostname.toLowerCase().indexOf('ptp-dev') === 0
            ? location.origin : Form.serviceBaseUrlDefault)
            + Form.servicePath;
        return Form;
    }(Django.AdminForm));
    intex.Form = Form;
})(intex || (intex = {}));
var intex_Form = null;
function form_submit(el) {
    if (!intex_Form) {
        intex_Form = new intex.Form(el);
    }
    intex_Form.submit();
}
