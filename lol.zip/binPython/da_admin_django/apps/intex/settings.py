
database = {
    'conn_variable': 'ORAPIM_DBP',
    'engine': 'Oracle'
}
