# coding=utf-8
from __future__ import unicode_literals
import imp
import os
import sys


def get_folder_name(file_path):
    path = get_folder_path(file_path)

    parts = path.split('/')

    return parts[parts.__len__() - 1]


def get_folder_path(file_path):
    # Get the path to the folder containing the class
    file_path = os.path.abspath(file_path)[os.path.abspath('.').__len__():]
    path, filename = os.path.split(file_path)

    return path.replace('\\', '/')


def get_folder_path_as_module(file_path):
    path = get_folder_path(file_path)
    return to_module_path(path)


def to_module_path(path):
    return path.replace('\\', '/').lstrip('/').replace('/', '.').replace('..', '')


def override_extend(derived_instance):
    # Get the full path to the file containing the derived class
    derived_class_file = sys.modules[derived_instance.__class__.__module__].__file__

    # Get the path to the folder containing the derived class
    # Get the filename containing the derived class
    derived_class_path, derived_class_filename = os.path.split(derived_class_file)

    # Create the full path and key to the override file
    override_file = '{0}/overrides/{1}.py'.format(derived_class_path, os.path.splitext(derived_class_filename)[0]).replace('\\', '/')
    override_name = to_module_path(os.path.splitext(override_file)[0])

    if os.path.isfile(override_file):

        import warnings
        warnings.filterwarnings('ignore',
                                category=RuntimeWarning,
                                message='^Parent module \'.*\' not found while handling .*$')

        # Load the override file
        override_module = imp.load_source(override_name, override_file)

        # The class to override/extend
        class_name = derived_instance.__class__.__name__

        if override_module.__dict__.has_key(class_name):
            override_class = override_module.__dict__[class_name]
            override_dict = override_class.__dict__

            for key, value in override_dict.iteritems():
                if not key.startswith('__'):
                    setattr(derived_instance.__class__, key, override_dict[key])


class OverridableBase(object):
    def __init__(self):
        super(OverridableBase, self).__init__()
        override_extend(self)
        if hasattr(self, 'on_override'):
            self.on_override()
