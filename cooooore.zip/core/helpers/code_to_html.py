import ast
import json
from django.utils.html import format_html, escape


def _json_to_readonly_html(value):
    try:
        value = json.loads(value)
    except StandardError:
        try:
            value = ast.literal_eval(value)
        except StandardError:
            return ''

    return json.dumps(value, indent=4) if value else ''


def code_to_readonly_html(value, code_mode):
    if not value:
        return ''

    if code_mode == 'js' or code_mode == 'json':
        value = _json_to_readonly_html(value)

    return format_html('<div data-code-area="{}">{}</div>', code_mode, escape(value)) if value else ''
