from __future__ import unicode_literals
from django.db.models import *
import django.forms.models
import core.helpers
from fields import *


class ModelBase(Model):
    help_texts = {}
    verbose_names = {}

    def __init__(self, *args, **kwargs):
        super(ModelBase, self).__init__(*args, **kwargs)
        core.helpers.override_extend(self)
        if hasattr(self, 'on_override'):
            self.on_override()

        for field in self._meta.fields:
            if self.help_texts.has_key(field.name):
                field.help_text = self.help_texts[field.name]

            if self.verbose_names.has_key(field.name):
                field.verbose_name = self.verbose_names[field.name]

    def __unicode__(self):
        return self.get_unicode()

    def get_unicode(self):
        return u''

    class Meta:
        abstract = True
        #base_manager_name = None
        db_tablespace = ''
        #default_manager_name = None
        default_permissions = ('add', 'change', 'delete', 'read')
        default_related_name = ''
        get_latest_by = []
        managed = False
        order_with_respect_to = ''
        ordering = []
        permissions = ()
        proxy = False
        required_db_features = []
        select_on_save = False


def ClientSideFormHttpCodeField(verbose_name):
    field = CodeHighlightField(verbose_name=verbose_name, blank=True, help_text='', editable=True)
    field.code_mode = 'json'
    return field


class ClientSideFormModelBase(ModelBase):
    http_status_fields = ['http_status', 'http_request', 'http_response']

    http_request = ClientSideFormHttpCodeField(u'Request')
    http_response = ClientSideFormHttpCodeField(u'Response')
    http_status = ClientSideFormHttpCodeField(u'Status')

    class Meta:
        abstract = True


class BaseInlineFormSetLimit(django.forms.models.BaseInlineFormSet):
    list_per_page = 10

    def get_queryset(self) :
        qs = super(BaseInlineFormSetLimit, self).get_queryset()
        return qs[:self.list_per_page]