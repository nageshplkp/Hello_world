class SiteMapContentType(object):

    def __init__(self):
        self.site_map_id = 0
        self.content_type_id = 0
