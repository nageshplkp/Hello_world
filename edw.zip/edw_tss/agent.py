import ast
import datetime
import getpass
import json
import logging
import Queue
import thread
import threading
import time

from core.common import mail
from core.rest.client import ClientException
from core.services.timeseries.ts_proxy import TsProxy
from etl.core.da_config import get_env
from etl.core.util import parse_args
from etl.repo.fnd_cfdw.d_ts_series import DTsSeriesRepo
from etl.repo.fnd_cfdw.stgp_f_ts_series import StgpFTsSeriesRepo
from sqlalchemy import or_

USAGE = ['PL TSS Agent',
         ['action', {'help': 'TSS_DATA'}],
         ['--worker_pool_size', dict(type=int, default=15, help='Number of parallel workers for data transfer')],
        ]


def _get_tss_base_url():

    # for testing purposes, lets stick to the same server. When committing, comment out the below line
    # return 'http://devpmwsv7:61000/timeseries/v1'

    return get_env()


class EdwTssDataTransferAgent(object):
    current_row_id = 0
    env = get_env()
    mail_from = None
    mail_to = None
    mode = None
    queue = Queue.Queue(maxsize=0)
    queue_max_size = 0
    queue_size_per_thread = 20
    save_retry_max = 5
    save_retry_timeout = 10
    svc_request_status_code_exclusions = ['NOT_FOUND']
    ts_proxy = TsProxy(base_url=_get_tss_base_url())
    username = getpass.getuser()
    workers = {}
    workers_lock = threading.Lock()
    workers_max_size = 0

    def __init__(self, mode, pool_size):
        self.mail_from = 'EDW_TSS_Agent-%s@pimco.com' % self.env
        self.mail_to = 'DAAlert-%s@pimco.com' % self.env
        self.mode = mode
        self.queue_max_size = pool_size * self.queue_size_per_thread
        self.workers_max_size = pool_size

    def _db_save_with_retry(self, thread_id, item, repo, retry_count):
        if retry_count > 0:
            logging.warn('EdwTssDataTransferAgent - Thread: %s, row id: %s, status: RETRY_SAVE, retry_count: %s'
                         % (thread_id, item.dw_row_id, retry_count))

        def save():
            repo.save(item)
            logging.info('EdwTssDataTransferAgent - Thread: %s, row id: %s, status: SAVED, retry_count: %s'
                         % (thread_id, item.dw_row_id, retry_count))

        t = threading.Thread(target=save)
        t.start()

        if t.is_alive():
            def cancel():
                pass

            timer = threading.Timer(self.save_retry_timeout, cancel)
            timer.start()

            while t.is_alive() and timer.is_alive():
                pass

            if not t.is_alive():
                timer.cancel()
            else:
                thread.start_new_thread(t.join)
                if retry_count < self.save_retry_max:
                    repo.db.session.expire_all()
                    return self._db_save_with_retry(thread_id, item, repo, retry_count + 1)

        return repo

    def _dequeue(self):
        # Allow time for the queue to populate if it's empty
        i = 1
        while self.queue.empty():
            time.sleep(0.5)
            i += 1
            if i == 10:
                return None

        item = self.queue.get()
        self.queue.task_done()
        return item

    def _queue_worker(self, repo):
        if self.queue.qsize() >= self.queue_max_size:
            return

        if self.queue.qsize() < self.queue_max_size:
            logging.info('EdwTssDataTransferAgent - populate_queue, status: STARTED, current size: %s' % self.queue.qsize())

            # Get records that:
            # 1)  Has not completed the svc call (is_svc_call_done = 0)
            # 2a) Row Id is greater than the max row id from the last pull
            #     Or
            # 2b) Update date is older than the retry date
            # 3)  Not in the exclusion status codes

            model = repo.model
            retry_datetime = datetime.datetime.now() - datetime.timedelta(minutes=30)

            items = repo.query\
                .filter(model.is_svc_call_done == 0,
                        or_(model.dw_row_id > self.current_row_id,
                            model.dw_update_date <= retry_datetime),
                        model.svc_request_status_code.notin_(self.svc_request_status_code_exclusions)) \
                .order_by(model.dw_row_id) \
                .limit(self.queue_max_size)\
                .all()

            count = items.__len__()

            if count <= 0:
                logging.info('EdwTssDataTransferAgent - populate_queue, status: FOUND %s' % count)

            else:
                for o in items:
                    self.queue.put(o)

                old_row_id = self.current_row_id
                self.current_row_id = max(o.dw_row_id for o in items)

                logging.info('EdwTssDataTransferAgent - populate_queue, status: FOUND %s, current size: %s, old row id: %s, new row id: %s'
                             % (count, self.queue.qsize(), old_row_id, self.current_row_id))

        if self.queue.qsize() > 0:
            # Create a queue worker to continuously try to ensure the queue has items
            t = threading.Timer(self.workers_max_size, self._queue_worker, args=[repo])
            t.start()

    def _worker(self, thread_id):
        logging.info('EdwTssDataTransferAgent - Thread: %s, status: STARTED' % (thread_id))
        repo = StgpFTsSeriesRepo()
        series_key_repo = DTsSeriesRepo()

        while 1:
            item = self._dequeue()

            if not item:
                logging.info('EdwTssDataTransferAgent - Thread: %s, status: ENDED' % (thread_id))
                self.workers_lock.acquire()
                self.workers.pop(thread_id)
                self.workers_lock.release()

            else:
                logging.info('EdwTssDataTransferAgent - Thread: %s, row id: %s, status: STARTED' % (thread_id, item.dw_row_id))
                error_message = None
                item.svc_response = None

                try:
                    obj = json.loads(item.svc_body)

                    resp = self.ts_proxy.post_obj('/series/update', obj)

                    svc_request_status_code = resp.update_code
                    status_code = svc_request_status_code
                    item.svc_response = json.dumps(ast.literal_eval(str(resp)))

                    logging.info('EdwTssDataTransferAgent - Thread: %s, row id: %s, status: TSS_POST_%s' % (thread_id, item.dw_row_id, status_code))

                    update_detail = resp.update_details[0]

                    if status_code == 'SUCCESS':
                        item.is_svc_call_done = 1

                    # else:
                    #     error_message = update_detail.message
                    #     logging.warn('EdwTssDataTransferAgent - Thread: %s, row id: %s, status: %s, key: %s, message: %s'
                    #                  % (thread_id, item.dw_row_id, update_detail.update_code, update_detail.request_id, update_detail.message))

                    if item.series_key <= 0:
                        series_key = series_key_repo.get_by_series_code(update_detail.request_id)
                        if series_key:
                            item.series_key = series_key.series_key

                except ClientException as e:
                    logging.warn('EdwTssDataTransferAgent - Thread: %s, row id: %s, status: HTTP_EXCEPTION' % (thread_id, item.dw_row_id))
                    svc_request_status_code = 'RESPONSE'
                    status_code = e.detail_json['status']
                    error_message = e.detail_json['reason']
                    item.svc_response = json.dumps(ast.literal_eval(str(e.detail_json)))

                except ValueError as e:
                    logging.warn('EdwTssDataTransferAgent - Thread: %s, row id: %s, status: INVLD_JSON, field: SVC_BODY, message: %s' % (thread_id, item.dw_row_id, e.message))
                    svc_request_status_code = 'FAILURE'
                    status_code = 'INVALID_JSON'
                    error_message = e.message
                    item.is_svc_call_done = 2
                    item.svc_response = json.dumps({'status:': status_code, 'field:': 'SVC_BODY', 'reason': error_message})

                except Exception as e:
                    logging.warn('EdwTssDataTransferAgent - Thread: %s, row id: %s, status: EXCEPTION' % (thread_id, item.dw_row_id))
                    svc_request_status_code = 'FAILURE'
                    status_code = 'EXCEPTION'
                    error_message = e.message
                    item.svc_response = json.dumps({'status:': status_code, 'reason': error_message})

                item.svc_request_status_code = svc_request_status_code
                item.dw_update_by = self.username
                item.dw_update_date = datetime.datetime.now()

                try:
                    repo = self._db_save_with_retry(thread_id, item, repo, 0)
                except Exception as e:
                    logging.warn('EdwTssDataTransferAgent - Thread: %s, row id: %s, status: SAVE_DB_EXCEPTION, message: %s' % (thread_id, item.dw_row_id, e.message))
                    status_code = 'SAVE_DB_EXCEPTION'
                    error_message = e.message

                if error_message:
                    mail.send_mail(self.mail_from, self.mail_to, subj='(%s)%s error' % (self.env, status_code), msg=error_message)

    def run(self):
        logging.info('EdwTssDataTransferAgent - status: STARTED')

        # Load the initial queue
        self._queue_worker(StgpFTsSeriesRepo())

        # Create the workers if there are items in the queue
        if self.queue.qsize() > 0:
            self.workers_lock.acquire()
            for i in range(self.workers_max_size):
                worker = threading.Thread(target=self._worker, args=(i,))
                # worker.setDaemon(True)
                worker.start()
                self.workers[i] = worker
            self.workers_lock.release()

            while self.workers.__len__() > 0:
                pass

        logging.info('EdwTssDataTransferAgent - status: ENDED')


if __name__ == '__main__':
    args = parse_args(*USAGE)
    action = args.action.upper()
    if action in ('TSS_DATA'):
        agent = EdwTssDataTransferAgent(action, args.worker_pool_size)
    else:
        raise RuntimeError('Unknown action specified: {}'.format(action))

    agent.run()