#!/bin/bash
export appenv=${appenv:='dev'}
export ETL_ENV=$appenv

USAGE="USAGE: source $(basename $0) [dev|alpha|beta|prod]"

if [[ -z "$1" ]]; then
    echo "Defaulting to '$appenv' appenv, $USAGE"
else
    appenv=$1
    ETL_ENV=$1
fi
echo 'appenv='$appenv

. /appl/pimbeta/pimco_common/pypimco/env.new.sh $appenv
PYTHONPATH=${PYTHONPATH}:/appl/pimdev/pimco_common/pypimco_infra/anaconda_linux/lib/python2.7/site-packages

[[ -e venv ]] || virtualenv venv
. venv/bin/activate
pip install -r requirements.txt

