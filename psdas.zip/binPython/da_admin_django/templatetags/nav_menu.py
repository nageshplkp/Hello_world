from django import template
register = template.Library()


def _get_app(all_models, app_label):
    return None if not app_label else\
        next((app for app in all_models if app['app_label'].lower() == app_label.lower()), None)


def _get_app_models(all_models, app, model_name = None, exclude_models = None):
    if not app:
        return []
    else:
        app_label = app['app_label']
        exclude_models = exclude_models.lower().split(',') if exclude_models else []

        # Check if this app was excluded
        if '{0}.*'.format(app_label) in exclude_models:
            return []

        if not model_name or model_name == '*':
            models = app['models']
        else:
            models = [model
                      for model in app['models']
                      if model['object_name'].lower() == model_name.lower()]

        return [_to_menu_item(app_label, model)
                for model in models
                # Check if this model or app + model was excluded
                if model['object_name'].lower() not in exclude_models
                and '{0}.{1}'.format(app_label, model['object_name'].lower()) not in exclude_models]


def _get_menu_item_models(all_models, site_map):
    models = []

    if site_map.app_label:
        values = site_map.app_label.split('.')
        app_label = values[0]

        if app_label.lower() == 'apps':
            # All Apps
            for app in all_models:
                app_label2 = app['app_label']
                if app_label2 != 'auth':
                    # Exclude Auth app
                    model = _to_menu_item(app_label2, app)
                    model.site_maps = _get_app_models(all_models, app, None, site_map.exclude_models)
                    if model.site_maps.__len__() > 0:
                        models.append(model);

        else:
            # Specific App
            app = _get_app(all_models, app_label)
            if app:
                site_map.url = _get_native_model_url(app)
                models += _get_app_models(
                    all_models,
                    app,
                    values[1] if values.__len__() >= 2 else None,
                    site_map.exclude_models)

    for content_type in site_map.content_types:
        app = _get_app(all_models, content_type.app_label)
        models += _get_app_models(all_models, app, content_type.model)

    return models


def _get_native_model_name(model):
    """
    Get model name by its last part of url
    """
    from django.core.urlresolvers import reverse, resolve

    url_parts = _get_native_model_url(model).rstrip('/').split('/')
    root_url_parts = reverse('admin:index').rstrip('/').split('/')
    return '.'.join(url_parts[len(root_url_parts):][:2])


def _get_native_model_url(model):
    return model.get('url', model.get('app_url', model.get('admin_url', model.get('add_url', ''))))


def _to_menu_item(app_label, item):
    if isinstance(item, dict):
        menu_item = type('', (), {})()
        menu_item.app_label = app_label
        menu_item.icon = item.get('icon', None)
        menu_item.name = _get_native_model_name(item)
        menu_item.title = item.get('name', app_label.upper())
        menu_item.url = _get_native_model_url(item)
        menu_item.add_url = item.get('add_url', None)
        menu_item.perms = item.get('perms', None)

    else:
        menu_item = item

    menu_item.blank = True if menu_item.url and menu_item.url.startswith('http') else None

    return menu_item


def cleanup_menu_item(items):
    for o in items[::-1]:
        if not hasattr(o, 'site_maps'):
            continue

        # Recursive cleanup
        cleanup_menu_item(o.site_maps)

        # Merge content_types with site_maps
        o.site_maps += o.content_types

        # Remove empty menu
        if o.site_maps.__len__() == 0 and (not o.url or o.app_label):
            items.remove(o)


def process_menu_item(all_models, site_map):
    if site_map.title == '-':
        site_map = type('', (), {})()
        site_map.parent_id = None
        site_map.title = None
        return site_map

    else:
        site_map.content_types = _get_menu_item_models(all_models, site_map)

        if not hasattr(site_map, 'site_maps'):
            site_map.site_maps = []

        return _to_menu_item(site_map.app_label, site_map)


@register.assignment_tag(takes_context=True)
def get_menu(context, request):
    from django.apps import apps
    from suit.templatetags.suit_menu import get_admin_site

    template_response = get_admin_site(request.current_app).index(request)
    app_list = template_response.context_data['app_list']
    if app_list.__len__() == 0:
        return []

    site_maps = list(apps.get_model('pim_de', 'DjangoSiteMap').objects.order_by('parent_id', 'sort_order', 'id').all())
    if site_maps.__len__() == 0:
        return []

    site_map_content_types = list(apps.get_model('pim_de', 'DjangoSiteMapContentType').objects
                                  .order_by('sort_order', 'id')
                                  .select_related('content_type_id')
                                  .all())

    menu_items = []

    for site_map in site_maps:
        site_map.content_types = [
            o.content_type_id
            for o in site_map_content_types
            if o.site_map_id_id == site_map.id
        ]

        site_map = process_menu_item(app_list, site_map)
        if site_map:
            # Attach to parent
            if hasattr(site_map, 'parent_id_id') and site_map.parent_id_id:
                parent = next(o for o in site_maps if o.id == site_map.parent_id_id)
                site_map.parent_id = parent

                if not hasattr(parent, 'site_maps'):
                    parent.site_maps = [site_map]
                else:
                    parent.site_maps.append(site_map)
            else:
                site_map.parent_id_id = 0
                menu_items.append(site_map)

    cleanup_menu_item(menu_items)

    return menu_items

