# coding=utf-8
from __future__ import unicode_literals
import importlib
import os
import sys


def get_attr(namespace, name=None):
    try:
        module = importlib.import_module(namespace)
        return module if not name else getattr(module, name, None)
    except:
        return None


def get_folder_name(file_path):
    path = get_folder_path(file_path)

    parts = path.split('/')

    return parts[parts.__len__() - 1]


def get_folder_path(file_path):
    # Get the path to the folder containing the class
    file_path = os.path.abspath(file_path)[os.path.abspath('.').__len__():]
    path, filename = os.path.split(file_path)

    return path.replace('\\', '/')


def get_folder_path_as_module(file_path):
    path = get_folder_path(file_path)
    return to_module_path(path)


def has_attr(namespace, name=None):
    try:
        module = importlib.import_module(namespace)
        return True if not name else hasattr(module, name)
    except:
        return False


def to_module_path(path):
    return path.replace('\\', '/').lstrip('/').replace('/', '.').replace('..', '')


def override_extend(derived_instance):
    derived_module_name = derived_instance.__class__.__module__

    # Get the full path to the file containing the derived class
    derived_class_file = sys.modules[derived_module_name].__file__

    # Get the path to the folder containing the derived class
    # Get the filename containing the derived class
    derived_class_path, derived_class_filename = os.path.split(derived_class_file)

    # Check if there is an override file
    override_file = '{0}/overrides/{1}.py'.format(derived_class_path, os.path.splitext(derived_class_filename)[0]).replace('\\', '/')
    if not os.path.isfile(override_file):
        return

    import warnings
    warnings.filterwarnings('ignore',
                            category=RuntimeWarning,
                            message='^Parent module \'.*\' not found while handling .*$')

    # Load the override file
    override_name = '.overrides'.join(os.path.splitext(derived_module_name))
    override_module = importlib.import_module(override_name)

    # The class to override/extend
    class_name = derived_instance.__class__.__name__

    if override_module.__dict__.has_key(class_name):
        override_class = override_module.__dict__[class_name]
        override_dict = override_class.__dict__

        for key, value in override_dict.iteritems():
            if not key.startswith('__'):
                setattr(derived_instance.__class__, key, override_dict[key])


class OverridableBase(object):
    def __init__(self):
        super(OverridableBase, self).__init__()
        override_extend(self)
        if hasattr(self, 'on_override'):
            self.on_override()
