import ast
import json
from django.utils.html import format_html, escape
from cx_Oracle import LOB


def _json_to_readonly_html(value):

    try:
        if isinstance(value, LOB):
            value = str(value)

        value = json.loads(value)
    except:
        try:
            value = ast.literal_eval(value)
        except:
            return ''

    return json.dumps(value, indent=4) if value else ''


def code_to_html_readonly(value, code_mode):
    if not value:
        return ''

    code = None

    if code_mode == 'js' or code_mode == 'json':
        code = _json_to_readonly_html(value)

    return format_html('<div data-code-area="{}">{}</div>', code_mode, escape(code)) if code else value
