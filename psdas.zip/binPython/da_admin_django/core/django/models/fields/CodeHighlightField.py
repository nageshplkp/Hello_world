from __future__ import unicode_literals
from django.db import models as md
from django.utils.translation import ugettext_lazy as _
from core.helpers.code_to_html import code_to_html_readonly


class CodeHighlightField(md.TextField):
    code_mode = None
    description = _("CodeHighlight")

    def get_internal_type(self):
        return "CodeHighlightField"

    def formfield(self, **kwargs):
        defaults = {}
        defaults.update(kwargs)
        form = super(CodeHighlightField, self).formfield(**defaults)
        form.widget.attrs['data-code-area'] = self.code_mode
        return form

    def value_to_html_readonly(self, value):
        return code_to_html_readonly(value, self.code_mode)
