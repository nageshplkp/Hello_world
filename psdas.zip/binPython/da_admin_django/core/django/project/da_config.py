from ConfigParser import SafeConfigParser
import os


def get_env():
    app_env = os.environ.get('appenv')
    return 'dev' if app_env is None else app_env

def get_etl_cfg(env=None):
    env = env or get_env()
    return read_cfg('etl_%s.conf' % (env,))

def get_db_cfg():
    return read_cfg('da_conn.ini')

def read_cfg(cfg_name):
    cfg_path = os.path.join(get_config_path(), cfg_name)
    cfg = SafeConfigParser()
    cfg.optionxform = str
    cfg.read(cfg_path)
    return cfg2dict(cfg)

def get_config_path():
    return os.environ.get('DA_CONFIG_DIR')

def cfg2dict(cfg):
    return {section: dict(cfg.items(section)) for section in cfg.sections()}
