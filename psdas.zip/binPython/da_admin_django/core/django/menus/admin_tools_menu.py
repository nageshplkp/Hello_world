try:
    from django.urls import reverse
except ImportError:
    from django.core.urlresolvers import reverse
from django.utils.translation import ugettext_lazy as _
from admin_tools.menu import items, Menu

from .mock.admin_tools_menu import *


class AdminToolsMenu(Menu):

    def __init__(self, **kwargs):
        super(Menu, self).__init__(**kwargs)

        self.children = [
            items.MenuItem('Dashboard', reverse('admin:index')),
            items.Bookmarks,
            items.AppList(_('Applications'), exclude=('django.contrib.*',)),
        ]

        menuItems = {}

        # Create the ModelList menu item
        for item in siteMapContentTypes:

            if menuItems.has_key(item.site_map_id):
                menuItem = menuItems[item.site_map_id]
            else:
                siteMap = siteMaps[item.site_map_id]
                menuItem = items.ModelList(siteMap.title, [])
                menuItems[item.site_map_id] = menuItem

            contentType = contentTypes[item.content_type_id]

            if contentType.app_label == 'da_app':
                menuItem.models.append("{0}.models.{1}.{1}".format(contentType.app_label, contentType.model))
            else:
                menuItem.models.append("{0}.models.{1}".format(contentType.app_label, contentType.model))

        # Add the MenuItems
        for key, value in siteMaps.iteritems():

            # Create the menu item if it doesn't exist
            if menuItems.has_key(value.id):
                menuItem = menuItems[value.id]
            else:
                menuItem = items.MenuItem(title=value.title, url=value.url, children=[])
                menuItems[value.id] = menuItem

            if value.id == 1:
                pass
            elif value.parent_id == 1:
                # Add as top level menu
                self.children.append(menuItem)
            else:
                # Add to parent
                menuItems[value.parent_id].children.append(menuItem)

        self.children.append(items.AppList(_('Administration'), models=('django.contrib.*',)))

#    class Media:
#        css = {'all': ()}
#        js = ()




