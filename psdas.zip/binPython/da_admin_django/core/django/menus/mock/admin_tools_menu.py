from ..models import *

# =================================
contentTypes = {}

contentType = ContentType()
contentType.id = 1
contentType.app_label = 'da_app'
contentType.model = 'CdatGroup'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 2
contentType.app_label = 'da_app'
contentType.model = 'CdatMatrix'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 3
contentType.app_label = 'da_app'
contentType.model = 'CdatMeasure'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 4
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlConfig'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 5
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlDatePart'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 6
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlEmailSource'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 7
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlFile'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 8
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlFileSource'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 9
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlFileSourceDefault'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 10
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlFtpProtocol'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 11
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlHttpSource'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 12
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlJobCriticality'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 13
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlSource'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 14
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlSourceGroup'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 15
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlSourceProvider'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 16
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlFilterType'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 17
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlFilter'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 18
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlBbgProgram'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 19
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlBbgSource'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 20
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlBbgSrc'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 21
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlBbgTicker'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 22
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlBbgYellowKey'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 23
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlBbgInstrmnt'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 24
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlBbgMnemonic'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 25
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlBbgOption'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 26
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlSourceInBbgInstrmnt'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 27
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlSourceInBbgMnemonic'
contentTypes[contentType.id] = contentType

contentType = ContentType()
contentType.id = 28
contentType.app_label = 'cfdw_app'
contentType.model = 'EtlSourceInBbgOption'
contentTypes[contentType.id] = contentType
# =================================

# =================================
siteMaps = {}

siteMap = SiteMap()
siteMap.id = 1
siteMap.parent_id = 0
siteMap.title = 'Admin Tools'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 2
siteMap.parent_id = 1
siteMap.title = 'Custom Menu 1'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 3
siteMap.parent_id = 2
siteMap.title = 'CDAT'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 4
siteMap.parent_id = 2
siteMap.title = 'Data Warehouse - ETL'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 5
siteMap.parent_id = 2
siteMap.title = 'Data Warehouse - ETL Bloomberg'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 6
siteMap.parent_id = 2
siteMap.title = 'Index Solutions - Vendors and Mappings'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 7
siteMap.parent_id = 2
siteMap.title = 'Index Solutions - Vendor Files and Formats'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 8
siteMap.parent_id = 2
siteMap.title = 'Index Solutions - Vendor File Instances and Data'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 9
siteMap.parent_id = 2
siteMap.title = 'Index Solutions - Miscellaneous'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 10
siteMap.parent_id = 1
siteMap.title = 'Custom Menu 2'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 11
siteMap.parent_id = 10
siteMap.title = 'CDAT'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 12
siteMap.parent_id = 10
siteMap.title = 'Data Warehouse'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 13
siteMap.parent_id = 12
siteMap.title = 'ETL'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 14
siteMap.parent_id = 12
siteMap.title = 'ETL Bloomberg'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 15
siteMap.parent_id = 10
siteMap.title = 'Index Solutions'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 16
siteMap.parent_id = 15
siteMap.title = 'Vendors and Mappings'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 17
siteMap.parent_id = 15
siteMap.title = 'Vendor Files and Formats'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 18
siteMap.parent_id = 15
siteMap.title = 'Vendor File Instances and Data'
siteMaps[siteMap.id] = siteMap

siteMap = SiteMap()
siteMap.id = 19
siteMap.parent_id = 15
siteMap.title = 'Miscellaneous'
siteMaps[siteMap.id] = siteMap
# =================================

# =================================
siteMapContentTypes = []

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 3
siteMapContentType.content_type_id = 1
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 3
siteMapContentType.content_type_id = 2
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 3
siteMapContentType.content_type_id = 3
siteMapContentTypes.append(siteMapContentType)


siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 4
siteMapContentType.content_type_id = 4
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 4
siteMapContentType.content_type_id = 5
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 4
siteMapContentType.content_type_id = 6
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 4
siteMapContentType.content_type_id = 7
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 4
siteMapContentType.content_type_id = 8
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 4
siteMapContentType.content_type_id = 9
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 4
siteMapContentType.content_type_id = 10
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 4
siteMapContentType.content_type_id = 11
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 4
siteMapContentType.content_type_id = 12
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 4
siteMapContentType.content_type_id = 13
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 4
siteMapContentType.content_type_id = 14
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 4
siteMapContentType.content_type_id = 15
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 4
siteMapContentType.content_type_id = 16
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 4
siteMapContentType.content_type_id = 17
siteMapContentTypes.append(siteMapContentType)


siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 5
siteMapContentType.content_type_id = 18
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 5
siteMapContentType.content_type_id = 19
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 5
siteMapContentType.content_type_id = 20
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 5
siteMapContentType.content_type_id = 21
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 5
siteMapContentType.content_type_id = 22
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 5
siteMapContentType.content_type_id = 23
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 5
siteMapContentType.content_type_id = 24
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 5
siteMapContentType.content_type_id = 25
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 5
siteMapContentType.content_type_id = 26
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 5
siteMapContentType.content_type_id = 27
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 5
siteMapContentType.content_type_id = 28
siteMapContentTypes.append(siteMapContentType)


siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 11
siteMapContentType.content_type_id = 1
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 11
siteMapContentType.content_type_id = 2
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 11
siteMapContentType.content_type_id = 3
siteMapContentTypes.append(siteMapContentType)


siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 13
siteMapContentType.content_type_id = 4
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 13
siteMapContentType.content_type_id = 5
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 13
siteMapContentType.content_type_id = 6
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 13
siteMapContentType.content_type_id = 7
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 13
siteMapContentType.content_type_id = 8
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 13
siteMapContentType.content_type_id = 9
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 13
siteMapContentType.content_type_id = 10
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 13
siteMapContentType.content_type_id = 11
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 13
siteMapContentType.content_type_id = 12
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 13
siteMapContentType.content_type_id = 13
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 13
siteMapContentType.content_type_id = 14
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 13
siteMapContentType.content_type_id = 15
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 13
siteMapContentType.content_type_id = 16
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 13
siteMapContentType.content_type_id = 17
siteMapContentTypes.append(siteMapContentType)


siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 14
siteMapContentType.content_type_id = 18
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 14
siteMapContentType.content_type_id = 19
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 14
siteMapContentType.content_type_id = 20
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 14
siteMapContentType.content_type_id = 21
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 14
siteMapContentType.content_type_id = 22
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 14
siteMapContentType.content_type_id = 23
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 14
siteMapContentType.content_type_id = 24
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 14
siteMapContentType.content_type_id = 25
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 14
siteMapContentType.content_type_id = 26
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 14
siteMapContentType.content_type_id = 27
siteMapContentTypes.append(siteMapContentType)

siteMapContentType = SiteMapContentType()
siteMapContentType.site_map_id = 14
siteMapContentType.content_type_id = 28
siteMapContentTypes.append(siteMapContentType)
# =================================
