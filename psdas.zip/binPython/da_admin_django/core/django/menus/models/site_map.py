class SiteMap(object):

    def __init__(self):
        self.id = 0
        self.parent_id = 0
        self.title = None
        self.url = None

    def __unicode__(self):
        return self.title