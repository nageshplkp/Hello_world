$(function() {
    var body = $('body');

    $('.multiselect').each(function() {
        var parent = $(this);
        var selectContainer = parent.find('>:first-child');
        var select = selectContainer.find('select');
        var options = parent.find('.options');
        var checkboxes = options.find('input[type=checkbox]')
        var option = $('<option/>').prop('selected', true);
        var fieldName = select.data('name');
        var fieldTitle = select.data('title');

        // Add a default option placeholder
        select
            .find('option').remove()
            .end().append(option);

        // Click event to cancel closing current drop down if child is clicked vs body
        parent.on('click', function(e) {
            e.stopPropagation();
            return $(this).find(e.target).length >= 0;
        });

        // Prevent the select drop down from showing
        select.on('focus mousedown', function(e) {
            if (e.stopPropagation) {
                e.stopPropagation();
                e.preventDefault();
            }
        });

        // Update the text of the select drop down
        var updateSelectOption = function() {
            var checkedItems = checkboxes.filter(':checked');

            var text = '';
            var value = '';
            switch (checkedItems.length) {
                case 0:
                    text = fieldTitle;
                    select.removeAttr('name');
                    break;
                case 1:
                    text = checkedItems.val();
                    value = text;
                    if (text === '') { text = '1 selected'; }
                    text = fieldTitle+ ': ' + text;
                    break;
                default:
                    text = fieldTitle+ ': ' + checkedItems.length + ' selected';
                    value = checkedItems.map(function() { return this.value; }).get().join(',');
            }

            if (checkedItems.length > 0 && select.prop('name') === '') {
                select.prop('name', fieldName + '__in');
            }

            option.text(text).val(value);
        };
        updateSelectOption();
        select.removeAttr('name');

        // Add click event to the select container
        parent.toggleExpand = function(e) {
            if (options.hasClass('expanded')) {
                body.off('click', parent.toggleExpand);

                parent.removeClass('expanded');
                options.removeClass('expanded');
            } else {
                body.trigger('click');

                options.css({
                    top: selectContainer.outerHeight(),
                    width: selectContainer.outerWidth()
                        - parseInt(options.css('padding-left'))
                        - parseInt(options.css('padding-right'))
                });

                parent.addClass('expanded');
                options.addClass('expanded');

                body.on('click', parent.toggleExpand);
            };
        };
        selectContainer.on('click', parent.toggleExpand);

        // Add checked event to the select container
        checkboxes.on('change', updateSelectOption);
    });
});
