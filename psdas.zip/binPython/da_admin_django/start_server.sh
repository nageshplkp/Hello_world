#!/bin/bash

DJANGOPORT=8000
appenv=${appenv:='dev'}
LOGFILE=logs/$(date +"%Y%m%d_%H%M%S").log

[[ -z $1 ]] || appenv=$1
[[ -z $2 ]] || DJANGOPORT=$2

source env.sh $appenv
[[ -d logs ]] || mkdir -p logs
echo "Starting Django on port $DJANGOPORT; Loging to $LOGFILE"
python ./manage.py runserver 0.0.0.0:$DJANGOPORT |& tee $LOGFILE
deactivate
