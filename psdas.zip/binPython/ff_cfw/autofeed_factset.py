import datetime
import getpass
import logging
import os
import sys
from subprocess import call, check_output, CalledProcessError

from core.common import mail
from etl.core.da_config import get_env
from etl.core.util import parse_args
from etl.repo.fnd_cfdw import EtlFileRepo, VetlFileSourceDefaultRepo

USAGE = ['FactSet Consolidation Process',
         ['file_source_code', {'help': 'ETL metadata file source code'}]]

HEADER_ROW_TAG = '"PIMCO CUSIP"'
TOTAL_ROW_TAG = ',,"Total"'


class AutofeedFactset(object):
    def __init__(self, source_code):
        self._sqla_logger = logging.getLogger('sqlalchemy')
        self._sqla_logger.propagate = False
        self.source_code = source_code
        self._rtn = 100
        self._exceptions = []
        self._file_errors = []
        self.defaults = None

    def run(self):
        self.defaults = VetlFileSourceDefaultRepo.instance.get_by_file_source_code(self.source_code)
        if not self.defaults:
            raise RuntimeError("Cannot get defaults for source code '{}'".format(self.source_code))
        tag_files = self.get_tag_files(self.defaults.ftp_ls_cmd_template)
        for tag_file in tag_files:
            expected_files = self.get_file_list_from_tag(os.path.join(self.defaults.ftp_file_folder, tag_file))
            data = []
            header = None
            all_files_exist = True
            for f in expected_files:
                try:
                    f_data = self.get_data_from_file(os.path.join(self.defaults.ftp_file_folder, f))
                    if f_data[2]:
                        self._file_errors.append("WARNING!!\nError in file {}:{}\n".format(f, f_data[2]))
                except IOError:
                    all_files_exist = False
                    break
                if not header and f_data[0]:
                    header = f_data[0]
                if f_data[1].strip():
                    data.append(f_data[1])
            if not all_files_exist:
                continue
            if header:
                data.insert(0, header)
            csv_file_name = '{}.{}.csv'.format(self.source_code.lower(), datetime.datetime.now().strftime(
                '%Y%m%d_%H%M%S'))
            self.write_to_csv(os.path.join(self.defaults.local_file_folder, csv_file_name), data)
            EtlFileRepo.instance.save(self.create_etl_file(self.defaults, csv_file_name))
            self._rtn = 0
            if self.defaults.is_ftp_done == 0:
                expected_files.append(tag_file)
                try:
                    self.move_processed_files(self.defaults.ftp_cmd_template, expected_files)
                except RuntimeError as e:
                    self._exceptions.append("Error moving files associated with {} - {}".format(tag_file, e.message))
        if len(self._file_errors) > 0:
            self.send_file_errors(self.defaults.notify_email_dl, self._file_errors)
        if len(self._exceptions) > 0:
            raise RuntimeError(self._exceptions)
        sys.exit(self._rtn)

    @staticmethod
    def get_tag_files(ls_cmd):
        try:
            ls_output = check_output(ls_cmd, shell=True)
        except CalledProcessError as e:
            if e.returncode == 1 or e.returncode == 2:
                ls_output = ''
            else:
                raise RuntimeError("Error! get_tag_files - Command returned error ({}): {} [{}]".format(
                    e.returncode, e.output, e.cmd))
        return [i for i in (ls_output or '').strip().splitlines() if not (i == '.' or i == '..')]

    @staticmethod
    def get_file_list_from_tag(file_path):
        with open(file_path) as f:
            return [i.strip().split(',')[0] for i in f.readlines()]

    @staticmethod
    def get_data_from_file(file_path):
        header = ''
        totals = ''
        error = ''
        prev_data = ''
        with open(file_path) as f:
            data = f.readlines()
        for line in data:
            if line.startswith(TOTAL_ROW_TAG):
                totals = line
            elif line.startswith(HEADER_ROW_TAG):
                header = line
            elif line.strip():
                prev_data = line
            if header and totals:
                error = ''
                break
        if not header and not totals:
            error = prev_data
        return header, totals, error

    @staticmethod
    def write_to_csv(target_file, data):
        with open(target_file, 'wb') as output:
            output.writelines(data)

    @staticmethod
    def create_etl_file(defaults, file_name):
        rtn = EtlFileRepo.instance.EtlFile()
        rtn.is_enabled = 1
        rtn.scheduled_pickup_date = datetime.datetime.now() + datetime.timedelta(minutes=-30)
        rtn.is_ftp_done = 1
        rtn.is_etl_done = defaults.is_etl_done
        rtn.file_source = defaults.file_source_code
        rtn.file_yyyymmdd = datetime.date.today().strftime('%Y%m%d')
        rtn.file_frequency = 'V'
        rtn.ftp_server_name = defaults.ftp_server_name
        rtn.ftp_user_name = defaults.ftp_user_name
        rtn.ftp_password = defaults.ftp_password
        rtn.ftp_file_folder = defaults.ftp_file_folder
        rtn.ftp_file_name = file_name
        rtn.local_file_folder = defaults.local_file_folder
        rtn.local_file_name = file_name
        rtn.supplier_email_address = defaults.supplier_email_address
        rtn.log_file_path = defaults.log_file_path_template
        rtn.action_on_error = defaults.action_on_error
        rtn.dw_insert_by = 'Python FactSetAutoFeed'
        rtn.dw_insert_date = datetime.datetime.now()
        rtn.dw_update_by = 'Python FactSetAutoFeed'
        rtn.dw_update_date = datetime.datetime.now()
        rtn.port_no = defaults.port_no
        if defaults.pre_ftp_cmd_template:
            rtn.pre_ftp_cmd = defaults.pre_ftp_cmd_template.replace('##FTP_FILE_NAME##', file_name)
        if defaults.ftp_cmd_template:
            rtn.ftp_cmd = defaults.ftp_cmd_template.replace('##FTP_FILE_NAME##', file_name)
        if defaults.post_ftp_cmd_template:
            rtn.post_ftp_cmd = defaults.post_ftp_cmd_template.replace('##FTP_FILE_NAME##', file_name).replace(
                '##LOCAL_FILE_NAME##', file_name)
        rtn.file_cutoff_date = datetime.datetime.now() + datetime.timedelta(minutes=60)
        return rtn

    def send_file_errors(self, notify_address, errors):
        subj = "[{}]{} - File Errors - {}".format(get_env().upper(), self.defaults.file_source_code,
                                                  datetime.date.today().strftime('%Y%m%d'))
        mail.send_mail(mailFrom=getpass.getuser(), mailTo=notify_address, subj=subj, msg='\n'.join(errors))

    @staticmethod
    def move_processed_files(ftp_template, file_list):
        for f in file_list:
            cmd = ftp_template.replace('##FTP_FILE_NAME##', f)
            call(cmd, shell=True)


if __name__ == '__main__':
    AutofeedFactset(parse_args(*USAGE).file_source_code).run()
