#!/bin/bash

export PYTHONPATH=`pwd -P`

export BLPAPI=/appl/coreservicebeta/blpapi/cpp/current
export PYTHON_279="/appl/pm/vendor/python/lx-x86_64/2.7.9"
export MONGODB="/appl/pm/vendor/mongodb/lx-x86_64/2.6.1/src/mongodb-linux-x86_64-2.6.1/bin"
export SYBASE="/appl/toolbox/linux/sybase"
export ORACLE_HOME=/appl/pm/vendor/oracle/lx-x86_64/product/11.2.0/client_1
export LD_LIBRARY_PATH="$PYTHON_279/lib:$ORACLE_HOME/lib:$LD_LIBRARY_PATH"
#export PATH="$PYTHON_279/bin:$PATH:$MONGODB"
export LD_LIBRARY_PATH="$ORACLE_HOME/lib:$PYTHON_279/lib:$LD_LIBRARY_PATH:/appl/pm/vendor/gsl/lx-x86_64/1.15/lib:$GCC_HOME/lib64:$SYBASE/OCS-15_0/lib:$BLPAPI/Linux"
export PATH="$ORACLE_HOME/bin:/appl/pm/vendor/git/bin:$PYTHON_279/bin:$PATH:$GCC_HOME/bin:$MONGODB:$BLPAPI"

export PYTHONPATH=/appl/pimdev/pimco_common/pypimco:.

if [ -z "$1" ]
then
    export appenv=dev
    export ETL_ENV=dev
else
    export appenv=$1
    export ETL_ENV=$1
fi

echo 'appenv='$appenv


