from dbmodels import dais_own
from proxies.bbg import DataLicenseBbgProxy


class BbgManager:
    """
    Bloomberg manager - orchestrates bloomberg integration
    """
    def __init__(self, context):
        """
        Manager constructor

        args:
            context (PipelineContext): Instance containing pipeline execution context.
        """
        self.context = context

    def get_securities(self, securities, request_type):
        """
        Get Bloomberg securities

        args:
            securities(list): List of security details
            request_type(str): Bloomberg request type (i.e. STG, PRC, etc)
        """
        mnemonics = self.get_mnemonics(request_type)
        return self.get_proxy_instance().get_securities(securities, mnemonics)

    def get_mnemonics(self, request_type):
        """
        Get mnemonics based on request type

        args:
            request_type(str): Bloomberg request type (i.e. STG, PRC, etc)
        """
        # Get list of bbg field names associated to request type
        results = self.context.session_pim.query(dais_own.BbgFieldInRequestType) \
                      .join(dais_own.BbgFieldInRequestType.bbg_field) \
                      .filter(dais_own.BbgFieldInRequestType.bbg_request_type_code == request_type) \
                      .order_by(dais_own.BbgFieldInRequestType.sort_sequence)

        #print 'sql: {0}'.format(results)

        return [field.bbg_field.bbg_field_name for field in results]

    def get_proxy_instance(self):
        """
        Proxy factory method - determines which proxy to use, currently always uses 
        data license implementation
        """
        return DataLicenseBbgProxy(self.context.config)

