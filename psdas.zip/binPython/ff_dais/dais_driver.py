#!/usr/bin/env python
import os
import sys
import logging
import copy

from datetime import datetime
from etl.core import util
from etl.core import da_config
from etl.core.db import ora_xxx
from pipeline.pipeline import PipelineManager, PipelineContext

logging.getLogger('sqlalchemy.engine').setLevel(logging.WARN)


class DaisDriver:
    """
    Main driver for Dais batch processing.
    """

    def __init__(self, logger=None, options=None):
        """ 
        Displays auditing  details, retrieves  configuration info, captures
        etl_audit_id and connects to Oracle databases.
        """

        self.log = logger or logging.getLogger("{}".format(
            os.path.splitext(os.path.basename(__file__))[0]))

        try:
            # Display auditing details
            self.start_time = datetime.now()
            self.end_time = None

            self.options = copy.deepcopy(
                vars(options) if options is not None else dict())
            self.default_config = da_config.get_etl_cfg()
            self.config = copy.deepcopy(self.default_config)
            self.config.update(self.options)

            level_name = self.config.get('log_level')
            if not level_name:
                level_name = self.config.get('dais').get('log_level', 'INFO')

            level = logging.getLevelName(level_name)
            os.environ['PYPIMCO_LOG_LEVEL_OVERRIDE'] = level_name
            from core.log import log_config
            log_config.init_logging(None, True)
            self.log.setLevel(level)

            formatter = logging.Formatter(
                '%(asctime)s %(threadName)s:%(thread)d %(name)s %(levelname)s %(message)s')

            logger = logging.getLogger('')
            for handler in logger.handlers:
                handler.setFormatter(formatter)

            self.log.info("DAIS Driver started at %s", self.start_time)

            # Try command line argument first --audit-id & --source-group-code
            self.etl_audit_id = self.options.get('audit_id')
            self.etl_source_group_code = self.options.get('source_group_code')

            # Use environment variable param if command line
            # for audit id is not set
            if self.etl_audit_id is None:
                # Capture etl audit id. This id is created by etl wrapper script
                # and saved to the ETL_AUDIT_ID environment variable
                self.etl_audit_id = os.environ.get('ETL_AUDIT_ID')

            if self.etl_source_group_code is None:
                # Use default value as IDS_GRP
                self.etl_source_group_code = 'IDS_GRP'

            # make sure audit id type is int
            # make sure audit id type is int
            self.etl_audit_id = self.etl_audit_id if self.etl_audit_id \
                else self.etl_audit_id

            self.etl_audit_id = int(self.etl_audit_id)
            self.log.info("ETL_AUDIT_JOB_ID: %s", self.etl_audit_id)

            # for RDS requests
            self.requestor = "PBOGIE"
            self.req_idx_tpl = "dais_sw_{}"
            # Get configuration info and connect to PIM and FND Oracle databases
            # self.config = Config()
            self.oradb_pim = ora_xxx('DAIS_OWN', 'ORAPIM_DBP')
            self.oradb_fnd = ora_xxx('CFDW_OWN', 'ORAFND_DBP')

            # Build pipeline context
            self.context = PipelineContext(self.config, self.etl_audit_id,
                                           self.requestor,
                                           self.req_idx_tpl,
                                           self.etl_source_group_code)
            self.context.oradb_pim = self.oradb_pim
            self.context.session_pim = self.oradb_pim.session
            self.context.oradb_fnd = self.oradb_fnd
            self.context.session_fnd = self.oradb_fnd.session

        except Exception as e:
            self.log.exception("Unable to initialize DaisDriver: %s", e)
            raise

    def __enter__(self):
        # make a database connection and return it

        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources
        self.finalize()

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("Driver completed at %s", self.end_time)
        self.log = None

    def finalize(self):
        """ 
        Releases resources and displays auditing details.
        """
        self.release()

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time

        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("DAIS Driver completed at %s", self.end_time)

    def release(self):
        """ 
        Releases database and configuration resources
        """
        # Release resources
        try:
            if self.oradb_pim is not None:
                self.oradb_pim.release()
        finally:
            self.oradb_pim = None

        try:
            if self.oradb_fnd is not None:
                self.oradb_fnd.release()
        finally:
            self.oradb_fnd = None

        if self.config is not None:
            self.config = None

    def validate(self):
        """
        Executes validatation logic upon start up of the driver.
        """
        if self.etl_audit_id is None:
            raise ValueError(
                'Required audit job id not found in '
                'environment vars or cmd line params.')

    def process(self):
        """
        Delegates pipeline processing to PipelineManager instance.
        """

        try:
            # Ensure validation passes before continuing
            self.validate()

            # Pipeline pre, core, and post processing
            pipeline_mgr = PipelineManager(self.context)

            pipeline_mgr.pre()
            pipeline_mgr.core()
            pipeline_mgr.post()

        except Exception as e:
            self.log.exception("Error in DaisDriver process: %s", e)
            raise


USAGE = [
    'DA IndexSolutions Driver',
    [['-l', '--log-level', '--log_level'],
        {'help': 'DEBUG, INFO, WARN, ERROR, CRITICAL',
         'choices': ['DEBUG', 'INFO', 'WARN', 'ERROR', 'CRITICAL']}],
    [['-a', '--audit-id', '--audit_id'],
        {'help': 'Etl audit id for etl jobs max-len(10)', 'type': int}],
    [['--source-group-code', '--source_group_code'],
        {'help': 'ETL File metadata source_group_code'}]
]


def main():
    """ 
    Delegates all processing to DaisDriver instance.
    """
    logger = logging.getLogger("dais_driver")
    # noinspection PyBroadException
    try:
        cmd_line = util.sanitize_cmd_line(copy.copy(sys.argv))
        logging.info(cmd_line)
        args = util.parse_args(*USAGE)
        with DaisDriver(logger=logger, options=args) as driver:
            driver.process()
    except Exception:
        logger.critical("Error in DaisDriver::", exc_info=1)
        logger.critical("DaisDriver exited with error.")
        return -1
    else:
        logger.info("DaisDriver completed successfully.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
