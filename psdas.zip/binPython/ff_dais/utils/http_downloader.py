#!/usr/bin/env python

import os
import requests
from requests.auth import HTTPBasicAuth
import sys

from optparse import OptionParser

# Test files
# 30KB: https://data.ny.gov/api/views/9upz-c7xg/rows.csv?accessType=DOWNLOAD
#470GB: https://data.lacity.org/api/views/wjz9-h9np/rows.csv?accessType=DOWNLOAD

USAGE = "USAGE: python http_downloader.py -u {url_to_download} -o {output_file_name} [-s {username} -p {password}]"
#block_size = 1024     # 1 kb
block_size = 1048576  # 1 mb

def main():
    auth = None
    downloaded_block_count = 0

    # Get and validate command line args
    parser = OptionParser()
    parser.add_option("-u", "--url", dest="url")
    parser.add_option("-o", "--output-file", dest="output_file")
    parser.add_option("-s", "--username", dest="username")
    parser.add_option("-p", "--password", dest="password")
    (options, args) = parser.parse_args()

    if options.url is None:
        print "Url is a required parameter."
        print USAGE
        sys.exit(1)

    if options.output_file is None:
        print "Output file is a required parameter."
        print USAGE
        sys.exit(1)

    if options.username is not None and \
       options.password is not None:
        auth = HTTPBasicAuth(options.username, options.password)

    # Debug
    #print "url:         {0}".format(options.url)
    #print "output_file: {0}".format(options.output_file)
    #print "auth:        {0}".format(auth)

    # Construct full file name
    path = os.path.dirname(os.path.realpath(__file__))
    full_file_name = os.path.join(path, options.output_file)

    # Download file as a stream and write each block to output
    with open(full_file_name, 'wb') as handle:
        response = requests.get(options.url, auth=auth, stream=True)

        if not response.ok:
            print 'HTTP download failed for ' + options.url
            print "response: {0}".format(response)
            sys.exit(1)

        for block in response.iter_content(block_size):
            handle.write(block)

            downloaded_block_count += 1
            if downloaded_block_count % 10 == 0: print "{0} blocks downloaded...".format(downloaded_block_count)

        print "{0} blocks downloaded.".format(downloaded_block_count)
        print "Download complete."


if __name__ == '__main__':
    main()
