#!/usr/bin/env python

import base64
import email
import getpass
import imaplib
import os
import sys

from optparse import OptionParser

MAILBOX_NAME = 'INBOX'
USAGE = 'python email_downloader.py -n {exchange_host_name} -r {exchange_port_num} -c {content_type} -o {output_file} -u {user_name} -p {password} -f {from_query} -s {subject_query}'

def main():
    # Get and validate arguments
    (options, args) = get_commandline_args()

    conn = imaplib.IMAP4_SSL(options.host_name, options.port)
    conn.login(options.user, options.password)
    conn.select(MAILBOX_NAME)

    # Create and execute query; extract message ids
    query = build_query(options)
    results, data = conn.search(None, query)
    msg_ids = data[0].split()

    path = os.path.dirname(os.path.realpath(__file__))

    # Multiple email matches
    if len(msg_ids) > 1:
        for msg_id in msg_ids:
            msg = get_email_message(conn, msg_id)
            file_name = clean_file_name(msg['subject'], options.content_type)
            full_file_name = os.path.join(path, file_name)

            save_email_to_file(msg, full_file_name, options)

    # Single email match
    elif len(msg_ids) == 1:
        msg = get_email_message(conn, msg_ids[0])

        if options.output_file is not None:
            file_name = options.output_file
        else:
            file_name = clean_file_name(msg['subject'], options.content_type)
        full_file_name = os.path.join(path, file_name)

        save_email_to_file(msg, full_file_name, options)
    # No matches
    else:
        print 'No emails found to process'

    conn.logout()

def get_email_message(conn, msg_id):
    typ, data = conn.fetch(msg_id, '(RFC822)')
    return email.message_from_string(data[0][1])

def clean_file_name(file_name, content_type):
    print 'before: ' + file_name

    clean_name = ''
    whitespace_chars = ' \n\t'
    bad_chars = '!@#$%^&*()=+;\':\\|[]{},'

    for c in file_name:
        # Exclude bad chars from file name
        # and convert white space to '_'
        if c in bad_chars:
            pass
        elif c in whitespace_chars:
            clean_name += '_'
        else:
            clean_name += c

    if content_type is None:
        clean_name += '.txt'
    elif content_type == 'text/html':
        clean_name += '.html'
    else:
        clean_name += '.txt'

    print 'after:  ' + clean_name
    return clean_name

def save_email_to_file(msg, full_file_name, options):
    with open(full_file_name, 'wb') as out_file:
        if msg.get_content_maintype() == 'multipart':
            for part in msg.walk():
                if part.get_content_type() == options.content_type:
                    body = part.get_payload(decode=True)
                    out_file.write(body)
        else:
            body = msg.get_payload(decode=True)
            out_file.write(body)

def get_commandline_args():
    parser = OptionParser()
    parser.add_option("-n", "--host-name", dest="host_name")
    parser.add_option("-r", "--port", dest="port")
    parser.add_option("-c", "--content-type", dest="content_type")
    parser.add_option("-o", "--output-file", dest="output_file")
    parser.add_option("-u", "--user", dest="user")
    parser.add_option("-p", "--password", dest="password")
    parser.add_option("-f", "--from-query", dest="from_query")
    parser.add_option("-s", "--subject-query", dest="subject_query")
    (options, args) = parser.parse_args()

    if options.host_name is None:
        print "Host name is a required parameter."
        print USAGE
        sys.exit(1)

    if options.port is None:
        print "Port is a required parameter."
        print USAGE
        sys.exit(1)

    if options.content_type is None:
        print "Content type is a required parameter."
        print USAGE
        sys.exit(1)

    # Output file name defaults to email subject
    #if options.output_file is None:
    #    print "Output file is a required parameter."
    #    print USAGE
    #    sys.exit(1)

    if options.user is None:
        print "User is a required parameter."
        print USAGE
        sys.exit(1)

    # Password is optional - prompt if not provided
    #if options.password is None:
    #    print "Password is a required parameter."
    #    print USAGE
    #    sys.exit(1)

    # Prompt for password if not provided
    if options.password is None:
        options.password = getpass.getpass()

    # Output file is optional - content disposition
    # header will be used if no output file is provided
    #if options.output_file is None:
    #    print "Output file is a required parameter."
    #    print USAGE
    #    sys.exit(1)

    return (options, args)
def build_query(options):
    query = ''
    
    # Check from query
    if options.from_query is not None:
        query += ' FROM "{0}"'.format(options.from_query)

    # Check subject query
    if options.subject_query is not None:
        query += ' SUBJECT "{0}"'.format(options.subject_query)

    query = '({0})'.format(query.strip())
    return query

if __name__ == "__main__":
    main()
