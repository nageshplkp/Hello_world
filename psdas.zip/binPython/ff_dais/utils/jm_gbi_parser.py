#!/usr/bin/env python

import csv
import os
import requests
import sys

from optparse import OptionParser

USAGE = "USAGE: python jm_gbi_parser.py -i {input_file_name} -o {output_file_name}"

block_size = 1048576  # 1 mb

def main():
    # Get and validate arguments
    (options, args) = get_commandline_args()

    # Build and validate file names
    path = os.path.dirname(os.path.realpath(__file__))
    input_file_name = os.path.join(path, options.input_file)

    if not os.path.exists(input_file_name):
        print "Input file not found: {0}".format(input_file_name)
        sys.exit(1)

    # Read html and extract url
    html = get_html_content(input_file_name)
    url = extract_url(html)

    # Debug
    #print "url: {0}".format(url)

    # Download and save file
    download_file(url, path, options.output_file)

def get_commandline_args():
    parser = OptionParser()
    parser.add_option("-i", "--input-file", dest="input_file")
    parser.add_option("-o", "--output-file", dest="output_file")
    (options, args) = parser.parse_args()

    if options.input_file is None:
        print "Input file is a required parameter."
        print USAGE
        sys.exit(1)

    # Output file is optional - content disposition 
    # header will be used if no output file is provided
    #if options.output_file is None:
    #    print "Output file is a required parameter."
    #    print USAGE
    #    sys.exit(1)

    return (options, args)

def get_html_content(input_file_name):
    # Extract contents of html document
    html = ''
    with open(input_file_name, 'r') as input_file:
        html = input_file.read()

    # Find start of anchor
    idx1 = html.find('Excel report')
    if idx1 >= 0:
        idx2 = html.find('<a', idx1)
        if idx2 >= 0:
            html = html[idx2:]
        else:
            html = html[idx1:]

    # Find end of anchor
    idx1 = html.find('</a>')
    if idx1 >= 0:
        html = html[:idx1 + 4]
    
    return html

def extract_url(html):
    url = None
    href_token1 = 'href="'
    href_token2 = "href='"

    # Find start of href attr, looking for 
    # value wrapped in double quotes first, 
    # then checking for value wrapped in single 
    # quotes
    idx1 = html.find(href_token1)
    if idx1 >= 0:
        html = html[idx1 + 6:]
        idx1 = html.find('"')
        if idx1 >= 0:
            url = html[:idx1]
    else:
        idx2 = html.find(href_token2)
        if idx2 >= 0:
            html = html[idx2 + 6:]
            idx2 = html.find("'")
            if idx2 >= 0:
                url = html[:idx2]

    return url

def download_file(url, output_path, output_file):
    downloaded_block_count = 0

    # Download file as a stream
    response = requests.get(url, stream=True)

    if not response.ok:
        print "Download failed for {0}".format(url)
        print "Response: {0}".format(response)
        sys.exit(1)

    # Check response header for file name
    if output_file is None and 'Content-disposition' in response.headers:
        output_file = get_file_name_from_header(response.headers['Content-disposition'])

    if output_file is None:
        print "Unable to determine file name from response header.  Please provide output file name parameter"
        print USAGE
        sys.exit(1)

    output_file_name = os.path.join(output_path, output_file)

    # Write each block to output file
    with open(output_file_name, 'wb') as handle:
        for block in response.iter_content(block_size):
            handle.write(block)

            downloaded_block_count += 1
            if downloaded_block_count % 10 == 0: print "{0} blocks downloaded...".format(downloaded_block_count)

        print "{0} blocks downloaded.".format(downloaded_block_count)
        print "Download complete."

def get_file_name_from_header(header):
    file_name = None

    idx1 = header.find('filename=')
    if idx1 >= 0:
        header = header[idx1+9:].strip()
        if header[0] == '"' or header[0] == "'":
            header = header[1:-1]
        file_name = header

    return file_name

if __name__ == '__main__':
    main()
