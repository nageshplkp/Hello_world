#!/usr/bin/python

#===============================================================================
# SUMMARY
#   
#   Name:        convert_delimiters.py
#   
#   Summary:     Converts field delimiters within a text file 
#                (i.e. converting a pipe-delimited file to csv)
#
#   Created By   Kevin Collins
#   Created Date 02/07/2017
#
#-------------------------------------------------------------------------------
# CHANGE HISTORY
#
#  By         Date       Description
#  ---------- ---------- -------------------------------------------------------
#  kcollins   02/08/2017 Initial version
#
#-------------------------------------------------------------------------------
# OPTIONS
#
#  Opt Name            Description
#  --- ------------    ---------------------------------------------------------
#  -d  in_delim        Delimiter used within the input file
#  -i  in_file         Name of the input file. This file must exist
#  -l  out_delim       Delimiter to be used within the output file
#  -o  out_file        Name of the output file to be created
#  -m  out_quote_mode  Values: [default: MIN]
#                        ALL    - Quotes all output values
#                        NONE   - Quotes no output values
#                        NONNUM - Quotes only non-numeric values
#                        MIN    - Quotes minimal output values (i.e. values 
#                                 containing delimiters or quote chars)
#  -c  out_quote_char  Character used to quote values in output file [default: "]
#  -e  out_escape_char Character used to escape special chars in output file.
#                      Default behavior doubles the character if no escape char
#                      is specified
#
#-------------------------------------------------------------------------------
# DEPENDENCIES
# 
#  Name                Description
#  ------------------- ---------------------------------------------------------
#  N/A
#
#-------------------------------------------------------------------------------
# ADDITIONAL INFORMATION
#
#  Use the help option for example usage and additional details
#  ./convert_delimiters.py --help
#
#===============================================================================

#-------------------------------------------------------------------------------
# Imports
#-------------------------------------------------------------------------------
import csv
import os
import sys

from optparse import OptionParser

#-------------------------------------------------------------------------------
# Help text
#-------------------------------------------------------------------------------
EPILOG_HELP_TEXT="""
------------------------------------------------------------------------------
NOTE:                                                                                 
Options for input delimiter, input file, output delimiter and output file                   
are required.                                                                    
------------------------------------------------------------------------------
Examples:                                                                       
1. Convert pipe delimited to csv:                                     
./convert_delimiters.py -d"|" -iin_pipe.txt -l"," -oout.txt                     
-                                                                                 
2. Convert tab delimited to csv:                                                
./convert_delimiters.py -d"\t" -iin_tab.txt -l"," -oout.txt                    
-                                                                                 
3. Convert pipe delimited to csv, quoting all output values:                                
./convert_delimiters.py -d"|" -iin_pipe.txt -l"," -oout.txt -mALL              
-                                                                                 
4. Convert pipe delimited to csv, using backslash as escape char
./convert_delimiters.py -d"|" -iin_pipe.txt -l"," -oout.txt -e"\\"             
------------------------------------------------------------------------------
"""
D_HELP_TEXT="Delimiter used within the input file"
I_HELP_TEXT="Name of the input file to be created"
L_HELP_TEXT="Delimiter to be used within the output file"
O_HELP_TEXT="Name of the output file to be created"
M_HELP_TEXT="""Mode used to quote values in output file
       Valid values:                              
        ALL    - Quotes all output values
        NONE   - Quotes no output values
        NONNUM - Quotes only non-numeric values
        MIN    - Quotes minimal output values (i.e. values 
                 containing delimiters or quote chars)
       [default: %default]"""
C_HELP_TEXT="Character used to quote values in output file. [default: %default]"
E_HELP_TEXT="Character used to escape special chars in output file"

#-------------------------------------------------------------------------------
#Validation errors
#-------------------------------------------------------------------------------
REQUIRED_PARM_ERROR="""The following parameters are required:
   -dDELM - input delimiter
   -iFILE - input file
   -lDELM - output delimiter
   -oFILE - output file
"""
FILE_NOT_FOUND_ERROR="Input file not found: {0}"

#-------------------------------------------------------------------------------
# Variables
#-------------------------------------------------------------------------------
SCRIPT_NAME = os.path.basename(__file__)
USAGE_TEXT = "Usage: {0} [options]".format(SCRIPT_NAME)

#-------------------------------------------------------------------------------
# Main function
#-------------------------------------------------------------------------------
def main():
    # Parse options
    options = parse_options()

    # Initialize
    (double_quote, quote_mode) = init(options)

    # Process file
    process_file(options, double_quote, quote_mode)

    # Return success
    sys.exit(0)

#-------------------------------------------------------------------------------
# Parse, validate and return command line arguments
#-------------------------------------------------------------------------------
def parse_options():
    # Add valid options to parser
    parser = OptionParser(usage=USAGE_TEXT, epilog=EPILOG_HELP_TEXT)
    parser.add_option("-d", "--in_delim", 
                      dest="in_delim", metavar="DELM", help=D_HELP_TEXT)
    parser.add_option("-i", "--in_file",
                      dest="in_file", metavar="FILE", help=I_HELP_TEXT)
    parser.add_option("-l", "--out_delim", 
                      dest="out_delim", metavar="DELM", help=L_HELP_TEXT)
    parser.add_option("-o", "--out_file", 
                      dest="out_file", metavar="FILE", help=O_HELP_TEXT)
    parser.add_option("-m", "--out_quote_mode", 
                      dest="out_quote_mode", metavar="MODE", default="MIN", help=M_HELP_TEXT)
    parser.add_option("-c", "--out_quote_char", 
                      dest="out_quote_char", metavar="CHAR", default="\"", help=C_HELP_TEXT)
    parser.add_option("-e", "--out_escape_char", 
                      dest="out_escape_char", metavar="CHAR", help=E_HELP_TEXT)

    # Parse command line
    (options, args) =  parser.parse_args()

    # Validate before returning
    validate_options(options)

    return options

#-------------------------------------------------------------------------------
# validate command line arguments
#-------------------------------------------------------------------------------
def validate_options(options):
    # Verify required parameters were provided
    if options.in_delim is None or \
       options.in_file is None or \
       options.out_delim is None or \
       options.out_file is None:
        print(USAGE_TEXT)
        print(REQUIRED_PARM_ERROR)
        sys.exit(1)

    # Ensure input file exists
    if not os.path.isfile(options.in_file):
        print(FILE_NOT_FOUND_ERROR.format(options.in_file))
        sys.exit(1)

    # Fix delimiter escape sequences
    options.in_delim = options.in_delim.decode("string_escape")
    options.out_delim = options.out_delim.decode("string_escape")

#-------------------------------------------------------------------------------
# Initialize
#-------------------------------------------------------------------------------
def init(options):
    # Ensure output file does not exist
    if os.path.isfile(options.out_file):
        os.remove(options.out_file)
    
    # Determine output quote mode
    quote_mode = csv.QUOTE_MINIMAL
    if options.out_quote_mode == "ALL":
        quote_mode = csv.QUOTE_ALL
    elif options.out_quote_mode == "NONE":
        quote_mode = csv.QUOTE_NONE
    elif options.out_quote_mode == "MIN":
        quote_mode = csv.QUOTE_MINIMAL
    elif options.out_quote_mode == "NONNUM":
        quote_mode = csv.QUOTE_NONNUMERIC
    else:
        quote_mode = csv.QUOTE_MINIMAL
    
    # Determine output doublequote behavior
    # Character is doubled (repeated) unless an escape char
    # is specified, in which case the original char will be
    # prefixed with the escape char
    double_quote = True
    if options.out_escape_char is not None:
        double_quote = False

    return (double_quote, quote_mode)

#-------------------------------------------------------------------------------
# Copy input file to output file, converting field delimiters
#-------------------------------------------------------------------------------
def process_file(options, double_quote, quote_mode):
    with open(options.in_file, "rb") as in_file:
        with open(options.out_file, "wb") as out_file:

            # Create file reader and writer objects
            reader = csv.reader(in_file, 
                                delimiter=options.in_delim)
            writer = csv.writer(out_file, 
                                delimiter=options.out_delim, 
                                quoting=quote_mode,
                                quotechar=options.out_quote_char,
                                doublequote=double_quote,
                                escapechar=options.out_escape_char)
            
            # Read each row from the input file and write to output
            for row in reader:
                writer.writerow(row)

#-------------------------------------------------------------------------------
# Execute main
#-------------------------------------------------------------------------------
if __name__ == "__main__":
    main()
