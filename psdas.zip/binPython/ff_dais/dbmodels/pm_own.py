from etl.core import db


class SsmIdXref(object):

    def __init__(self, schema='pm_own', entity_name='ssm_id_xref'):
        self.db = db.ora_pim(schema)
        self.model = self.db.create_model(entity_name, pk=['ssm_id',
                                                           'source_key',
                                                           'source_sec_id'])

    def new(self, **kwargs):
        return self.model(**kwargs)

    def get(self, pk):
        return self.model.query.get(pk)

    def save(self, row):
        return self.db.save(row)

    def save_all(self, rows):
        with self.db.session.no_autoflush:
            return self.db.save_all(rows)
