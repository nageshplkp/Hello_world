#!/usr/bin/env python
import os
import sys
import logging
import copy
from datetime import datetime
from etl.core import util
from etl.core import da_config
from etl.core.timed import timed
from etl.core.db import ora_xxx
from etl.repo.pim_pm import SecPricesRepo

__app__ = sys.modules['__main__']


class PmPriceSynchAgent(object):
    """
    """

    def __init__(self, logger=None, options=None):
        self.start_time = datetime.now()
        self.end_time = None

        self.log = logger or logging.getLogger(
            "ff_dais.pm_price_sync_agent")

        self.options = copy.deepcopy(
            vars(options) if options is not None else dict())
        self.default_config = da_config.get_etl_cfg()
        self.config = copy.deepcopy(self.default_config)
        self.config.update(self.options)

        self.log = logger or logging.getLogger(
            "ff_dais.pm_price_sync_agent")

        level_name = self.config.get('log_level')
        if not level_name:
            level_name = self.config.get('dais').get('log_level', 'INFO')

        level = logging.getLevelName(level_name)
        os.environ['PYPIMCO_LOG_LEVEL_OVERRIDE'] = level_name
        self.log.setLevel(level)

        # Try command line argument first --audit-id
        self.etl_audit_id = self.options.get('etl_audit_id')

        # Use environment variable param if command line
        # for audit id is not set
        if self.etl_audit_id is None:
            # Capture etl audit id. This id is created by etl wrapper script
            # and saved to the ETL_AUDIT_ID environment variable
            self.etl_audit_id = os.environ.get('ETL_AUDIT_ID')

        # make sure audit id type is int
        self.etl_audit_id = int(self.etl_audit_id) if self.etl_audit_id \
            else self.etl_audit_id
        self.log.info("ETL_AUDIT_ID: %s", self.etl_audit_id)

        # Try command line argument first --start-date
        self.etl_load_start_date = self.options.get('etl_load_start_date')

        # Use environment variable param if command line
        # for etl load start date is not set
        if self.etl_load_start_date is None:
            # Capture etl load start date. This param is created by etl wrapper
            # script and saved to the ETL_LOAD_START_DATE environment variable
            self.etl_load_start_date = os.environ.get('ETL_LOAD_START_DATE')

        self.log.info("ETL_LOAD_START_DATE: %s", self.etl_load_start_date)

        # Try command line argument first --audit-id
        self.etl_load_end_date = self.options.get('etl_load_end_date')

        # Use environment variable param if command line
        # for audit id is not set
        if self.etl_load_end_date is None:
            # Capture etl load end date. This param is created by etl wrapper
            # script and saved to the ETL_LOAD_END_DATE environment variable
            self.etl_load_end_date = os.environ.get('ETL_LOAD_END_DATE')

        self.log.info("ETL_LOAD_END_DATE: %s", self.etl_load_end_date)

        self.dais_own = None

        self.log.info("Driver started at %s", self.start_time)

    def __enter__(self):
        # make a database connection and return it
        self.dais_own = ora_xxx('DAIS_OWN', 'ORAPIM_DBP')
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources
        try:
            if self.dais_own is not None:
                self.dais_own.release()
        finally:
            self.dais_own = None

        # Release resources
        if self.config is not None:
            self.config = None

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("Driver completed at %s", self.end_time)
        self.log = None

    def validate(self):
        """
        Executes validation logic upon start up of the driver.
        """
        if self.etl_audit_id is None:
            raise ValueError(
                'Required audit job id not found in '
                'environment var:ETL_AUDIT_ID or cmd line params.')

        if self.etl_load_start_date is None:
            raise ValueError(
                'Required load start date not found in environment variable'
                ':ETL_LOAD_START_DATE or cmd line params: --start-date.')

        if self.etl_load_end_date is None:
            raise ValueError(
                'Required load end date not found in environment variable' 
                ':ETL_LOAD_END_DATE or cmd line params: --end-date.')

    @timed()
    def run(self):
        try:
            # session = self.dais_own.session
            # yesterday = date.today() - timedelta(1)
            # today = date.today()
            repo = SecPricesRepo.instance
            repo.load_sec_prices(self.etl_audit_id,
                                 self.etl_load_start_date,
                                 self.etl_load_end_date)
        except Exception as e:
            self.log.critical(
                """pm_price_sync_agent::batch: {} completed with error: {}
                """.format(self.etl_audit_id, e)
            )
            raise


USAGE = [
    'PM Price Synchronization Agent Description',
    ['--log-level', {'help': 'DEBUG, INFO, WARN, ERROR, CRITICAL'}],
    ['--etl-audit-id', {'help': 'etl audit id for etl jobs max-len(10)'}],
    ['--etl-load-start-date', {'help': 'The start date for the incremental '
                               'process: '
                               'format => YYYY-MM-DD HH24:MI:SS "PST" or can '
                               'be set as env var:ETL_LOAD_START_DATE'}],
    ['--etl-load-end-date', {'help': 'The end date for the incremental process:'
                             ' format => YYYY-MM-DD HH24:MI:SS "PST"'
                             'or can be set as env var: ETL_LOAD_END_DATE'}]
]


def main():
    """ 
    Delegates all processing to Agent instance.
    """
    logger = logging.getLogger("ff_dais.pm_price_sync_agent")

    try:
        args = util.parse_args(*USAGE)
        with PmPriceSynchAgent(logger=logger, options=args) as agent:
            agent.validate()
            agent.run()

    except Exception as e:
        logger.critical("critical error in pm_price_sync_agent::", exc_info=1)
        logger.critical("Agent exited with error.")
        return -1
    else:
        logger.info("Agent completed successfully.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
