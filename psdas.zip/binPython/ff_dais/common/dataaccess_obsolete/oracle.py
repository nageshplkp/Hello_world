from ..config import config
import sqlalchemy
import os
from sqlalchemy import exc
from sqlalchemy.sql import text
from sqlalchemy.orm import sessionmaker, scoped_session

import pandas


class OracleDb:
    """
    Oracle database abstraction layer.  Manages database connections, sessions
    and execution of queries, inserts, updates and stored procedures.
    """
    DEFAULT_DATABASE_KEY = "ORAPIM_DBP"
    DEFAULT_WIN_ORACLE_HOME = r"W:\pm\vendor\oracle\win64\client_11.2.0"
    da_config_dir = os.environ.get("DA_CONFIG_DIR") if os.environ.get("DA_CONFIG_DIR") else "./config"
    CONTROL_FILE_PATH =  da_config_dir + "/da_conn.ini"
    #CONTROL_FILE_PATH = "./config/da_conn.ini"

    def __init__(self, database_key=DEFAULT_DATABASE_KEY):
        """ 
        OracleDb constructor.

        Args:
            database_key (str): configuration key used to retrieve database
            connection details
        """
        self.engine = None
        self.connection = None
        self.session = None

        try:
            # load config and control files
            self.config = config.Config()
            self.control = config.Config(OracleDb.CONTROL_FILE_PATH)
            
            # get database details
            self.connection_name = self.config.get("database", database_key)
            self.database_key = database_key
            self.database_name = self.control.get(
                self.connection_name, "server")
            self.user_id = self.control.get(self.connection_name, "user")
            self.password = self.control.get(self.connection_name, "password")
            
            # create database connection
            self.connect()

        except Exception as e:
            print "Unable to initialize OracleDb: {0}".format(e)
            raise

    def connect(self):
        """
        Establishes connection to Oracle and creates sessionmaker instance.
        """
        try:
            # For debugging on windows
            # if sys.platform == "win32":
            #    oracle_home = os.environ.get(
            #       "PYPIMLIB_ORACLE_HOME", self.DEFAULT_WIN_ORACLE_HOME)
            #    path = os.environ.get("PATH")
            #
            #    os.environ["ORACLE_HOME"] = oracle_home
            #    os.environ["PATH"] = "{0};{1}".format(oracle_home, path)
            # import cx_Oracle

            # release prior connection
            self.release()

            # Connect to Oracle
            url = "oracle://{0}:{1}@{2}".format(
                self.user_id, self.password, self.database_name)
            self.engine = sqlalchemy.create_engine(url)
            self.connection = self.engine.connect()

            # Configure sessionmaker to support  establishing future sessions
            # self.session = sessionmaker()
            session_factory = sessionmaker(bind=self.connection)
            self.session = scoped_session(session_factory)
            # self.session.configure(bind=self.connection)

        except exc.SQLAlchemyError as e:
            print "Failed to connect to {}. DatabaseError: {}".format(
                self.database_name, e)
            raise
    
    def create_session(self):
        """
        Creates a new session for the current database connection.
        """
        return self.session()

    def release(self):
        """
        Releases the database resources.
        """
        try:
            if self.connection is not None:
                self.connection.close()
        finally:
            self.connection = None

        try:
            if self.engine is not None:
                self.engine.dispose()
        finally:
            self.engine = None

    def query(self, sql, params=None):
        """
        Submits a select statement using the supplied parameters and returns a
        dataframe.

        Args:
            sql (str): statement to be executed (containing bind var names,
            i.e. :parm1, :parm2)
            params (list of dict): list of dictionaries
            containing values to be bound to vars in sql statement
        """
        try:
            # default params to empty list
            if params is None:
                params = []

            # execute sql and build dataframe for results
            result = self.connection.execute(text(sql), params)
            df = pandas.DataFrame(result.fetchall())

            # assigning column names to empty dataframe throws an error
            if len(df) > 0:
                df.columns = result.keys()

            return df

        except exc.SQLAlchemyError as e:
            print "Failed to execute sql statement. SQLAlchemyError: "
            "{} Sql: {} Parameters: {}".format(e, sql, params)
            raise

    def execute(self, sql, params=None):
        """
        Submits an insert/update/delete statement using the supplied parameters.

        Args:
            sql (str): statement to be executed (containing bind var names,
            i.e. :parm1, :parm2)
            params (list of dict): list of dictionaries containing values to be
            bound to vars in sql statement
        """
        try:
            # execute sql using provided parameters
            return self.connection.execute(text(sql), params)

        except exc.SQLAlchemyError as e:
            print "Failed to execute sql statement. SQLAlchemyError: "
            "{} Sql: {} Parameters: {}".format(e, sql, params)
            raise

    def execute_proc(self, procedure, params=None):
        """ 
        Executes a stored procedure using the supplied parameters.

        Args:
            procedure (str): database stored procedure to be executed
            params (list): list of parameter values
        """
        raw_connection = None

        try:
            # build sql statement for executing procedure
            sql = "BEGIN {0}; END;".format(procedure)

            # prepare raw connection and cursor
            raw_connection = self.engine.raw_connection()
            cursor = raw_connection.cursor()

            # execute procedure and commit results
            result = cursor.execute(sql, params)
            raw_connection.commit()

            return result

        except exc.SQLAlchemyError as e:
            if raw_connection is not None:
                raw_connection.rollback()

            print "Failed to execute stored procedure. SQLAlchemyError: "
            "{} Procedure: {1} Parameters: {2}".format(e, procedure, params)
            raise

    def bulk_insert(self, entity, data):
        """ 
        Bulk inserts a collection of data for a specific entity. Using the
        sqlalchemy core approach below is approximately 40% faster than using
        session.bulk_save_objects().

        Args:
            entity (obj): entity to be inserted
            data (list of dict): list of dictionaries containing entity values
        """

        try:
            # Insert using sqlalchemy core
            self.engine.execute(entity.__table__.insert(), data)

        except exc.SQLAlchemyError as e:
            print "Failed to execute bulk insert. SQLAlchemyError:"
            "{0} Entity: {1} Data: {2}".format(e, entity, data)
            raise
