import ConfigParser
import os

class ConfigError(ValueError):
    pass

class Config:
    def __init__(self, file_name = None):
        self.config = None

        # determine default config file anme
        if file_name is None:
            env = os.environ.get("ETL_ENV") if os.environ.get("ETL_ENV") else "dev"
            da_config_dir =  os.environ.get("DA_CONFIG_DIR") if os.environ.get("DA_CONFIG_DIR") else "./config"
            file_name = os.path.abspath(da_config_dir + "/app_config_" + env + ".ini")
        self.load(file_name)

    def load(self, file_name):
        # Make sure config file exists
        if not os.path.exists(file_name):
            raise ConfigError(file_name + " config file not found")

        self.config = ConfigParser.ConfigParser()
        self.config.read(file_name)

    def get(self, section, option):
        return self.config.get(section, option)

