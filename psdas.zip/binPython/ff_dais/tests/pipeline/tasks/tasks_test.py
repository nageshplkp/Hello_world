import pytest

from mock import patch
from pipeline.tasks.tasks import PubPostTask
from pipeline.pipeline import PipelineContext
from etl.core import util

@pytest.mark.parametrize('rds_status_code,enum_value', [
    ('IN_PROGRESS', 'PEND_RDS'),
    ('PENDING_REVIEW', 'DONE_RDS')
])
def test_get_sec_ident_status_returns_enum_value_for_in_progress(
        rds_status_code, enum_value):
    assert PubPostTask._get_sec_ident_status(rds_status_code) == enum_value


def test_get_sec_ident_status_throws_exception_for_unknown_status():
    with pytest.raises(TypeError):
        PubPostTask._get_sec_ident_status('BOGUS')

#
@pytest.mark.parametrize('item', [util.struct(vnd_file_inst_id=12345)])
@patch.object(PubPostTask, 'safe_print')
@patch.object(PubPostTask, '_submit_rds_reindex_request')
def test_process_given_when_then(A, B, item):
        uut = PubPostTask(None)
        uut.process(item)
