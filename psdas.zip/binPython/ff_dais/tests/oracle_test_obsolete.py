#!/usr/bin/env python

from common.dataaccess import oracle

def main():
    oradb = None
    oradb2 = None

    try:
        # connect to default db DAIS
        oradb = oracle.OracleDb()

        # open_cursore example
        print("Open cursor test")
        #sql = "SELECT COUNT(*) TABLE_COUNT FROM ALL_TABLES WHERE OWNER='DAIS_OWN'"
        sql = "SELECT COUNT(*) TABLE_COUNT FROM DUAL"
        cursor = oradb.open_cursor(sql)

        row = cursor.fetchone()
        print("TABLE_COUNT : " + str(row[0]))

        cursor.close()

        # get_resultset example
        #print("Get resultset test")
        #sql = "SELECT COUNT(*) REC_COUNT FROM DAIS_OWN.VND_FILE_INST"
        #rs = oradb.get_resultset(sql)
        #print(rs)

        # connect to default db DAIS
        oradb2 = oracle.OracleDb("ORAFND_DBP")

        # open_cursore example
        print("Open cursor test")
        #sql = "SELECT COUNT(*) TABLE_COUNT FROM ALL_TABLES WHERE OWNER='CFDW_OWN'"
        sql = "SELECT COUNT(*) TABLE_COUNT FROM DUAL"
        cursor = oradb2.open_cursor(sql)

        row = cursor.fetchone()
        print("TABLE_COUNT : " + str(row[0]))

        cursor.close()
    finally:
        if oradb is not None:
            oradb.disconnect()
        if oradb2 is not None:
            oradb2.disconnect()

if __name__ == "__main__":
    main()
