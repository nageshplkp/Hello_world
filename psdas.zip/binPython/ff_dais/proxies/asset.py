import os
import random
import requests
import uuid
import json
import logging
import getpass

from etl.core import util


# noinspection PyArgumentList
class AssetProxyBase(object):
    def __init__(self):
        pass

    def create(self, **instrument):
        pass

    def create_all(self, instruments):
        pass
        
    def unindex(self, **instrument):
        pass

    def unindex_all(self, instruments):
        pass

    def reindex(self, **instrument):
        pass

    def reindex_all(self, instruments):
        pass

    def get_status(self, request_id):
        pass

    def get_status_for_all(self, request_ids):
        pass


# noinspection PyArgumentList
class RdsAssetClient(AssetProxyBase):

    CREATE_INSTRUMENT_URL = "{0}/ref/v2/instruments/create"
    # CREATE_INSTRUMENT_URL = "{0}/v1/instruments"
    MANAGE_INSTRUMENT_URL = "{0}/ref/v2/instruments/manage"
    INSTRUMENT_STATUS_URL = "{0}/ref/v2/instruments/status/{1}"

    def __init__(self, config, logger=None):
        super(AssetProxyBase, self).__init__()
        self.config = config
        self.logger = logger or logging.getLogger(__name__)
        self.base_url = config.get("dais_rds_sec").get("base_url")
        self.client_app = config.get("dais_rds_sec").get("client_app")

    def _build_headers(self, request_id=None):
        """
        Builds and returns http headers for RDS requests.
        :param request_id: string(http_request_id): optional
        :return: dict(http_headers)
        :rtype: type dict
        """
        client_app = self.config.get("dais_rds_sec").get("client_app")
        client_enduser = self.config.get("dais_rds_sec").get("client_enduser")
        avsc_version = self.config.get("dais_rds_sec").get("avsc_version")

        http_request_id = request_id if request_id else str(uuid.uuid4())

        return {
            'Content-Type': 'application/json',
            'X-Request-Id': '-'.join([client_app, http_request_id]),
            'X-Client-EndUser': client_enduser,
            'X-Remote-User': getpass.getuser(),
            'X-AVSC-Version': avsc_version,
            "X-Process-Id": str(os.getpid()),
            "X-Debug-Id": str(random.randint(10000, 100000))
        }

    def _update(self, instruments, is_const=None):
        """
        https://pimcowiki:8443/display/CDAT/Create+and+Update+Instrument+API
        Calls RDS/EDM service API for reindex/unindex
        if is_const is provided, the value will be applied to all instruments
        else: it will try to extract it from instrument and apply per instrument
        :param instruments:list(dict) required keys/values:ssm_id
        :param is_const: bool: optional
        :return: object (status=True|False, data=list(data))
        """

        headers = self._build_headers()
        url = RdsAssetClient.MANAGE_INSTRUMENT_URL.format(self.base_url)

        data = [{
            "client_app": self.client_app,
            "ssm_id": v.get('ssm_id', ''),
            "instrument_request_id": v.get('request_id', str(uuid.uuid4())),
            'Index_Constituent': is_const if is_const is not None else bool(
                # make sure one of these values provided
                # be cautious not to convert '' to false
                # better to throw exception if value is not provided
                v['idx_const_sw'] == 'Y'
            )
        } for k, v in enumerate(instruments)]

        self.logger.debug(
            "RDS update instrument request:\r\n"
            "POST:    {}\r\n"
            "headers: {}\r\n"
            "body: {}\r\n".format(
                url,
                headers,
                data
            )
        )

        response = requests.post(url, headers=headers, json=data)
        process_id = headers.get("X-Process-Id", str(os.getpid()))

        debug_headers = response.headers
        debug_headers["X-Process-Id"] = process_id
        debug_headers["X-Debug-Id"] = headers.get("X-Debug-Id", "")

        self.logger.debug(
            "RDS update instrument response:\r\n"
            "status:  {}\r\n"
            "headers: {}\r\n"
            "body:    {}\r\n".format(
                response.status_code,
                debug_headers,
                response.text
            )
        )
        status = response.status_code == 200
        data = json.loads(response.text)
        return util.struct(status=status, data=data)

    def create(self, **instrument):
        return self.create_all([util.struct(**instrument)])
    
    def create_all(self, instruments):
        """
        Calls RDS/EDM CreateInstrument API
        https://pimcowiki:8443/display/CDAT/Create+and+Update+Instrument+API
        :param instruments:list(dict) : required
        :return: object (status=True|False, data=list(data))
        :rtype: type object
        """

        http_request_id = str(random.randint(10000, 100000))
        headers = self._build_headers(http_request_id)
        url = RdsAssetClient.CREATE_INSTRUMENT_URL.format(self.base_url)

        debug_headers = headers
        debug_headers["X-Process-Id"] = str(os.getpid())
        debug_headers["X-Debug-Id"] = http_request_id

        self.logger.info(
            "RDS create instrument request:\r\n"
            "POST:    {}\r\n"
            "headers: {}\r\n"
            "body:    {}\r\n".format(
                url,
                debug_headers,
                json.dumps(instruments)
            )
        )

        response = requests.post(url, headers=headers, json=instruments)

        debug_headers = response.headers
        debug_headers["X-Process-Id"] = str(os.getpid())
        debug_headers["X-Debug-Id"] = http_request_id

        self.logger.info(
            "RDS create instrument response:\r\n"
            "status:  {}\r\n"
            "headers: {}\r\n"
            "body:    {}\r\n".format(
                response.status_code,
                debug_headers,
                response.text
            )
        )
        status = response.status_code == 200
        data = json.loads(response.text)
        return util.struct(status=status, data=data)

    def update(self, **instrument):
        """@type instrument: dict[] dictionary"""
        return self.update_all([util.struct(**instrument)])

    def update_all(self, instruments):
        """
        Calls RDS/EDM CreateInstrument API
        https://pimcowiki:8443/display/CDAT/Create+and+Update+Instrument+API
        :param instruments:list(dict) : required
        :return: object (status=True|False, data=list(data))
        :rtype: type object
        """
        return self._update(instruments, None)

    def unindex(self, **instrument):
        return self.unindex_all(instruments=[instrument])

    def unindex_all(self, instruments):
        return self._update(instruments, is_const=False)
    
    def reindex(self, **instrument):
        """
        Reindexes instrument (index_constituent_sw = 'Y')
        @type instrument: dict[] : dictionary with keys('idx_const_sw',
                                 'request_id')
        :return:
        """
        return self.reindex_all(instruments=[instrument])

    def reindex_all(self, instruments):
        return self._update(instruments, is_const=True)

    def get_status(self, request_id):
        """
        checks status from the previously submitted request (see above:create)
        :param: request_id: string: required:
        :return: object (status=True|False, data=data)
        """
        return self.get_status_for_all([request_id])
    
    def get_status_for_all(self, request_ids):
        """
        https://pimcowiki:8443/display/CDAT/Create+and+Update+Instrument+API
        checks status from the previously submitted request (see above:create)
        :param: request_ids: list(string): required:
        :return: object (status=True|False, data=list(data))
        """

        headers = self._build_headers()
        url = RdsAssetClient.INSTRUMENT_STATUS_URL.format(
            self.base_url, ",".join(request_ids))
        
        self.logger.info(
            "RDS get status request:\r\n"
            "GET:    {}\r\n"
            "headers: {}\r\n".format(
                url,
                headers
            )
        )

        response = requests.get(url, headers=headers)
        process_id = headers.get("X-Process-Id", str(os.getpid()))

        debug_headers = response.headers
        debug_headers["X-Process-Id"] = process_id
        debug_headers["X-Debug-Id"] = headers.get("X-Debug-Id", "")

        self.logger.info(
            "RDS get status response:\r\n"
            "status:  {}\r\n"
            "headers: {}\r\n"
            "body:    {}\r\n".format(
                response.status_code,
                debug_headers,
                response.text
            )
        )
        status = response.status_code == 200
        data = json.loads(response.text)
        return util.struct(status=status, data=data)
