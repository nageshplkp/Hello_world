from csv import DictReader, DictWriter
from etl.core.util import parse_args
import sys

USAGE = ['DAIS Script to fetch Indexes from a common file. To be used for SnP',
         ['--working-dir', {'help': 'Current Working Directory',
                            'required': True}],
         ['--input-file', {'help': 'Input File for processing',
                           'required': True}],
         ['--output-file', {'help': 'Output File',
                            'required': True}],
         ['--filter-column', {'help': 'Column Index to used for filtering out the records',
                                    'required': True}],
         ['--filter-column-value', {'help': 'Column Value to be used for filtering',
                                    'required': True}],
         ['--vendor-code', {'help': 'Vendor Code to differentiate between RS & MK Vendor',
                                    'required': False}]]


def main():
    working_dir = parse_args(*USAGE).working_dir
    input_file = parse_args(*USAGE).input_file
    output_file = parse_args(*USAGE).output_file
    filter_column = parse_args(*USAGE).filter_column
    filter_column_value = parse_args(*USAGE).filter_column_value
    vendor_code = parse_args(*USAGE).vendor_code

    if vendor_code == 'MK':
        rtn = parse_csv_file_mk(working_dir, input_file, filter_column, filter_column_value, output_file)
    elif vendor_code == 'SP':
        rtn = parse_csv_file_sp(working_dir, input_file, filter_column, filter_column_value, output_file)
    else:
        rtn = parse_csv_file(working_dir, input_file, filter_column, filter_column_value, output_file)
    sys.exit(rtn)


def parse_csv_file_sp(working_dir, input_file, filter_column, filter_column_value, output_file):
    line_count = 0
    out_fh = open(working_dir + "/" + output_file, 'wb')
    with open(working_dir + "/" + input_file, 'r') as fh:
        csv_reader = DictReader(fh)
        writer = DictWriter(f=out_fh, fieldnames=csv_reader.fieldnames)
        writer.writeheader()
        for row in csv_reader:
            if row[filter_column] > filter_column_value:
                writer.writerow(row)
                line_count += 1

    out_fh.writelines("Line Count:" + str(line_count))
    fh.close()
    out_fh.close()
    return 0


def parse_csv_file_mk(working_dir, input_file, filter_column, filter_column_value, output_file):
    line_count = 0
    out_fh = open(working_dir + "/" + output_file, 'wb')
    with open(working_dir + "/" + input_file, 'r') as fh:
        csv_reader = DictReader(fh)
        writer = DictWriter(f=out_fh, fieldnames=csv_reader.fieldnames)
        writer.writeheader()
        for row in csv_reader:
            if row[filter_column] == filter_column_value:
                writer.writerow(row)
                line_count += 1

    out_fh.writelines("Line Count:" + str(line_count))
    fh.close()
    out_fh.close()
    return 0


def parse_csv_file(working_dir, input_file, filter_column, filter_column_value, output_file):
    line_count = 0
    out_fh = open(working_dir + "/" + output_file, 'wb')
    with open(working_dir + "/" + input_file, 'r') as fh:
        csv_reader = DictReader(fh)
        writer = DictWriter(f=out_fh, fieldnames=csv_reader.fieldnames)
        writer.writeheader()
        for row in csv_reader:
            if row[filter_column] == filter_column_value:
                writer.writerow(row)
                line_count += 1

    out_fh.writelines("Line Count:" + str(line_count))
    fh.close()
    out_fh.close()
    return 0


if __name__ == '__main__':
    main()
