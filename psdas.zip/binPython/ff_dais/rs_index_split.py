import os
import sys
import logging
import copy
import csv
from datetime import datetime


from etl.core import util
from etl.core.timed import timed
from etl.core import da_config

OUT_FILE_NAME_TEMPLATE = "H_RGS_${YYYYMMDD}_${vnd_file_code}.csv"


def coroutine(func):
    """
    A  decorator  function that takes care of starting a co-routine
    automatically on call.
    :param func:
    :return: coroutine
    """
    def start(*args, **kwargs):
        cr = func(*args, **kwargs)
        cr.next()
        return cr
    return start


def produce(reader):
    for row in reader:
        yield row


@coroutine
def consume(writer):
    try:
        while True:
            row = (yield)
            writer.writerow(row)
            logging.info(row)
    except GeneratorExit:
        logging.info("Done with writing!")


def sanitize(text, sanitizer):
    return sanitizer.sub("", text).strip()


def evaluate_template(template, expr_dictionary):
    evaluated = template
    for k, v in expr_dictionary.items():
        evaluated = evaluated.replace(k, v)

    return evaluated


class RsDataEvaluator(object):

    @staticmethod
    def is_valid_rst2(row):
        return str(row.get("T", "")).strip() == "Y" \
               and str(row.get("Shares", "")).strip() != "0"

    @staticmethod
    def is_valid_rs1g(row):
        return str(row.get("1", "")).strip() == "Y" \
               and str(row.get("GroShares", "")).strip() != "0"

    @staticmethod
    def is_valid_rs1v(row):
        return str(row.get("1", "")).strip() == "Y" \
               and str(row.get("ValShares", "")).strip() != "0"

    @staticmethod
    def is_valid_rs5g(row):
        return str(row.get("5", '')).strip() == "Y" \
               and str(row.get("GroShares", "")).strip() != "0"

    @staticmethod
    def is_valid_rs5v(row):
        return str(row.get("5", '')).strip() == "Y" \
               and str(row.get("ValShares", "")).strip() != "0"

    @staticmethod
    def is_valid_rsmv(row):
        return str(row.get("M", '')).strip() == "Y" \
               and str(row.get("ValShares", "")).strip() != "0"

    @staticmethod
    def is_valid_rsmg(row):
        return str(row.get("M", '')).strip() == "Y" \
               and str(row.get("GroShares", "")).strip() != "0"

    @staticmethod
    def is_valid_rs2v(row):
        return str(row.get("2", '')).strip() == "Y" \
               and str(row.get("ValShares", "")).strip() != "0"

    @staticmethod
    def is_valid_rs2g(row):
        return str(row.get("2", '')).strip() == "Y" \
               and str(row.get("GroShares", "")).strip() != "0"

    @staticmethod
    def is_valid_rs25(row):
        return str(row.get("5", '')).strip() == "Y" \
               and str(row.get("Shares", "")).strip() != "0"

    @staticmethod
    def is_valid_rsmc(row):
        return str(row.get("M", '')).strip() == "Y" \
               and str(row.get("Shares", "")).strip() != "0"

    @staticmethod
    def is_valid_rs10(row):
        return str(row.get("1", '')).strip() == "Y" \
               and str(row.get("Shares", "")).strip() != "0"

    @staticmethod
    def is_valid_rs20(row):
        return str(row.get("2", '')).strip() == "Y" \
               and str(row.get("Shares", "")).strip() != "0"

    @staticmethod
    def is_valid_rs30(row):
        return str(row.get("WT-R3", '')).strip() \
               and str(row.get("WT-R3", "")).strip() != "0"


    @staticmethod
    def is_valid_rs3v(row):
        return str(row.get("WT-R3V", '')).strip() \
               and str(row.get("WT-R3V", "")).strip() != "0"

    @staticmethod
    def default_handler(code):
        raise ValueError("Invalid vendor file code:{}".format(code))

    @staticmethod
    def is_valid(row, code):
        code = (code or '').strip().lower()

        switch = {
            "rst2": RsDataEvaluator.is_valid_rst2,
            "rs1g": RsDataEvaluator.is_valid_rs1g,
            "rs1v": RsDataEvaluator.is_valid_rs1v,
            "rs5g": RsDataEvaluator.is_valid_rs5g,
            "rs5v": RsDataEvaluator.is_valid_rs5v,
            "rsmv": RsDataEvaluator.is_valid_rsmv,
            "rsmg": RsDataEvaluator.is_valid_rsmg,
            "rs2v": RsDataEvaluator.is_valid_rs2v,
            "rs2g": RsDataEvaluator.is_valid_rs2g,
            "rs25": RsDataEvaluator.is_valid_rs25,
            "rsmc": RsDataEvaluator.is_valid_rsmc,
            "rs10": RsDataEvaluator.is_valid_rs10,
            "rs20": RsDataEvaluator.is_valid_rs20,
            "rs30": RsDataEvaluator.is_valid_rs30,
            "rs3v": RsDataEvaluator.is_valid_rs3v
        }

        return switch.get(code, RsDataEvaluator.default_handler)(row)


class RgsDataFeedParser(object):
    """
    """

    # region private methods
    def __init__(self, logger=None, options=None):

        self.log = logger or logging.getLogger("{}".format(
            os.path.splitext(os.path.basename(__file__))[0]))

        try:

            self.start_time = datetime.now()
            self.end_time = None

            self.options = copy.deepcopy(
                vars(options) if options is not None else dict())
            self.default_config = da_config.get_etl_cfg()
            self.config = copy.deepcopy(self.default_config)
            self.config.update(self.options)

            level_name = self.config.get('log_level')
            if not level_name:
                level_name = self.config.get('dais').get('log_level', 'INFO')

            level = logging.getLevelName(level_name)
            os.environ['PYPIMCO_LOG_LEVEL_OVERRIDE'] = level_name
            from core.log import log_config
            log_config.init_logging(None, True)
            self.log.setLevel(level)

            formatter = logging.Formatter(
                '%(asctime)s %(threadName)s:%(thread)d %(name)s %(levelname)s %(message)s')

            logger = logging.getLogger('')
            for handler in logger.handlers:
                handler.setFormatter(formatter)

            # Try command line argument first --audit-id
            self.etl_audit_id = self.options.get('etl_audit_id')

            # Use environment variable param if command line
            # for audit id is not set
            if not self.etl_audit_id:
                # Capture etl audit id. This id is created by etl wrapper script
                # and saved to the ETL_AUDIT_ID environment variable
                self.etl_audit_id = os.environ.get('ETL_AUDIT_ID')

            # make sure audit id type is int
            # make sure audit id type is int
            self.etl_audit_id = int(self.etl_audit_id) if self.etl_audit_id \
                else self.etl_audit_id
            self.log.info("ETL_AUDIT_ID: %s", self.etl_audit_id)

            self.vnd_file_code = self.options.get('vnd_file_code')

            self.in_file = self.options.get('in_file')
            self.out_file = self.options.get('out_file')

            if not self.out_file:
                self.out_file = evaluate_template(
                    OUT_FILE_NAME_TEMPLATE, dict([
                            ("${YYYYMMDD}", datetime.now().strftime('%Y%m%d')),
                            ("${vnd_file_code}", self.vnd_file_code)
                        ])
                )

            self.ctx = util.struct(etl_audit_id=self.etl_audit_id,
                                   in_file=self.in_file,
                                   vnd_file_code=self.vnd_file_code)

            self.log.info("Agent started at %s", self.start_time)

        except Exception as e:
            self.log.critical(
                "Unable to initialize BbgRequestFlow: %s", e)
            raise

    def __enter__(self):
        # make a database connection and return it
        # self.dais_own = ora_xxx('DAIS_OWN', 'ORAPIM_DBP')
        # # make a database connection and return it
        # self.cfdw_own = ora_xxx('CFDW_OWN', 'ORAFND_DBP')
        #
        # self.ctx = util.struct(dais_own=self.dais_own,
        #                        cfdw_own=self.cfdw_own, **self.ctx)

        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources

        if self.config is not None:
            self.config = None

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("Agent completed at %s", self.end_time)
        self.log = None
    # endregion

    # region public methods
    def validate(self):
        """
        Executes validation logic upon start up of the driver.
        """
        if not self.etl_audit_id:
            raise ValueError(
                'Required audit job id not found in '
                'environment var:ETL_AUDIT_ID or cmd line params.')

        if not self.in_file:
            raise ValueError(
                'Required --in-file cmd line argument was not found.')

        if not self.vnd_file_code:
            raise ValueError(
                'Required --vnd-file-code cmd line argument was not found.')

        if not self.out_file:
            raise ValueError(
                '--out-file should be specified or derived from '
                '--vnd-file-code: "H_RGS_${YYYYMMDD}_${vnd_file_code}.csv"')

    @timed()
    def run(self):
        """
        Delegates processing to BbgIndexFlow instance.
        """
        try:

            if self.out_file:
                d, f = os.path.split(os.path.abspath(self.out_file))
                if not os.path.exists(d):
                    os.makedirs(d)

            with open(self.in_file, 'r') as in_file:
                csv_reader = csv.DictReader(in_file)
                producer = produce(csv_reader)
                with open(self.out_file, 'w') as out_file:
                    csv_writer = csv.DictWriter(
                        out_file, fieldnames=csv_reader.fieldnames,
                        quoting=csv.QUOTE_ALL, lineterminator="\n")
                    csv_writer.writeheader()
                    consumer = consume(csv_writer)
                    for row in producer:
                        if RsDataEvaluator.is_valid(row, self.vnd_file_code):
                            consumer.send(row)
                            self.log.info("code:%s, processing row: %s",
                                          self.vnd_file_code, row)
                        else:
                            self.log.info("code:%s, skipping row: %s",
                                          self.vnd_file_code, row)
                    consumer.close()
                producer.close()
        except Exception as e:
            self.log.critical(
                "{}: {} completed with error: {}".format(
                    os.path.splitext(os.path.basename(__file__))[0],
                    self.etl_audit_id, e), exc_info=1
            )
            raise

    # endregion


USAGE = [
    'RS CSV file splitter',
    ['--log-level', {'help': 'DEBUG, INFO, WARN, ERROR, CRITICAL'}],
    ['--etl-audit-id', {'help': 'Etl audit id for etl jobs max-len(10)'}],
    ['--vnd-file-code', {'help': 'Vendor file code', 'required': True}],
    ['--in-file', {'help': 'Etl input file name', 'required': True}],
    ['--out-file', {'help': 'Etl output file name', 'required': False}]
]


# noinspection PyBroadException
def main():
    """
    Delegates all processing to Agent instance.
    """
    logger = logging.getLogger("{}".format(
        os.path.splitext(os.path.basename(__file__))[0]))

    try:
        cmd_line = util.sanitize_cmd_line(copy.copy(sys.argv))
        logging.info(cmd_line)
        args = util.parse_args(*USAGE)
        with RgsDataFeedParser(logger=logger, options=args) as agent:
            agent.validate()
            agent.run()
    except Exception:
        logger.critical(
            "critical error in {}::".format(
                os.path.splitext(os.path.basename(__file__))[0]), exc_info=1)
        logger.critical("Agent exited with error.")
        return -1
    else:
        logger.info("Agent completed successfully.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
