from etl.core.db import ora_xxx

cfdw_own = ora_xxx('CFDW_OWN', 'ORAFND_DBP')
etl_source = cfdw_own.create_model('ETL_SOURCE')
etl_file = cfdw_own.create_model('ETL_FILE')

dais_own = ora_xxx('DAIS_OWN', 'ORAPIM_DBP')
vnd_file_inst = dais_own.create_model('VND_FILE_INST')


etl_file_dataset = cfdw_own.session.query(
    etl_file
).join(
    etl_source, etl_source.source_code == etl_file.file_source
).filter(
    etl_source.source_group_code == 'IDS',
    etl_file.is_ftp_done == 1, etl_file.is_etl_done == 0
)

if etl_file_dataset.count() > 0:
    for etl_file_row in etl_file_dataset:
        # print ("the ETL_FILE_ID is %s" %etl_file_row.etl_file_id)
        new_v_file_inst = vnd_file_inst(
            vnd_file_code=etl_file_row.file_type_code,
            vnd_file_inst_status_code='NEW',
            is_raw_pre_done=0,
            is_raw_core_done=0,
            is_raw_post_done=0,
            is_fmt_pre_done=0,
            is_fmt_core_done=0,
            is_fmt_post_done=0,
            is_nrm_pre_done=0,
            is_nrm_core_done=0,
            is_nrm_post_done=0,
            is_enr_pre_done=0,
            is_enr_core_done=0,
            is_enr_post_done=0,
            is_pub_pre_done=0,
            is_pub_core_done=0,
            is_pub_post_done=0,
            dw_etl_file_id=etl_file_row.etl_file_id,
            etl_run_date=etl_file_row.last_is_ftp_done_update_date,
            folder_name=etl_file_row.local_file_folder,
            file_name=etl_file_row.local_file_name,
            row_insert_by='svc_etl',
            row_update_by='svc_etl'
        )
        dais_own.save(new_v_file_inst)
        etl_file_row.is_etl_done = 1
        cfdw_own.save(etl_file_row)
