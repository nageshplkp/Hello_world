#!/usr/bin/env python
import sys
import logging
import os
import copy

from promise import Promise
from datetime import datetime, timedelta
from itertools import groupby

import etl.repo
from etl.core.db import ora_xxx

from etl.core import util, da_config
from etl.core.timed import timed
from etl.repo.pim_pm import *
from etl.repo.pim_dais import *
from etl.enum.pim_dais import *
from common.utils.bbg_data_license import BbgDL, BbgStatus

from managers.asset import AssetManager

logging.getLogger('sqlalchemy.engine').setLevel(logging.WARN)


# noinspection PyUnresolvedReferences
def _update_model(model, **kwargs):
    for k, v in kwargs.items():
        setattr(model, k.lower(), v)
    return model


def _reset_dict_keys(d, *keys):
    if isinstance(d, dict):
        for k in keys:
            if k in d:
                del d[k]


# noinspection PyUnresolvedReferences
class RdsSecIdBuilder(object):

    @staticmethod
    def _corp(for_sector, bb_id, isin, cusip, ticker, exch_code=None):

        _bb_id = (bb_id or '').upper()

        # 'Bank Loan 8/16/23  added BF 10/8/15'
        if _bb_id.startswith('BL') or \
                _bb_id.startswith('LN') or _bb_id.startswith('BF'):

            return util.struct(sec_id=bb_id, id_type='BBID',
                               source_sec_id=bb_id)
        elif len(isin or '') > 0:
            return util.struct(sec_id=isin, id_type='ISIN', source_sec_id=cusip)
        elif len(bb_id or '') > 0:
            return util.struct(
                sec_id=bb_id, id_type='BBID', source_sec_id=cusip)
        else:
            RdsSecIdBuilder._raise_error(
                for_sector, bb_id, isin, cusip, ticker, exch_code
            )

    @staticmethod
    def _muni(for_sector, bb_id, isin, cusip, ticker, exch_code=None):
        if len(cusip or '') > 0:
            return util.struct(
                sec_id=cusip, id_type='CUSIP', source_sec_id=cusip)
        else:
            RdsSecIdBuilder._raise_error(
                for_sector, bb_id, isin, cusip, ticker, exch_code
            )

    @staticmethod
    def _govt(for_sector, bb_id, isin, cusip, ticker, exch_code=None):
        if len(bb_id or '') > 0:
            return util.struct(
                sec_id=bb_id, id_type='BBID', source_sec_id=cusip)
        else:
            RdsSecIdBuilder._raise_error(
                for_sector, bb_id, isin, cusip, ticker, exch_code
            )

    @staticmethod
    def _mtge(for_sector, bb_id, isin, cusip, ticker, exch_code=None):
        if len(isin or '') > 0:
            return util.struct(sec_id=isin, id_type='ISIN', source_sec_id=cusip)
        else:
            RdsSecIdBuilder._raise_error(
                for_sector, bb_id, isin, cusip, ticker, exch_code
            )

    @staticmethod
    def _mmkt(for_sector, bb_id, isin, cusip, ticker, exch_code=None):
        if len(cusip or '') > 0:
            return util.struct(sec_id=cusip, id_type='CUSIP', source_sec_id=cusip)
        else:
            RdsSecIdBuilder._raise_error(
                for_sector, bb_id, isin, cusip, ticker, exch_code
            )

    @staticmethod
    def _equity(for_sector, bb_id, isin, cusip, ticker, exch_code=None):
        _ticker = (ticker or '')
        # sec_id = ''
        # It is safe to assume that exchange code should be the same as
        # Bloomberg ID for equities.
        # exch_code = exch_code or bb_id

        if len((ticker or '')) > 0 and len((exch_code or '')) > 0:

            last_ticker_char = _ticker[-1:]
            if last_ticker_char in ['u', 'r', 'w']:
                sec_id = "{}-{} {}".format(ticker[0:-1],
                                           last_ticker_char.upper(),
                                           exch_code)
            else:
                sec_id = "{} {}".format(ticker, exch_code)

            source_sec_id = "{}{}".format(exch_code, ticker)
            return util.struct(
                sec_id=sec_id, id_type='TICKER', source_sec_id=source_sec_id
            )

        elif len((isin or '')) > 0 and len((ticker or '')) > 0 and len((
                exch_code or '')) > 0:

            sec_id = "{} {}".format(isin, exch_code)
            source_sec_id = "{}{}".format(exch_code, ticker)
            return util.struct(
                sec_id=sec_id, id_type='ISIN', source_sec_id=source_sec_id
            )
        else:
            RdsSecIdBuilder._raise_error(
                for_sector, bb_id, isin, cusip, ticker, exch_code
            )

    @staticmethod
    def _pfd(for_sector, bb_id, isin, cusip, ticker, exch_code=None):

        if len((isin or '')) > 0:
            return util.struct(sec_id=isin, id_type='ISIN', source_sec_id=cusip)
        # 'added on 9/7/12 to deal with missing isins
        elif len((bb_id or '')) > 0:
            return util.struct(
                sec_id=bb_id, id_type='BBID', source_sec_id=cusip)
        else:
            RdsSecIdBuilder._raise_error(
                for_sector, bb_id, isin, cusip, ticker, exch_code
            )

    @staticmethod
    def _default(for_sector, bb_id, isin, cusip, ticker, exch_code=None):
        raise ValueError("Invalid sector: {}".format(for_sector))

    @staticmethod
    def _raise_error(for_sector, bb_id, isin, cusip, ticker, exch_code=None):
        raise ValueError(
            "Could not find  sec_id for sector: {}, bb_id: {}, "
            "isin: {}, cusip: {}, ticker: {}, exch_code: {}".format(
                for_sector, bb_id, isin, cusip, ticker, exch_code
            )
        )

    @staticmethod
    def get_sec_id(for_sector, bb_id, isin, cusip, ticker, exch_code=None):
        """
         Identify security id for RDS create instrument request.
         Logic was extracted from  DTS package [PORT_index 3 : Step: Load
         scratchdb..dts_ssm_id_gen]

        :param for_sector: str(CORP|MUNI|GOVT|MTGE|EQUITY|PFD)
        :param bb_id: str(), bloomberg id
        :param isin:
        :param cusip:
        :param ticker:
        :param exch_code:
        :return: namedtuple('Results', 'sec_id', 'id_type', 'source_sec_id')
        """
        sector = (for_sector or '').lower()

        switch = {
            "corp": RdsSecIdBuilder._corp,
            "muni": RdsSecIdBuilder._muni,
            "govt": RdsSecIdBuilder._govt,
            "mtge": RdsSecIdBuilder._mtge,
            "equity": RdsSecIdBuilder._equity,
            "pfd": RdsSecIdBuilder._pfd,
            "m-mkt":  RdsSecIdBuilder._mmkt
        }

        return switch.get(
            sector, RdsSecIdBuilder._default
        )(for_sector, bb_id, isin, cusip, ticker, exch_code)

    @staticmethod
    def get_sec_ident_status(rds_status_code):
        # IN_PROGRESS, PENDING_REVIEW, BAD_IDENTIFIER, BAD_REQUEST,
        # UNKNOWN_APP, SUCCESS, FAILED
        switch = {
            "IN_PROGRESS": lambda: SecIdentityStatusEnum.PEND_RDS.value,
            "PENDING_REVIEW": lambda: SecIdentityStatusEnum.DONE_RDS.value,
            "SUCCESS": lambda: SecIdentityStatusEnum.DONE_RDS.value,
            "BAD_REQUEST": lambda: SecIdentityStatusEnum.FAILED.value,
            "BAD_IDENTIFIER": lambda: SecIdentityStatusEnum.FAILED.value,
            "UNKNOWN_APP": lambda: SecIdentityStatusEnum.FAILED.value,
            "FAILED": lambda: SecIdentityStatusEnum.FAILED.value,
            # [TODO] remove this after RDS is fixed
            "NOT_SUPPORTED": lambda: SecIdentityStatusEnum.PEND_RDS.value,
            "INVALID requestId": lambda: SecIdentityStatusEnum.FAILED.value,
        }

        return switch.get(rds_status_code, SecIdentityStatusEnum.FAILED.value)()


class BbgRequestFlow(object):

    def __init__(self, logger=None, options=None):
        """
        Displays auditing details, retrieves configuration info, configures
        logger, captures etl_audit_id and connects to Oracle databases.
        #
        """
        # create module logger
        self.log = logger or logging.getLogger("ff_dais.enrichment_agent")
        try:

            self.options = copy.deepcopy(
                options if options is not None else dict())

            self.default_config = da_config.get_etl_cfg()
            self.config = copy.deepcopy(self.default_config)
            self.config.update(self.options)

            level_name = self.config.get('log_level')
            if not level_name:
                level_name = self.config.get('dais').get('log_level', 'INFO')

            level = logging.getLevelName(level_name)
            self.log.setLevel(level)

            self.etl_audit_job_id = self.options.get('etl_audit_id')

            # Build pipeline context
            self.context = util.struct(
                etl_audit_job_id=self.etl_audit_job_id,
                config=self.config, logger=None)

        except Exception as e:
            self.log.critical(
                "Unable to initialize BbgRequestFlow: %s", e)
            raise

    # BBG request flow

    @timed()
    def run_orig(self, **ctx):

        self.log.info('entering: bbg_request_flow')

        ctx = self.retrieve_mnemonics_for_bloomberg_call(**ctx)
        ctx = self.create_and_sync_dummy_securities(**ctx)
        ctx = self.sync_vnd_sec_set_with_sec_identity(**ctx)
        condition = True

        while condition:
            ctx = self.create_bbg_request_record(**ctx)
            ctx = self.create_records_for_bloomberg_call(**ctx)
            ctx = self.retrieve_securities_for_bloomberg_call(**ctx)

            condition = len(ctx.securities) > 0
            if condition:
                ctx = self.make_bloomberg_security_call(**ctx)
            else:
                repo = BbgSecRequestRepo.instance
                repo.db.session.delete(ctx.request)
                repo.db.session.commit()
                self.log.info('No more securities for Bloomberg call')

        self.log.info('exiting: bbg_request_flow')

    @timed()
    def run(self, **ctx):

        ctx = self.retrieve_mnemonics_for_bloomberg_call(**ctx)
        ctx = self.create_and_sync_dummy_securities(**ctx)
        ctx = self.sync_vnd_sec_set_with_sec_identity(**ctx)
        ctx = self.create_records_for_bloomberg_call(**ctx)
        ctx = self.retrieve_securities_for_bloomberg_call(**ctx)
        bbg_request = ctx.get('bbg_request')
        condition = len(ctx.securities) > 0 and bbg_request
        if condition:
            self.make_bloomberg_security_call(**ctx)

    @staticmethod
    def format_bbg_request_name(request_name):
        request_name = request_name.replace(
            '{session}', datetime.now().strftime('%m%d%H%M%S')
        )
        return request_name

    @staticmethod
    @timed()
    def retrieve_mnemonics_for_bloomberg_call(req_type_code, **kw):
        """
        :param req_type_code:
        :return:
        """
        rt_repo = BbgRequestTypeRepo.instance
        request_type = rt_repo.get_by_bbg_request_type_code(req_type_code)
        type_code = request_type.bbg_request_type_code

        repo = BbgMnemonicinRequestTypeRepo.instance
        results = repo.list_by_bbg_request_type_code(type_code)

        mnemonics = map(lambda item: item.bbg_mnemonic_code, results)
        ctx = util.struct(
            request_type=request_type, mnemonics=mnemonics, **kw
        )
        return ctx

    @staticmethod
    @timed()
    def create_and_sync_dummy_securities(audit_id, **kw):
        repo = VndSecSetRepo.instance
        repo.load_dummy_securities(audit_id)

        return util.struct(audit_id=audit_id, **kw)

    @staticmethod
    @timed()
    def create_bbg_request_record(request_type, **kw):

        request_name = request_type.req_name_template
        request_name = BbgRequestFlow.format_bbg_request_name(request_name)

        repo = BbgSecRequestRepo.instance

        last_request_time = datetime.now() - timedelta(minutes=55)
        last_request = repo.get_last_request(last_request_time)

        if not last_request:
            model = repo.model(
                bbg_request_name=request_name,
                bbg_response_name=request_name,
                bbg_request_type_code=BbgRequestTypeEnum.SEC.value,
                initial_request_date=datetime.now(),
                current_status_code=BbgSecRequestStatusEnum.NEW.value,
                current_status_date=datetime.now()
            )
            model = repo.save(model)
            kw['bbg_request'] = model
        return util.struct(
            request_type=request_type,
            **kw
        )

    @staticmethod
    @timed()
    def create_records_for_bloomberg_call(**kw):

        repo = BbgSecReqinSecIdentityRepo.instance
        config = kw.get('config')
        batch_size = config.get('dais_bbg_sec').get('batch_size')

        repo.create_records_for_bloomberg_call(
            audit_id=kw.get('audit_id'),
            limit=int(batch_size)
        )

        return util.struct(**kw)

    @timed()
    def retrieve_securities_for_bloomberg_call(self, offset=0, limit=10000, **kw):

        repo = BbgSecReqinSecIdentityRepo.instance
        rows = repo.list_next_available_batch(offset=offset, limit=limit)

        if rows:
            kw = self.create_bbg_request_record(**kw)
            bbg_request = kw.get('bbg_request')
            if bbg_request:
                request_id = bbg_request.bbg_sec_request_id
                for row in rows:
                    row.bbg_sec_request_id = request_id
                rows = repo.save(rows)

        rows = map(lambda sec: sec.bbg_request_value, rows)
        kw['securities'] = rows
        return util.struct(**kw)

    @staticmethod
    @timed()
    def retrieve_securities_for_bloomberg_call_orig(bbg_request, **kw):

        repo = BbgSecReqinSecIdentityRepo.instance
        rows = repo.list_by_bbg_sec_request_id(
            bbg_request.bbg_sec_request_id
        )

        rows = map(lambda sec: sec.bbg_request_value, rows)
        kw['securities'] = rows
        return util.struct(request=bbg_request, **kw)

    @timed()
    def make_bloomberg_security_call(
            self, bbg_request, mnemonics, securities, **kw):

        config = kw.get('config')
        cfg_section = config.get('dais_bbg_sec')
        req_dir = cfg_section['new_dir_{}'.format(os.name)]
        res_dir = cfg_section['old_dir_{}'.format(os.name)]
        archive_dir = cfg_section['archive_dir_{}'.format(os.name)]
        staging_dir = cfg_section['staging_dir_{}'.format(os.name)]

        headers = config.get('bbg_header')

        # noinspection PyUnusedLocal
        try:
            if len(securities) == 0 or len(mnemonics) == 0:
                self.log.warn(
                    "Skipping bloomberg call, mnemonics:%s or security "
                    "list:%s cannot be empty", mnemonics, securities,
                )
                raise ValueError(
                    "mnemonics:{} or security list:{} cannot be "
                    "empty".format(mnemonics, securities)
                )
            bbg = BbgDL(
                staging_dir=staging_dir,
                req_dir=req_dir,
                res_dir=res_dir,
                archive_dir=archive_dir,
            )
            req_name = bbg_request.bbg_request_name
            res_name = bbg_request.bbg_response_name

            status = bbg.data_request(
                req_name=req_name,
                res_name=res_name,
                headers=dict(headers),
                field_names=mnemonics,
                securities=securities)

            self.log.warn(
                "Created Bloomberg DL request: %s, with mnemonics:%d and "
                "securities: %d", req_name, len(mnemonics), len(securities)
            )

            if status == BbgStatus.SUCCESS:
                self._update_bbg_request_status(
                    bbg_request, BbgSecRequestStatusEnum.SUBMITTED.value)
            else:
                self._update_bbg_request_status(
                    bbg_request, BbgSecRequestStatusEnum.SUBMIT_FAILED.value)

        except Exception as e:
            self.log.exception(
                "Failed to submit bloomberg security request")
            self._update_bbg_request_status(
                bbg_request, BbgSecRequestStatusEnum.SUBMIT_FAILED.value)
            raise

        return util.struct(bbg_request=bbg_request, mnemonics=mnemonics,
                           securities=securities, **kw)

    @staticmethod
    @timed()
    def sync_vnd_sec_set_with_sec_identity(audit_id, **kw):
        repo = VndSecSetRepo.instance
        repo.sync_sec_ids(audit_id)

        return util.struct(audit_id=audit_id, **kw)

    @staticmethod
    @timed()
    def _update_bbg_request_status(request, status_code):
        repo = BbgSecRequestRepo.instance
        request.current_status_code = status_code
        request.current_status_date = datetime.now()
        repo.save(request)


class BbgResponseFlow(object):

    def __init__(self, logger=None, options=None):
        """
        Displays auditing details, retrieves configuration info, configures
        logger, captures etl_audit_id and connects to Oracle databases.
        """
        # create module logger
        self.log = logger or logging.getLogger("ff_dais.enrichment_agent")
        try:

            self.options = copy.deepcopy(
                options if options is not None else dict())

            self.default_config = da_config.get_etl_cfg()
            self.config = copy.deepcopy(self.default_config)
            self.config.update(self.options)

            level_name = self.config.get('log_level')
            if not level_name:
                level_name = self.config.get('dais').get('log_level', 'INFO')

            level = logging.getLevelName(level_name)
            self.log.setLevel(level)

            self.etl_audit_job_id = self.options.get('audit_id')

            # Build pipeline context
            self.context = util.struct(
                etl_audit_job_id=self.etl_audit_job_id,
                config=self.config, logger=None)

        except Exception as e:
            self.log.critical(
                "Unable to initialize BbgRequestFlow: %s", e)
            raise

    @timed()
    def run(self, **ctx):

        self.log.info('entering: bbg_response_flow')

        repo = BbgSecRequestRepo.instance

        condition = True
        while condition:
            request = repo.update_status_and_get_request(
                BbgSecRequestStatusEnum.SUBMITTED.value,
                BbgSecRequestStatusEnum.PENDING.value
            )
            condition = request is not None
            if condition:
                ctx['request'] = request
                ctx = self.try_process_pending_bbg_request(**ctx)
                if ctx.get('error', False) or ctx.get('exception', False):
                    self.log.warn(
                        "Error while trying to read DL response file:"
                        "{}".format(request.bbg_response_name)
                    )
                    self.log.warn(
                        "Skipping response file:"
                        "{}".format(request.bbg_response_name)
                    )
                    request.current_status_code = \
                        BbgSecRequestStatusEnum.ERRORED.value
                    request.current_status_date = datetime.now()
                    repo.save(request)
                    continue

                bbg_file_arrived = ctx.get('bbg_file_arrived', False)
                if bbg_file_arrived:
                    ctx = self.try_process_bbg_response_data_rows(**ctx)
                    ctx = self.try_process_upsert_securities(**ctx)
                else:
                    request.current_status_code = \
                        BbgSecRequestStatusEnum.SUBMITTED.value
                    request.current_status_date = datetime.now()
                    repo.save(request)
            else:
                self.log.info(
                    "There is no more pending bbg request, exiting pipeline..."
                )

        self.log.info('exiting: bbg_response_flow')

    @timed()
    def read_bloomberg_response(self, **kw):

        # def exclude(d, keys):
        #     return {key: val for key, val in d.items() if key not in keys}
        config = kw.get('config')
        cfg_sec = config.get('dais_bbg_sec')
        staging_dir = cfg_sec['staging_dir_{}'.format(os.name)]
        req_dir = cfg_sec['new_dir_{}'.format(os.name)]
        res_dir = cfg_sec['old_dir_{}'.format(os.name)]
        archive_dir = cfg_sec['archive_dir_{}'.format(os.name)]

        bbg_req_repo = BbgSecRequestRepo.instance

        request = bbg_req_repo.update_status_and_get_request(
            BbgSecRequestStatusEnum.SUBMITTED.value,
            BbgSecRequestStatusEnum.PENDING.value
        )
        securities = []

        try:

            if request is None:
                self.log.info(
                    "There is no pending bbg request, exiting pipline...")
                return util.struct(request=request, securities=securities, **kw)

            bbg = BbgDL(
                staging_dir=staging_dir, req_dir=req_dir,
                res_dir=res_dir, archive_dir=archive_dir)

            bbg_sec_in_req_repo = BbgSecReqinSecIdentityRepo.instance
            data_rows = bbg.data_rows(name=request.bbg_response_name)

            items = []
            for row in data_rows:

                security = str(row.get('SECURITY', ''))
                item = \
                    bbg_sec_in_req_repo.get_by_request_name_and_security_id(
                        name=request.bbg_response_name,
                        security_id=security
                    )

                if item is None:
                    self.log.warn(
                        "unable to find security: %s, for request:%s",
                        security,
                        request.bbg_response_name
                    )
                    continue

                status = int(row.get('RETURN_STATUS', -1))

                item.bbg_return_status = str(status)
                item.bbg_response_value = row.get('RAW_LINE', '')

                items.append(item)

                if status == 0:
                    securities.append(row)
                else:
                    # self.logger.warn(
                    #     "unable to resolve security id:%s, in %s request, "
                    #     "status:%d, row:%s",
                    #     security,
                    #     request.bbg_response_name,
                    #     status,
                    #     row.get('RAW_LINE', '')
                    # )
                    self.log.warn(
                        "unable to resolve security id:%s, in %s request, "
                        "status:%d",
                        security,
                        request.bbg_response_name,
                        status
                    )

            # bbg_sec_in_req_repo.bulk_save(items)
            bbg_sec_in_req_repo.save(items)

        except Exception as e:

            self.log.exception("Failed to parse bloomberg response:%s in "
                               "directory: %s, with exception: %s",
                               request.bbg_response_name, res_dir, e)

            bbg_req_repo.update_status_and_list_request(
                rows=[request] if request is not None else [],
                from_status=BbgSecRequestStatusEnum.PENDING.value,
                to_status=BbgSecRequestStatusEnum.ERRORED.value
            )

        return util.struct(request=request,
                           securities=securities, **kw)

    @staticmethod
    @timed()
    def try_get_bbg_global_id(bbg_sec_dict):
        return bbg_sec_dict.get('ID_BB_GLOBAL', '').strip()

    @timed()
    def try_process_upsert_securities(self, **ctx):

        request = ctx.get('request')
        securities = ctx.get('securities', [])
        securities.sort(key=lambda s: s['ID_BB_GLOBAL'])
        sec_ident_rows = []
        sec_ident_bbg_rows = []
        sec_ident_repo = SecIdentityRepo.instance
        sec_ident_bbg_repo = SecIdentityBbgRepo.instance
        bbg_req_repo = BbgSecRequestRepo.instance
        request_status = BbgSecRequestStatusEnum.SUCCEEDED.value
        try:
            for k, v in groupby(
                    securities, key=lambda s: s['ID_BB_GLOBAL']):

                values = list(v)
                if len(values) > 0:
                    sorted_list = sorted(
                        values, key=lambda s: s.get('LAST_UPDATE_DT', ''),
                        reverse=True
                    )
                    # pick most recently updated record
                    bbg_sec_dict = sorted_list[0]

                    id_bb_global = self.try_get_bbg_global_id(bbg_sec_dict)

                    # id_bb_global = bbg_sec_dict['ID_BB_GLOBAL']

                    if (id_bb_global or '').strip() == '':
                        self.log.warning(
                            "BBG_SECURITY_RESOLUTION_ERROR:"
                            "Empty id_bb_global: request:%s, "
                            "row: %s",
                            str(request),
                            str(bbg_sec_dict)
                        )
                        continue

                    sec_ident = sec_ident_repo.get_by_bb_global_id(
                        id_bb_global)

                    if sec_ident is None:
                        sec_ident = sec_ident_repo.model()

                    sec_ident = self.update_sec_identity(
                        sec_ident, bbg_sec_dict)

                    sec_ident = sec_ident_repo.save(sec_ident)

                    sec_ident_rows.append(sec_ident)

                    sec_ident_bbg = sec_ident_bbg_repo.get_by_sec_identity_id(
                        sec_ident.sec_identity_id)

                    if sec_ident_bbg is None:
                        sec_ident_bbg = sec_ident_bbg_repo.model()

                    sec_ident_bbg = self.update_sec_identity_bbg(
                        item=sec_ident_bbg, sec_ident=sec_ident,
                        security=bbg_sec_dict, request=request)

                    sec_ident_bbg = sec_ident_repo.save(sec_ident_bbg)
                    sec_ident_bbg_rows.append(sec_ident_bbg)

                # self.logger.info("ID:%s, count:%d, values:%s", k,
                #                  len(values), values)
                self.log.debug(
                    "response: %s, ID: %s, count: %d",
                    request.bbg_response_name, k, len(values))
            self.log.debug(
                "Saving security info, from bbg response: %s",
                request.bbg_response_name)

            # sec_ident_rows = sec_ident_repo.save(sec_ident_rows)
            self.log.debug(
                "Saved %d sec_identity records, from response: %s",
                len(sec_ident_rows), request.bbg_response_name)

            # for rec in sec_ident_bbg_rows:
            #     sec = next((s for s in sec_ident_rows if s.bb_global_id
            #                 == rec.bb_global_id), None)
            #
            #     if sec is not None:
            #         rec.sec_identity_id = sec.sec_identity_id
            #     else:
            #         self.log.error("cannot find security with: %s",
            #                        rec.bb_global_id)
            #         raise ValueError("Invalid security record:{}".format(
            #             json.dumps(rec)
            #         ))
            #
            # sec_ident_bbg_rows = sec_ident_bbg_repo.save(sec_ident_bbg_rows)
            self.log.info(
                "Saved %d sec_identity_bbg records, from response: %s",
                len(sec_ident_bbg_rows), request.bbg_response_name)

        except Exception as e:
            self.log.exception("Failed to upsert securities for request:%s "
                               "with exception: %s",
                               request.bbg_response_name, e)

            request_status = BbgSecRequestStatusEnum.ERRORED.value
        finally:
            bbg_req_repo.update_current_status(
                rows=[request] if request is not None else [],
                from_status=BbgSecRequestStatusEnum.PENDING.value,
                to_status=request_status
            )

        return util.struct(**ctx)

    @staticmethod
    @timed()
    def update_sec_identity(item, security):
        item.isin = security.get('ID_ISIN', '').strip()
        item.cusip = security.get('ID_CUSIP_ID_NUM', '').strip()
        item.sedol = security.get('ID_SEDOL1', '').strip()
        item.bb_id = security.get('ID_BB', '').strip()
        item.bb_global_id = security.get('ID_BB_GLOBAL', '').strip()
        item.street_ticker = security.get('TICKER', '').strip()
        item.exchange_code = security.get('EXCH_CODE', '').strip()
        item.sector = security.get('MARKET_SECTOR_DES', '').strip()
        item.sec_identity_status_code = SecIdentityStatusEnum.DONE_BBG.value

        return item

    @staticmethod
    @timed()
    def update_sec_identity_bbg(item, sec_ident, security, request):

        def excluded(d, keys):
            return {key: val for key, val in d.items() if key not in keys}

        sec_dict = excluded(security, ['RAW_LINE', 'SECURITY',
                                       'RETURN_STATUS', 'NUM_OF_FIELDS'])

        item = _update_model(item, **sec_dict)
        item.sec_identity_id = sec_ident.sec_identity_id
        item.bb_global_id = sec_dict.get('ID_BB_GLOBAL', '')
        item.refresh_req_date = request.initial_request_date
        item.refresh_complete_date = request.current_status_date
        return item

    @timed()
    def try_process_pending_bbg_request(self, **ctx):

        config = ctx.get('config')
        cfg_sec = config.get('dais_bbg_sec')
        request = ctx.get('request', None)
        req_dir = cfg_sec['new_dir_{}'.format(os.name)]
        res_dir = cfg_sec['old_dir_{}'.format(os.name)]
        try:
            staging_dir = cfg_sec['staging_dir_{}'.format(os.name)]
            archive_dir = cfg_sec['archive_dir_{}'.format(os.name)]
            _reset_dict_keys(ctx, 'bbg_data_rows', 'error', 'error_resp')

            bbg_data_rows = []
            ctx['bbg_data_rows'] = bbg_data_rows

            if request is None:
                self.log.warn("Can't process empty request.")
                return util.struct(securities=bbg_data_rows, **ctx)

            bbg = BbgDL(staging_dir=staging_dir, req_dir=req_dir,
                        res_dir=res_dir, archive_dir=archive_dir)

            name = request.bbg_response_name
            error, error_resp = bbg.err_response(name=name)

            if error:
                self.log.error(
                    "BBG request: %s returned error: %s", name, error_resp)
                ctx['error'] = error
                ctx['error_resp'] = error_resp
                return util.struct(**ctx)

            arrived, bbg_data_rows = bbg.data_rows(name=name)
            ctx['bbg_file_arrived'] = arrived
            ctx['bbg_data_rows'] = bbg_data_rows

        except Exception as e:
            self.log.exception("Failed to parse bloomberg response:%s in "
                               "directory: %s, with exception: %s",
                               request.bbg_response_name, res_dir, e)
            ctx['exception'] = e
        return util.struct(**ctx)

    @timed()
    def try_process_bbg_response_data_rows(self, **ctx):
        data_rows = ctx.get('bbg_data_rows', [])
        repo = BbgSecReqinSecIdentityRepo.instance
        request = ctx.get('request', None)
        name = request.bbg_response_name
        items = []
        securities = []

        _reset_dict_keys(ctx, 'securities')
        has_rows = False
        for row in data_rows:
            has_rows = True
            security = row.get('SECURITY', '')
            item = repo.get_by_request_name_and_security_id(
                name=name,
                security_id=security
            )

            if item is None:
                self.log.warn(
                    "unable to find security: %s, for request:%s",
                    security, name)
                continue

            status = int(row.get('RETURN_STATUS', -1))

            item.bbg_return_status = str(status)
            item.bbg_response_value = row.get('RAW_LINE', '')
            item.bb_global_id = row.get('ID_BB_GLOBAL', '')

            item = repo.save(item)
            items.append(item)

            if status == 0:
                securities.append(row)
            else:
                self.log.warn(
                    "unable to resolve security in request:%s,  id:%s, "
                    "status:%d",
                    name,
                    security,
                    status
                )
        # repo.save(items)

        if not has_rows:
            request.current_status_code = \
                BbgSecRequestStatusEnum.SUBMITTED.value
            request.current_status_date = datetime.now()
            repo.save(request)

        ctx['securities'] = securities
        return util.struct(**ctx)


class SsmIdMigrationFlow(object):

    def __init__(self, logger=None, options=None):
        """
        Displays auditing details, retrieves configuration info, configures
        logger, captures etl_audit_id and connects to Oracle databases.
        """
        # create module logger
        self.log = logger or logging.getLogger("ff_dais.ssm_id_migration_flow")
        try:

            self.options = copy.deepcopy(
                options if options is not None else dict())

            self.default_config = da_config.get_etl_cfg()
            self.config = copy.deepcopy(self.default_config)
            self.config.update(self.options)

            level_name = self.config.get('log_level')
            if not level_name:
                level_name = self.config.get('dais').get('log_level', 'INFO')

            level = logging.getLevelName(level_name)
            self.log.setLevel(level)

            self.etl_audit_job_id = self.options.get('audit_id')

            # Build pipeline context
            self.context = util.struct(
                etl_audit_job_id=self.etl_audit_job_id,
                config=self.config, logger=None)

        except Exception as e:
            self.log.critical(
                "Unable to initialize SsmIdMigrationFlow: %s", e)
            raise

    # region RDS- Request Flow

    @timed()
    def run(self, **ctx):
        is_debug = logging.DEBUG >= self.log.getEffectiveLevel()
        self.etl_audit_job_id = ctx.get('audit_id')
        with ora_xxx('DAIS_OWN', 'ORAPIM_DBP') as db:
            db.execute_proc(
                procedure='DAIS_OWN.SP_LOAD_SSM_ID_FROM_TAPS',
                params=util.struct(
                    i_is_in_debug=is_debug,
                    i_etl_audit_job_id=self.etl_audit_job_id
                )
            )

        return util.struct(**ctx)


class RdsRequestFlow(object):

    def __init__(self, logger=None, options=None):
        """
        Displays auditing details, retrieves configuration info, configures
        logger, captures etl_audit_id and connects to Oracle databases.
        """
        # create module logger
        self.log = logger or logging.getLogger("ff_dais.enrichment_agent")
        try:

            self.options = copy.deepcopy(
                options if options is not None else dict())

            self.default_config = da_config.get_etl_cfg()
            self.config = copy.deepcopy(self.default_config)
            self.config.update(self.options)

            level_name = self.config.get('log_level')
            if not level_name:
                level_name = self.config.get('dais').get('log_level', 'INFO')

            level = logging.getLevelName(level_name)
            self.log.setLevel(level)

            self.etl_audit_job_id = self.options.get('audit_id')

            # Build pipeline context
            self.context = util.struct(
                etl_audit_job_id=self.etl_audit_job_id,
                config=self.config, logger=None)

            self.db = etl.repo.OraPimRepo().db
            self.manager = AssetManager(self.context)
            self.requestor = "PBOGIE"
            self.req_type = "NewSecurity"
            self.id_type = "ID_BB_GLOBAL"
            # self.client_app = self.config.get("dais_rds_sec").get("client_app")
            self.req_id_tpl = "dais_ci_{}"

        except Exception as e:
            self.log.critical(
                "Unable to initialize BbgRequestFlow: %s", e)
            raise

    # region RDS- Request Flow

    @timed()
    def run(self, **ctx):

        self.log.info('entering: rds_request_flow')

        for securities in self.get_new_securities_from_sec_identity(**ctx):
            self.create_rds_request_sec_records(securities, **ctx)

        for r in self.call_create_instruments(**ctx):
            self.update_rds_request_sec_records(
                request_data=r.request_data,
                response=r.response,
                rds_request_sec_rows=r.rds_request_sec_rows, **ctx)

        self.log.info('exiting: rds_request_flow')

    @timed()
    def get_new_securities_from_sec_identity(self, **kw):

        repo = SecIdentityRepo(self.db)
        config = kw.get('config')
        batch_size = int(config.get('dais_rds_sec').get('batch_size'))
        iteration = kw.get('iteration', 0)
        condition = True

        while condition:
            # offset = iteration * batch_size
            offset = 0
            sec_identities = repo.update_status_and_list_new_sec_identities(
                from_status=SecIdentityStatusEnum.DONE_BBG.value,
                to_status=SecIdentityStatusEnum.ON_RDS.value,
                offset=offset, limit=batch_size
            )
            self.log.info(
                "Updated sec_identity status from:%s, to:%s for %d rows.",
                SecIdentityStatusEnum.DONE_BBG.value,
                SecIdentityStatusEnum.ON_RDS.value,
                len(sec_identities)
            )
            condition = len(sec_identities) > 0
            if condition:
                yield sec_identities
                iteration += 1
            else:
                break

        return

    @timed()
    def create_rds_request_sec_records(self, sec_identities, **kw):

        rds_sr_repo = RdsRequestSecRepo(self.db)
        vss_repo = VndSecSetRepo(self.db)
        vnd_repo = VndRepo(self.db)
        rds_request_sec_rows = []
        rds_sec_id_builder = RdsSecIdBuilder
        vss_distinct_by = ['sec_identity_id', 'vnd_code']

        for si in sec_identities:
            vss_rows = vss_repo.list_by_sec_identity_id(
                ids=[si.sec_identity_id],
                distinct_by=vss_distinct_by
            )

            vnd_codes = map(lambda v: v.vnd_code, vss_rows)
            vnd_rows = vnd_repo.list_by_vnd_codes(
                vnd_codes, distinct_by=['client_app'])

            for vnd_row in vnd_rows:
                sec_info = rds_sec_id_builder.get_sec_id(
                    for_sector=si.sector,
                    bb_id=si.bb_id,
                    isin=si.isin,
                    cusip=si.cusip,
                    ticker=si.street_ticker,
                    exch_code=si.exchange_code
                )

                rds_req_sec = rds_sr_repo.model(
                    sec_identity_id=si.sec_identity_id,
                    requestor=self.requestor,
                    asof_date=datetime.now().date(),
                    sector=si.sector,
                    bb_global_id=si.bb_global_id,
                    id_type=sec_info.id_type,
                    sec_id=sec_info.sec_id,
                    source_sec_id=sec_info.source_sec_id,
                    tries=0,
                    client_app=vnd_row.client_app
                )
                rds_request_sec_rows.append(rds_req_sec)

        rds_sr_repo.save(rds_request_sec_rows)
        self.log.info(
            "Created %d rds request records.", len(rds_request_sec_rows))
        return util.struct(**kw)

    @timed()
    def call_create_instruments(self, **kw):
        repo = RdsRequestSecRepo(self.db)
        config = kw.get('config')
        batch_size = int(config.get('dais_rds_sec').get('batch_size'))
        iteration = kw.get('iteration', 0)
        condition = True

        while condition:
            offset = iteration * batch_size
            rds_request_sec_rows = repo.list_rds_request_records(
                offset=offset, limit=batch_size)

            for k, v in groupby(
                    rds_request_sec_rows, key=lambda r: r.client_app):

                values = list(v)
                request_data = map(lambda r: {
                    "client_app": r.client_app,
                    "instrument_request_id": self.req_id_tpl.format(r.rds_request_sec_id),
                    "isdts_asof_date": r.asof_date.date().isoformat(),
                    "isdts_requestor": r.requestor,
                    "bbgid": r.bb_global_id,
                    "isdts_req_type": self.req_type,
                    "isdts_source_sec_id": r.source_sec_id,
                    "isdts_sec_id": r.sec_id,
                    "isdts_id_type": r.id_type,
                    "isdts_sector": r.sector
                }, values or [])

                condition = len(rds_request_sec_rows) > 0
                if condition:
                    self.log.info(
                        "making create instrument request for client app: %s"
                        ", count: %d", k, len(values)
                    )
                    response = self.manager.create_all(instruments=request_data)

                    yield util.struct(
                        request_data=request_data, response=response,
                        rds_request_sec_rows=rds_request_sec_rows
                    )

            condition &= len(rds_request_sec_rows) > 0
            if condition:
                iteration += 1
            else:
                break

    @timed()
    def call_create_instruments_orig(self, **kw):
        repo = RdsRequestSecRepo(self.db)
        config = kw.get('config')
        batch_size = int(config.get('dais_rds_sec').get('batch_size'))
        iteration = kw.get('iteration', 0)
        condition = True

        while condition:
            offset = iteration * batch_size
            request_data = []
            rds_request_sec_rows = repo.list_rds_request_records(
                offset=offset, limit=batch_size)

            for row in rds_request_sec_rows:
                req_id = self.req_id_tpl.format(row.rds_request_sec_id)

                request_data.append({
                    "client_app": row.client_app,
                    "instrument_request_id": req_id,
                    "isdts_asof_date": row.asof_date.date().isoformat(),
                    "isdts_requestor": row.requestor,
                    "bbgid": row.bb_global_id,
                    "isdts_req_type": self.req_type,
                    "isdts_source_sec_id": row.source_sec_id,
                    "isdts_sec_id": row.sec_id,
                    "isdts_id_type": row.id_type,
                    "isdts_sector": row.sector
                })

            condition = len(rds_request_sec_rows) > 0
            if condition:
                response = self.manager.create_all(instruments=request_data)
                yield util.struct(request_data=request_data, response=response,
                                  rds_request_sec_rows=rds_request_sec_rows)
                iteration += 1
            else:
                break

    @timed()
    def update_rds_request_sec_records(self, request_data, response,
                                       rds_request_sec_rows, **kw):

        sec_repo = SecIdentityRepo(self.db)
        repo = RdsRequestSecRepo(self.db)
        if response.status and isinstance(response.data, list):

            # update database
            for i, d in enumerate(response.data or []):
                row = next((r for idx, r in enumerate(
                    rds_request_sec_rows or []
                ) if self.req_id_tpl.format(
                    r.rds_request_sec_id) == d['instrument_request_id']))

                if row is not None:
                    row.request_date = datetime.now()
                    row.response_date = datetime.now()
                    row.response_status = d.get('status', '')
                    row.response_status_message = d.get('status_msg', '')

                    row.current_status_date = datetime.now()
                    row.current_status = d.get('status', '')
                    row.current_status_message = d.get('status_msg', '')
                    if d.get('ssm_id'):
                        row.ssm_id = d.get('ssm_id', '').strip()

                    row = repo.save(row)

                    sec_identity_id = row.sec_identity_id
                    sec = sec_repo.get_by_sec_identity_id(sec_identity_id)

                    if sec is not None:
                        sec.sec_identity_status_code = \
                            RdsSecIdBuilder.get_sec_ident_status(
                                row.response_status)
                        if row.ssm_id:
                            sec.ssm_id = row.ssm_id
                        sec_repo.save(sec)
                    else:
                        self.log.error(
                            "Unable to find security with id:"
                            " {}".format(sec_identity_id)
                        )
                else:
                    # we received an item that we haven't sent a request for
                    self.log.warning(
                        "Unknown record, this should "
                        "not happen:\r\nat index: {}\r\n"
                        "data: {}".format(i, d)
                    )
            # update rds_request_sec_rows records to RDS_REQUEST_SEC table,
            # so it reflects the latest RDS API request/response status
            # rds_request_sec_rows = repo.save(rds_request_sec_rows)

        else:
            self.log.error("Error while making create instrument request "
                           "to RDS API, with status: %s", response.status)

            for rds_req in rds_request_sec_rows:
                sec_identity_id = rds_req.sec_identity_id
                sec = sec_repo.get_by_sec_identity_id(sec_identity_id)

                if sec is not None:
                    sec.sec_identity_status_code = \
                        SecIdentityStatusEnum.FAILED.value
                    sec_repo.save(sec)

                    rds_req.current_status = 'FAILED'
                    rds_req.current_status_date = datetime.now()
                    repo.save(rds_req)
                else:
                    self.log.error(
                        "Unable to find security with id:"
                        " {}".format(sec_identity_id)
                    )
            raise SystemError(response.status)

        util.struct(request_data=request_data, response=response,
                    rds_request_sec_rows=rds_request_sec_rows, **kw)

    # endregion


class RdsResponseFlow(object):

    def __init__(self, logger=None, options=None):
        """
        Displays auditing details, retrieves configuration info, configures
        logger, captures etl_audit_id and connects to Oracle databases.
        """
        # create module logger
        self.log = logger or logging.getLogger("ff_dais.rds_response_flow")
        try:

            self.options = copy.deepcopy(
                options if options is not None else dict())

            self.default_config = da_config.get_etl_cfg()
            self.config = copy.deepcopy(self.default_config)
            self.config.update(self.options)

            level_name = self.config.get('log_level')
            if not level_name:
                level_name = self.config.get('dais').get('log_level', 'INFO')

            level = logging.getLevelName(level_name)
            self.log.setLevel(level)

            self.etl_audit_job_id = self.options.get('audit_id')

            # Build pipeline context
            self.context = util.struct(
                etl_audit_job_id=self.etl_audit_job_id,
                config=self.config, logger=None)

            self.manager = AssetManager(self.context)
            self.requestor = "PBOGIE"
            self.req_type = "NewSecurity"
            self.id_type = "ID_BB_GLOBAL"
            self.client_app = self.config.get("dais_rds_sec").get("client_app")
            self.req_id_tpl = "dais_ci_{}"

        except Exception as e:
            self.log.critical(
                "Unable to initialize BbgRequestFlow: %s", e)
            raise

    # region RDS- Response Flow

    @timed()
    def run(self, **ctx):

        self.log.info('entering: rds_response_flow')
        for pr in self.read_pending_rds_request_sec_records(**ctx):
            ctx['rds_request_sec_rows'] = pr
            ctx = self.check_pending_rds_request_status(**ctx)
            ctx = self.update_pending_rds_request_status(**ctx)
            ctx = self.update_ssm_id_xref_records(**ctx)

        ctx = self.sync_vnd_sec_set_with_sec_identity(**ctx)
        self.log.info('exiting: rds_request_flow')
        return ctx

    def read_pending_rds_request_sec_records(self, **kw):

        repo = RdsRequestSecRepo.instance
        config = kw.get('config')
        batch_size = int(config.get('dais_rds_sec').get('batch_size'))
        max_tries = int(config.get('dais_rds_sec').get('max_tries'))
        rds_retry_delta = int(config.get('dais_rds_sec').get('rds_retry_delta'))
        # it = kw.get('it', 0)
        # offset = 0
        condition = True

        while condition:
            # offset = it * batch_size
            offset = 0
            rds_pending_request_sec_rows = \
                repo.list_rds_pending_request_records(
                    offset=offset, limit=batch_size,
                    max_tries=max_tries, rds_retry_delta=rds_retry_delta
                )

            condition = len(rds_pending_request_sec_rows) > 0
            if condition:
                kw['rds_request_sec_rows'] = rds_pending_request_sec_rows
                yield rds_pending_request_sec_rows
                # it += 1
            else:
                self.log.info('No more pending RDS requests found.')
                break

        return

    def check_pending_rds_request_status(self, rds_request_sec_rows, **kw):

        request_ids = map(
            lambda row: self.req_id_tpl.format(row.rds_request_sec_id),
            rds_request_sec_rows
        ) or []
        response = self.manager.get_status_for_all(request_ids=request_ids)

        kw['rds_request_sec_rows'] = rds_request_sec_rows
        kw['response'] = response
        return util.struct(**kw)

    def update_pending_rds_request_status(self, rds_request_sec_rows,
                                          response, **kw):

        rds_request_sec_repo = RdsRequestSecRepo.instance
        sec_repo = SecIdentityRepo.instance

        if not response.status:
            raise SystemError(
                getattr(response, 'message', 'Unable to retrieve request status'
                                             ' from RDS'))

        if not hasattr(response, 'data') or not response.data:
            for row in rds_request_sec_rows:
                row.tries = (row.tries or 0) + 1
                row.current_status_date = datetime.now()
        elif isinstance(response.data, list):
            # update database
            for i, d in enumerate(response.data or []):
                row = next((r for idx, r in enumerate(
                    rds_request_sec_rows or []
                ) if self.req_id_tpl.format(r.rds_request_sec_id) ==
                    d['instrument_request_id']))

                if row is not None:
                    row.current_status = d.get('status', '')
                    row.current_status_message = d.get('status_msg', '')
                    row.current_status_date = datetime.now()
                    row.tries = (row.tries or 0) + 1

                    if d.get('ssm_id'):
                        row.ssm_id = d.get('ssm_id', '').strip()
                        sec_identity_id = row.sec_identity_id
                        sec = sec_repo.get_by_sec_identity_id(sec_identity_id)

                        if sec is not None:
                            sec.sec_identity_status_code = \
                                RdsSecIdBuilder.get_sec_ident_status(
                                    row.current_status)
                            sec.ssm_id = row.ssm_id
                            sec_repo.save(sec)

                        else:
                            self.log.error(
                                "Unable to find security with id:"
                                " {}".format(sec_identity_id)
                            )
                else:
                    # we received an item that we haven't sent a request for
                    self.log.warning(
                        "Unknown record, this should "
                        "never happen:\r\nat index: {}\r\n"
                        "data: {}".format(i, d)
                    )

        # update rds_request_sec_rows records to RDS_REQUEST_SEC table,
        # so it reflects the latest RDS API request/response status
        rds_request_sec_rows = rds_request_sec_repo.save(
            rds_request_sec_rows)

        kw['rds_request_sec_rows'] = rds_request_sec_rows
        kw['response'] = response
        return util.struct(**kw)

    @staticmethod
    def update_ssm_id_xref_records(**kw):
        repo = SsmIdXrefRepo.instance
        bbg_repo = SecIdentityBbgRepo.instance

        rds_request_sec_rows = kw.get('rds_request_sec_rows', [])

        filtered = (r for r in rds_request_sec_rows if (r.ssm_id or '').strip())
        for r in filtered:
            sk = 57 if r.sector == 'Equity' else 3

            RdsResponseFlow.update_ssm_id_xref(r, repo, sk)

            bbg_rec = bbg_repo.get_by_sec_identity_id(r.sec_identity_id)

            if bbg_rec is not None:
                # Check for bank loans
                if bbg_rec.market_sector_des == 'Corp' and \
                        bbg_rec.security_subflag == '99':
                    sk = 600
                    RdsResponseFlow.update_ssm_id_xref(r, repo, sk)

        return util.struct(**kw)

    @staticmethod
    def update_ssm_id_xref(rec, repo, sk):
        repo.query.filter(
            repo.model.source_key == sk
        ).filter(
            repo.model.source_sec_id == rec.source_sec_id
        ).delete()
        repo.db.session.commit()

        repo.save(repo.model(ssm_id=rec.ssm_id, source_sec_id=rec.source_sec_id,
                             source_key=sk, pricing_date=rec.asof_date,
                             validated_sw='Y'))

    @staticmethod
    def update_sec_prices_records(**kw):
        # repo = SsmIdXrefRepo.instance

        return util.struct(**kw)

    @staticmethod
    def sync_vnd_sec_set_with_sec_identity(audit_id, **kw):
        repo = VndSecSetRepo.instance
        repo.sync_sec_ids(audit_id)

        return util.struct(audit_id=audit_id, **kw)

    # endregion


# noinspection PyArgumentList,PyTypeChecker,PyUnresolvedReferences
class EnrichmentAgent(object):
    """
    Main driver for Bbg/Rds batch processing.
    """
    # region private methods
    def __init__(self, logger=None, options=None):
        """ 
        Displays auditing details, retrieves configuration info, configures
        logger, captures etl_audit_id and connects to Oracle databases.
        """
        # create module logger
        self.log = logger or logging.getLogger("{}".format(
            os.path.splitext(os.path.basename(__file__))[0]))
        try:
            # Display auditing details
            self.start_time = datetime.now()
            self.end_time = self.start_time

            self.options = copy.deepcopy(
                vars(options) if options is not None else dict())
            self.default_config = da_config.get_etl_cfg()
            self.config = copy.deepcopy(self.default_config)
            self.config.update(self.options)

            level_name = self.config.get('log_level')
            if not level_name:
                level_name = self.config.get('dais').get('log_level', 'INFO')

            level = logging.getLevelName(level_name)
            os.environ['PYPIMCO_LOG_LEVEL_OVERRIDE'] = level_name
            from core.log import log_config
            log_config.init_logging(None, True)
            self.log.setLevel(level)

            formatter = logging.Formatter(
                '%(asctime)s %(threadName)s:%(thread)d %(name)s %(levelname)s %(message)s')

            logger = logging.getLogger('')
            for handler in logger.handlers:
                handler.setFormatter(formatter)
            # print "RDS Driver started at {0}".format(self.driver_start_time)
            self.log.info("RDS Driver started at {0}".format(
                self.start_time))

            # Try command line argument first --audit-id
            self.etl_audit_id = self.options.get('etl_audit_id')

            # Use environment variable param if command line
            # for audit id is not set
            if self.etl_audit_id is None:
                # Capture etl audit id. This id is created by etl wrapper script
                # and saved to the ETL_AUDIT_ID environment variable
                self.etl_audit_id = os.environ.get('ETL_AUDIT_ID')

            # make sure audit id type is int
            self.etl_audit_id = int(self.etl_audit_id) if self.etl_audit_id \
                else self.etl_audit_id
            self.log.info("ETL_AUDIT_JOB_ID: %s", self.etl_audit_id)

            # Build pipeline context
            self.context = util.struct(
                etl_audit_job_id=self.etl_audit_id,
                config=self.config, logger=None)

            self.manager = AssetManager(self.context)
            self.requestor = "PBOGIE"
            self.req_type = "NewSecurity"
            self.id_type = "ID_BB_GLOBAL"
            self.client_app = self.config.get("dais_rds_sec").get("client_app")
        except Exception as e:
            self.log.critical(
                "Unable to initialize EnrichmentAgent: %s", e)
            raise

    def __enter__(self):
        # make a database connection and return it
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources
        # try:
        #     if self.connection is not None:
        #         self.connection.release()
        # finally:
        #     self.connection = None

        # Release resources
        if self.default_config is not None:
            self.default_config = None

        if self.config is not None:
            self.config = None

        if self.options is not None:
            self.options = None

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("Agent completed at %s", self.end_time)
        self.log = None
    # endregion

    @timed()
    def run(self):
        """
        Delegates pipeline processing to PipelineManager instance.
        """
        try:
            @Promise.safe
            def do():
                req_type_code = BbgRequestTypeEnum.SEC.value
                bbg_req_ctx = util.struct(
                    audit_id=self.etl_audit_id, req_type_code=req_type_code,
                    config=self.config
                )

                bbg_res_ctx = util.struct(
                    audit_id=self.etl_audit_id, config=self.config
                )

                ssm_id_ctx = util.struct(
                    audit_id=self.etl_audit_id, config=self.config
                )

                rds_req_ctx = util.struct(
                    audit_id=self.etl_audit_id, config=self.config,
                )

                rds_res_ctx = util.struct(
                    audit_id=self.etl_audit_id, config=self.config
                )

                bbg_req_flow = BbgRequestFlow(self.log, self.config)
                bbg_res_flow = BbgResponseFlow(self.log, self.config)
                ssm_id_flow = SsmIdMigrationFlow(self.log, self.config)
                rds_req_flow = RdsRequestFlow(self.log, self.config)
                rds_res_flow = RdsResponseFlow(self.log, self.config)

                return Promise.all([
                    bbg_req_flow.run(**bbg_req_ctx),
                    bbg_res_flow.run(**bbg_res_ctx),
                    ssm_id_flow.run(**ssm_id_ctx),
                    rds_req_flow.run(**rds_req_ctx),
                    rds_res_flow.run(**rds_res_ctx),
                ]).then(
                    lambda values: self.batch_completed(*values)
                )

            do().get()

        except Exception as e:
            self.log.critical(
                """Batch: {} completed with error: {}
                """.format(self.etl_audit_id, e)
            )
            raise

    # noinspection PyUnusedLocal
    @timed()
    def batch_completed(self, *values):
        self.log.info(
            "Batch: {} completed successfully".format(self.etl_audit_id)
        )
        return

    @timed()
    def validate(self):
        """ 
        Executes validation logic upon start up of the driver.
        """
        if self.etl_audit_id is None:
            raise ValueError(
                'Required audit job id not found in environment vars '
                'or cmd line params.')

    @timed()
    def finalize(self):
        """ 
        Releases resources and displays auditing details.
        """
        self.release()
        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: {0}s".format(elapsed_time))
        self.log.info(
            "RDS Driver completed at {0}".format(self.end_time)
        )

    @timed()
    def release(self):
        """ 
        Releases database and configuration resources
        """
        # Release resources
        if self.config is not None:
            self.config = None


USAGE = [
    'PM Price Synchronization Agent Description',
    ['--log-level', {'help': 'DEBUG, INFO, WARN, ERROR, CRITICAL'}],
    ['--etl-audit-id', {'help': 'audit id for etl jobs max-len(10)'}]
]


@timed()
def main():
    """ 
    Delegates all processing to EnrichmentAgent instance.
    """
    logger = logging.getLogger("{}".format(
        os.path.splitext(os.path.basename(__file__))[0]))
    # noinspection PyBroadException
    try:
        cmd_line = util.sanitize_cmd_line(copy.copy(sys.argv))
        logging.info(cmd_line)
        args = util.parse_args(*USAGE)
        with EnrichmentAgent(logger=logger, options=args) as agent:
            agent.validate()
            agent.run()

    except Exception:
        logger.critical(
            "critical error in EnrichmentAgent::", exc_info=1)
        logger.critical("Agent exited with error.")
        return -1
    else:
        logger.info("Agent completed successfully.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
