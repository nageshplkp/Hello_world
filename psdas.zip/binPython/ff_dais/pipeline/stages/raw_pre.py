
from base import PipelineStageBase

class RawPreStage(PipelineStageBase):
    def process_stage(self, vendor_file_instance):
        pass
