from base import PipelineStageBase

class RawCoreStage(PipelineStageBase):
    def process_stage(self, vendor_file_instance):
        pass

