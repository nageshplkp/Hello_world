import os
import sys
import logging

import etl.repo
from ff_dais.common import enums
from etl.core.db import ora_xxx
from ff_dais.dbmodels import cfdw_own
from ff_dais.dbmodels import dais_own
from tasks import tasks
# noinspection PyCompatibility
from Queue import Queue, Empty
from threading import Event, Thread


class PipelineManager:
    """
    Manages overall pipeline processing, including populating the pipeline
    and orchestrating the processing of pipeline items.
    """
    THREAD_POOL_SIZE = 10

    ins_sql = """
    INSERT INTO DAIS_OWN.VND_FILE_INST(
        VND_FILE_CODE, 
        VND_FILE_INST_STATUS_CODE,
        IS_RAW_PRE_DONE,
        IS_RAW_CORE_DONE,
        IS_RAW_POST_DONE,
        IS_FMT_PRE_DONE,
        IS_FMT_CORE_DONE,
        IS_FMT_POST_DONE,
        IS_NRM_PRE_DONE,
        IS_NRM_CORE_DONE,
        IS_NRM_POST_DONE,
        IS_ENR_PRE_DONE,
        IS_ENR_CORE_DONE,
        IS_ENR_POST_DONE,
        IS_PUB_PRE_DONE,
        IS_PUB_CORE_DONE,
        IS_PUB_POST_DONE,
        DW_ETL_FILE_ID,
        ETL_RUN_DATE,
        FOLDER_NAME,
        FILE_NAME,
        ROW_INSERT_BY,
        ROW_INSERT_DATE,
        ROW_UPDATE_BY,
        ROW_UPDATE_DATE)
      VALUES(
        :vnd_file_code,
        :vnd_file_inst_status_code,
        :is_raw_pre_done,
        :is_raw_core_done,
        :is_raw_post_done,
        :is_fmt_pre_done,
        :is_fmt_core_done,
        :is_fmt_post_done,
        :is_nrm_pre_done,
        :is_nrm_core_done,
        :is_nrm_post_done,
        :is_enr_pre_done,
        :is_enr_core_done,
        :is_enr_post_done,
        :is_pub_pre_done,
        :is_pub_core_done,
        :is_pub_post_done,
        :dw_etl_file_id,
        SYSDATE,
        :folder_name,
        :file_name,
        USER,
        SYSDATE,
        USER,
        SYSDATE)
    """

    update_sql = """
    update cfdw_own.etl_file  
        set is_etl_done=1
    where 1=1
        and file_source in (
                select source_code 
                from cfdw_own.etl_source 
                where source_group_code=:source_group_code
            )
        and is_enabled=1
        and is_ftp_done=1
        and is_etl_done=0
    """

    def __init__(self, ctx):
        """
        PipelineManager constructor

        args:
            context (PipelineContext): Instance containing pipeline execution
            context.
        """
        self.ctx = ctx
        self.ctx.logger = logging.getLogger(__name__)

    def pre(self):
        """ 
        Pipeline pre task - Populate pipeline. Populates pipeline by loading
        records
        from CFDW_OWN.ETL_FILE and populating DAIS_OWN.VND_FILE_INST table.
        """
        data = []

        # query ETL_FILE where
        #   IS_ENABLED = 1
        #   IS_FTP_DONE = 1
        #   IS_ETL_DONE = 0
        # join ETL_SOURCE where
        #   SOURCE_GROUP_CODE = 'IDS'
        files = self.ctx.session_fnd.query(
            cfdw_own.EtlFile).join(
            cfdw_own.EtlFile.etl_source).filter(
            (cfdw_own.EtlSource.source_group_code == self.ctx.etl_source_group_code)
            & (cfdw_own.EtlFile.is_enabled == 1)
            & (cfdw_own.EtlFile.is_ftp_done == 1)
            & (cfdw_own.EtlFile.is_etl_done == 0)
        ).order_by(cfdw_own.EtlFile.scheduled_pickup_date)
        # print "etl file count: {0}".format(files.count())
        self.ctx.logger.info("etl file count: %i", files.count())

        # Build dictionary containing details for new VND_FILE_INST records
        for vnd_file in files:
            data.append({
                "vnd_file_code": vnd_file.custom_field_1,
                # "vnd_file_code": vnd_file.file_type_code,
                "vnd_file_inst_status_code": 'NEW',
                "is_raw_pre_done": 0,
                "is_raw_core_done": 0,
                "is_raw_post_done": 0,
                "is_fmt_pre_done": 0,
                "is_fmt_core_done": 0,
                "is_fmt_post_done": 0,
                "is_nrm_pre_done": 0,
                "is_nrm_core_done": 0,
                "is_nrm_post_done": 0,
                "is_enr_pre_done": 0,
                "is_enr_core_done": 0,
                "is_enr_post_done": 0,
                "is_pub_pre_done": 0,
                "is_pub_core_done": 0,
                "is_pub_post_done": 0,
                "dw_etl_file_id": vnd_file.etl_file_id,
                "etl_run_date": vnd_file.last_is_ftp_done_update_date,
                "folder_name": vnd_file.local_file_folder,
                "file_name": vnd_file.local_file_name,
                "row_insert_by": 'svc_etl',
                "row_update_by": 'svc_etl'
            })

        # List of file ids being processed
        etl_file_ids = [vnd_file.etl_file_id for vnd_file in files]

        self.ctx.logger.info(
            'found: {} etl_files with etl_files_ids: {}'.format(
                len(etl_file_ids), etl_file_ids
            )
        )

        if len(etl_file_ids) > 0 and len(data) > 0:
            # load DAIS_OWN.VND_FILE_INST
            # self.ctx.oradb_pim.execute(PipelineManager.ins_sql, data)
            self.ctx.oradb_pim.execute_sql(PipelineManager.ins_sql, data)
            self.ctx.session_pim.commit()

            self.ctx.oradb_fnd.execute_sql(
                PipelineManager.update_sql, {'source_group_code': 'IDS_GRP'}
            )

            # # mark CFDW_OWN.ETL_FILE.IS_ETL_DONE to 1
            # self.ctx.session_fnd.query(cfdw_own.EtlFile) \
            #     .filter((cfdw_own.EtlFile.etl_file_id.in_(etl_file_ids))) \
            #     .update({cfdw_own.EtlFile.is_etl_done: 1},
            #             synchronize_session='fetch')
            self.ctx.session_fnd.commit()

        return len(etl_file_ids)

    def core(self):
        """ 
        Pipeline core task - Process pipeline.
        """
        try:
            # Get pipeline items...
            pipeline_item_ids = self.get_pipeline_items()

            self.ctx.logger.info(
                'create {} pipeline_items with pipeline_item_ids: {}'.format(
                    len(pipeline_item_ids), pipeline_item_ids
                )
            )
            # ... and process them
            if len(pipeline_item_ids) > 0:
                self.process_pipeline(pipeline_item_ids)

            # print "Processing completed successfully."
            self.ctx.logger.info("Processing completed successfully.")

        except Exception as e:
            # print "Error in pipeline core task: {0}".format(e)
            self.ctx.logger.info("Error in pipeline core task: {0}".format(e))
            raise

    def process_pipeline(self, pipeline_item_ids):
        """
        Process pipeline items based on id.

        args:
            pipeline_item_ids (list of int): List of vendor file instance ids 
            currently in the pipeline to be processed.
        """
        # print "pipeline count: {0}".format(len(pipeline_item_ids))
        self.ctx.logger.info(
            "pipeline count: {0}".format(len(pipeline_item_ids)))

        # Initialize pipeline queue
        pipeline_queue = self.create_pipeline_queue(pipeline_item_ids)

        # Create worker threads
        thread_pool = self.create_thread_pool(pipeline_queue)

        # Wait for queue items to be processed
        self.block_until_completed(pipeline_queue, thread_pool)

    @staticmethod
    def create_pipeline_queue(pipeline_item_ids):
        """
        Create and initalize pipeline queue.

        args:
            pipeline_item_ids (list of int): List of vendor file instance ids 
            currently in the pipeline to be processed.
            Pipeline queue initialized with provided pipeline item ids.
        """
        pipeline_queue = Queue()

        for item_id in pipeline_item_ids:
            pipeline_queue.put(item_id)

        return pipeline_queue

    def create_thread_pool(self, pipeline_queue):
        """
        Create pool of worker threads for processing pipeline items

        args:
            pipeline_queue (Queue): pipeline queue containing items to be
            processed

        returns:
            List of pipeline worker threads
        """
        # Create pool of threads
        thread_pool = [self.create_thread(pipeline_queue, i + 1) for i in
                       range(PipelineManager.THREAD_POOL_SIZE)]

        # Start threads after thread pool is established
        # print "Starting worker threads..."
        self.ctx.logger.info("Starting worker threads...")
        for thread in thread_pool:
            thread.start()

        return thread_pool

    def create_thread(self, pipeline_queue, thread_number):
        """
        Create worker thread for processing pipeline items

        args:
            pipeline_queue (Queue): Pipeline queue containing items to be
            processed thread_number (int): Unique number identifying thread
            to be created.

        returns:
            Instance of pipeline worker thread.
        """
        thread = PipelineWorkerThread(
            self.ctx.config, self.ctx.etl_audit_job_id,
            self.ctx.requestor, pipeline_queue)
        thread.name = "WorkerThread{0}".format(thread_number)
        thread.setDaemon(True)
        return thread

    def block_until_completed(self, pipeline_queue, thread_pool):
        """
        Block main process until worker threads have completed.

        args:
            pipeline_queue (Queue): Pipeline queue containing items
            to be processed thread_number (int):
                Unique number identifying thread to be created.
        """
        # Wait for items in queue to be processed
        pipeline_queue.join()

        # Stop threads...
        # print "Stopping worker threads..."
        self.ctx.logger.info("Stopping worker threads...")
        for thread in thread_pool:
            thread.stop()

        # ... and wait for them to finish
        for thread in thread_pool:
            thread.join()

        # print "Worker threads stopped successfully."
        self.ctx.logger.info("Worker threads stopped successfully.")

    def post(self):
        """ 
        Pipeline post task - Pipeline post processing. 
        """
        pass

    def get_pipeline_items(self):
        """
        Retrieve ids for pipeline items ready for processing.
        """
        items = self.ctx.session_pim.query(
            dais_own.VndFileInst
        ).filter(
            dais_own.VndFileInst.is_raw_pre_done.in_([0, 1]),
            dais_own.VndFileInst.is_raw_core_done.in_([0, 1]),
            dais_own.VndFileInst.is_raw_post_done.in_([0, 1]),
            dais_own.VndFileInst.is_fmt_pre_done.in_([0, 1]),
            dais_own.VndFileInst.is_fmt_core_done.in_([0, 1]),
            dais_own.VndFileInst.is_fmt_post_done.in_([0, 1]),
            dais_own.VndFileInst.is_nrm_pre_done.in_([0, 1]),
            dais_own.VndFileInst.is_nrm_core_done.in_([0, 1]),
            dais_own.VndFileInst.is_nrm_post_done.in_([0, 1]),
            dais_own.VndFileInst.is_enr_pre_done.in_([0, 1]),
            dais_own.VndFileInst.is_enr_core_done.in_([0, 1]),
            dais_own.VndFileInst.is_enr_post_done.in_([0, 1]),
            dais_own.VndFileInst.is_pub_pre_done.in_([0, 1]),
            dais_own.VndFileInst.is_pub_core_done.in_([0, 1]),
            dais_own.VndFileInst.is_pub_post_done.in_([0])
        )
        return [item.vnd_file_inst_id for item in items]


class PipelineWorkerThread(Thread):
    """
    Worker thread used to process pipeline items.
    """
    QUEUE_POLLING_TIMEOUT_SECS = 2

    def __init__(self, config, etl_audit_job_id, requestor, pipeline_queue):
        """
        PipelineWorkerThread constructor.

        args:
            config (Config): Configuration object containing environment
            config values. etl_audit_job_id (int): Audit id used for
            tracking purposes in data warehouse. pipeline_queue (Queue):
                Pipeline queue containing items to be processed
        """
        super(PipelineWorkerThread, self).__init__()
        self.stop_requested = Event()
        self.config = config
        self.etl_audit_job_id = etl_audit_job_id
        self.requestor = requestor
        self.req_idx_tpl = "dais_sw_{}"
        self.pipeline_queue = pipeline_queue
        self.logger = logging.getLogger(__name__)

    def stop(self):
        """
        Requests thread to stop processing. If the thread is currently
        processing an item, it will complete processing before stopping.
        If the thread is waiting for items to be loaded into the queue,
        it will exit gracefully when the polling timeout is reached.
        """
        if not self.stop_requested.isSet():
            self.stop_requested.set()

    def run(self):

        """
        Runs main thread logic - Process items in the pipeline queue until 
        requested to stop by the parent process.
        """
        item_mgr = self.create_item_manager()

        # Get next available item from pipeline queue and process. Continue
        # processing queue items until thread is requested to stop by parent
        # process.
        while not self.stop_requested.isSet():
            vnd_file_inst_id = None
            try:
                # Try to get next item from the pipeline queue
                vnd_file_inst_id = self.pipeline_queue.get(
                    True, PipelineWorkerThread.QUEUE_POLLING_TIMEOUT_SECS)

                # Process pipeline item
                self.process_item(item_mgr, vnd_file_inst_id)

                # Mark queue item complete
                # self.pipeline_queue.task_done()
            except Empty:
                # Timeout expired before an item was available in the queue.
                # Time to check if we've been requested to stop.
                continue
            except Exception as e:

                self.logger.exception(
                    "thread::%s, Exception occurred in:%s ", self.name, e)
            except:
                self.logger.exception(
                    "thread::%s, Unexpected error:%s",
                    self.name, sys.exc_info()[0])
            finally:
                # Mark queue item complete even if an exception occurred
                if vnd_file_inst_id is not None:
                    self.pipeline_queue.task_done()

        # self.safe_print("{0} thread shutting down...".format(self.name))
        self.logger.info("{0} thread shutting down...".format(self.name))

    def create_item_manager(self):
        """
        Creates an instance of PipelineItemManager with a dedicated context.
        """
        # Create dedicated pipeline context instance
        context = PipelineContext(
            self.config, self.etl_audit_job_id, self.requestor,
            self.req_idx_tpl, self.name)

        # context.oradb_pim = OracleDb("ORAPIM_DBP")
        # context.session_pim = context.oradb_pim.session
        # context.oradb_fnd = OracleDb("ORAFND_DBP")
        # context.session_fnd = context.oradb_fnd.session

        # share DbContext  per thread
        context.oradb_pim = ora_xxx('DAIS_OWN', 'ORAPIM_DBP')
        context.session_pim = context.oradb_pim.session
        context.oradb_fnd = ora_xxx('CFDW_OWN', 'ORAFND_DBP')
        context.session_fnd = context.oradb_fnd.session

        # share repo db connection per thread
        context.ora_pim_db = etl.repo.OraPimRepo().db
        context.ora_fnd_db = etl.repo.OraFndRepo().db

        # Create item manager using the new context
        return PipelineItemManager(context)

    @staticmethod
    def process_item(item_mgr, vnd_file_inst_id):
        """
        Process pipeline item using the vendor file instance id.

        args:
            item_mgr: (PipelineItemManager): Instance of pipeline item manager
            to use to process item  vnd_file_inst_id: (int): Unique
            identifier for the vendor file instance
        """
        # Load vendor file instance
        item = item_mgr.context.session_pim \
            .query(dais_own.VndFileInst) \
            .filter(dais_own.VndFileInst.vnd_file_inst_id == vnd_file_inst_id) \
            .first()

        # print "{0}: Item: {1}: {2}".format(self.name, vnd_file_inst_id, item)
        # Delegate item processing to pipeline item manager

        # patch path names for windows
        # \\nasclusdev\da_dev\da_data\
        # '/appl/da_dev/da_data/ids/sb/in/'
        # if os.sys.platform == "win32":
        #     item.folder_name = item.folder_name.replace(
        #         '/appl', '\\\\nasclusdev'
        #     ).replace('/', '\\')
        #     item.file_name = item.file_name.replace('/', '\\')

        # change the status back to processing
        status_code_field = dais_own.VndFileInst.vnd_file_inst_status_code

        item_mgr.context.session_pim.query(
            dais_own.VndFileInst
        ).filter(
            dais_own.VndFileInst.vnd_file_inst_id == item.vnd_file_inst_id
        ).update({
            status_code_field: enums.VndFileInstStatus.PROCESSING.value
        }, synchronize_session='fetch')
        item_mgr.context.session_pim.commit()

        item_mgr.pre(item)
        item_mgr.core(item)
        item_mgr.post(item)

    @staticmethod
    def safe_print(message):
        """
        Prints messages to sysout in a thread safe manner.

        args: 
            message (str): message to be printed
        """
        print ("{0}\n".format(message))


class PipelineContext(object):
    """
    Pipeline execution context, including configuration, database connections
    and other environment specific details.
    """

    def __init__(self, config, etl_audit_job_id, requestor, req_idx_tpl,
                 etl_source_group_code,  thread_name=None):
        """
        PipelineContext constructor.

        args:
            config (Config): Configuration object containing environment
            config values.
            etl_audit_job_id (int): Audit id used for tracking purposes in
            data warehouse.
        """
        self.config = config
        self.etl_audit_job_id = etl_audit_job_id
        self.requestor = requestor
        self.req_idx_tpl = req_idx_tpl
        self.thread_name = thread_name

        self.ora_pim_db = None
        self.oradb_pim = None
        self.session_pim = None

        self.ora_fnd_db = None
        self.oradb_fnd = None
        self.session_fnd = None

        self.logger = None
        self.etl_source_group_code = etl_source_group_code


class PipelineItemManager(object):
    """ 
    Manages pipeline item processing through raw, format, normalization, 
    enrichment and publish phases.
    """

    def __init__(self, context):
        """
        PipelineItemManager constructor.
        
        args:
            context (PipelineContext): Instance containing pipeline execution
            context.
        """
        self.context = context
        self.tasks = [
            tasks.RawPreTask(self.context),
            tasks.RawCoreTask(self.context),
            tasks.RawPostTask(self.context),
            tasks.FmtPreTask(self.context),
            tasks.FmtCoreTask(self.context),
            tasks.FmtPostTask(self.context),
            tasks.NrmPreTask(self.context),
            tasks.NrmCoreTask(self.context),
            tasks.NrmPostTask(self.context),
            tasks.EnrPreTask(self.context),
            tasks.EnrCoreTask(self.context),
            tasks.EnrPostTask(self.context),
            tasks.PubPreTask(self.context),
            tasks.PubCoreTask(self.context),
            tasks.PubPostTask(self.context),
        ]

    def pre(self, item):
        """
        Pipeline item pre task - Item pre processing.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        pass

    def core(self, item):
        """
        Pipeline item core task - Process item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        # Pass pipeline item to each task for processing
        for task in self.tasks:
            if task.is_ready(item):
                task.process(item)

    def post(self, item):
        """
        Pipeline item post task - Item post processing.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        pass
