#!/usr/bin/env python
import itertools
import os
import sys
import logging
import copy
from datetime import datetime

import etl.repo
from etl.core import util
from etl.core import da_config
from etl.core.timed import timed
from etl.core.db import ora_xxx
from etl.enum.pim_dais import *
from etl.repo.pim_dais import RdsRequestIdxConstSwRepo
from managers.asset import AssetManager

__app__ = sys.modules['__main__']


class IdxConstSwAgent(object):
    """
    #
    """

    # region private methods
    def __init__(self, logger=None, options=None):
        self.start_time = datetime.now()
        self.end_time = None

        self.options = copy.deepcopy(
            vars(options) if options is not None else dict())
        self.default_config = da_config.get_etl_cfg()
        self.config = copy.deepcopy(self.default_config)
        self.config.update(self.options)

        self.log = logger or logging.getLogger(
            "ff_dais.idx_const_switch_synch_agent")

        level_name = self.config.get('log_level')
        if not level_name:
            level_name = self.config.get('dais').get('log_level', 'INFO')

        level = logging.getLevelName(level_name)
        os.environ['PYPIMCO_LOG_LEVEL_OVERRIDE'] = level_name

        # Reinitialize pypimco log handlers with requested level
        from core.log import log_config
        log_config.init_logging(None, True)
        self.log.setLevel(level)

        # Try command line argument first --audit-id
        self.etl_audit_id = self.options.get('etl_audit_id')

        # Use environment variable param if command line
        # for audit id is not set
        if self.etl_audit_id is None:
            # Capture etl audit id. This id is created by etl wrapper script
            # and saved to the ETL_AUDIT_ID environment variable
            self.etl_audit_id = os.environ.get('ETL_AUDIT_ID')

        # make sure audit id type is int
        self.etl_audit_id = int(self.etl_audit_id) if self.etl_audit_id \
            else self.etl_audit_id

        self.log.info("ETL_AUDIT_ID: %s", self.etl_audit_id)

        self.dais_own = None
        self.req_id_tpl = "dais_sw_{}"
        self.requestor = "PBOGIE"
        self.pim_db = None

        self.context = util.struct(
            etl_audit_job_id=self.etl_audit_id,
            config=self.config, logger=None)

        self.log.info("Driver started at %s", self.start_time)

    def __enter__(self):
        # make a database connection and return it
        self.dais_own = ora_xxx('DAIS_OWN', 'ORAPIM_DBP')
        self.pim_db = etl.repo.OraPimRepo().db
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources
        try:
            if self.dais_own is not None:
                self.dais_own.release()

            if self.pim_db is not None and self.pim_db.session:
                self.pim_db.session.close()

            if self.pim_db is not None and self.pim_db.engine:
                self.pim_db.engine.dispose()

        finally:
            self.dais_own = None
            if self.pim_db is not None and self.pim_db.session:
                self.pim_db.session = None

            if self.pim_db is not None and self.pim_db.engine:
                self.pim_db.engine = None

            self.pim_db = None

        # Release resources
        if self.config is not None:
            self.config = None

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("Driver completed at %s", self.end_time)
        self.log = None

    @staticmethod
    def _get_sec_ident_status(rds_status_code):
        # IN_PROGRESS, PENDING_REVIEW, BAD_IDENTIFIER, BAD_REQUEST,
        # UNKNOWN_APP, SUCCESS, FAILED
        switch = {
            "IN_PROGRESS": lambda: SecIdentityStatusEnum.PEND_RDS.value,
            "PENDING_REVIEW": lambda: SecIdentityStatusEnum.DONE_RDS.value,
            "SUCCESS": lambda: SecIdentityStatusEnum.DONE_RDS.value,
            "BAD_REQUEST": lambda: SecIdentityStatusEnum.FAILED.value,
            "BAD_IDENTIFIER": lambda: SecIdentityStatusEnum.FAILED.value,
            "UNKNOWN_APP": lambda: SecIdentityStatusEnum.FAILED.value,
            "FAILED": lambda: SecIdentityStatusEnum.FAILED.value,
            # [TODO] remove this after RDS is fixed
            "NOT_SUPPORTED": lambda: SecIdentityStatusEnum.PEND_RDS.value,
            "INVALID requestId": lambda: SecIdentityStatusEnum.FAILED.value,
        }

        return switch.get(rds_status_code, SecIdentityStatusEnum.FAILED.value)()

    # endregion

    # region RDS request idx const switch update
    def _get_rds_idx_const_sw_requests(self, batch_size):
        """
        :param: int(batch_size)
        :return: list
        :rtype: list
        """
        repo = RdsRequestIdxConstSwRepo(self.pim_db)
        iteration = 0
        condition = True

        while condition:
            # offset = iteration * batch_size
            offset = 0

            if condition:
                response = repo.list_new_rds_idx_const_sw_requests(
                    offset=offset, limit=batch_size)
                self.log.info(
                    "list_new_rds_idx_const_sw_requests"
                    "(offset=%i, limit=%i), count:%i",
                    offset, batch_size, len(response)
                )
                yield response
                iteration += 1
                condition = len(response) > 0
            else:
                break

    def _update_rds_idx_const_sw_request_status(self, request, response):

        repo = RdsRequestIdxConstSwRepo(self.pim_db)

        # update database
        for i, d in enumerate(response or []):
            row = next((r for idx, r in enumerate(
                request or []
            ) if self.req_id_tpl.format(
                r.rds_request_idx_const_sw_id
            ) == d['instrument_request_id']))

            if row is not None:
                row.request_date = datetime.now()
                row.response_date = datetime.now()
                row.response_status = d.get('status', '')
                row.response_status_message = d.get('status_msg', '')

            else:
                # we received an item that we haven't sent a request for
                self.log.warning(
                    "Unknown record, this should "
                    "not happen:\r\nat index: {}\r\n"
                    "data: {}".format(i, d)
                )
            repo.save(request)

    def _submit_rds_idx_const_sw_request(self):

        cfg = self.context.config
        batch_size = int(cfg.get('dais_rds_sec').get('batch_size'))

        is_debug = self.log.level == logging.DEBUG
        repo = RdsRequestIdxConstSwRepo(self.pim_db)
        repo.create_new_rds_idx_const_sw_request_records(
            audit_id=self.etl_audit_id, requestor=self.requestor,
            is_debug=is_debug)

        for batch in self._get_rds_idx_const_sw_requests(batch_size):

            if len(batch) == 0:
                self.log.info("There is no pending idx constituent sw "
                              "items to process")
                continue

            batch = [sorted(
                list(v),
                key=lambda r: getattr(r, 'row_insert_date'),
                reverse=True)[0] for k, v in itertools.groupby(
                batch, key=lambda r: getattr(r, 'ssm_id'))]

            req_data = map(lambda o: util.struct(
                request_id=self.req_id_tpl.format(o.rds_request_idx_const_sw_id),
                ssm_id=o.ssm_id,
                idx_const_sw=o.idx_const_sw
            ), batch)

            self._submit_request_and_update_status(batch, req_data)
        return

    def _try_update_current_status(self, batch, status):

        try:
            repo = RdsRequestIdxConstSwRepo(self.pim_db)
            for rds_idx_req in batch:
                rds_idx_req.current_status = str(status)
                rds_idx_req.current_status_date = datetime.now()
            repo.save(batch)
        except Exception as e:
            self.log.exception(
                "Unable to update status of rds_request_idx_consts records: %s"
                ", with error: %s.",
                len(batch or []),
                e
            )

    def _try_update_response_status(self, batch, status):

        try:
            repo = RdsRequestIdxConstSwRepo(self.pim_db)
            for rds_idx_req in batch:
                rds_idx_req.response_status = str(status)
                rds_idx_req.response_date = datetime.now()
                rds_idx_req.response_date = \
                    rds_idx_req.response_date or datetime.now()
            repo.save(batch)
        except Exception as e:
            self.log.exception(
                "Unable to update status of rds_request_idx_consts records: %s"
                ", with error: %s.",
                len(batch or []),
                e
            )

    def _submit_request_and_update_status(self, batch, req_data):

        manager = AssetManager(self.context)
        response = manager.update_all(req_data)

        if response.status and isinstance(response.data, list):
            data = response.data
            self._update_rds_idx_const_sw_request_status(batch, data)
        else:
            self.log.error(
                "Error while making reindex instrument request "
                "to RDS API, with status: %s", str(response.status))

            self._try_update_response_status(batch, 'FAILED')
            raise SystemError(response.status)

    # endregion

    # region RDS check idx const switch update status
    def _retrieve_and_update_rds_reindex_request_status(self):

        cfg = self.context.config
        batch_size = int(cfg.get('dais_rds_sec').get('batch_size'))
        batches = self._get_rds_idx_const_sw_pending_requests(batch_size)

        for batch in batches:

            response = self._get_status_from_rds(batch)
            data = response.data
            if response.status and isinstance(data, list):
                self._update_pending_rds_idx_const_sw_request_status(
                    batch, data)
            else:
                self.log.error(
                    "Error while retrieving reindex instrument status "
                    "from RDS API, with response: %s", str(data))
                self._try_update_current_status(batch, 'FAILED')
                raise SystemError(data)

    def _get_rds_idx_const_sw_pending_requests(self, batch_size):

        rds_retry_delta = int(
            self.config.get('dais_rds_sec').get('rds_retry_delta'))
        repo = RdsRequestIdxConstSwRepo(self.pim_db)
        condition = True
        while condition:
            rows = repo.list_pending_rds_idx_const_sw_requests(
                0, batch_size, rds_retry_delta
            )
            self.log.info(
                "found %d pending rds_idx_const_sw_request records.", len(rows))
            condition = bool(rows)
            if condition:
                yield rows
            else:
                break

    def _get_status_from_rds(self, requests):
        manager = AssetManager(self.context)
        request_data = map(
            lambda o: self.req_id_tpl.format(o.rds_request_idx_const_sw_id),
            requests)
        response = manager.get_status_for_all(request_data)
        return response

    def _update_pending_rds_idx_const_sw_request_status(self, request, response):
        repo = RdsRequestIdxConstSwRepo(self.pim_db)

        try:
            # update database
            for i, d in enumerate(response or []):
                row = next((r for idx, r in enumerate(
                    request or []
                ) if self.req_id_tpl.format(
                    r.rds_request_idx_const_sw_id
                ) == d['instrument_request_id']))

                if row is not None:

                    row.current_status_date = datetime.now()
                    row.current_status = d.get('status', '')
                    row.current_status_message = d.get('status_msg', '')
                    row.tries = (row.tries or 0) + 1

                else:
                    # we received an item that we haven't sent a request for
                    self.log.warning(
                        "Unknown record, this should "
                        "not happen:\r\nat index: %i\r\n"
                        "data: %s", i, d)
            repo.save(request)
        except Exception as e:
            self._try_update_current_status(request, 'FAILED')
            self.log.exception(
                "Unable to update idx_const_sw with error: %s", e)
            raise
    # endregion

    # region public methods
    def validate(self):
        """
        Executes validation logic upon start up of the driver.
        """
        if self.etl_audit_id is None:
            raise ValueError(
                'Required audit job id not found in '
                'environment var:ETL_AUDIT_ID or cmd line params.')

    @timed()
    def run(self):
        try:
            self._submit_rds_idx_const_sw_request()
            self._retrieve_and_update_rds_reindex_request_status()
        except Exception as e:
            self.log.critical(
                "idx_const_switch_synch_agent::batch: "
                "{} completed with error: {}".format(self.etl_audit_id, e)
            )
            raise
    # endregion


USAGE = [
    'PM Price Synchronization Agent Description',
    ['--log-level', {'help': 'DEBUG, INFO, WARN, ERROR, CRITICAL'}],
    ['--etl-audit-id', {'help': 'etl audit id for etl jobs max-len(10)'}]
]


def main():
    """ 
    Delegates all processing to Agent instance.
    """
    logger = logging.getLogger("ff_dais.idx_const_switch_synch_agent")

    # noinspection PyBroadException
    try:
        cmd_line = util.sanitize_cmd_line(copy.copy(sys.argv))
        logging.info(cmd_line)
        args = util.parse_args(*USAGE)
        with IdxConstSwAgent(logger=logger, options=args) as agent:
            agent.validate()
            agent.run()
    except Exception:
        logger.critical(
            "critical error in idx_const_switch_synch_agent::", exc_info=1)
        logger.critical("Agent exited with error.")
        return -1
    else:
        logger.info("Agent completed successfully.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
