import logging
from datetime import datetime, timedelta

from flask import request, url_for, render_template, make_response, abort
from flask_restful import Resource

from etl.bbg_transport.config import config_api
from etl.bbg_transport.dto import RequestItem, ResponseItem, ResponseFileItem, RequestorItem
from etl.bbg_transport.util import BbgConfig, BtRepoBase
from etl.core.csv_util import csv_to_dict_list
from etl.enum.cor_da import BtStatusEnum


class BtProvider(BtRepoBase):
    def __init__(self):
        super(BtProvider, self).__init__()
        logging.getLogger(__name__).setLevel(int(config_api().get('log_level')))
        self.config = BbgConfig()

    @property
    def in_location(self):
        return self.config.data[BbgConfig.KEY_DATA_FILE_IN_LOC]

    @property
    def in_location_win(self):
        return self.config.data[BbgConfig.KEY_DATA_FILE_IN_LOC_WIN]

    def submit_request(self, submitted_by, request_model=None, request_json=None):
        if request_model is None and request_json is None:
            abort(400, description="Invalid Request! No data found")
        # Todo: Validate against Json Schema
        model = request_model or RequestItem.from_json(request_json)
        if not isinstance(model, RequestItem):
            abort(400, description="Invalid Request Type!")
        if not model.is_valid:
            abort(400, description="InvalidR Request Payload: {}".format(model.validation_errors))
        requestor = self.validate_requestor(model.requestor_code)
        row = self._bt_request_from_dto(model, hash(model), request_json)
        progress_url = 'bbg_transport.statusapi'
        if requestor.lookback_minutes != 0:
            lookback_time = datetime.now() - timedelta(minutes=float(requestor.lookback_minutes))
            lookback_request = self.request_repo.get_lookback_request(row.request_data_hash, lookback_time)
            if lookback_request is not None:
                if lookback_request.bt_status_code in BbgConfig.STATUS_LIST_COMPLETE:
                    progress_url = 'bbg_transport.responseapi'
                row.bt_status_code = lookback_request.bt_status_code
                row.lookback_bt_request_id = lookback_request.bt_request_id
        row.requestor_login = submitted_by or '#UND#'
        row = self.request_repo.save(row)
        p_url = url_for(progress_url, request_id=row.bt_request_id, _external=True)
        return ResponseItem(request_id=row.bt_request_id,
                            request_status=row.bt_status_code,
                            status_date=row.status_date,
                            data_file_path=None,
                            response_file_info=None,
                            progression_url=p_url,
                            win_file_path=None)

    def get_status(self, request_id):
        item = self.request_repo.get_by_bt_request_id(request_id)
        if item is None:
            abort(404, "Request Id: '{}' could not be found".format(request_id))
        p_url = url_for('bbg_transport.statusapi', request_id=request_id, _external=True)
        if item.bt_status_code in BbgConfig.STATUS_LIST_COMPLETE:
            p_url = url_for('bbg_transport.responseapi', request_id=request_id, _external=True)
        return ResponseItem(request_id=request_id,
                            request_status=item.bt_status_code,
                            status_date=item.status_date,
                            data_file_path=item.data_file_path,
                            response_file_info=self.get_response_file_info(item.bt_request_id),
                            progression_url=p_url,
                            win_file_path=self.get_win_location(item.data_file_path))

    def get_response_file_info(self, request_id):
        batch_list = self.batch_repo.list_by_bt_request_id(request_id)
        return [ResponseFileItem(file_location=b.response_file_path,
                                 is_error=b.is_error_response,
                                 error_text=b.error_text,
                                 response_date=b.response_received_date,
                                 bbg_time_started=b.bbg_time_started,
                                 bbg_time_finished=b.bbg_time_finished) for b in batch_list]

    def get_win_location(self, data_file_path):
        if not data_file_path:
            return None
        return data_file_path.replace(self.in_location, self.in_location_win)

    def get_response(self, request_id):
        item = self.request_repo.get_by_bt_request_id(request_id)
        if item is None:
            abort(404, description="Request Id: '{}' could not be found".format(request_id))
        if item.bt_status_code in BbgConfig.STATUS_LIST_INCOMPLETE:
            return "Request {} is incomplete. Please try again later.".format(request_id)
        batches = self.get_response_file_info(item.bt_request_id)
        if item.bt_status_code == BtStatusEnum.SUCCESS.value:
            data = csv_to_dict_list(item.data_file_path)
            return ResponseItem(request_id=item.bt_request_id,
                                request_status=item.bt_status_code,
                                status_date=item.status_date,
                                data_file_path=item.data_file_path,
                                data=data,
                                win_file_path=self.get_win_location(item.data_file_path),
                                response_file_info=batches)
        error_text = "\n".join([b.error_text for b in batches if b.is_error_response])
        if item.bt_status_code == BtStatusEnum.BTERROR.value:
            return "BBG Transport encountered the following errors: {}".format(error_text)
        if item.bt_status_code == BtStatusEnum.BBGERROR.value:
            return "The following errors were returned from Bloomberg: {}".format(error_text)
        return "Unknown Status"

    def validate_requestor(self, requestor_code):
        requestor = self.requestor_repo.get_by_bt_requestor_code(requestor_code)
        if requestor is None:
            abort(403, description="Requestor Code {} is not authorized".format(requestor_code))
        if bool(requestor.is_restricted) and datetime.today().weekday() not in [5, 6]:
            today = datetime(datetime.today().year, datetime.today().month, datetime.today().day)
            start_time = today + timedelta(hours=float(requestor.wkd_req_start_hour))
            end_time = today + timedelta(hours=float(requestor.wkd_req_end_hour))
            if not (start_time <= datetime.now() <= end_time):
                msg = "Request sent during restricted hours ({} - {})".format(start_time.strftime("%H:%M"),
                                                                              end_time.strftime("%H:%M"))
                abort(403, description=msg)
        return requestor

    def create_requestor(self, requestor_model=None, json_payload=None):
        model = requestor_model or RequestorItem.from_json(json_payload)
        if not model.is_valid:
            return ResponseItem(request_status=BtStatusEnum.BTERROR.value,
                                status_date=datetime.now(),
                                response_file_info=[
                                    ResponseFileItem(
                                        is_error=True,
                                        response_date=datetime.now(),
                                        error_text="Invalid Request Payload: {}".format(model.validation_errors))])
        self.requestor_repo.save(self._bt_requestor_from_dto(model))
        return "Requestor Created Successfully"

    def _bt_request_from_dto(self, dto, hash_val, request_json=None):
        rtn = self.request_repo.BtRequest()
        rtn.request_description = dto.request_description
        rtn.bbg_program_code = dto.program_code
        rtn.bbg_interface_code = dto.interface_code
        rtn.bt_requestor_code = dto.requestor_code
        rtn.bt_status_code = BtStatusEnum.INITIAL.value
        rtn.retry_count = 0
        rtn.request_data_hash = hash_val
        rtn.request_date = datetime.now()
        rtn.status_date = datetime.now()
        rtn.request_object_data = request_json
        rtn.response_format_code = dto.response_format_code
        rtn.callback_uri = dto.callback_uri
        rtn.process_date = datetime.now()
        return rtn

    def _bt_requestor_from_dto(self, dto):
        rtn = self.requestor_repo.BtRequestor()
        rtn.bt_requestor_code = dto.bt_requestor_code
        rtn.requestor_description = dto.requestor_description
        rtn.primary_contact_name = dto.primary_contact_name
        rtn.primary_contact_email = dto.primary_contact_email
        return rtn

    def get_pending_request_report(self):
        rpt_time = datetime.now()

        def _calculate_time_diff(req):
            diff = rpt_time - req.status_date
            setattr(req, 'time_diff',
                    "{}:{}:{}".format((diff.days * 24 + diff.seconds // 3600), ((diff.seconds % 3600) // 60),
                                      (diff.seconds % 60)))
            return req

        return [_calculate_time_diff(item) for item in
                sorted(self.request_repo.list_pending_requests(), key=lambda i: i.status_date, reverse=True)]

    def get_error_report(self, start_date_key, end_date_key):
        # class ErrorReportEncoder(BtRequestEncoder):
        #     def obj_to_dict(self, obj):
        #         data = super(ErrorReportEncoder, self).obj_to_dict(obj)
        #         data['error_text'] = obj.error_text
        #         return {key: value for key, value in data.items() if key in [
        #             'bt_request_id',
        #             'request_description',
        #             'bbg_program_code',
        #             'error_text',
        #             'bbg_interface_code',
        #             'bt_requestor_code',
        #             'bt_status_code',
        #             'request_date',
        #             'status_date',
        #             'retry_count',
        #             'requestor_login']}

        # enc = ErrorReportEncoder()

        def _get_error_text_and_encode(req):
            batches = self.batch_repo.list_by_bt_request_id(req.bt_request_id)
            setattr(req, 'error_text', '\n'.join([e.error_text for e in batches if bool(e.is_error_response)]))
            # return enc.default(req)
            return req

        return [_get_error_text_and_encode(item) for item in
                sorted(self.request_repo.list_error_request_by_dates(start_date_key, end_date_key),
                       key=lambda i: i.status_date,
                       reverse=True)]


class RequestApi(Resource):
    def __init__(self):
        logging.getLogger(__name__).setLevel(int(config_api().get('log_level')))
        self._provider = None

    @property
    def provider(self):
        if self._provider is None:
            self._provider = BtProvider()
        return self._provider

    def post(self):
        user = None
        if request.environ is not None and 'HTTP_X_REMOTE_USER' in request.environ:
            logging.info("HTTP_X_REMOVE_USER found in request.environ")
            user = request.environ['HTTP_X_REMOTE_USER']
        elif request.headers is not None and 'X-Remote-User' in request.headers:
            logging.info("X-Remote-User found in request.headers")
            user = request.headers.get('X-Remote-User')
        return self.provider.submit_request(user, request_json=request.data).to_json()


class StatusApi(Resource):
    def __init__(self):
        logging.getLogger(__name__).setLevel(int(config_api().get('log_level')))
        self._provider = None

    @property
    def provider(self):
        if self._provider is None:
            self._provider = BtProvider()
        return self._provider

    def get(self, request_id):
        return self.provider.get_status(request_id).to_json()


class ResponseApi(Resource):
    def __init__(self):
        logging.getLogger(__name__).setLevel(int(config_api().get('log_level')))
        self._provider = None

    @property
    def provider(self):
        if self._provider is None:
            self._provider = BtProvider()
        return self._provider

    def get(self, request_id):
        rtn = self.provider.get_response(request_id)
        return rtn.to_json() if isinstance(rtn, ResponseItem) else rtn


class RequestorApi(Resource):
    def __init__(self):
        logging.getLogger(__name__).setLevel(int(config_api().get('log_level')))
        self._provider = None

    @property
    def provider(self):
        if self._provider is None:
            self._provider = BtProvider()
        return self._provider

    def post(self):
        self.provider.create_requestor(json_payload=request.data)


class ErrorReportApi(Resource):
    def __init__(self):
        logging.getLogger(__name__).setLevel(int(config_api().get('log_level')))
        self._provider = None

    @property
    def provider(self):
        if self._provider is None:
            self._provider = BtProvider()
        return self._provider

    def get(self, start_date_key, end_date_key):
        return make_response(render_template('error_report.html',
                                             items=self.provider.get_error_report(start_date_key, end_date_key),
                                             start_date_key=start_date_key,
                                             end_date_key=end_date_key))


class PendingReportApi(Resource):
    def __init__(self):
        logging.getLogger(__name__).setLevel(int(config_api().get('log_level')))
        self._provider = None

    @property
    def provider(self):
        if self._provider is None:
            self._provider = BtProvider()
        return self._provider

    def get(self):
        return make_response(render_template('pending_report.html', items=self.provider.get_pending_request_report()))
