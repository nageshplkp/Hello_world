import json

from etl.bbg_transport.util import BbgConfig
from etl.core.model_base import JSONModelBase, RequiredAttribModel


class RequestDataItem(RequiredAttribModel, JSONModelBase):
    def __hash__(self):
        return (self.is_valid, self.data_item_string).__hash__()

    def __init__(self, yellow_key=None, ticker=None, bbg_query=None, isin=None, cusip=None, bb_id=None, tag=None):
        self.yellow_key = yellow_key
        self.ticker = ticker
        self.bbg_query = bbg_query
        self.isin = isin
        self.cusip = cusip
        self.bb_id = bb_id
        self.tag = tag

    @classmethod
    def from_dict(cls, data):
        rtn = cls()
        rtn.__dict__ = data
        rtn.check_for_req_attribs()
        return rtn

    @classmethod
    def from_json(cls, data):
        rtn = cls()
        rtn.__dict__ = json.loads(data)
        rtn.check_for_req_attribs()
        return rtn

    @staticmethod
    def req_obj_attribs():
        return [RequiredAttribModel.RequiredObjAttrib('yellow_key', None),
                RequiredAttribModel.RequiredObjAttrib('ticker', None),
                RequiredAttribModel.RequiredObjAttrib('bbg_query', None),
                RequiredAttribModel.RequiredObjAttrib('isin', None),
                RequiredAttribModel.RequiredObjAttrib('cusip', None),
                RequiredAttribModel.RequiredObjAttrib('bb_id', None),
                RequiredAttribModel.RequiredObjAttrib('tag', None)]

    @property
    def data_item_string(self):
        rtn = None
        if self.bbg_query:
            rtn = self.bbg_query
        if self.bb_id:
            rtn = "{} | BB_UNIQUE".format(self.bb_id)
        if self.yellow_key and self.ticker:
            rtn = "{} {} |".format(self.yellow_key, self.ticker)
        if self.cusip:
            rtn = "{} | CUSIP".format(self.cusip)
        if self.isin:
            rtn = "{} | ISIN".format(self.isin)
        tag = "##{}##\n".format(self.tag.replace('##', '')) if self.tag else ''
        return "{}{}".format(tag, rtn)

    @property
    def is_valid(self):
        return (self.yellow_key and self.ticker) or self.isin or self.bbg_query or self.cusip or self.bb_id


class RequestOptionItem(RequiredAttribModel, JSONModelBase):
    def __hash__(self):
        return self.option_string.__hash__()

    def __init__(self, option_name=None, option_value=None):
        self.option_name = option_name
        self.option_value = option_value

    @classmethod
    def from_dict(cls, data):
        rtn = cls()
        rtn.__dict__ = data
        rtn.check_for_req_attribs()
        return rtn

    @staticmethod
    def req_obj_attribs():
        return [RequiredAttribModel.RequiredObjAttrib('option_name', None),
                RequiredAttribModel.RequiredObjAttrib('option_value', None)]

    @property
    def option_string(self):
        return "{}={}".format(self.option_name, self.option_value)


class RequestItem(RequiredAttribModel, JSONModelBase):
    def __hash__(self):
        return (
            self.is_valid,
            self.program_code,
            self.interface_code,
            ''.join([i.data_item_string for i in sorted(self.request_data_items, key=lambda z: z.data_item_string)]),
            ''.join([i.option_string for i in sorted(self.request_options, key=lambda z: z.option_string) if
                     i.option_name not in self.config.hash_exclude_options()]),
            ''.join([i for i in sorted(self.request_fields)])).__hash__()

    def __init__(self,
                 request_description=None,
                 requestor_code=None,
                 program_code=None,
                 interface_code=None,
                 response_format_code=None,
                 request_data_items=None,
                 request_options=None,
                 request_fields=None):
        self.request_description = request_description
        self.requestor_code = requestor_code
        self.program_code = program_code
        self.interface_code = interface_code
        self.response_format_code = response_format_code
        self.callback_uri = None
        self.request_data_items = request_data_items or []
        self.request_options = request_options or []
        self.request_fields = request_fields or []
        self._validation_errors = None
        self._config = None

    @staticmethod
    def req_obj_attribs():
        return [RequiredAttribModel.RequiredObjAttrib('_validation_errors', None),
                RequiredAttribModel.RequiredObjAttrib('_config', None),
                RequiredAttribModel.RequiredObjAttrib('requestor_code', None),
                RequiredAttribModel.RequiredObjAttrib('program_code', None),
                RequiredAttribModel.RequiredObjAttrib('request_description', None),
                RequiredAttribModel.RequiredObjAttrib('interface_code', None),
                RequiredAttribModel.RequiredObjAttrib('response_format_code', None),
                RequiredAttribModel.RequiredObjAttrib('callback_uri', None),
                RequiredAttribModel.RequiredObjAttrib('request_data_items', []),
                RequiredAttribModel.RequiredObjAttrib('request_fields', [])]

    @classmethod
    def from_json(cls, data):
        rtn = cls()
        rtn.__dict__ = json.loads(data)
        rtn.check_for_req_attribs()
        rtn.request_data_items = [RequestDataItem.from_dict(i) for i in rtn.request_data_items]
        rtn.request_options = [RequestOptionItem.from_dict(i) for i in rtn.request_options]
        return rtn

    def validate(self):
        if not self._validation_errors:
            self._validation_errors = []
        if not self.request_description:
            self._validation_errors.append("RequestDescription Is Null")
        if not self.requestor_code:
            self._validation_errors.append("RequestorCode Is Null")
        if not self.program_code:
            self._validation_errors.append("ProgramCode Is Null")
        if not self.interface_code:
            self._validation_errors.append("InterfaceCode Is Null")
        if not self.response_format_code:
            self._validation_errors.append("ResponseFormatCode Is Null")
        if not self.request_data_items or not isinstance(self.request_data_items, list) or len(
                self.request_data_items) < 1:
            self._validation_errors.append("Request Data Items Are Null")
        else:
            di_err_cnt = sum(1 for i in self.request_data_items if not i.is_valid)
            if di_err_cnt > 0:
                self._validation_errors.append('{} Data item errors found'.format(di_err_cnt))
        if not self.request_fields or not isinstance(self.request_fields, list) or len(self.request_fields) < 1:
            self._validation_errors.append('Request Fields are Null')

    @property
    def config(self):
        if self._config is None:
            self._config = BbgConfig()
        return self._config

    @property
    def validation_errors(self):
        self.validate()
        return self._validation_errors

    @property
    def is_valid(self):
        self.validate()
        return len(self._validation_errors) == 0


class RequestorItem(RequiredAttribModel):
    def __init__(self,
                 bt_requestor_code=None,
                 requestor_description=None,
                 primary_contact_name=None,
                 primary_contact_email=None,
                 lookback_minutes=None,
                 is_restricted=None,
                 wkd_req_start_hour=None,
                 wkd_req_end_hour=None):
        self.bt_requestor_code = bt_requestor_code
        self.requestor_description = requestor_description
        self.primary_contact_name = primary_contact_name
        self.primary_contact_email = primary_contact_email
        self.lookback_minutes = lookback_minutes
        self.is_restricted = is_restricted
        self.wkd_req_start_hour = wkd_req_start_hour
        self.wkd_req_end_hour = wkd_req_end_hour
        self._validation_errors = None

    @staticmethod
    def req_obj_attribs():
        return [RequiredAttribModel.RequiredObjAttrib('_validation_errors', None),
                RequiredAttribModel.RequiredObjAttrib('bt_requestor_code', None),
                RequiredAttribModel.RequiredObjAttrib('requestor_description', None),
                RequiredAttribModel.RequiredObjAttrib('primary_contact_name', None),
                RequiredAttribModel.RequiredObjAttrib('primary_contact_email', None),
                RequiredAttribModel.RequiredObjAttrib('lookback_minutes', None),
                RequiredAttribModel.RequiredObjAttrib('is_restricted', None),
                RequiredAttribModel.RequiredObjAttrib('wkd_req_start_hour', None),
                RequiredAttribModel.RequiredObjAttrib('wkd_req_end_hour', None)]

    @classmethod
    def from_json(cls, data):
        rtn = cls()
        rtn.__dict__ = json.loads(data)
        rtn.check_for_req_attribs()
        return rtn

    def validate(self):
        if not self._validation_errors:
            self._validation_errors = []
        if not self.bt_requestor_code:
            self._validation_errors.append("BtRequestorCode Is Null")
        if not self.requestor_description:
            self._validation_errors.append("RequestorDescription Is Null")
        if not self.primary_contact_name:
            self._validation_errors.append("PrimaryContactName Is Null")
        if not self.primary_contact_email:
            self._validation_errors.append("PrimaryContactEmail Is Null")
        if self.is_restricted is True:
            if self.wkd_req_start_hour is None or self.wkd_req_end_hour is None:
                self._validation_errors.append("Start and End times are required when restricted.")
            elif self.wkd_req_end_hour <= self.wkd_req_start_hour:
                self._validation_errors.append("Start Hour must be prior to End Hour.")

    @property
    def validation_errors(self):
        self.validate()
        return self._validation_errors

    @property
    def is_valid(self):
        self.validate()
        return len(self._validation_errors) == 0


class ResponseFileItem(JSONModelBase):
    def __init__(self,
                 file_location=None,
                 is_error=None,
                 error_text=None,
                 response_date=None,
                 bbg_time_started=None,
                 bbg_time_finished=None):
        self.file_location = file_location
        self.is_error_response = is_error
        self.error_text = error_text
        self.response_date = response_date
        self.bbg_time_started = bbg_time_started
        self.bbg_time_finished = bbg_time_finished


class ResponseItem(JSONModelBase):
    def __init__(self,
                 request_id=None,
                 request_status=None,
                 status_date=None,
                 data_file_path=None,
                 progression_url=None,
                 response_file_info=None,
                 win_file_path=None,
                 data=None):
        self.request_id = request_id
        self.request_status = request_status
        self.status_date = status_date
        self.data_file_path = data_file_path
        self.progression_url = progression_url
        self.win_file_path = win_file_path
        self.response_file_info = response_file_info or []
        self.data = data

    def to_dict(self):
        rtn = super(ResponseItem, self).to_dict()
        rtn['is_error'] = self.is_error()
        return rtn

    def is_error(self):
        if not self.response_file_info:
            return False
        return sum([1 for i in self.response_file_info if i is not None and i.is_error_response is True]) > 0


if __name__ == '__main__':
    from etl.bbg_transport.client import get_options, get_fields, get_data_items

    item = RequestItem(request_description='my hash test',
                       program_code='GETDATA',
                       request_data_items=get_data_items(),
                       request_options=get_options(),
                       request_fields=get_fields())
    h = hash(item)
    print(h)
