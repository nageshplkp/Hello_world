import os

from etl.core.da_config import get_etl_cfg, read_app_cfg, get_env

_config_api = None


def config_api():
    global _config_api
    if _config_api is None:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'app.config')
        _config_api = get_etl_cfg()
        _config_api.update(read_app_cfg(path)[get_env().lower()])
    return _config_api


if __name__ == '__main__':
    config = config_api()
    print(config)
