import django
from django.db.backends.oracle.introspection import DatabaseIntrospection
from django.db.backends.base.introspection import TableInfo


class PatchedOracleDatabaseIntrospection(DatabaseIntrospection):
    """
    This one is aware of the current schema. The default Django implementation doesn't support
    schema officially.
    """

    def get_table_list(self, cursor):
        """
        Returns a list of table and view names in the current database schema.
        """
        schema = cursor.db.settings_dict.get('SCHEMA')
        if schema:
            cursor.execute("SELECT TABLE_NAME, 't' FROM ALL_TABLES WHERE OWNER = '%s'" % schema)
            return [TableInfo(row[0].lower(), row[1]) for row in cursor.fetchall()]
        super(PatchedOracleDatabaseIntrospection, self).get_table_list(cursor)


def apply_patch():
    django.db.backends.oracle.introspection.DatabaseIntrospection = PatchedOracleDatabaseIntrospection
