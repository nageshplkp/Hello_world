from __future__ import unicode_literals
from django.db.models import *
import django.forms.models
import core.helpers
from fields import *


def model_exists(self, file_name, model_name=None):
    module_path = self.__module__
    app_path = module_path[:module_path.index('.')]
    model_path = '%s.models.%s' % (app_path, file_name,)
    return core.helpers.has_attr(model_path, model_name)


class ModelBase(Model):
    # field_help_texts = {'field_name': 'Help text for field'}
    field_help_texts = {}
    # field_verbose_names = {'field_name': 'Displayed name for field'}
    field_verbose_names = {}

    def __init__(self, *args, **kwargs):
        super(ModelBase, self).__init__(*args, **kwargs)
        core.helpers.override_extend(self)
        if hasattr(self, 'on_override'):
            self.on_override()

        for field in self._meta.fields:
            if self.field_help_texts.has_key(field.name):
                field.help_text = self.field_help_texts[field.name]

            if self.field_verbose_names.has_key(field.name):
                field.verbose_name = self.field_verbose_names[field.name]

    def __unicode__(self):
        return self.get_unicode()

    def get_unicode(self):
        return u''

    class Meta:
        abstract = True
        #base_manager_name = None
        db_tablespace = ''
        #default_manager_name = None
        default_permissions = ('add', 'change', 'delete', 'read')
        default_related_name = ''
        get_latest_by = []
        managed = False
        order_with_respect_to = ''
        ordering = []
        permissions = ()
        proxy = False
        required_db_features = []
        select_on_save = False


def ClientSideFormHttpCodeField(verbose_name):
    field = CodeHighlightField(verbose_name=verbose_name, blank=True, help_text='', editable=True)
    field.code_mode = 'json'
    return field


class ClientSideFormModelBase(ModelBase):
    http_status_fields = ['http_status', 'http_request', 'http_response']

    http_request = ClientSideFormHttpCodeField(u'Request')
    http_response = ClientSideFormHttpCodeField(u'Response')
    http_status = ClientSideFormHttpCodeField(u'Status')

    class Meta:
        abstract = True


class BaseInlineFormSetLimit(django.forms.models.BaseInlineFormSet):
    list_per_page = 10

    queryset_cache = {'instance': None, 'query': None, 'queryset': None}

    def get_queryset(self) :
        qs = super(BaseInlineFormSetLimit, self).get_queryset()
        instance = str(self.instance)
        try:
            query = str(qs.query)
        except:
            return qs

        if self.queryset_cache['instance'] == instance\
                and self.queryset_cache['query'] == query:
            return self.queryset_cache['queryset']

        qs = list(qs[:self.list_per_page].all())

        self.queryset_cache = {
            'instance': instance,
            'query': query,
            'queryset': qs
        }

        return qs
