from django import template
from django.core.urlresolvers import reverse
from django.db.models import ForeignKey
from django.utils.safestring import mark_safe
from core.django.models.fields.CodeHighlightField import CodeHighlightField

try:
    # Django 1.9
    from django.contrib.admin.utils import lookup_field
except ImportError:
    from django.contrib.admin.util import lookup_field

register = template.Library()


@register.assignment_tag(takes_context=True)
def prerender_field(context, field):
    displayed = field.contents()

    if field.is_readonly:
        obj = field.form.instance
        field_name = field.field['field']

        try:
            model = None
            field_type, attr, value = lookup_field(field_name, obj, field.model_admin)

            if field_type.primary_key:
                model = field_type.model;
                pk = value
            elif isinstance(field_type, ForeignKey):
                model = value;
                pk = value.pk
            elif isinstance(field_type, CodeHighlightField):
                displayed = field_type.value_to_html_readonly(value)

            if model:
                info = (model._meta.app_label, model._meta.object_name.lower())

                if context.request.user.has_perm('%s.change_%s' % info)\
                    or context.request.user.has_perm('%s.read_%s' % info):

                    url = reverse('admin:%s_%s_change' % info, args=(pk,))
                    displayed = "<a href='%s'>%s</a>" % (url, displayed)

        except:
            pass

    return mark_safe(displayed)
