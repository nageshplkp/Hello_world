"""
This file was generated with the custommenu management command, it contains
the classes for the admin menu, you can customize this class as you want.

To activate your custom menu add the following to your settings.py::
    ADMIN_TOOLS_MENU = 'da_admin_django.menu.CustomMenu'
"""

try:
    from django.urls import reverse
except ImportError:
    from django.core.urlresolvers import reverse
from django.utils.translation import ugettext_lazy as _

from admin_tools.menu import items, Menu
from django.contrib.auth.models import Permission
from django.contrib.auth.models import User
from django.apps import apps
from django.contrib.admin import ModelAdmin
from django.utils.text import capfirst
#from django.db.models import get_models
from django.utils.safestring import mark_safe
#from django.contrib.admin import ModelAdmin
#from django.contrib.admin.validation import validate
import json


class CustomMenu(Menu):
    """
    Custom Menu for da_admin_django admin site.
    """
    def __init__(self, **kwargs):
        Menu.__init__(self, **kwargs)
        self.children += [
            items.MenuItem(_('Dashboard'), reverse('admin:index')),
            items.Bookmarks(),
            items.AppList(
                _('Administration'),
                models=('django.contrib.*',)
            ),
            #items.MenuItem('Data WAREHOUSE - ETL',
            #               children=[
            #                   items.MenuItem('ETL Config', 'cfdw_app/etlconfig'),
            #                   items.MenuItem('ETL DateParts', 'cfdw_app/etldatepart'),
            #              ]
            #               ),
            #items.ModelList(
            #    'CDAT', ['da_app.*', ]
            #),
            #items.MenuItem('Data WAREHOUSE - ETL BLOOMBERG',
            #               children=[
            #                   items.MenuItem('Bloomberg Programs', 'cfdw_app/etlbbgprogram'),
            #                   items.MenuItem('Bloomberg Sources', 'cfdw_app/etlbbgsource'),
            #               ]
            #               ),

        ]

    def init_with_context(self, context):
        """
        Use this method if you need to access the request context.
        """
        request = context['request']
        print(custom_app_list(request))
        customapplist_dict = custom_app_list(request)
        #print(get_user_permissions(request.user))


        #self.children.append(MenuItem(
        #    title=item['title'],
        #    url=item['url']
        #))
        return super(CustomMenu, self).init_with_context(context)

def get_user_permissions(user):
    if user.is_superuser:
        return Permission.objects.all()
    #return user.user_permissions.all() | Permission.objects.filter(group__user=user)
    return User.objects.get(username=user).get_all_permissions()


IGNORE_MODELS = (
    "sites",
    "sessions",
    "admin",
    "contenttypes",
    "auth",
    "menu",
    "dashboard",
)


def custom_app_list(request):
    # Get all models and add them to the context apps variable.
    user = request.user
    app_dict = {}
    admin_class = ModelAdmin


    for model in apps.get_models():
        model_admin = admin_class(model, None)
        app_label = model._meta.app_label
        if app_label in IGNORE_MODELS:
            continue
        has_module_perms = user.has_module_perms(app_label)
        if has_module_perms:
            perms = model_admin.get_model_perms(request)
            # Check whether user has any perm for this module.
            # If so, add the module to the model_list.
            if True in perms.values():
                model_dict = {
                    'name': capfirst(model._meta.verbose_name),
                    'admin_url': mark_safe('%s/%s/' % (app_label, model.__name__.lower())),
                }
                if app_label in app_dict:
                    app_dict[app_label]['models'].append(model_dict)
                else:
                    app_dict[app_label] = {
                        'name': app_label.title(),
                        'app_url': app_label + '/',
                        'has_module_perms': has_module_perms,
                        'models': [model_dict],
                    }
    app_list = app_dict.values()
    app_list.sort(key=lambda x: x['name'])
    for app in app_list:
        app['models'].sort(key=lambda x: x['name'])
    return {'apps': app_list}


def get_app_grouping():
    with open('mock/custom_menu.json') as json_data:
        app_grp_json = json.load(json_data)
        return app_grp_json

def get_custom_menu_label(apptext):
    custom_app_group = get_app_grouping()


