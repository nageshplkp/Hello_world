# ======================================================================
# This is the app specific configuration for the AdminViewModels
# ======================================================================
from __future__ import unicode_literals
from apps.admin_view_model_base import AdminViewModelBase, AdminTabularInlineViewModelBase


class AdminViewModelBase(AdminViewModelBase):
    pass


class AdminTabularInlineViewModelBase(AdminTabularInlineViewModelBase):
    pass
