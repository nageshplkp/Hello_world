from __future__ import unicode_literals
from gen.etl_trth_field_in_etl_source import *


class InlineHelper(InlineHelper):
    pass
