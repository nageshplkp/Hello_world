from __future__ import unicode_literals
from gen.etl_trth_report_type import *


class InlineHelper(InlineHelper):
    pass
