from __future__ import unicode_literals
from gen.etl_trth_ric_in_etl_src import *


class InlineHelper(InlineHelper):
    pass
