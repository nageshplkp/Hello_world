from __future__ import unicode_literals
from gen.etl_haver_instrmnt import *


class InlineHelper(InlineHelper):
    pass
