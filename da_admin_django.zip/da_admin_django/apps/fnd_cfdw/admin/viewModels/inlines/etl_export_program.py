from __future__ import unicode_literals
from gen.etl_export_program import *


class InlineHelper(InlineHelper):
    pass
