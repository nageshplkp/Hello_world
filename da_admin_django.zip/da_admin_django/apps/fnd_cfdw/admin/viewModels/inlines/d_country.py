from __future__ import unicode_literals
from gen.d_country import *


class InlineHelper(InlineHelper):
    pass
