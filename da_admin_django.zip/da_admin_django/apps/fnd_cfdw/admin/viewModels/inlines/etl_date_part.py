from __future__ import unicode_literals
from gen.etl_date_part import *


class InlineHelper(InlineHelper):
    pass
