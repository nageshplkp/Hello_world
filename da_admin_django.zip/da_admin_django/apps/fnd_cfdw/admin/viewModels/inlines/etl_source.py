from __future__ import unicode_literals
from gen.etl_source import *


class InlineHelper(InlineHelper):
    from etl_bbg_source import EtlBbgSourceAdminTabularInlineViewModel
    from etl_email_source import EtlEmailSourceAdminTabularInlineViewModel
    # from etl_export_source import EtlExportSourceAdminTabularInlineViewModel
    # from etl_file import EtlFileAdminTabularInlineViewModel
    from etl_file_source import EtlFileSourceAdminTabularInlineViewModel
    # from etl_haver_source import EtlHaverSourceAdminTabularInlineViewModel
    # from etl_holiday_code_in_etl_source import EtlHolidayCodeinEtlSourceAdminTabularInlineViewModel
    from etl_http_source import EtlHttpSourceAdminTabularInlineViewModel
    # from etl_source_in_workflow import EtlSourceinWorkflowAdminTabularInlineViewModel
    # from etl_source_sla import EtlSourceSlaAdminTabularInlineViewModel

    class EtlSourceEtlSourceAdminTabularInlineViewModelDaSourceCode(EtlSourceAdminTabularInlineViewModel):
        fk_name = 'da_source_code'


    def get_inlines(self):
        return [
            InlineHelper.EtlSourceEtlSourceAdminTabularInlineViewModelDaSourceCode,
            InlineHelper.EtlBbgSourceAdminTabularInlineViewModel,
            InlineHelper.EtlEmailSourceAdminTabularInlineViewModel,
            # InlineHelper.EtlExportSourceAdminTabularInlineViewModel,
            # InlineHelper.EtlFileAdminTabularInlineViewModel,
            InlineHelper.EtlFileSourceAdminTabularInlineViewModel,
            # InlineHelper.EtlHaverSourceAdminTabularInlineViewModel,
            # InlineHelper.EtlHolidayCodeinEtlSourceAdminTabularInlineViewModel,
            InlineHelper.EtlHttpSourceAdminTabularInlineViewModel,
            # InlineHelper.EtlSourceinWorkflowAdminTabularInlineViewModel,
            # InlineHelper.EtlSourceSlaAdminTabularInlineViewModel,
        ]
