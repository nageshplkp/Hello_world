from __future__ import unicode_literals
from gen.d_holiday_code import *


class InlineHelper(InlineHelper):
    pass
