from __future__ import unicode_literals
from gen.etl_process_workflow_detail import *


class InlineHelper(InlineHelper):
    pass
