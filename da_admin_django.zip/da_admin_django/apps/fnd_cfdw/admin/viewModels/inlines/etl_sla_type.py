from __future__ import unicode_literals
from gen.etl_sla_type import *


class InlineHelper(InlineHelper):
    pass
