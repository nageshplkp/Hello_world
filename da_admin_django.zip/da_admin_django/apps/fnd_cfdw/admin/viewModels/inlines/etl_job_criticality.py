from __future__ import unicode_literals
from gen.etl_job_criticality import *


class InlineHelper(InlineHelper):
    pass
