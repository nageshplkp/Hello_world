from __future__ import unicode_literals
from django.db import models as md


class ModelFieldHelper():
    def issue_currency_key(self):
        if self.foreign_fields.__contains__('issue_currency_key'):
            self.foreign_fields.remove('issue_currency_key')
        return md.IntegerField(verbose_name=u'Issue Currency Key', db_column='ISSUE_CURRENCY_KEY', help_text='', editable=True)

    def web_geo_region_key(self):
        if self.foreign_fields.__contains__('web_geo_region_key'):
            self.foreign_fields.remove('web_geo_region_key')
        return md.IntegerField(verbose_name=u'Web Geo Region Key', db_column='WEB_GEO_REGION_KEY', help_text='', editable=True)
