from __future__ import unicode_literals
from django.db import models as md


class ModelFieldHelper():
    def date_key(self):
        if self.foreign_fields.__contains__('date_key'):
            self.foreign_fields.remove('date_key')
        return md.IntegerField(verbose_name=u'Date Key', db_column='DATE_KEY', db_index=True, help_text='', editable=True)
