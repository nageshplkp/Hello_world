from __future__ import unicode_literals
from gen.process_type import *


class InlineHelper(InlineHelper):
    pass
