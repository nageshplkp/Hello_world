from __future__ import unicode_literals
from gen.vnd_measure_error import *


class InlineHelper(InlineHelper):
    pass
