from __future__ import unicode_literals
from gen.vnd_currency_map import *


class InlineHelper(InlineHelper):
    pass
