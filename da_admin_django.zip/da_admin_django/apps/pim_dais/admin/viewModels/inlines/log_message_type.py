from __future__ import unicode_literals
from gen.log_message_type import *


class InlineHelper(InlineHelper):
    pass
