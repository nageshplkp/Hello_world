from __future__ import unicode_literals
from gen.vnd_audit import *


class InlineHelper(InlineHelper):
    pass
