from __future__ import unicode_literals
from gen.data_entity import *


class InlineHelper(InlineHelper):
    pass
