from __future__ import unicode_literals
from gen.vnd_file_fmt_query import *


class InlineHelper(InlineHelper):
    pass
