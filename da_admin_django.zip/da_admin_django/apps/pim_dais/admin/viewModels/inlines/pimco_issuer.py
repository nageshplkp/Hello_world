from __future__ import unicode_literals
from gen.pimco_issuer import *


class InlineHelper(InlineHelper):
    pass
