from __future__ import unicode_literals
from gen.process_group import *


class InlineHelper(InlineHelper):
    pass
