from __future__ import unicode_literals
from gen.vnd_file import *


class InlineHelper(InlineHelper):
    pass
