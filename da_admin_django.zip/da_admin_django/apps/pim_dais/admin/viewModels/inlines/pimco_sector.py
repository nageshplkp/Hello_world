from __future__ import unicode_literals
from gen.pimco_sector import *


class InlineHelper(InlineHelper):
    pass
