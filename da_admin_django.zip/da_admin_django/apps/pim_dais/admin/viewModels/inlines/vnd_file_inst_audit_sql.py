from __future__ import unicode_literals
from gen.vnd_file_inst_audit_sql import *


class InlineHelper(InlineHelper):
    pass
