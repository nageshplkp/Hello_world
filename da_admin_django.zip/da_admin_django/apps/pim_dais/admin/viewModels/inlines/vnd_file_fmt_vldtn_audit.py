from __future__ import unicode_literals
from gen.vnd_file_fmt_vldtn_audit import *


class InlineHelper(InlineHelper):
    pass
