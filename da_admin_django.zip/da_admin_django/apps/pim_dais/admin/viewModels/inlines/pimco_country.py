from __future__ import unicode_literals
from gen.pimco_country import *


class InlineHelper(InlineHelper):
    pass
