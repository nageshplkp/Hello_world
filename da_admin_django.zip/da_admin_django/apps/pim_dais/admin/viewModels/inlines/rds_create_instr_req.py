from __future__ import unicode_literals
from gen.rds_create_instr_req import *


class InlineHelper(InlineHelper):
    pass
