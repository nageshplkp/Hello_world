from __future__ import unicode_literals
from gen.vnd_exchange_map import *


class InlineHelper(InlineHelper):
    pass
