from __future__ import unicode_literals
from gen.vnd_industry_map import *


class InlineHelper(InlineHelper):
    pass
