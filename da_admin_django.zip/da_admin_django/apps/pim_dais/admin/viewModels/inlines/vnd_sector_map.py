from __future__ import unicode_literals
from gen.vnd_sector_map import *


class InlineHelper(InlineHelper):
    pass
