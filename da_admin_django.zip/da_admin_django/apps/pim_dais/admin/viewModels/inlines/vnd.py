from __future__ import unicode_literals
from gen.vnd import *


class InlineHelper(InlineHelper):
    pass
