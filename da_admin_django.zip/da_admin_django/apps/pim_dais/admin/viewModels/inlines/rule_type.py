from __future__ import unicode_literals
from gen.rule_type import *


class InlineHelper(InlineHelper):
    pass
