from __future__ import unicode_literals
from gen.vnd_sec_set import *


class InlineHelper(InlineHelper):
    pass
