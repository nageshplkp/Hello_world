from __future__ import unicode_literals
from gen.vnd_data_fmt_ext import *


class InlineHelper(InlineHelper):
    pass
