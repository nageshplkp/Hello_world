from __future__ import unicode_literals
from gen.pimco_exchange import *


class InlineHelper(InlineHelper):
    pass
