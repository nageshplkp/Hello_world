from __future__ import unicode_literals
from gen.data_attribute import *


class InlineHelper(InlineHelper):
    pass
