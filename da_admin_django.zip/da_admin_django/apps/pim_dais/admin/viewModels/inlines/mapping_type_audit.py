from __future__ import unicode_literals
from gen.mapping_type_audit import *


class InlineHelper(InlineHelper):
    pass
