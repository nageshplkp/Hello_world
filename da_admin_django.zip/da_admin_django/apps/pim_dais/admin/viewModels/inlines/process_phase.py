from __future__ import unicode_literals
from gen.process_phase import *


class InlineHelper(InlineHelper):
    pass
