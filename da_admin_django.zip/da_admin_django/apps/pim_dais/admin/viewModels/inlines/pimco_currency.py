from __future__ import unicode_literals
from gen.pimco_currency import *


class InlineHelper(InlineHelper):
    pass
