from __future__ import unicode_literals
from gen.port_index import *


class InlineHelper(InlineHelper):
    pass
