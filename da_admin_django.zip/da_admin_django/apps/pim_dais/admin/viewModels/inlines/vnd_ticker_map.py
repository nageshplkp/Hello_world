from __future__ import unicode_literals
from gen.vnd_ticker_map import *


class InlineHelper(InlineHelper):
    pass
