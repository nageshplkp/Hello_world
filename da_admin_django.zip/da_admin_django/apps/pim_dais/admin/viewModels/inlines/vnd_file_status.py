from __future__ import unicode_literals
from gen.vnd_file_status import *


class InlineHelper(InlineHelper):
    pass
