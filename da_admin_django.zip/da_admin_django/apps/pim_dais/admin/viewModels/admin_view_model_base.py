# ======================================================================
# This is the app specific configuration for the AdminViewModels
# ======================================================================
from __future__ import unicode_literals
from apps.admin_view_model_base import AdminViewModelBase, AdminTabularInlineViewModelBase


class AdminViewModelBase(AdminViewModelBase):

    class Media:
        css = {
            'all': ('css/pim-dais/styles.css',)
        }


class AdminTabularInlineViewModelBase(AdminTabularInlineViewModelBase):
    pass
