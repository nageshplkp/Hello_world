from core.django.admin.filters import *

null_indicator_cells = ['sec_identity_id', 'bb_id']


class VndSecSetAdminViewModel(object):
    list_filter = (('sec_identity_id', NullListFilter),('bb_id', NullListFilter),)

    def suit_cell_attributes(self, obj, column):
        if column in null_indicator_cells:
            value = getattr(obj, column)
            if value is None or value == '':
                return {'class': 'warning'}

    class Media:
        js = (
            'js/pim-dais/vnd-sec-set.js',
        )
