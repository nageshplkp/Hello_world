
class VndCountryMapAdminViewModel(object):
    list_display = ['vnd_country_map_id', 'vnd_code', 'vnd_country_value', 'pimco_country_code', 'edit']