from core.django.admin.filters import *

status_cells = ['is_raw_pre_done', 'is_raw_core_done', 'is_raw_post_done', 'is_fmt_pre_done',
                'is_fmt_core_done', 'is_fmt_post_done', 'is_nrm_pre_done', 'is_nrm_core_done',
                'is_nrm_post_done', 'is_enr_pre_done', 'is_enr_core_done', 'is_enr_post_done',
                'is_pub_pre_done', 'is_pub_core_done', 'is_pub_post_done']


class VndFileInstAdminViewModel(object):
    fields = ['vnd_file_inst_id', 'vnd_file_code', 'vnd_file_inst_status_code', 'asof_date', 'is_raw_pre_done',
              'is_raw_core_done', 'is_raw_post_done', 'is_fmt_pre_done', 'is_fmt_core_done', 'is_fmt_post_done',
              'is_nrm_pre_done', 'is_nrm_core_done', 'is_nrm_post_done', 'is_enr_pre_done', 'is_enr_core_done',
              'is_enr_post_done', 'is_pub_pre_done', 'is_pub_core_done', 'is_pub_post_done', 'dw_etl_file_id',
              'etl_run_date', 'folder_name', 'file_name', 'file_row_count', 'filtered_row_count', 'raw_val_row_count',
              'fmt_val_row_count', 'row_update_date']

    list_display = ['vnd_file_inst_id', 'vnd_file_code', 'vnd_file_inst_status_code', 'asof_date', 'is_raw_pre_done',
                    'is_raw_core_done', 'is_raw_post_done', 'is_fmt_pre_done', 'is_fmt_core_done', 'is_fmt_post_done',
                    'is_nrm_pre_done', 'is_nrm_core_done', 'is_nrm_post_done', 'is_enr_pre_done', 'is_enr_core_done',
                    'is_enr_post_done', 'is_pub_pre_done', 'is_pub_core_done', 'is_pub_post_done', 'row_update_date',
                    'dw_etl_file_id', 'etl_run_date', 'folder_name', 'file_name', 'file_row_count',
                    'filtered_row_count', 'raw_val_row_count', 'fmt_val_row_count', 'edit']
    list_filter = (('vnd_file_inst_status_code__vnd_file_inst_status_name', AllValuesFieldListFilter),
                   ('asof_date', DateFieldListFilter),)

    ordering = ('-row_update_date','vnd_file_inst_status_code',)

    def suit_cell_attributes(self, obj, column):
        if column in status_cells:
            css_class = {
                2: 'warning',
                1: 'success',
                0: '',
                -1: 'error',
            }.get(getattr(obj, column))

            if css_class:
                return {'class': css_class}

    class Media:
        js = (
            'js/pim-dais/vnd-file-inst.js',
        )
