from __future__ import unicode_literals
from django.utils.html import format_html, escape
from ....models.helpers.vnd_file_fmt_query import ModelFieldHelper


class VndFileFmtQueryAdminViewModel():
    list_display_links = [o for o in ModelFieldHelper.list_display_fields if o != 'sql_template']
    list_display = ['sql_template_html' if o == 'sql_template' else o for o in ModelFieldHelper.list_display_fields] + ['edit']

    def sql_template_html(self, obj):
        return format_html('<pre><code class="language-sql line-numbers">{}</code></pre>', escape(obj.sql_template)) if obj.sql_template else ''

    sql_template_html.short_description = 'Sql Template'

    class Media:
        css = {
            'all': ('prism/prism.css',)
        }
        js = ('prism/prism.js',)