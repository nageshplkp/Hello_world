class VndMeasureAdminViewModel(object):
    pass