# coding=utf-8

from __future__ import unicode_literals
from core.django.models import *
from core.helpers import OverridableBase


class FieldNames():
    deal_name='deal_name'


class ModelFieldHelper(OverridableBase):
    model_verbose_name = 'Get Deal'
    model_verbose_plural = 'Get Deal'

    # field_help_texts = {'field_name': 'Help text for field'}
    field_help_texts = {}
    # field_verbose_names = {'field_name': 'Displayed name for field'}
    field_verbose_names = {}

    foreign_fields = []
    form_fields = [FieldNames.deal_name]
    indexed_fields = []
    list_display_fields = []
    raw_id_fields = foreign_fields
    readonly_fields = []
    to_string_fields = [FieldNames.deal_name]

    def get_unicode(self, modelInstance):
        return ' - '.join([unicode(getattr(modelInstance, o))
                           for o in self.to_string_fields
                           if o not in self.foreign_fields])

    def deal_name(self):
        return CharField(verbose_name=u'Deal Name', max_length=200, help_text='', editable=True)
