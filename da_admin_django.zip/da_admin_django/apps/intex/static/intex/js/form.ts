interface jQuery { }
module Django {
    export abstract class AdminForm {
        protected actionName: string;
        protected actionToExecute: (inputValues: Object, errors: Array<string>) => boolean;
        protected form: any;

        constructor(el: Element) { }

        protected ajaxGet = (url: string): jQuery => { return null; };
        protected ajaxPost = (url: string, data: {} | FormData): jQuery => { return null; }
        protected onAjaxComplete = (): void => { }
        protected onAjaxError = (xhr, status, errorThrown): void => { }
        protected onAjaxSuccess = (data, status, xhr): void => { }
        protected printHttpRequest = (settings: any): void => { }
        protected printHttpStatus = (status: string, message?: any): void => { }
        protected toggleFormDisable = (disable: boolean): void => { }
        protected toFormData = (file: File, expectedExtension: string): FormData => { return null; }
        protected toPrismHtml = (data: any): string => { return null; }

        public submit(): void { }
    }
}
/* DELETE FROM HERE AND UP FROM THE GENERATED CODE */
/* =============================================== */

module intex {
    export class Form extends Django.AdminForm {
        static serviceBaseUrlDefault: string = 'http://ptp-dev';
        static servicePath: string = '/workshop/service/da/intex';
        static serviceBaseUrl: string =
            (location.hostname.toLowerCase().indexOf('ptp-dev') === 0
            ? location.origin : Form.serviceBaseUrlDefault)
            + Form.servicePath;

        constructor(el: Element) {
            super(el);

            switch (this.actionName) {
                case 'getdeal':
                    this.actionToExecute = this.actionGetDeal;
                    break;
                case 'getpreprice':
                    this.actionToExecute = this.actionGetPrePrice;
                    break;
                case 'uploadcdi':
                    this.actionToExecute = (inputValues: Object, errors: Array<string>) => this.actionUpload(inputValues, errors, 'cdi');
                    break;
                case 'uploadcdu':
                    this.actionToExecute = this.actionUploadCdu;
                    break;
                case 'uploadzip':
                    this.actionToExecute = (inputValues: Object, errors: Array<string>) => this.actionUpload(inputValues, errors, 'zip');
                    break;
            }
        }

        private actionGetDeal = (inputValues: Object, errors: Array<string>): boolean => {
            var dealName = inputValues['deal_name'];
            this.ajaxPost(Form.serviceBaseUrl + '/deal/' + dealName, {});
            return true;
        }

        private actionGetPrePrice = (inputValues: Object, errors: Array<string>): boolean => {
            var dealName = inputValues['deal_name'];
            var password = inputValues['password'];
            this.ajaxPost(Form.serviceBaseUrl + '/deal/' + dealName, {'password': password});
            return true;
        }

        private actionUpload = (inputValues: Object, errors: Array<string>, expectedExtension: string): boolean => {
            var files = this.files;

            if (files.length <= 0) {
                errors.push('Unable to get a file to upload.');
            } else {
                var formData = this.toFormData(files[0], expectedExtension);
                if (formData === null) { return false; }

                this.ajaxPost(Form.serviceBaseUrl + '/upload/', formData);
                return true;
            }

            return false;
        }

        private actionUploadCdu = (inputValues: Object, errors: Array<string>): boolean => {
            var expectedExtension = 'cdu';

            var files = this.files;

            if (files.length <= 0) {
                errors.push('Unable to get a file to upload.');
            } else {
                var formData = this.toFormData(files[0], expectedExtension);
                if (formData === null) { return false; }

                var month = inputValues['month'];
                var year = inputValues['year'];

                this.ajaxPost(Form.serviceBaseUrl + '/upload/' + year + '/' + month, formData);
                return true;
            }

            return false;
        }

        private get files(): File[] {
            return this.form.find('div.controls input#id_file').prop('files');
        }
    }
}
var intex_Form: intex.Form = null;

function form_submit(el: Element): void {
    if (!intex_Form) {
        intex_Form = new intex.Form(el);
    }

    intex_Form.submit();
}
