# ======================================================================
# This is the application wide configuration for the AdminViewModels
# ======================================================================
from __future__ import unicode_literals
from core.django.admin import *


class AdminViewModelBase(AdminViewModelBase):
    pass


class AdminTabularInlineViewModelBase(AdminTabularInlineViewModelBase):
    pass
