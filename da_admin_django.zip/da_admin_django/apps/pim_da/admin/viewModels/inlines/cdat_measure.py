from __future__ import unicode_literals
from gen.cdat_measure import *


class InlineHelper(InlineHelper):
    from cdat_matrix import CdatMatrixAdminTabularInlineViewModel

    def get_inlines(self):
        return [
            InlineHelper.CdatMatrixAdminTabularInlineViewModel,
        ]
