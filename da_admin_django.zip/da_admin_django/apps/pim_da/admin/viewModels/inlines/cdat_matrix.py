from __future__ import unicode_literals
from gen.cdat_matrix import *


class InlineHelper(InlineHelper):
    pass
