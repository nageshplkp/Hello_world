import logging
import logging.handlers
import os
import socket
from pprint import pformat
import base64

import six
from pymongo import MongoClient
from six.moves import configparser

if six.PY3:
    _PARSER = configparser.ConfigParser
elif six.PY2:
    _PARSER = configparser.SafeConfigParser


CONFIG = {}


def load():
    global CONFIG  # ensure we dont' load multiple times.
    if CONFIG:
        logging.info('already loaded!!')
        return

    logging.info('app env:%s' % _env())

    path = os.path.dirname(os.path.abspath(__file__))
    configToPrint = _load(os.path.join(path, 'app.config'))

    logging.debug('app config:\n%s' % pformat(configToPrint))
    logging.debug('host: %s' % socket.gethostname())

    try:
        _load_mongo_config()
    except Exception as ex:
        # print ex
        pass


def configCopy():
    return CONFIG.copy()


def get(key):
    """
    gets config val from app.config
    """

    if key.lower() in CONFIG:
        return CONFIG.get(key.lower())

    return os.environ.get(key.lower())

def load_config_file(path):
    _load(path)


def _get_mongo_config(file_cfg, appenv):
    mongo_cfg = {}
    connStr = 'mongodb://%s:%s@%s/appconfig' % (file_cfg['mongo_config_reader'], __conn_pass__(), file_cfg['mongo_host'])
    mc = MongoClient(connStr)
    config = mc.appconfig.pypimco_config.find_one()

    # load the new pypimco config
    if config:
        del config['_id']
        d = {}
        for k, v in six.iteritems(config):
            d[str(k).lower().strip()] = str(v)

        mongo_cfg.update(d)

    # load the legacy config. retire this later
    config = mc.appconfig[appenv].find_one()
    if config:
        del config['_id']
        d = {}
        for k, v in six.iteritems(config):
            d[str(k).lower().strip()] = str(v)

        mongo_cfg.update(d)
    return mongo_cfg

def __conn_pass__():
    return base64.b64decode('YW5nZWxzMzIx')

def _load_mongo_config():
    global CONFIG
    CONFIG.update(_get_mongo_config(CONFIG, get('appenv')))

def _load(path):
    global CONFIG  # ensure we dont' load multiple times.

    env = _env()

    if CONFIG is None:
        CONFIG = {}

    CONFIG.update(get_cfg_by_file(path, env))

    for k, v in six.iteritems(CONFIG):
        CONFIG[k] = v.strip()

    CONFIG['appenv'] = env
    config_to_print = {}

    for k, v in six.iteritems(CONFIG):
        if 'pass' not in k:
            config_to_print[k] = v

    return config_to_print


def append_env(path):
    global CONFIG  # ensure we dont' load multiple times.
    CONFIG.update(get_cfg_by_file(path, _env()))


def _env():
    env = os.environ.get('appenv')
    return 'dev' if not env else env.lower()


def get_cfg_by_file(file_path, env):
    parser = _PARSER()
    parser.read(file_path)
    return dict(parser.items(env))


def get_cfg_by_env(env):
    """ Reads default configuration for a given section. From app.config and mongo db """
    def_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'app.config')
    d = get_cfg_by_file(def_path, env)
    try:
        d.update(_get_mongo_config(d, env))
    except:
        pass
    return d
