__author__ = 'anikolaev'
import pandas
import logging
from sas7bdat import SAS7BDAT

# Using sas7bdat
# https://pypi.python.org/pypi/sas7bdat

class query(object):
    def __init__(self):
         logging.info("Initializing sas query module!")
    def close(self):
         logging.info("Shutting down sas query module!")
    def query(self, sas_file_name):
        """  Query the time series service for data. Nomenclature
        :param sas_file_name:     Location to sas file to open.
        """
        try:
            with SAS7BDAT(sas_file_name) as f:
                df = f.to_data_frame();
            return df
        except Exception, e:
            logging.exception(e)
            logging.warning('exception while opening %s', sas_file_name)
        return {}
