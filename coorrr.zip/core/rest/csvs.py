import json
import cStringIO as StringIO
import random
import collections
import datetime
import time
import pandas as pd
import numpy as np
import functools
import itertools
from core.common.util import tz_offset_str, first, df_to_py_list

__DT_TYPES = [datetime.datetime, datetime.date]
__NUM_TYPES = [int, bool, float, long]
__WHOLE_TYPES = [int, bool, long]

__TYPE_CONV_MAP = {
    (datetime.datetime, datetime.date): datetime.datetime,
    (bool, int): int,
    (bool, long): long,
    (bool, float): float,
    (int, long): long,
    (int, float): float,
    (long, float): float,
}

__TYPENAME_MAP = {
    str: 'STRING',
    bool: 'BOOLEAN',
    int: 'INT',
    long: 'LONG',
    float: 'DOUBLE',
    datetime.date: 'STRING/ISODATE',
    datetime.datetime: 'STRING/ISODATETIME',
}

__REVERSE_CONV = {
    'STRING/ISODATE': lambda x: datetime.datetime.strptime(x[:10], "%Y-%m-%d").date() if x is not None else x,
    'STRING/ISODATETIME': lambda x: datetime.datetime.strptime(x[:26], "%Y-%m-%dT%H:%M:%S.%f") if x is not None else x,
    'STRING/DECIMAL': float,
}


def __conv_value(row, col, value, type_):
    if value is None:
        return value

    if type_ in __DT_TYPES:
        if type_ == datetime.datetime:
            if isinstance(value, datetime.date):
                if isinstance(value, datetime.datetime):
                    return value.strftime("%Y-%m-%dT%H:%M:%S.%f") + tz_offset_str()
                else:
                    return value.strftime("%Y-%m-%dT00:00:00.000") + tz_offset_str()
            else:
                raise Exception("Value %s @ %d:%d is not a datetime" % (value, row, col))
        else:
            if isinstance(value, datetime.date):
                return value.strftime("%Y-%m-%d")
            else:
                raise Exception("Value %s @ %d:%d is not a datetime" % (value, row, col))
    if not isinstance(value, type_):
        return type_(value)
    return value


def __produce_row(row, names):
    if isinstance(row, collections.Mapping):
        return [row.get(x) for x in names]
    else:
        return row


def __conv_row(row, data, types, names):
    if len(data) != len(types):
        raise Exception("Length of row %d doesn't match the length of names" % row)

    data = __produce_row(data, names)
    return map(lambda x: __conv_value(row, x, data[x], types[x]), xrange(len(data)))


def to_list(json_string):
    data = json.loads(json_string) if isinstance(json_string, basestring) else json_string
    if 'names' in data and 'types' in data and 'data' in data:
        names = data['names']
        types = data['types']
        return names, types, [
            [(__REVERSE_CONV[t](v) if t in __REVERSE_CONV else v) for t, v in itertools.izip(types, r)]
            for r in data['data']]
    else:
        return dict([(x, to_list(y)) for x, y in data.iteritems()])


def to_col_dict(json_string):
    data = json.loads(json_string) if isinstance(json_string, basestring) else json_string
    if 'names' in data and 'types' in data and 'data' in data:
        names = data['names']
        types = data['types']
        return names, types, dict((n,
                                   [(__REVERSE_CONV[t](v[i]) if t in __REVERSE_CONV else v[i]) for v in data['data']]
                                   ) for n, t, i in itertools.izip(names, types, range(len(names))))
    else:
        return dict([(x, to_col_dict(y)) for x, y in data.iteritems()])


def __col_dict_to_df(names, types, data):
    for n, t in itertools.izip(names, types):
        if t == 'STRING/ISODATE' or t == 'STRING/ISODATETIME':
            data[n] = np.array(data[n], dtype=np.datetime64)

    return pd.DataFrame(data=data)


def to_df(json_string):
    data = to_col_dict(json_string)
    if isinstance(data, dict):
        v = dict((n, __col_dict_to_df(*v)) for n, v in data.iteritems())
        if len(v) == 1:
            return v.values()[0]
        else:
            return v
    else:
        return __col_dict_to_df(*data)


def from_df(df, names=None, types=None, namesarray=None, descriptions=None, index_columns=None, nanAndInfAsNone=False):
    names, data = df_to_py_list(df, names, index_columns, nanAndInfAsNone=nanAndInfAsNone)
    return from_list(data, names, types=types, namesarray=namesarray, descriptions=descriptions)


def from_list(data, names, types=None, namesarray=None, descriptions=None):
    if not names:
        raise Exception("Names array can not be empty")

    data = data or tuple()
    if not isinstance(data, collections.Sequence) or isinstance(data, basestring):
        raise Exception("Data must be a collection")

    if not isinstance(names, collections.Sequence) or isinstance(names, basestring):
        raise Exception("Types must be a collection")

    if not descriptions:
        descriptions = names

    if not isinstance(descriptions, collections.Sequence) or isinstance(descriptions, basestring):
        raise Exception("Descriptions must be a collection")

    if len(descriptions) != len(names):
        raise Exception("Length of descriptions and length of names must be same")

    if not types:
        if not data:
            raise Exception("Can not guess types when data is empty")

        sample = random.sample(range(len(data)), len(data) if len(data) < 50 else len(data) / 10)
        types = [None] * len(names)
        for s in sample:
            row = __produce_row(data[s], names)
            for i, c in enumerate(names):
                if len(row) != len(names):
                    raise Exception("Length of row %d doesn't match length of names" % s)

                if isinstance(row[i], bool):
                    vtype = bool
                elif isinstance(row[i], int):
                    vtype = int
                elif isinstance(row[i], long):
                    vtype = long
                elif isinstance(row[i], float):
                    vtype = float
                elif isinstance(row[i], datetime.datetime):
                    vtype = datetime.datetime
                elif isinstance(row[i], datetime.date):
                    vtype = datetime.date
                elif row[i] is None:
                    vtype = None
                else:
                    vtype = str

                if vtype:
                    if not types[i]:
                        types[i] = vtype
                    else:
                        if types[i] == vtype:
                            continue

                        conv = __TYPE_CONV_MAP.get((types[i], vtype))
                        if not conv:
                            conv = __TYPE_CONV_MAP.get((vtype, types[i]))

                        if not conv:
                            conv = str

                        types[i] = conv

        for i in range(len(types)):
            if types[i] is None:
                types[i] = str
    else:
        if not isinstance(types, collections.Sequence) or isinstance(types, basestring):
            raise Exception("Types must be a collection")

        if len(types) != len(names):
            raise Exception("Length of descriptions and length of types must be same")

        for t in types:
            if not issubclass(t, (bool, int, datetime.date, long, float, basestring)):
                raise Exception("Type %s is not supported" % t)

        types = map(lambda x: first((bool, int, long, float, datetime.datetime, datetime.date, basestring),
                                    lambda y: issubclass(x, y)), types)

        types = [(str if t is basestring else t) for t in types]

    if namesarray is not None:
        if not isinstance(namesarray, collections.Sequence) or isinstance(namesarray, basestring):
            raise Exception("namesarray must be a collection")
        if len(namesarray) != len(names):
            raise Exception("Length of names array and length of names must be same")

    result_dict = {
        "names": names,
        "descriptions": descriptions,
        "data": map(lambda x: __conv_row(x, data[x], types, names), xrange(len(data))),
        'types': map(__TYPENAME_MAP.get, types)
    }

    if namesarray is not None:
        result_dict['namesarray'] = namesarray

    return result_dict
