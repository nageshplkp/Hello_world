from avrogen import write_schema_files, write_protocol_files
import argparse


def avsc_url_schema(url):
    from core.rest import client
    return client.get(url + '?_avsc', parse_content_as='text')


def avsc_file_schema(file_name):
    with open(file_name, "r+") as f:
        return f.read()


def avpr_file_protocol(file_name):
    with open(file_name, "r+") as f:
        return f.read()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--url', required=False, type=avsc_url_schema, help='Popcorn service endpoint')
    parser.add_argument('--avsc', required=False, type=avsc_file_schema, help='AVSC File')
    parser.add_argument('--avpr', required=False, type=avsc_file_schema, help='AVPR File')
    parser.add_argument('--output', required=True, type=str, help='Output location')
    args = parser.parse_args()
    if args.url:
        write_schema_files(args.url, args.output)
    elif args.avsc:
        write_schema_files(args.avsc, args.output)
    elif args.avpr:
        write_protocol_files(args.avpr, args.output)
    else:
        import sys
        parser.print_help()
        print "Must provide either url, avsc, or avpr."
        return -1
    return 0


if __name__ == "__main__":
    main()
