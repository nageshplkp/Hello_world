import requests
import requests.auth
from pprint import pformat
from core.opensource.requests_kerberos import HTTPKerberosAuth, REQUIRED as MUTUAL_AUTH_REQUIRED, \
    DISABLED as MUTUAL_AUTH_DISABLED, \
    OPTIONAL as MUTUAL_AUTH_OPTIONAL

import rest_config
import avro
import logging
import avro.schema
import urlparse
import time
from io import BytesIO
from avro.io import DatumReader, BinaryDecoder
from core.rest import serialize
from core.rest import csvs
import functools
from core.common.json_encoders import DictWrapperJsonEncoder

JSON_SERIALIZER = serialize.to_json
AVRO_SERIALIZER = serialize.to_avro
JSON_SERIALIZER_DW_ENC = functools.partial(serialize.to_json_with_encoder, DictWrapperJsonEncoder)

"""
Rest client with kerberos, supports json only for now
"""

rest_config.install_krb5()
app_name = 'python-client'

__schema_cache = {}

class ClientException(Exception):
    def __init__(self, message, detail_json):
        self.detail_json = detail_json
        super(Exception, self).__init__(message)

def raise_err(response, req_id):
    err = {
        'status': response.status_code,
        'msg': response.text,
        'url': response.url,
        'reason': response.reason,
        'id': req_id,
        'response_headers': response.headers,
        'request_headers': response.request.headers
    }

    raise ClientException('Rest err %s' % pformat(err), err)


def _process_response(r, req_id, parse_content_as, avro_schema=None, avro_reader_cls=None):
    if 200 <= r.status_code < 300 and r.status_code != 204:
        ct = r.headers.get(rest_config.CONTENT_TYPE, 'application/octet-stream')  # we have cases where external servers
        # do not set content type
        if ct.startswith('application/json') and parse_content_as == 'json':
            try:
                return r.json()
            except Exception, ex:
                return r.text
        elif ct == rest_config.MIME_JSON_CSVS and parse_content_as == 'csvs':
            return csvs.to_df(r.json())
        elif (ct.startswith('application/avro') or ct.startswith(rest_config.MIME_AVRO_BIN)) \
                and parse_content_as == 'avro' and (avro_schema is not None or avro_reader_cls is not None):
            bytes_content = BytesIO(r.content)
            decoder = BinaryDecoder(bytes_content)
            if avro_reader_cls is not None:
                reader = avro_reader_cls(writers_schema=avro_schema)
            else:
                reader = DatumReader(avro_schema)

            return reader.read(decoder)
        elif parse_content_as == 'binary':
            return BytesIO(r.content)
        return r.text
    elif r.status_code == 204:
        return None
    else:
        raise_err(r, req_id)


def __get_avro_schema(url, use_kerberos):
    endpoint = get_endpoint(url)
    if endpoint in __schema_cache:
        return __schema_cache[endpoint]

    try:
        url = endpoint + '?_avsc'

        schema_json = get(url, use_kerberos=use_kerberos, parse_content_as='text')
        schema = avro.schema.parse(schema_json)
    except:
        schema = None
        import traceback
        logging.warn("Failed to get avro schema for %s", endpoint)
        logging.warn(traceback.format_exc())

    __schema_cache[endpoint] = schema
    return schema


def get_endpoint(url):
    parsed_url = urlparse.urlparse(url)
    endpoint = '%s://%s%s' % (parsed_url.scheme, parsed_url.netloc, parsed_url.path)
    return endpoint


def getWithContenType(url, params=None, headers=None, use_kerberos=True, parse_content_as='json',
                      timeout=300000, req_id=None, proxies=rest_config.BLANK_PROXIES,
                      kerb_mutual_auth=MUTUAL_AUTH_REQUIRED,
                      avro_reader_cls=None, ssl_verify=True):
    """
        :param url: url string to send
        :param params:  optional dictionary of query params to send
        :param headers:  headers to send.
        :param use_kerberos: Use kerberos authentication
        :param parse_content_as: "json" or "text", "json" is default and used for all unknown types
        :param timeout: length of time in milliseconds to allow call to take before terminating. Default is 5 minutes
        :param req_id: Specify an id for the request - defaults to None in which case we use a guid
        :param proxies: Any http proxy to use
        :return:  json doc

        Currently handles json formats only
        """

    auth = HTTPKerberosAuth(kerb_mutual_auth, delegate=False) if use_kerberos else None

    deadline, real_headers, real_req_id = rest_config._process_args(headers, timeout, req_id, app_name,
                                                                    parse_content_as)

    avro_schema = None
    if parse_content_as == 'avro':
        avro_schema = __get_avro_schema(url, use_kerberos)

    timeout_secs = timeout / 1000.0
    r = requests.get(url, params=params, headers=real_headers, auth=auth, proxies=proxies, timeout=timeout_secs,
                     verify=ssl_verify)

    return r.headers ,  _process_response(r, real_req_id, parse_content_as, avro_schema=avro_schema, avro_reader_cls=avro_reader_cls)


def get(url, params=None, headers=None, use_kerberos=True, parse_content_as='json',
        timeout=300000, req_id=None, proxies=rest_config.BLANK_PROXIES, kerb_mutual_auth=MUTUAL_AUTH_REQUIRED,
        avro_reader_cls=None, ssl_verify=True, retry=True):

    if not retry:
        return _get(url, params=params, headers=headers, use_kerberos=use_kerberos, parse_content_as=parse_content_as,
                    timeout=timeout, req_id=req_id, proxies=proxies, kerb_mutual_auth=kerb_mutual_auth,
                    avro_reader_cls=avro_reader_cls, ssl_verify=ssl_verify)

    for i in range(1, 3):
        try:
            return _get(url, params=params, headers=headers, use_kerberos=use_kerberos, parse_content_as=parse_content_as,
                        timeout=timeout, req_id=req_id, proxies=proxies, kerb_mutual_auth=kerb_mutual_auth,
                        avro_reader_cls=avro_reader_cls, ssl_verify=ssl_verify)
        except ClientException, ex:
            status_code = ex.detail_json.get('status')
            if status_code and int(status_code) in [502, 503, 504, 511]:  # for bad gateway re-try 3 times
                time.sleep(1*i)
                logging.info('*** retry on get()')
            else:
                raise ex


def _get(url, params=None, headers=None, use_kerberos=True, parse_content_as='json',
        timeout=300000, req_id=None, proxies=rest_config.BLANK_PROXIES, kerb_mutual_auth=MUTUAL_AUTH_REQUIRED,
        avro_reader_cls=None, ssl_verify=True):
    """
    :param url: url string to send
    :param params:  optional dictionary of query params to send
    :param headers:  headers to send.
    :param use_kerberos: Use kerberos authentication
    :param parse_content_as: "json" or "text", "json" is default and used for all unknown types
    :param timeout: length of time in milliseconds to allow call to take before terminating. Default is 5 minutes
    :param req_id: Specify an id for the request - defaults to None in which case we use a guid
    :param proxies: Any http proxy to use
    :return:  json doc

    Currently handles json formats only
    """

    auth = HTTPKerberosAuth(kerb_mutual_auth, delegate=False) if use_kerberos else None

    deadline, real_headers, real_req_id = rest_config._process_args(headers, timeout, req_id, app_name,
                                                                    parse_content_as)

    avro_schema = None
    if parse_content_as == 'avro':
        avro_schema = __get_avro_schema(url, use_kerberos)

    timeout_secs = timeout / 1000.0
    r = requests.get(url, params=params, headers=real_headers, auth=auth, proxies=proxies, timeout=timeout_secs,
                     verify=ssl_verify)

    return _process_response(r, real_req_id, parse_content_as, avro_schema=avro_schema, avro_reader_cls=avro_reader_cls)


def delete(url, params=None, headers=None, use_kerberos=True, parse_content_as='json',
           timeout=300000, req_id=None, proxies=rest_config.BLANK_PROXIES, kerb_mutual_auth=MUTUAL_AUTH_REQUIRED,
           avro_reader_cls=None, ssl_verify=True):
    """
    :param url: url string to send
    :param params:  optional dictionary of query params to send
    :param headers:  headers to send.
    :param use_kerberos: Use kerberos authentication
    :param parse_content_as: "json" or "text", "json" is default and used for all unknown types
    :param timeout: length of time in milliseconds to allow call to take before terminating. Default is 5 minutes
    :param req_id: Specify an id for the request - defaults to None in which case we use a guid
    :param proxies: Any http proxy to use
    :return:  json doc

    Currently handles json formats only
    """

    auth = HTTPKerberosAuth(kerb_mutual_auth, delegate=False) if use_kerberos else None

    deadline, real_headers, real_req_id = rest_config._process_args(headers, timeout, req_id, app_name,
                                                                    parse_content_as)

    avro_schema = None
    if parse_content_as == 'avro':
        avro_schema = __get_avro_schema(url, use_kerberos)

    timeout_secs = timeout / 1000.0
    r = requests.delete(url, params=params, headers=real_headers, auth=auth, proxies=proxies, timeout=timeout_secs,
                        verify=ssl_verify)

    return _process_response(r, real_req_id, parse_content_as, avro_schema=avro_schema, avro_reader_cls=avro_reader_cls)


def get_as_post(url, params, headers=None, use_kerberos=True, parse_content_as='json',
                timeout=300000, req_id=None, proxies=rest_config.BLANK_PROXIES,
                kerb_mutual_auth=MUTUAL_AUTH_REQUIRED, avro_reader_cls=None, ssl_verify=True):
    post_headers = {
        rest_config.X_METHOD_OVERWRITE: 'GET',
        rest_config.X_AVSC_SCHEMA: rest_config.QUERY_PARAMETERS
    }

    post_params = rest_config.PopcornParameters(params)
    if headers != None:
        post_headers.update(headers)

    return post(url, post_params.to_json(), headers=post_headers, use_kerberos=use_kerberos,
                parse_content_as=parse_content_as,
                timeout=timeout, req_id=req_id, proxies=proxies, kerb_mutual_auth=kerb_mutual_auth,
                avro_reader_cls=avro_reader_cls, ssl_verify=ssl_verify)


def post(url, data, headers=None, use_kerberos=True, parse_content_as='json',
         timeout=300000, req_id=None, proxies=rest_config.BLANK_PROXIES, kerb_mutual_auth=MUTUAL_AUTH_REQUIRED,
         avro_reader_cls=None, ssl_verify=True, request_serializer=JSON_SERIALIZER, request_schema=None, retry=True):

    if not retry:
        return _post(url, data, headers=headers, use_kerberos=use_kerberos, parse_content_as=parse_content_as,
                     timeout=timeout, req_id=req_id, proxies=proxies, kerb_mutual_auth=kerb_mutual_auth,
                     avro_reader_cls=avro_reader_cls, ssl_verify=ssl_verify, request_serializer=request_serializer,
                     request_schema=request_schema)

    for i in range(1, 3):
        try:
            return _post(url, data, headers=headers, use_kerberos=use_kerberos, parse_content_as=parse_content_as,
                        timeout=timeout, req_id=req_id, proxies=proxies, kerb_mutual_auth=kerb_mutual_auth,
                        avro_reader_cls=avro_reader_cls, ssl_verify=ssl_verify, request_serializer=request_serializer,
                         request_schema=request_schema)
        except ClientException, ex:
            status_code = ex.detail_json.get('status')
            if status_code and int(status_code) in [502, 503, 504, 511]:  # for bad gateway re-try 3 times
                time.sleep(1 * i)
                logging.info('*** retry on post()')
            else:
                raise ex


def _post(url, data, headers=None, use_kerberos=True, parse_content_as='json',
         timeout=300000, req_id=None, proxies=rest_config.BLANK_PROXIES, kerb_mutual_auth=MUTUAL_AUTH_REQUIRED,
         avro_reader_cls=None, ssl_verify=True, request_serializer=JSON_SERIALIZER, request_schema=None):
    """
    :param url: url string to send
    :param data: Data to post to service
    :param headers:  headers to send.
    :param use_kerberos: Use kerberos authentication
    :param parse_content_as: "json" or "text", "json" is default and used for all unknown types
    :param timeout: length of time in milliseconds to allow call to take before terminating. Default is 5 minutes
    :param req_id: Specify an id for the request - defaults to None in which case we use a guid
    :param proxies: Any http proxy to use
    :return:  json doc

    Currently handles json formats only
    """

    if not isinstance(data, (str, unicode, bytes, bytearray)) and request_serializer is not None:
        content_type, data = request_serializer(data, request_schema)
        headers = headers or dict()
        headers[rest_config.CONTENT_TYPE] = content_type

    auth = HTTPKerberosAuth(kerb_mutual_auth, delegate=False) if use_kerberos else None
    deadline, real_headers, real_req_id = rest_config._process_args(headers, timeout, req_id,
                                                                    app_name=app_name,
                                                                    parse_content_as=parse_content_as,
                                                                    has_body=True)

    avro_schema = None
    if parse_content_as == 'avro':
        avro_schema = __get_avro_schema(url, use_kerberos)

    timeout_secs = timeout / 1000.0
    r = requests.post(url, data=data, headers=real_headers, auth=auth, proxies=proxies, timeout=timeout_secs,
                      verify=ssl_verify)

    return _process_response(r, real_req_id, parse_content_as, avro_schema=avro_schema, avro_reader_cls=avro_reader_cls)

def put(url, data, headers=None, use_kerberos=True, parse_content_as='json',
         timeout=300000, req_id=None, proxies=rest_config.BLANK_PROXIES, kerb_mutual_auth=MUTUAL_AUTH_REQUIRED,
         avro_reader_cls=None, ssl_verify=True, request_serializer=JSON_SERIALIZER, request_schema=None):
    """
    :param url: url string to send
    :param data: Data to post to service
    :param headers:  headers to send.
    :param use_kerberos: Use kerberos authentication
    :param parse_content_as: "json" or "text", "json" is default and used for all unknown types
    :param timeout: length of time in milliseconds to allow call to take before terminating. Default is 5 minutes
    :param req_id: Specify an id for the request - defaults to None in which case we use a guid
    :param proxies: Any http proxy to use
    :return:  json doc

    Currently handles json formats only
    """

    if not isinstance(data, (str, unicode, bytes, bytearray)) and request_serializer is not None:
        content_type, data = request_serializer(data, request_schema)
        headers = headers or dict()
        headers[rest_config.CONTENT_TYPE] = content_type

    auth = HTTPKerberosAuth(kerb_mutual_auth, delegate=False) if use_kerberos else None
    deadline, real_headers, real_req_id = rest_config._process_args(headers, timeout, req_id,
                                                                    app_name=app_name,
                                                                    parse_content_as=parse_content_as,
                                                                    has_body=True)

    avro_schema = None
    if parse_content_as == 'avro':
        avro_schema = __get_avro_schema(url, use_kerberos)

    timeout_secs = timeout / 1000.0

    print url

    r = requests.put(url, data=data, headers=real_headers, auth=auth, proxies=proxies, timeout=timeout_secs,
                      verify=ssl_verify)

    return _process_response(r, real_req_id, parse_content_as, avro_schema=avro_schema, avro_reader_cls=avro_reader_cls)

def patch(url, data, headers=None, use_kerberos=True, parse_content_as='json',
         timeout=300000, req_id=None, proxies=rest_config.BLANK_PROXIES, kerb_mutual_auth=MUTUAL_AUTH_REQUIRED,
         avro_reader_cls=None, ssl_verify=True, request_serializer=JSON_SERIALIZER, request_schema=None):
    """
    :param url: url string to send
    :param data: Data to post to service
    :param headers:  headers to send.
    :param use_kerberos: Use kerberos authentication
    :param parse_content_as: "json" or "text", "json" is default and used for all unknown types
    :param timeout: length of time in milliseconds to allow call to take before terminating. Default is 5 minutes
    :param req_id: Specify an id for the request - defaults to None in which case we use a guid
    :param proxies: Any http proxy to use
    :return:  json doc

    Currently handles json formats only
    """

    if not isinstance(data, (str, unicode, bytes, bytearray)) and request_serializer is not None:
        content_type, data = request_serializer(data, request_schema)
        headers = headers or dict()
        headers[rest_config.CONTENT_TYPE] = content_type

    auth = HTTPKerberosAuth(kerb_mutual_auth, delegate=False) if use_kerberos else None
    deadline, real_headers, real_req_id = rest_config._process_args(headers, timeout, req_id,
                                                                    app_name=app_name,
                                                                    parse_content_as=parse_content_as,
                                                                    has_body=True)

    avro_schema = None
    if parse_content_as == 'avro':
        avro_schema = __get_avro_schema(url, use_kerberos)

    timeout_secs = timeout / 1000.0

    print url

    r = requests.patch(url, data=data, headers=real_headers, auth=auth, proxies=proxies, timeout=timeout_secs,
                      verify=ssl_verify)

    return _process_response(r, real_req_id, parse_content_as, avro_schema=avro_schema, avro_reader_cls=avro_reader_cls)

#print get('http://ptp-prod/ref/v1/instruments?street_ticker=IBM')