import isodate
import logging
import pandas


def popcorn_jcsv_to_dataframe(jsonmap, throw_on_error=False, debug=False, is_matrix=False):
    res = pandas.DataFrame(jsonmap['data'], columns=jsonmap['names'])

    if is_matrix:
        names_array = jsonmap.get('namesarray')
        if names_array and isinstance(names_array, (list, tuple)) and isinstance(names_array[0], (list, tuple)) and len(names_array) == 2:
            res.columns = pandas.MultiIndex.from_arrays([names_array[0], names_array[1]])

    # Convert to pandas date time format
    col = 0
    for col_type in jsonmap['types']:
        if col_type == u'STRING/ISODATE':
            datavector = res.iloc[:, col]
            # Standard iso date format, perhaps should be moved to a tools class
            iso_date_fmt = '%Y-%m-%d'

            # for backward compatibility try yyyymmdd
            # Do not remove until producing services have switched over universally to iso_date_fmt
            for x in datavector:
                if x != None and x:
                    if str.find(x.encode('ascii'), '-') == -1:
                        iso_date_fmt = '%Y%m%d'
                    break

            def as_str(s):
                if s == None or s == '9999-12-31':
                    return None
                return s.encode('ascii')

            data = map(as_str, datavector)
            xdatavector = [(x if x == None else pandas.to_datetime(x, format=iso_date_fmt)) for x in data]

            res.iloc[:, col] = xdatavector

        if col_type == u'STRING/ISODATETIME':
            datavector = res.iloc[:, col]
            try:
                def as_str(s):
                    if s == None or s.startswith('9999-12-31'):
                        return None
                    return s.encode('ascii')

                data = map(as_str, datavector)
                xdatavector = [(x if x == None else isodate.parse_datetime(x)) for x in data]

            except Exception, e:
                if debug:
                    logging.exception(e)
                if throw_on_error:
                    raise e

            res.iloc[:, col] = xdatavector
        col += 1

    return res
