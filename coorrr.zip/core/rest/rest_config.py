import sys
import os
import os.path
import logging
import tempfile
import json
import uuid
import time
import requests
import threading

X_REQUEST_ID = 'X-Request-ID'
X_USER_APP = 'X-User-Application'
X_ACCEPT_DEADLINE = 'X-Accept-Deadline'
CONTENT_TYPE = 'Content-Type'
ACCEPT = 'Accept'
MIME_JSON = 'application/json'
MIME_JSON_CSVS = 'application/json;fmt=csvs'
MIME_AVRO_BIN = 'application/octet-stream;fmt=avro'
X_AVSC_VERSION = 'X-Avsc-Version'
X_METHOD_OVERWRITE = 'X-Method-Overwrite'
X_AVSC_SCHEMA = 'X-Avsc-Schema'
QUERY_PARAMETERS = 'com.pimco.popcorn:popcorn-schema:com.pimco.popcorn.dto.queryParams.QueryParameters'

BLANK_PROXIES = {
  "http": None,
  "https": None,
}


class _CurrentRequest(threading.local):
    req_id = None
    initialized = False

    def __init__(self, **kwargs):
        if self.initialized:
            raise SystemError('__init__ called too many times')
        self.initialized = True
        self.__dict__.update(kwargs)

        super(_CurrentRequest, self).__init__()

__current_request = _CurrentRequest(req_id=None)


def _set_request_id(req_id):
    __current_request.req_id = req_id


def _get_request_id():
    return __current_request.req_id


def _process_args(override_headers, timeout, req_id, app_name, parse_content_as, has_body=False):
    deadline = long(time.time()) * 1000L + timeout
    req_id = req_id or _get_request_id()
    real_req_id = req_id or str(uuid.uuid4())

    headers = requests.structures.CaseInsensitiveDict()
    headers[X_USER_APP] = app_name
    headers[X_REQUEST_ID] = real_req_id
    headers[X_ACCEPT_DEADLINE] = str(deadline)

    # If the caller supplied any headers add them over the top of the default ones
    if override_headers is not None:
        for k, v in override_headers.iteritems():
            headers[k] = v

    if has_body and CONTENT_TYPE not in headers:
        headers[CONTENT_TYPE] = MIME_JSON

    if not ACCEPT in headers:
        if parse_content_as == 'avro':
            headers[ACCEPT] = MIME_AVRO_BIN
        else:
            headers[ACCEPT] = MIME_JSON
        #headers[ACCEPT] = ",".join([MIME_JSON, MIME_JSON_CSVS])

    return (deadline, headers, real_req_id)


def install_krb5():
    m = sys.modules['core.rest.client']
    if hasattr(m, 'kerberos_installed'):
        logging.info("Kerberos Auth config was already processed.")
        return

    logging.info('Checking kerberos auth config')
    if 'WINDIR' in os.environ:
        logging.info("Kerberos Auth config doesn't need reprocessing on windows.")
        m.kerberos_installed = False
        return

    # Two places for krb5.conf:
    # - /base/vendor/kerberos/krb5.conf for the pimco one
    # - /etc/krb5.conf for the system one
    # If we are pointing at or can find the pimco one, just use it, else patch whichever other one we find
    # to remove the reverse DNS lookup that mucks up hostnames where there are multiple aliases for the same
    # host or load balancer
    process_krb5_conf = True
    if 'KRB5_CONFIG' in os.environ:
        source_config = os.environ['KRB5_CONFIG']
        # env var was set but is pointing at PIMCO krb5, so leave it alone
        if source_config == '/base/vendor/kerberos/krb5.conf':
            process_krb5_conf = False
    elif os.path.isfile('/base/vendor/kerberos/krb5.conf'):
        # No env var, but we can find PIMCO krb5.conf so set and leave
        source_config = '/base/vendor/kerberos/krb5.conf'
        os.environ['KRB5_CONFIG'] = source_config
        process_krb5_conf = False
    else:
        source_config = '/etc/krb5.conf'
    # Check what ever file we have exists!
    if not os.path.isfile(source_config):
        source_config = '/etc/krb5.conf'
        if not os.path.isdir(source_config):
            logging.warn("System not configured for kerberos")
            m.kerberos_installed = False
            return

    if process_krb5_conf:
        logging.info("Rewriting config: " + source_config)
        with open(source_config, 'r') as s:
            with tempfile.NamedTemporaryFile("w+", delete=False) as f:
                l = s.readline()
                while l:
                    f.write(l)
                    if l.startswith('[libdefaults]'):
                        f.write('\trdns = false\n')
                    l = s.readline()
                temp_name = f.name

        logging.info("Rewrote kerberos config: " + temp_name)
        os.environ['KRB5_CONFIG'] = temp_name
    m.kerberos_installed = True


class PopcornParameters:
    """
    class to mimic Avro record QueryParameters {
    string id = "";
    map<array<string>> parameters = {};
    }
    """
    def __init__(self, params):
        self.id = '1'
        self.parameters = {}
        # Iterate making sure the value is an array
        for k,v in params.iteritems():
            if k in self.parameters:
                self.parameters[k].append(v)
            elif isinstance(v, list):
                self.parameters[k] = v
            else:
                self.parameters[k] = [v]

    def to_json(self):
        return json.dumps(self.__dict__)

