import json
from . import rest_config
from avro.io import BinaryEncoder, DatumWriter
from io import BytesIO


def to_json(obj, schema=None):
    return rest_config.MIME_JSON, json.dumps(obj)


def to_json_with_encoder(encoder_cls, obj, schema=None):
    return rest_config.MIME_JSON, json.dumps(obj, cls=encoder_cls)


def to_avro(obj, schema=None):
    if obj is not None:
        if hasattr(type(obj), 'RECORD_SCHEMA'):
            schema = type(obj).RECORD_SCHEMA

    if schema is None:
        raise Exception('Could not deduce request avro schema and no schema was passed')
    target = BytesIO()
    w = DatumWriter(schema)
    enc = BinaryEncoder(target)
    w.write(obj, enc)

    return rest_config.MIME_AVRO_BIN, target.getvalue()
