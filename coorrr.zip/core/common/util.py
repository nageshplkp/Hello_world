import time
import collections
import datetime
import os
import socket
import string
import sys
import time
import traceback
import six
import functools
from core.common import dates
import importlib
import itertools


def fullname(cls):
    """
    Gets fuill name of a type

    :param cls: Type
    :return: Full name
    :rtype: str
    """

    return '%s.%s' % (cls.__module__, cls.__name__)


def getclassbyname(cls_name):
    """
    Gets type object by full name

    :param cls_name: Full name of type (i.e. __builtin__.int)
    :type cls_name: str
    :return: Type
    :rtype: type
    """

    rdot = cls_name.rfind('.')
    if rdot < 0:
        raise Exception('Can not find type by local name')
    module = cls_name[:rdot]
    cls_name = cls_name[rdot+1:]

    module = sys.modules.get(module)
    if module is None:
        module = importlib.import_module(module)
    return getattr(module, cls_name)


def unique(l):
    s = set()
    r = []
    for x in l:
        if x in s:
            continue
        r.append(x)
        s.add(x)
    return r


def transform_np2py(value, nanAndInfAsNone=False):
    import pandas as pd
    import numpy as np
    if value is None:
        return
    elif isinstance(value, np.generic):
        if nanAndInfAsNone and isinstance(value, float) and (np.isnan(value) or np.isinf(value)):
            return
        return value.item()
    elif isinstance(value, pd.Timestamp):
        return value.to_pydatetime()
    elif isinstance(value, collections.Sequence) and not isinstance(value, basestring):
        return tuple(itertools.imap(transform_np2py, value))
    return value


def make_tuple(val, size):
    if not isinstance(val, collections.Sequence) or isinstance(val, basestring):
        val = (val,)

    if len(val) < size:
        return val[:size]
    elif len(val) > size:
        return val + (None,) * len(val)
    return val


def df_to_py_list(df, columns=None, index_columns=None, nanAndInfAsNone=False):
    import pandas as pd
    assert isinstance(df, pd.DataFrame)
    if not columns:
        columns = df.columns

    def to_tuple(c):
        if not isinstance(c, (list, tuple)):
            return (c, str(c))
        return c

    columns = map(to_tuple, columns)
    #columns = [((c, str(c)) if not isinstance(c, (list, tuple)) else c) for c in columns]

    col_series = itertools.izip(*[itertools.imap(transform_np2py, df[c[0]], itertools.repeat(nanAndInfAsNone, len(df)))
                                  for c in columns])
    data_series = col_series
    names = [c[1] for c in columns]

    if index_columns is not None:
        if isinstance(index_columns, basestring) or not isinstance(index_columns, collections.Sequence):
            index_columns = [index_columns]
        names = index_columns + names
        index_series = itertools.imap(lambda x: make_tuple(transform_np2py(x), len(index_columns)), df.index)

        data_series = itertools.imap(lambda x, y: x + y, index_series, col_series)

    return names, list(data_series)


def tz_offset_str(tz=None):
    tz = tz or time.timezone / 3600
    return ('-' if tz >= 0 else '+') + '%02d:00' % abs(tz)

def str_to_bool(v):
  return v.lower() in ("yes", "true", "t", "1")


def username():
    return os.environ.get('USERNAME', os.environ.get('USER'))

def python_dir():
    import sys
    return sys.exec_prefix

def reserve_port(ip='127.0.0.1'):
    from socket import socket, SOL_SOCKET, SO_REUSEADDR

    """Bind to an ephemeral port, force it into the TIME_WAIT state, and unbind it.
    This means that further ephemeral port alloctions won't pick this "reserved" port,
    but subprocesses can still bind to it explicitly, given that they use SO_REUSEADDR.
    By default on linux you have a grace period of 60 seconds to reuse this port.
    To check your own particular value:
    $ cat /proc/sys/net/ipv4/tcp_fin_timeout
    60
    By default, the port will be reserved for localhost (aka 127.0.0.1).
    To reserve a port for a different ip, provide the ip as the first argument.
    Note that IP 0.0.0.0 is interpreted as localhost.
    """
    s = socket()
    s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
    s.bind((ip, 0))

    # the connect below deadlocks on kernel >= 4.4.0 unless this arg is greater than zero
    s.listen(1)

    sockname = s.getsockname()

    # these three are necessary just to get the port into a TIME_WAIT state
    s2 = socket()
    s2.connect(sockname)
    s.accept()

    return int(sockname[1])


def recursive_update(existing, new):
    if not isinstance(existing, collections.Mapping):
        raise Exception('existing must be a dict-like object')
    if not isinstance(new, collections.Mapping):
        raise Exception('new must be a dict-like object')

    for k in new.iterkeys():
        if k in existing:
            if isinstance(existing[k], collections.Mapping) and isinstance(new[k], collections.Mapping):
                recursive_update(existing[k], new[k])
            else:
                existing[k] = new[k]
        else:
            existing[k] = new[k]


def past_week_sunday(dt=datetime.datetime.now()):
    '''
    one week ago, sunday. useful for replaying back past week's data
    '''
    # days of week, mon = 0, sun = 6
    dt = dt - datetime.timedelta(days=5)

    while dt.weekday() != 6:
        dt = dt - datetime.timedelta(days=1)

    return datetime.datetime(dt.year, dt.month, dt.day)


def exceptionAsStr(ex):
    return '\nEXCEPTION: %s\nTRACE:%s' % (ex.message, traceback.format_exc())


def error_as_str(ex):
    return '\nEXCEPTION: %s\nTRACE:%s' % (ex.message, traceback.format_exc())


def print_stack_trace():
    traceback.print_stack()


def str2bool(v):
    if not v: return False

    if isinstance(v, bool):
        return v

    return v.lower() in ("yes", "true", "t", "1")

def str_diff(s1, s2):
    import difflib
    d = difflib.Differ()
    return "\n".join(difflib.ndiff([s1], [s2])),

def get_mem():
    import psutil
    '''
    return process working set in megs
    '''
    p = psutil.Process(os.getpid())
    mem = p.memory_info()

    return mem.rss / 1024.0 / 1024.0


def host():
    return socket.gethostname()

def proc_info():
    host = socket.gethostname()
    proc_id = os.getpid()
    running_dir = os.path.abspath(sys.argv[0])
    return 'host=%s proc_id=%s script=%s' % (host, proc_id, running_dir)

def find_procs_by_name(name, strict=False, return_one=False):
    import psutil
    procs = []
    try:
        if strict:
            procs = [p for p in  psutil.process_iter() if name in  p.name().lower()]
        else:
            procs_all = [p for p in psutil.process_iter()]
            for p in procs_all:
                if [c for c in p.cmdline() if name in c.lower()]:
                    procs.append(p)
            procs = list(set(procs))
    except Exception as ex:
        print(ex)

    if not procs:
        return None
    elif return_one:
        return procs[0]
    else:
        return procs

def pid():
    return os.getpid()


def pprintDf(table):
    print(pformatDf(table))

def pformatDf(table):
    from tabulate import tabulate
    return tabulate(table, headers='keys', tablefmt='psql', floatfmt="0,.4f")


def isWindows():
    return sys.platform == 'win32'


def window_iterator(collection, window_size=2, filler=0.0):
    for i in xrange(0, len(collection)):
        yield [filler] * max(0, (window_size - i - 1)) + collection[
                                                         max(i - window_size + 1, 0): max(i - window_size + 1, 0) + min(
                                                             window_size, i + 1)]


def extract_params(func, func_locals):
    import inspect
    arg_names, varargs, keywords, defaults = inspect.getargspec(func)

    defaults = defaults or []

    pos_arg_names = arg_names if not defaults else arg_names[:-len(defaults)]
    kw_arg_names = [] if not defaults else arg_names[-len(defaults):]
    args = [func_locals.get(x) for x in pos_arg_names]
    if varargs:
        args += func_locals.get(varargs, [])
    kwargs = dict((x, func_locals.get(x)) for x in kw_arg_names)
    if keywords:
        kwargs.update(func_locals.get(keywords, {}))

    return args, kwargs


def explicit_param_checker(f):
    def wrapper(*args, **kwargs):
        kwargs['__explicit_params'] = kwargs
        return f(*args, **kwargs)

    return wrapper




DEFAULT_HOLIDAYS = [
    datetime.datetime.strptime('11/11/2014', '%m/%d/%Y').date(),
    datetime.datetime.strptime('11/27/2014', '%m/%d/%Y').date(),
    datetime.datetime.strptime('10/13/2014', '%m/%d/%Y').date(),
    datetime.datetime.strptime('12/25/2014', '%m/%d/%Y').date(),
    datetime.datetime.strptime('9/23/2014', '%m/%d/%Y').date(),
    datetime.datetime.strptime('1/1/2015', '%m/%d/%Y').date(),
    datetime.datetime.strptime('1/19/2015', '%m/%d/%Y').date(),
    datetime.datetime.strptime('11/11/2015', '%m/%d/%Y').date(),
    datetime.datetime.strptime('11/26/2015', '%m/%d/%Y').date(),
    datetime.datetime.strptime('12/25/2015', '%m/%d/%Y').date(),
    datetime.datetime.strptime('1/1/2016', '%m/%d/%Y').date(),
    datetime.datetime.strptime('12/31/2015', '%m/%d/%Y').date(),
    datetime.datetime.strptime('1/18/2016', '%m/%d/%Y').date(),
    datetime.datetime.strptime('2/15/2016', '%m/%d/%Y').date(),
    datetime.datetime.strptime('2/16/2015', '%m/%d/%Y').date(),
    datetime.datetime.strptime('4/3/2015', '%m/%d/%Y').date(),
    datetime.datetime.strptime('5/25/2015', '%m/%d/%Y').date(),
    datetime.datetime.strptime('7/3/2015', '%m/%d/%Y').date(),
    datetime.datetime.strptime('10/12/2015', '%m/%d/%Y').date(),
    datetime.datetime.strptime('3/25/2016', '%m/%d/%Y').date(),
    datetime.datetime.strptime('12/26/2016', '%m/%d/%Y').date(),
    datetime.datetime.strptime('1/2/2017', '%m/%d/%Y').date(),
    datetime.datetime.strptime('1/16/2017', '%m/%d/%Y').date(),
    datetime.datetime.strptime('2/20/2017', '%m/%d/%Y').date(),
    datetime.datetime.strptime('4/14/2017', '%m/%d/%Y').date(),
    datetime.datetime.strptime('5/29/2017', '%m/%d/%Y').date(),
    datetime.datetime.strptime('7/4/2017', '%m/%d/%Y').date(),
    datetime.datetime.strptime('9/4/2017', '%m/%d/%Y').date(),
    datetime.datetime.strptime('10/9/2017', '%m/%d/%Y').date(),
    datetime.datetime.strptime('11/23/2017', '%m/%d/%Y').date(),
    datetime.datetime.strptime('11/23/2017', '%m/%d/%Y').date(),
    datetime.datetime.strptime('12/25/2017', '%m/%d/%Y').date(),
    datetime.datetime.strptime('1/1/2018', '%m/%d/%Y').date(),
    datetime.datetime.strptime('1/15/2018', '%m/%d/%Y').date(),
    datetime.datetime.strptime('2/19/2018', '%m/%d/%Y').date(),
    datetime.datetime.strptime('3/30/2018', '%m/%d/%Y').date(),
    datetime.datetime.strptime('5/28/2018', '%m/%d/%Y').date(),
    datetime.datetime.strptime('7/4/2018', '%m/%d/%Y').date(),
    datetime.datetime.strptime('9/3/2018', '%m/%d/%Y').date(),
    datetime.datetime.strptime('10/8/2018', '%m/%d/%Y').date(),
    datetime.datetime.strptime('11/12/2018', '%m/%d/%Y').date(),
    datetime.datetime.strptime('11/22/2018', '%m/%d/%Y').date(),
    datetime.datetime.strptime('12/25/2018', '%m/%d/%Y').date(),
    datetime.datetime.strptime('1/1/2019', '%m/%d/%Y').date(),
    datetime.datetime.strptime('1/21/2019', '%m/%d/%Y').date(),
    datetime.datetime.strptime('2/18/2019', '%m/%d/%Y').date(),
    datetime.datetime.strptime('4/19/2019', '%m/%d/%Y').date(),
    datetime.datetime.strptime('5/27/2019', '%m/%d/%Y').date(),
    datetime.datetime.strptime('7/4/2019', '%m/%d/%Y').date(),
    datetime.datetime.strptime('11/2/2019', '%m/%d/%Y').date(),
    datetime.datetime.strptime('10/14/2019', '%m/%d/%Y').date(),
    datetime.datetime.strptime('11/11/2019', '%m/%d/%Y').date(),
    datetime.datetime.strptime('11/28/2019', '%m/%d/%Y').date(),
    datetime.datetime.strptime('12/25/2019', '%m/%d/%Y').date(),
    datetime.datetime.strptime('1/1/2020', '%m/%d/%Y').date(),
]


def generate_workdays(start_date, num, holidays=DEFAULT_HOLIDAYS):
    from datetime import date as pydate, timedelta
    r = []
    assert isinstance(start_date, pydate)
    for i in xrange(num):
        while start_date.weekday() > 4 or start_date in holidays:
            start_date = start_date - timedelta(days=1)
        r.append(start_date)
        start_date = start_date - timedelta(days=1)

    return list(reversed(r))


def merge_data_using_workdays(*frames):
    from datetime import date as pydate, timedelta
    import pandas as pd

    workdays = generate_workdays(pydate.today() - timedelta(days=1), 365 * 2)

    aliases, frames = zip(*[
        (frames[x], frames[x + 1]) for x in xrange(0, len(frames), 2)
        ])

    frames = [x.set_index('ASOF_DATE') for x in frames]
    frames_orig = frames
    frames = [x.to_records(index=True, convert_datetime64=True)
              for x in frames]

    frames = [dict((r[0].date(), tuple(r)[1:]) for r in f) for f in frames]

    cols = [('ASOF_DATE', pd.to_datetime(workdays))]
    for a, f, of in zip(aliases, frames, frames_orig):
        empty = (None,) * len(of.columns)
        for i, c in enumerate(of.columns):
            new_name = '%s_%s' % (a, c)
            cols.append((new_name, [f.get(w, empty)[i] for w in workdays]))

    return pd.DataFrame(data=dict(cols))


def ireversed(collection):
    for i in xrange(len(collection), 0, -1):
        yield collection[i - 1]


def first(collection, predicate=lambda x: True):
    for x in collection:
        if predicate(x):
            return x
    return None


def last(collection, predicate=lambda x: True):
    for x in ireversed(collection):
        if predicate(x):
            return x
    return None


def first_index(collection, predicate=lambda x: True):
    for i, x in enumerate(collection):
        if predicate(x):
            return i
    return -1


def last_index(collection, predicate=lambda x: True):
    for i, x in enumerate(ireversed(collection)):
        if predicate(x):
            return len(collection) - i - 1
    return -1


def ireadlines(f, strip=True):
    l = f.readline()
    while l:
        if strip:
            l = l.strip()
        yield l
        l = f.readline()


def df_rolling_sum_one_month(current, prior):
    return prior > dates.dateMinusMonths(current, 1, resetToFirst=False)


def df_rolling_sum_one_week(current, prior):
    return prior > dates.dateMinusDays(current, 7)


def df_rolling_sum_one_year(current, prior):
    return prior > dates.dateMinusMonths(current, 12, resetToFirst=False)


def df_rolling_sum(df, column, index_predicate=df_rolling_sum_one_month):
    import pandas as pd

    x = 0
    rs = 0.0

    r = pd.Series(index=df.index)
    for y in xrange(len(df.index)):
        rs += df.ix[df.index[y], column]
        while x < y and not index_predicate(df.index[y], df.index[x]):
            rs -= df.ix[df.index[x], column]
            x += 1
        r.loc[df.index[y]] = rs

    return r


def is_number(s, support_sci_notation=False):
    """Test if a given string is a number.

    Args:
        s: The string to be tested
        support_sci_notation: If True, will support scientific notations such as 5e10. Expect relatively slower
              performance for invalid inputs. Better performance for valid inputs.
    """
    if support_sci_notation:
        try:
            float(s)
            return True
        except ValueError:
            pass
    else:
        if s:
            s = s[1:] if s[0]== '-' else s
            return s.replace('.','',1).isdigit()
    return False


def dict_merge(dct, merge_dct):
    """Recursive dict merge. Inspired by :meth:``dict.update()``, instead of
    updating only top-level keys, dict_merge recurses down into dicts nested
    to an arbitrary depth, updating keys. The ``merge_dct`` is merged into
    ``dct``.

    :param dct: dict onto which the merge is executed
    :param merge_dct: dct merged into dct
    :return: None
    """
    for k, v in merge_dct.iteritems():
        if k in dct and isinstance(dct[k], dict) and isinstance(merge_dct[k], collections.Mapping):
            dict_merge(dct[k], merge_dct[k])
        else:
            dct[k] = merge_dct[k]
    return dct


def normalize_line_endings(temp):
    """
    Normalizes the line endings so that python can handle the line endings with default os.linesep
    """
    if temp:
        temp = string.replace(temp, '\r\n', '\n')
        temp = string.replace(temp, '\r', '\n')
    return temp


def is_string(txt):
    """
    Future proof way of telling if something is a string
    """
    return isinstance(txt, six.string_types)


def as_str(txt, enc='utf8'):
    """
    Future-proof way to ensure you get str instead of unicode. Default 'utf8' endcoding is  used.
    Pass enc parameter to override encoding
    """
    return txt.encode(enc) if six.PY2 and isinstance(txt, six.string_types) and not isinstance(txt, str) else txt


def auto_str(cls):
    def __str__(self):
        return '%s(%s)' % (type(self).__name__, ', '.join('%s=%s' % item for item in vars(self).items()))
    cls.__str__ = __str__
    cls.__repr__ = __str__
    return cls


def pretty_int(v):
    return '{:0,.0f}'.format(v)


def pretty_float(v):
    return '{:0,.4f}'.format(v)


def topo_sort(data):
    """
    Dependencies are expressed as a dictionary whose keys are items
    and whose values are a set of dependent items. Output is a list of
    sets in topological order. The first set consists of items with no
    dependencies, each subsequent set consists of items that depend upon
    items in the preceding sets.
    Courtesy: https://bitbucket.org/ericvsmith/toposort
    """

    # Special case empty input.
    if len(data) == 0:
        return

    # Copy the input so as to leave it unmodified.
    data = data.copy()

    # Ignore self dependencies.
    for k, v in data.items():
        v.discard(k)
    # Find all items that don't depend on anything.
    extra_items_in_deps = functools.reduce(set.union, data.values()) - set(data.keys())
    # Add empty dependencies where needed.
    data.update({item:set() for item in extra_items_in_deps})
    while True:
        ordered = set(item for item, dep in data.items() if len(dep) == 0)
        if not ordered:
            break
        yield ordered
        data = {item: (dep - ordered)
                for item, dep in data.items()
                if item not in ordered}
    if len(data) != 0:
        s = 'Circular dependencies exist among these items: {{{}}}'.\
            format(', '.join('{!r}:{!r}'.format(key, value) for key, value in sorted(data.items())))
        raise Exception(s)


def topo_sort_flatten(data, sort=True):
    """
    Returns a single list of dependencies. For any set returned by
    topo_sort(), those items are sorted and appended to the result (just to
    make the results deterministic).
    """

    result = []
    for d in topo_sort(data):
        result.extend((sorted if sort else list)(d))
    return result