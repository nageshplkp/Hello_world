import sys
import subprocess
import os
import abc
import logging
import os.path
import six

from core.common.decorate import memoize

logger = logging.getLogger('core.common.impersonate')


class ImpersonationHandle(object):
    def __init__(self, data, impersonator):
        self.__data = data
        self.__impersonator = impersonator

    @property
    def data(self):
        return self.__data

    def revert(self):
        self.__impersonator.revert_impersonation(self)
        self.__impersonator = None
        self.__data = None

    def __enter__(self, *args, **kwargs):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.revert()


class Impersonator(object):
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def impersonate(self, username, password, group=None, load_profile=True):
        """
        Impersonates user in the current process
        
        :param username: 
        :param group: 
        :param load_profile: 
        :return: Impersonation handle
        :rtype: ImpersonationHandle
        """
        pass

    def revert_impersonation(self, handle):
        """
        Revert impersonation
        
        :param ImpersonationHandle handle: 
        :return: 
        """
        try:
            self._revert_impersonation_core(handle)
        except:
            import traceback
            logger.error('Could not revert impersonation: %s', traceback.format_exc())
            raise

    @abc.abstractmethod
    def _revert_impersonation_core(self, handle):
        pass

    @abc.abstractmethod
    def launch_process_as(self, args, username, password, group=None, load_profile=True,
                          bufsize=0, executable=None,
                          stdin=None, stdout=None, stderr=None,
                          preexec_fn=None, close_fds=False, shell=False,
                          cwd=None, additional_env=None, universal_newlines=False,
                          startupinfo=None, creationflags=0, subprocess_module=None):
        pass


class WindowsUsername(object):
    __slots__ = ['username', 'domain']

    def __init__(self, username_and_domain, domain=None):
        if '\\' in username_and_domain:
            self.domain, self.username = username_and_domain.split('\\')
        elif '@' in username_and_domain:
            self.username, self.domain = username_and_domain.split('@')
        else:
            self.username = username_and_domain
            self.domain = domain or 'PIMCO.IMSWEST.SSCIMS.COM'

    def ntlm_syntax(self):
        if self.domain:
            return '%s\\%s' % (self.domain, self.username)
        else:
            return self.username

    def web_syntax(self):
        if self.domain:
            return '%s@%s' % (self.username, self.domain)
        else:
            return self.username


def _make_popen(subprocess_module=None):
    subprocess_module = subprocess_module or subprocess
    import pywintypes

    class _WinPOpen(subprocess_module.Popen):
        def __init__(self, *args, **kwargs):
            self.process_factory = kwargs.pop('process_factory')
            super(_WinPOpen, self).__init__(*args, **kwargs)

        def _execute_child(self, args, executable, preexec_fn, close_fds,
                           cwd, env, universal_newlines,
                           startupinfo, creationflags, shell,
                           p2cread, p2cwrite,
                           c2pread, c2pwrite,
                           errread, errwrite):
            import win32process
            from win32api import GetVersion
            from pywintypes import HANDLE
            if not isinstance(args, six.string_types):
                args = subprocess_module.list2cmdline(args)

            # Process startup details
            if startupinfo is None:
                startupinfo = subprocess_module.STARTUPINFO()
            if None not in (p2cread, c2pwrite, errwrite):
                startupinfo.dwFlags |= win32process.STARTF_USESTDHANDLES
                startupinfo.hStdInput = p2cread
                startupinfo.hStdOutput = c2pwrite
                startupinfo.hStdError = errwrite

            if shell:
                startupinfo.dwFlags |= win32process.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess_module.SW_HIDE
                comspec = os.environ.get("COMSPEC", "cmd.exe")
                args = '{} /c "{}"'.format(comspec, args)
                if GetVersion() >= 0x80000000 or os.path.basename(comspec).lower() == "command.com":
                    # Win9x, or using command.com on NT. We need to
                    # use the w9xpopen intermediate program. For more
                    # information, see KB Q150956
                    # (http://web.archive.org/web/20011105084002/http://support.microsoft.com/support/kb/articles/Q150/9/56.asp)
                    w9xpopen = self._find_w9xpopen()
                    args = '"%s" %s' % (w9xpopen, args)
                    # Not passing CREATE_NEW_CONSOLE has been known to
                    # cause random failures on win9x.  Specifically a
                    # dialog: "Your program accessed mem currently in
                    # use at xxx" and a hopeful warning about the
                    # stability of your system.  Cost is Ctrl+C wont
                    # kill children.
                    creationflags |= win32process.CREATE_NEW_CONSOLE

            # Start the process
            try:
                hp, ht, pid, tid = self.process_factory(executable, args,
                                                        # no special security
                                                        None, None,
                                                        int(not close_fds),
                                                        creationflags,
                                                        env,
                                                        cwd,
                                                        startupinfo)
            except pywintypes.error, e:
                # Translate pywintypes.error to WindowsError, which is
                # a subclass of OSError.  FIXME: We should really
                # translate errno using _sys_errlist (or similar), but
                # how can this be done from Python?
                raise WindowsError(*e.args)
            finally:
                # Child is launched. Close the parent's copy of those pipe
                # handles that only the child should have open.  You need
                # to make sure that no handles to the write end of the
                # output pipe are maintained in this process or else the
                # pipe will not close when the child process exits and the
                # ReadFile will hang.
                if p2cread is not None:
                    p2cread.Close()
                if c2pwrite is not None:
                    c2pwrite.Close()
                if errwrite is not None:
                    errwrite.Close()

            # Retain the process handle, but close the thread handle
            self._handle = hp
            self.pid = pid
            ht.Close()

    return _WinPOpen


class WindowsImpersonator(Impersonator):
    @staticmethod
    def get_sid(account_name):
        import win32security

        sid, domain, type_ = win32security.LookupAccountName(None, account_name)
        return sid

    @staticmethod
    def grant_logon_rights(account_name):
        import win32security
        policy = win32security.LsaOpenPolicy(None, win32security.POLICY_ALL_ACCESS)
        win32security.LsaAddAccountRights(policy, WindowsImpersonator.get_sid(account_name),
                                          (win32security.SE_SERVICE_LOGON_NAME,))
        win32security.LsaAddAccountRights(policy, WindowsImpersonator.get_sid(account_name),
                                          (win32security.SE_INTERACTIVE_LOGON_NAME,))
        win32security.LsaAddAccountRights(policy, WindowsImpersonator.get_sid(account_name),
                                          (win32security.SE_BATCH_LOGON_NAME,))

        win32security.LsaClose(policy)

    @staticmethod
    def get_user_profile(username):
        import win32net

        try:
            ui = win32net.NetUserGetInfo(None, username, 4)
            return ui['profile'] or None
        except:
            return None

    def launch_process_as(self, args, username, password, group=None, load_profile=True, bufsize=0, executable=None,
                          stdin=None,
                          stdout=None, stderr=None, preexec_fn=None, close_fds=False, shell=False, cwd=None,
                          additional_env=None,
                          universal_newlines=False, startupinfo=None, creationflags=0, subprocess_module=None):
        import functools
        POpen = _make_popen(subprocess_module)
        return POpen(args, bufsize, executable, stdin, stdout, stderr, preexec_fn, close_fds, shell, cwd,
                     additional_env, universal_newlines, startupinfo, creationflags,
                     process_factory=functools.partial(self.__create_process_as_user, username=username,
                                                       password=password,
                                                       load_profile=load_profile))

    def __create_process_as_user(self, app_name, cmd_line, proc_attrs, thread_attrs, inherit, flags, env_mapping,
                                 curdir, startup_info, username=None, password=None,
                                 load_profile=True):  # real signature unknown; restored from __doc__
        import win32process
        with self.__impersonate(username, password, load_profile=load_profile, env_only=True) as h:
            env = dict(os.environ)
            env_mapping = {str(k): str(v) for k, v in six.iteritems(env_mapping)}
            env.update(env_mapping)
            return win32process.CreateProcessAsUser(h.data['handle'], app_name, cmd_line,
                                                    proc_attrs, thread_attrs, inherit, flags,
                                                    env_mapping, curdir, startup_info)

    def impersonate(self, username, password, group=None, load_profile=True):
        return self.__impersonate(username, password, group, load_profile, False)

    def __impersonate(self, username, password, group=None, load_profile=True, env_only=False):
        import win32security
        import win32profile

        w32username = WindowsUsername(username)
        handle = win32security.LogonUser(w32username.username, w32username.domain, password,
                                         win32security.LOGON32_LOGON_SERVICE,
                                         win32security.LOGON32_PROVIDER_DEFAULT)

        restore_env = dict(os.environ)
        try:
            profile_env = None
            profile = None
            if load_profile:
                profile = win32profile.LoadUserProfile(handle, {'UserName': w32username.username, 'Flags': 0,
                                                                'ProfilePath': WindowsImpersonator.get_user_profile(
                                                                    w32username.username)})
                profile_env = dict(os.environ)
                user_env = win32profile.CreateEnvironmentBlock(handle, False)
                profile_env.update(user_env)
                profile_env = {str(k): str(v) for k, v in six.iteritems(profile_env)}

            if not env_only:
                win32security.ImpersonateLoggedOnUser(handle)

            if load_profile:
                for k, v in six.iteritems(profile_env):
                    os.environ[k] = v

            return ImpersonationHandle(dict(env=restore_env, handle=handle, profile=profile, env_only=env_only), self)

        except:
            if load_profile and profile:
                win32profile.UnloadUserProfile(handle, profile)
                profile.close()
            handle.close()
            for k, v in six.iteritems(restore_env):
                os.environ[k] = v

            raise

    def _revert_impersonation_core(self, handle):
        import win32security
        import win32profile

        if not handle.data['env_only']:
            win32security.RevertToSelf()

        if 'profile' in handle.data:
            win32profile.UnloadUserProfile(handle.data['handle'], handle.data['profile'])
            handle.data['profile'].close()

        handle.data['handle'].close()
        for k, v in six.iteritems(handle.data['env']):
            os.environ[k] = v

        keys = os.environ.keys()
        for k in keys:
            if k not in handle.data['env']:
                del os.environ[k]


class LinuxImpersonator(Impersonator):
    def impersonate(self, username, password, group=None, load_profile=True):
        gid, uid = self.get_uid_and_gid(username, group)

        restore_env = dict(os.environ)

        save_gid = os.getgid()
        os.setegid(gid)
        os.seteuid(uid)

        self.load_profile_env()

        return ImpersonationHandle(dict(restore_env=restore_env, save_gid=save_gid), self)

    def load_profile_env(self):
        from tech.apps.cliqr.agent_util import get_current_profile

        env = dict(os.environ)
        profile_env = get_current_profile()
        profile_env = {str(k): str(v) for k, v in six.iteritems(profile_env)}
        env.update(profile_env)
        for k, v in six.iteritems(env):
            os.environ[k] = v

    def get_uid_and_gid(self, username, group, subprocess_module=None):
        from core.common import getent

        uid = getent.passwd(username, subprocess_module=subprocess_module)
        uid = uid.get(username)
        if uid is None:
            raise Exception('Invalid user: %s' % username)
        gid = getent.group(group, subprocess_module=subprocess_module) \
            if group else getent.group(uid['gid'], subprocess_module=subprocess_module)
        if len(gid) == 0:
            raise Exception('Invalid group: %s' % (group or uid['gid']))
        gid = gid.values()[0]
        uid, gid = uid['uid'], gid['gid']
        return gid, uid

    def _revert_impersonation_core(self, handle):
        restore_env = handle.data['restore_env']
        os.seteuid(0)
        os.setegid(handle.data['save_gid'])

        for k, v in six.iteritems(restore_env):
            os.environ[k] = v

        keys = os.environ.keys()
        for k in keys:
            if k not in restore_env:
                del os.environ[k]

    def launch_process_as(self, args, username, password=None, group=None, load_profile=True, bufsize=0,
                          executable=None,
                          stdin=None,
                          stdout=None, stderr=None, preexec_fn=None, close_fds=False, shell=False, cwd=None,
                          additional_env=None,
                          universal_newlines=False, startupinfo=None, creationflags=0, subprocess_module=None):
        subprocess_module = subprocess_module or subprocess

        wusername = WindowsUsername(username, 'PIMCO.IMSWEST.SSCIMS.COM')
        username = wusername.username

        gid, uid = self.get_uid_and_gid(username, group, subprocess_module=subprocess_module)

        if password is None:
            if not os.path.isfile('/home/%s/.ssh/%s.keytab' % (username, username)):
                raise Exception('To impersonate without password a keytab must be present')

        def _custom_preexec(*args, **kwargs):
            os.setgid(gid)
            os.setuid(uid)

            os.environ['USER'] = os.environ['USERNAME'] = username
            os.environ['HOME'] = '/home/%s' % username
            os.environ['USER_PRINCIPAL_NAME'] = wusername.web_syntax()

            if load_profile:
                self.load_profile_env()

            processed_env = {str(k): str(v) for k, v in six.iteritems(additional_env)} if additional_env else {}
            os.environ.update(processed_env)
            r = None
            if preexec_fn:
                r = preexec_fn(*args, **kwargs)

            pid = os.fork()
            if pid == 0:
                os.closerange(3, os.sysconf('SC_OPEN_MAX'))
                import prctl, signal
                prctl.set_pdeathsig(signal.SIGKILL)
                self.krb5_sentry(password)

            return r

        return subprocess_module.Popen(args, bufsize=bufsize, executable=executable, stdin=stdin, stdout=stdout,
                                       stderr=stderr, preexec_fn=_custom_preexec, close_fds=close_fds,
                                       shell=shell, cwd=cwd, universal_newlines=universal_newlines,
                                       startupinfo=startupinfo, creationflags=creationflags)

    def krb5_sentry(self, password):
        import datetime
        import time

        logging.getLogger('').handlers = []
        logging.basicConfig(stream=sys.stderr, level=logging.INFO)

        while True:
            try:
                next_time = self.refresh_and_get_next(password)
                ts = next_time - datetime.datetime.now()
                time.sleep(ts.total_seconds() + .1)
            except:
                import traceback
                logger.error(traceback.format_exc())
                return

    def refresh_and_get_next(self, password):
        import fcntl
        import time
        from tech.apps.krb5_sentry import util as krb5_util

        refresh_script = krb5_util.resolve_refresh_script()
        with open('/tmp/krb5sentry_%d' % os.getuid(), "w+") as f:
            fcntl.lockf(f.fileno(), fcntl.LOCK_EX)

            p = subprocess.Popen('source %s' % refresh_script, shell=True,
                                 stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if password:
                time.sleep(3)
                stdout, stderr = p.communicate(password)
            else:
                stdout, stderr = p.communicate()

            if p.returncode != 0:
                logger.error('Failed to obtain initial ticket: \n%s\n=============\n%s', stdout, stderr)

            next_time = krb5_util.get_ticket_exp_time(None)
        return next_time


__IMPERSONATORS = {
    'windows': WindowsImpersonator,
    'linux': LinuxImpersonator
}


def get_impersonator():
    """
    Gets impersonator class
    
    :return: Impersonator class
    :rtype: Impersonator
    """
    return __IMPERSONATORS[get_impersonator_class()]()


@memoize
def get_impersonator_class():
    _is_windows = sys.platform.startswith('win')

    if _is_windows:
        return 'windows'
    return 'linux'
