class EventHandler(object):
    def __init__(self, name='event'):
        self.__handler_list = set()
        self.__name = name

    @property
    def name(self):
        return self.__name

    @property
    def handler_list(self):
        return list(self.__handler_list)

    def __iadd__(self, other):
        if other is None:
            raise Exception('Cannot add None to EventHandler')
        if not callable(other):
            raise Exception('Can only add callables to EventHandler')
        self.__handler_list.add(other)
        return self

    def __isub__(self, other):
        self.__handler_list.remove(other)
        return self

    def __call__(self, *args, **kwargs):
        for e in self.__handler_list:
            e(*args, **kwargs)

    def __str__(self):
        return "Event[%s]" % self.name

    def __repr__(self):
        return self.__str__()