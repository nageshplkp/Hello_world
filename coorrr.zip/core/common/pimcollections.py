def first(iterable, default=None):
    for y in iterable:
        return y
    return default