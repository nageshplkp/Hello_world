import os, time, logging
from common import mailer
from config import config


class Notifier(object):
    '''
    Gradual notification, if same subject is repeated, slow down the notification pace
    *** notice the sleep here so thing will sleep for a bit

    after first 10, runs notifies every 1 hour with sleeping for 1 minute on the process..
    '''
    def __init__(self):
         self.counter = {}

    def get_counter(self, subject):
        if  subject not in self.counter:
            self.counter[subject] = 0

        return self.counter.get(subject) + 1

    def reset_counter(self, subject):
        self.counter[subject] = 0

    def set_counter(self, subject, count):
        self.counter[subject] = count

    def notify(self, subject, msg):
        counter = self.get_counter(subject)
        env = config.get('appenv')
        logging.info('%s notifying an issue: %s' % (env.upper(), msg))
        msgToSend = '%s %s' % (env.upper(), msg)

        if counter <= 10:
            mailer.send_mail(msgToSend, msgToSend)
        else:
            time.sleep(60)
            if counter > 60:
                mailer.send_mail(msgToSend, msgToSend)
                self.set_counter(subject, 11)
