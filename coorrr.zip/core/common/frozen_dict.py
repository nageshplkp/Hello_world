import collections
import six


class FrozenDict(collections.Mapping):
    """
    Provides hashable readonly dict
    """

    def __init__(self, source_dict):
        """
        Constructs hashable, readonly dict.
        
        :param source_dict: Source dictionary 
        """

        source_dict = six.iteritems(source_dict) if isinstance(source_dict, collections.Mapping) else source_dict
        self.__dict = dict((x, FrozenDict.make_hashable(y)) for x, y in source_dict)

        self.__hash = hash(tuple(six.iteritems(self.__dict)))

    @staticmethod
    def make_hashable(x):
        """
        Returns a hashable version of the parameter
        
        :param x: Object to make hashable 
        """
        if isinstance(x, collections.Mapping):
            return FrozenDict((z, FrozenDict.make_hashable(y)) for z, y in six.iteritems(x))
        if isinstance(x, collections.Set):
            return frozenset(x)
        if isinstance(x, collections.Iterable) and not isinstance(x, six.string_types):
            return tuple(FrozenDict.make_hashable(z) for z in x)
        if isinstance(x, collections.Hashable):
            return x
        raise Exception('Can not make %s hashable')

    def __iter__(self):
        return self.__dict.__iter__()

    def __len__(self):
        return self.__dict.__len__()

    def __getitem__(self, item):
        return self.__dict.__getitem__(item)

    def __hash__(self):
        return self.__hash

    def __getstate__(self):
        return self.__dict

    def __setstate__(self, state):
        self.__init__(state)