import os
import logging
import time
import functools
from core.common import util
from core.common import mail

from core.common.frozen_dict import FrozenDict

def profile(f):
    """
    decorator to profile function calls
    """
    def wrapper(*args, **kwargs):
        import __main__
        moduleName = os.path.realpath(__main__.__file__).split(os.sep)[-1].replace('.py', '')
        desc = '%s.%s()' % (moduleName, f.__name__)
        logging.info('>> start %s' % desc)

        start = time.time()
        result = f(*args, **kwargs)
        end = time.time()

        size = ''
        if isinstance(result, (list, dict, tuple, set)):
            size = 'count=%s ' % len(result)

        time_elapsed = '%f (mins)' % (float(end-start)/60.0) if float(end-start) > 60 else '%f (secs)' % (end-start)
        logging.info('>> end %s time=%s  %s' % (desc, time_elapsed, size))

        return result

    return wrapper

class Timer:
    def __enter__(self):
        self.start = time.time()
        return self

    def __exit__(self, *args):
        self.end = time.time()
        self.seconds = self.end - self.start
        self.milliseconds= self.seconds * 1000.0
        self.interval = self.seconds
        self.minutes = self.seconds /60.0

class ExceptionHandler(object):
    '''
    helper decorator to email exception,  can log, email than swallow if needed.
    Use it at top of t
    '''
    def __init__(self, mailTo=None, context='Unknown', swallow=False, email=False):
        self.context = context  # need a context around the exception
        self.emailCount = 0
        self.email = email
        self.swallow = swallow  # swallow the exception or raise it
        self.mailTo = mailTo
        self.env = os.environ.get('appenv') or ' missing '

    def __call__(self, f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            try:
                return f(*args, **kwargs)
            except Exception as ex:
                msg = 'Error calling %s() ' % (f.__name__)
                err = '%s %s' %(msg, util.exceptionAsStr(ex))
                self.log(err)
                if not self.swallow: # may want to re-raise to stop the program.
                    raise

        return wrapper

    def log(self, msg, ex=None):
        err = msg
        if ex:
            err ='%s %S' %(msg, util.exceptionAsStr(ex))

        logging.error(err)

        if self.email:
            self.send_mail(err)

    def send_mail(self, msg):
        if self.emailCount < 5:
            if not self.mailTo:
                from ..config import config_api
                self.mailTo = config_api.get('email.to')

            if not self.mailTo:
                logging.error('ExceptionHandler missing mail to, not sending out email')
            else:
                mail.send_mail(self.mailTo, self.mailTo, subj='(%s)%s error' % (self.env, self.context), msg=msg)

            self.emailCount += 1  # ensure we dont over flood the mail, wont send after 5 emails per process


class Deprecated(object):
    import logging
    def __init__(self, msg):
        self.msg = msg

    def __call__(self, f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            logging.warn(self.msg)
            return f(*args, **kwargs)

        return wrapper

def memoize(f):
    """
    Decorator that caches return values from the decorated functions based on it's parameters.
    
    :param f: Function to decorate
    """
    cache = f.__memo_cache__ = {}

    @functools.wraps(f)
    def memoizer(*args, **kwargs):
        key = FrozenDict.make_hashable((args,kwargs))
        if key not in f.__memo_cache__:
            cache[key] = f(*args, **kwargs)
        return cache[key]

    return memoizer
