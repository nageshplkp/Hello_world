import core
import pandas as pd
import csv

def read_fixed_width(path, num_rows=1000):
    df = pd.read_fwf(path, header=0, nrows=5)
    cols = ['col%s' % i for i in range(len(df.columns))]
    return pd.read_fwf(path, names=cols, nrows=num_rows, quoting=csv.QUOTE_ALL, encoding='utf-8', dialect=csv.Dialect)


