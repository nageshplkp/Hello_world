import six
import abc


class Future(six.with_metaclass(abc.ABCMeta)):
    def __init__(self):
        pass

    @abc.abstractproperty
    def result(self):
        pass
