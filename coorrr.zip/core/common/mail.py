import getpass
import os
import six
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from optparse import OptionParser
from core.common import util


def send_exception(mailFrom, mailTo, subj, ex):
    msg = util.exceptionAsStr(ex)
    send_mail(mailFrom, mailTo, subj, msg)


def resolve_email_address(addresses):
    from core.common import pimldap
    if addresses:
        emails = []
        addresses = addresses.split(',')
        addresses = map(lambda x: x.strip(), addresses)
        for addr in addresses:
            if '@' not in addr:
                entry = pimldap.get_user_entry(addr)
                entry = entry and entry[0] or {}
                email = entry.get('mail')
                if email:
                    emails.append(email)
                    continue
            emails.append(addr)
        return ', '.join(emails)
    return addresses


def send_mail(mailFrom, mailTo, subj, msg, mailCc=None, attachments=[], img_attachments={}, as_html = False):
    """
    Sends out an email.

    :param mailFrom: a single email address as a string
    :param mailTo: single email address as a string or a list of email addresses
    :param subj:
    :param msg:
    :param mailCc: single email address as a string or a list of email addresses
    :param attachments: list of file paths
    :param img_attachments: Use this if you want to embed an image using CID. A dictionary of id and file paths
                            Example {"myimagecid": "/my/image/file.png"} and in your email contents you can use it as
                            <img src="cid:myimagecid"/>
    :param as_html: True if your content is HTML
    """
    if not mailTo:
        print("missing email addess to send")
        return
    
    msgPart = MIMEMultipart()
    
    msgPart['Subject'] = subj
    msgPart['From'] = resolve_email_address(mailFrom)
    
    
    if ( isinstance(mailTo,list) or isinstance(mailTo,set) ) and len(mailTo) == 1:
        #if there is only one param , then check if user has provided as , seperated list
        mailTo = mailTo[0].split(",")
    
    if isinstance(mailTo,list) or isinstance(mailTo,set):
        mailTo = ", ".join(mailTo)

    mailTo = resolve_email_address(mailTo)
    msgPart['To'] = mailTo
    
    if ( isinstance(mailCc,list) or isinstance(mailCc,set) ) and len(mailCc) == 1:
        mailCc = mailCc[0].split(",")
    
    if isinstance(mailCc,list) or isinstance(mailCc,set):
        mailCc = ", ".join(mailCc)

    mailCc = resolve_email_address(mailCc)
    msgPart['Cc'] = mailCc
    if as_html:
        msgPart.attach(MIMEText(msg,'html'))
    else:
        msgPart.attach(MIMEText(msg))
    for path in attachments:
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(path,"rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="{0}"'.format(os.path.basename(path)))
        msgPart.attach(part)

    for cid, path in six.iteritems(img_attachments):
        with open(path, 'rb') as fp:
            msg_image = MIMEImage(fp.read())
            msg_image.add_header('Content-ID', '<' + cid + '>')
            msg_image.add_header('Content-Disposition', 'inline')
            msgPart.attach(msg_image)

    smtp = smtplib.SMTP('mail' if util.isWindows() else 'mailhost.pimco.com')
    mailTo = mailTo.split(",") + (mailCc and mailCc.split(',') or [])
    smtp.sendmail(mailFrom, mailTo, msgPart.as_string())
    smtp.quit()

if __name__ == '__main__':
    parser = OptionParser()
    parser.add_option("-a", "--attachments", dest="attachments",action="append",
                  help="Files to be attached", metavar="FILE" , default = [])
    parser.add_option("-f", "--mailfrom",
                  dest="mailfrom", default = getpass.getuser() + "@pimco.com", 
                  help="From email id")
    parser.add_option("-t", "--mailto",
                  dest="mailto",  action="append",
                  help="List of email ids to send to")
    parser.add_option("-c", "--mailccto",
                  dest="mailccto",  action="append",
                  help="List of email ids to cc to")
    
    parser.add_option("-s", "--subject",
                  dest="subject",
                  help="Subject of the email")
    
    parser.add_option("-m", "--message",
                  dest="message",
                  help="Email message Content")
    (options, args) = parser.parse_args()
    
    send_mail(options.mailfrom,options.mailto,options.subject,options.message,options.mailccto,options.attachments)
    
    