import _abcoll
from cStringIO import StringIO


class ObjectDict(dict):
    __slots__ = []

    def clear(self):  # real signature unknown; restored from __doc__
        raise NotImplementedError()

    def copy(self):  # real signature unknown; restored from __doc__
        """ D.copy() -> a shallow copy of D """
        inst = object.__new__(type(self))
        for k, v in self.iteritems():
            setattr(inst, k, v)

    @staticmethod  # known case
    def fromkeys(S, v=None):  # real signature unknown; restored from __doc__
        raise NotImplementedError()

    def get(self, k, d=None):
        return getattr(self, k) if hasattr(self, k) else d

    def has_key(self, k):
        return hasattr(self, k)

    def items(self):  # real signature unknown; restored from __doc__
        """ D.items() -> list of D's (key, value) pairs, as 2-tuples """
        return list(self.iteritems())

    def iteritems(self):
        for slot in self.iterkeys():
            yield slot, self.get(slot)

    def iterkeys(self):
        for clazz in type(self).__mro__:
            if not hasattr(clazz, '__slots__'):
                continue
            for slot in clazz.__slots__:
                yield slot

    def itervalues(self):
        for slot in self.iterkeys():
            yield self.get(slot)

    def keys(self):
        return list(self.iterkeys())

    def pop(self, k, d=None):
        return self.get(k, d)

    def popitem(self):
        raise NotImplementedError()

    def setdefault(self, k, d=None):
        raise NotImplementedError()

    def update(self, E=None, **F):  # known special case of dict.update
        """
        D.update([E, ]**F) -> None.  Update D from dict/iterable E and F.
        If E present and has a .keys() method, does:     for k in E: D[k] = E[k]
        If E present and lacks .keys() method, does:     for (k, v) in E: D[k] = v
        In either case, this is followed by: for k in F: D[k] = F[k]
        """
        if E:
            try:
                for k in E.keys():
                    setattr(self, k, E[k])
            except:
                for k, v in E:
                    setattr(self, k, v)

        if F:
            for k, v in f.iteritems():
                setattr(self, k, v)

    def values(self):
        """ D.values() -> list of D's values """
        return list(self.itervalues())

    def viewitems(self):
        return _abcoll.ItemsView(self)

    def viewkeys(self):
        """ D.viewkeys() -> a set-like object providing a view on D's keys """
        return _abcoll.KeysView(self)

    def viewvalues(self):
        """ D.viewvalues() -> an object providing a view on D's values """
        return _abcoll.ValuesView(self)

    def __cmp__(self, y):
        """ x.__cmp__(y) <==> cmp(x,y) """
        if y is None:
            return 1

        if not isinstance(y, dict):
            return 1

        if len(self) != len(y):
            return cmp(len(self), len(y))

        my_keys = sorted(self.keys())
        their_keys = sorted(y.keys())

        zipped = zip(my_keys, their_keys)

        for my, their in zipped:
            c = cmp(my, their)
            if c != 0:
                return c
            c = cmp(self[my], y[their])
            if c != 0:
                return c

        if len(self) > len(zipped):
            return 1

        if len(y) > len(zipped):
            return -1

        return 0

    def __contains__(self, k):
        return hasattr(self, k)

    def __delitem__(self, y):
        raise NotImplementedError()

    def __eq__(self, y):
        return cmp(self, y) == 0

    def __getitem__(self, y):
        """ x.__getitem__(y) <==> x[y] """
        return getattr(self, y)

    def __ge__(self, y):
        """ x.__ge__(y) <==> x>=y """
        return cmp(self, y) >= 0

    def __gt__(self, y):
        """ x.__gt__(y) <==> x>y """
        return cmp(self, y) > 0

    def __init__(self, seq=None, **kwargs):
        self.update(seq, **kwargs)

    def __iter__(self):
        return self.iterkeys()

    def __len__(self):
        i = 0
        for k in self.keys():
            i += 1
        return i

    def __le__(self, y):
        return not self.__gt__(y)

    def __lt__(self, y):
        return not self.__ge__(y)

    def __ne__(self, y):
        """ x.__ne__(y) <==> x!=y """
        return not self.__eq__(y)

    def __repr__(self):
        sio = StringIO()

        sio.write(type(self).__name__)
        sio.write('({')
        for k, v in self.iteritems():
            sio.write(repr(k))
            sio.write(': ')
            sio.write(repr(v))
            sio.write(', ')

        sio.write('})')
        val = sio.getvalue()
        sio.close()
        return val

    def __str__(self):
        sio = StringIO()

        sio.write(type(self).__name__)
        sio.write('({')
        for k, v in self.iteritems():
            sio.write(str(k))
            sio.write(': ')
            sio.write(str(v))
            sio.write(', ')

        sio.write('})')
        val = sio.getvalue()
        sio.close()
        return val

    def __setitem__(self, i, y):
        """ x.__setitem__(i, y) <==> x[i]=y """
        setattr(self, i, y)
