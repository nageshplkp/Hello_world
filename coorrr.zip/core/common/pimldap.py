from core.common.util import first, username, isWindows
from core.common.com import ComThreadSafe
import srvlookup

PIMCO_DOMAIN = 'pimco.imswest.sscims.com'
PIMCO_CLOUD_DOMAIN = 'core.pimcocloud.net'

__LDAP_FIELDS = ['cn', 'co', 'company', 'department', 'displayName', 'employeeID', 'givenName', 'mail',
                         'manager', 'name', 'sAMAccountName', 'sn', 'telephoneNumber', 'ADsPath']

__LDAP_FIELDS_STR = ','.join(__LDAP_FIELDS)

def get_ldap_servers(domain=PIMCO_DOMAIN):
    return [(x.host, x.port) for x in sorted(srvlookup.lookup('ldap', 'tcp', domain),
                                             cmp=lambda x, y: cmp((x.priority, y.weight), (y.priority, x.weight)))]


def get_default_ldap_server(domain=PIMCO_DOMAIN):
    return first(get_ldap_servers(domain=domain))


def lx_verify_credentials(username, password):
    try:
        import ldap
        ldap_server = get_default_ldap_server()
        ldap_server = 'LDAP://%s:%d' % ldap_server if isinstance(ldap_server, tuple) else ldap_server

        l = ldap.initialize(ldap_server, trace_level=0)
        l.protocol_version = 3
        l.set_option(ldap.OPT_REFERRALS, 0)

        l.simple_bind_s(username, password)
        l.unbind_s()

        return True
    except:
        import traceback
        print(traceback.format_exc())
        return False


def get_user(ldap_qualified_name, ldap_server=None):
    ldap_server = ldap_server or get_default_ldap_server()
    ldap_server = 'LDAP://%s:%d' % ldap_server if isinstance(ldap_server, tuple) else ldap_server

    if isWindows():
        from win32com.client import Dispatch

        with ComThreadSafe():
            conn = Dispatch("ADODB.Connection")
            conn.Open("Provider=ADsDSOObject")

            search_str = "SELECT %s FROM 'LDAP://%s' WHERE objectClass='user'" % (
                __LDAP_FIELDS_STR, ldap_qualified_name)

            cmd = Dispatch("ADODB.Command")
            cmd.ActiveConnection = conn
            cmd.CommandText = search_str
            cmd.Properties['searchscope'] = 0

            record_set = cmd.Execute(search_str)
            record_set = record_set[0]
            member_list = []

            # Process if accounts are found.
            if record_set.RecordCount > 0:
                record_set.MoveFirst()
                while not record_set.EOF:
                    rec = dict()
                    for f in record_set.Fields:
                        rec[f.Name] = f.Value
                    member_list.append(rec)
                    record_set.MoveNext()

            # Return the list of results
            rs = member_list
    else:
        import ldap
        l = ldap.initialize(ldap_server, trace_level=0)
        l.protocol_version = 3
        l.set_option(ldap.OPT_REFERRALS, 0)

        at = ldap.sasl.gssapi()
        l.sasl_interactive_bind_s("", at)

        scope = ldap.SCOPE_SUBTREE
        search_filter = "(objectClass=user)"

        r_id = l.search(ldap_qualified_name, scope, search_filter,
                        __LDAP_FIELDS)
        rs = []
        while True:
            rt, rd = l.result(r_id, 0)
            if not rd:
                break
            if rt == ldap.RES_SEARCH_ENTRY:
                rs.append(__transform_lx_ldap_dict(rd[0][1]))

    return rs


def __transform_lx_ldap_dict(dct):
    return dict(
        (x, (first(y) if y else None)) for x,y in dct.iteritems()
    )

def get_user_entry(username_=None, ldap_server=None, base_dn='DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=com'):
    username_ = username_ or username()
    ldap_server = ldap_server or get_default_ldap_server()
    ldap_server = 'LDAP://%s:%d' % ldap_server if isinstance(ldap_server, tuple) else ldap_server

    if isWindows():
        from win32com.client import Dispatch

        with ComThreadSafe():
            conn = Dispatch("ADODB.Connection")
            conn.Open("Provider=ADsDSOObject")

            search_str = "SELECT %s FROM 'LDAP://%s' WHERE objectClass='user' and sAMAccountName='%s'" % (
            __LDAP_FIELDS_STR, base_dn, username_)

            cmd = Dispatch("ADODB.Command")
            cmd.ActiveConnection = conn
            cmd.CommandText = search_str
            cmd.Properties['searchscope'] = 2

            record_set = cmd.Execute(search_str)
            record_set = record_set[0]
            member_list = []

            # Process if accounts are found.
            if record_set.RecordCount > 0:
                record_set.MoveFirst()
                while not record_set.EOF:
                    rec = dict()
                    for f in record_set.Fields:
                        rec[f.Name] = f.Value
                    member_list.append(rec)
                    record_set.MoveNext()

            # Return the list of results
            rs = member_list
    else:
        import ldap
        l = ldap.initialize(ldap_server, trace_level=0)
        l.protocol_version = 3
        l.set_option(ldap.OPT_REFERRALS, 0)

        at = ldap.sasl.gssapi()
        l.sasl_interactive_bind_s("", at)

        scope = ldap.SCOPE_SUBTREE
        search_filter = "(&(objectClass=user)(sAMAccountName=%s))" % username_

        r_id = l.search(base_dn, scope, search_filter,
                        __LDAP_FIELDS)
        rs = []
        while True:
            rt, rd = l.result(r_id, 0)
            if not rd:
                break
            if rt == ldap.RES_SEARCH_ENTRY:
                rs.append(__transform_lx_ldap_dict(rd[0][1]))

    return rs


if __name__ == "__main__":
    user =  get_user_entry()[0]
    manager = get_user(user['manager'])

    print(user)
    if manager:
        print(manager[0])
