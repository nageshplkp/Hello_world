import json

from avrogen.dict_wrapper import DictWrapper


class DictWrapperJsonEncoder(json.JSONEncoder):
    """
    Encoder for the DictWrapper class.
    """

    def default(self, o):
        if isinstance(o, DictWrapper):
            return getattr(o, '_inner_dict')
        super(DictWrapperJsonEncoder, self).default(o)

    def iterencode(self, o, _one_shot=False):
        """
        Taken from the super class and substituted the _make_iterencode call
        """
        if self.check_circular:
            markers = {}
        else:
            markers = None
        if self.ensure_ascii:
            _encoder = json.encoder.encode_basestring_ascii
        else:
            _encoder = json.encoder.encode_basestring
        if self.encoding != 'utf-8':
            def _encoder(o, _orig_encoder=_encoder, _encoding=self.encoding):
                if isinstance(o, str):
                    o = o.decode(_encoding)
                return _orig_encoder(o)

        def floatstr(o, allow_nan=self.allow_nan,
                     _repr=json.encoder.FLOAT_REPR, _inf=json.encoder.INFINITY, _neginf=-json.encoder.INFINITY):
            # Check for specials.  Note that this type of test is processor
            # and/or platform-specific, so do tests which don't depend on the
            # internals.

            if o != o:
                text = 'NaN'
            elif o == _inf:
                text = 'Infinity'
            elif o == _neginf:
                text = '-Infinity'
            else:
                return _repr(o)

            if not allow_nan:
                raise ValueError(
                    "Out of range float values are not JSON compliant: " +
                    repr(o))

            return text

        _iterencode = json.encoder._make_iterencode(
            markers, self.default, _encoder, self.indent, floatstr,
            self.key_separator, self.item_separator, self.sort_keys,
            self.skipkeys, _one_shot, isinstance=isinstance_override)
        return _iterencode(o, 0)


def isinstance_override(p_object, class_or_type_or_tuple):
    # Tell the encoder that DictWrapper needs to be treated differently and not like dict
    # Even though it is an instance of dict, tell the encoder that its not
    # So, the encoder will invoke the "default" method.
    if class_or_type_or_tuple == dict:
        if isinstance(p_object, DictWrapper):
            return False
    return isinstance(p_object, class_or_type_or_tuple)
