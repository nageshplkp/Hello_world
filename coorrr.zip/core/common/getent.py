import subprocess
import six


def passwd(user_id=None, subprocess_module=None):
    subprocess_module = subprocess_module or subprocess
    if isinstance(user_id, six.string_types):
        user_name = user_id
        user_id = None
    else:
        user_name = None

    output = subprocess_module.check_output(['getent', 'passwd'])
    r = {}
    for x in output.split('\n'):
        x = x.strip()
        try:
            parsed_name, _, uid, gid, __, home, shell = x.split(':')
            if (user_name is None and user_id is None) or (user_name and user_name == parsed_name) or (user_id and user_id == int(uid)):
                r[parsed_name] = dict(username=parsed_name, uid=int(uid), gid=int(gid), home=home, shell=shell)
        except:
            pass
    return r


def group(group_id=None, subprocess_module=None):
    subprocess_module = subprocess_module or subprocess
    if isinstance(group_id, six.string_types):
        group_id = None
        group_name = group_id
    else:
        group_name = None

    output = subprocess_module.check_output(['getent', 'group'])
    r = {}
    for x in output.split('\n'):
        x = x.strip()
        try:
            parsed_name, _, gid, __ = x.split(':')
            gid = int(gid)
            if (group_id is None or gid == group_id) and (group_name is None or group_name == parsed_name):
                r[gid] = dict(gid=gid, name=parsed_name)
        except:
            pass
    return r
