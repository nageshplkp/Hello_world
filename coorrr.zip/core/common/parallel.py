SPARK_MAP_DEFAULT_SLICES = 0
SPARK_MAP_MAX_PARALLELIZM_SLICES = -1

import collections


def spark_map(mapper, collection, num_slices=SPARK_MAP_MAX_PARALLELIZM_SLICES):
    if not collection:
        return []

    if not isinstance(collection, collections.Sequence):
        raise Exception('Collection must be a sequence')

    if collection.__len__() == 0:
        return []

    try:
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
        sc = spark.sparkContext
    except:
        import logging
        logging.warn("Could not obtain Spark context. Reverting to regular map")
        return map(mapper, collection)

    if num_slices != 0:
        rdd = sc.parallelize(collection,
                             sc.defaultParallelism if num_slices == SPARK_MAP_MAX_PARALLELIZM_SLICES else num_slices)
    else:
        rdd = sc.parallelize(collection)

    return rdd.map(mapper).collect()
