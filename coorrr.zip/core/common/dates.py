import datetime
from dateutil.relativedelta import relativedelta
import dateutil
from datetime import timedelta
import six
import pytz

__tz_name = None
__local_tz = None

def get_local_tz_name():
    global __tz_name
    if not __tz_name:
        with open('/etc/sysconfig/clock', "r") as f:
            s = f.readline()
            while s:
                if s.startswith('ZONE="'):
                    s = s.strip()
                    __tz_name = s[len('ZONE="'):-1]
                    break
    return __tz_name

def set_local_tz(dt):
    local_tz = pytz.timezone(get_local_tz_name())
    return local_tz.localize(dt).replace(tzinfo=local_tz)

def as_local_tz(dt):
    """
    :param dt:  UTC DateTime
    :return:  Local DatTime with TZ set
    """
    global __local_tz
    if not __local_tz:
        __local_tz = pytz.timezone(get_local_tz_name())
    return dt.replace(tzinfo=pytz.utc).astimezone(__local_tz)

def as_utc(dt):
    return dt.astimezone(pytz.utc)

def parseDateTime(v, fmt='%Y/%m/%d %H:%M:%S'):
    if not v:
        return None

    if isinstance(v, six.string_types):
        try:
            return datetime.datetime.strptime(v, fmt)
        except Exception as ex:
            print('dates.parseDateTime() exception: %s %s ' % (v, ex))
            return None

    return v

def parseDate(v, fmt='%Y-%m-%d'):
    if not v:
        return None

    if isinstance(v, six.string_types):
        try:
            return datetime.datetime.strptime(v, fmt)
        except Exception as ex:
            print( 'dates.parseDate() exception: %s %s ' % (v, ex))
            return None

    return v

def as_str(v, fmt='%Y-%m-%dT%H:%M:%S'):
    return v.strftime(fmt)

def as_date_str(v, fmt='%Y-%m-%d'):
    return v.strftime(fmt)

def reset(v):
    return v.replace(minute=0, hour=0, second=0, microsecond=0)

def today():
    return reset(datetime.datetime.now())

def todayWithTime(hour=0, minute=0, second=0, microsecond=0, timezone=None):
    if timezone:
        return datetime.datetime.now(timezone).replace(minute=minute, hour=hour, second=second, microsecond=microsecond)
    else:
        return datetime.datetime.now().replace(minute=minute, hour=hour, second=second, microsecond=microsecond)

def tommorrow():
    return reset(datetime.datetime.now()) + relativedelta(days=1)

def now(include_tz=False):
    if include_tz:
        d = datetime.datetime.now()
        return set_local_tz(d)

    return datetime.datetime.now()

def utcnow(include_tz=False):
    if include_tz:
        d = datetime.datetime.utcnow()
        return set_local_tz(d)

    return datetime.datetime.utcnow()

def parseIntToDate(s):
    if not s: return None

    if isinstance(s, datetime.datetime):
        return s

    try:
        return dateutil.parser.parse(str(int(float(str(s)))))
    except Exception as ex:
        print('error trying to parse int date %s ' % s)

    try:
        return dateutil.parser.parse(s)
    except Exception as ex:
        print('error trying to parse int date %s ' % s)
        return None

def dateMinusMonths(date, months, resetToFirst=True):
    newDate = date - relativedelta(months=months)

    if resetToFirst:
        return newDate.replace(day=1)

    return newDate

def prev_bus_day(date=None):
    if not date:
        date = today()

    off_set = (3, 1, 1, 1, 1, 1, 2)
    return date - timedelta(days=off_set[date.weekday()])

def dateMinusDays(date, days):
    return date - relativedelta(days=days)

def add_hours(date, num_of_hours):
    return date + timedelta(hours=num_of_hours)

def past_week_sunday(dt=datetime.datetime.now()):
    '''
    one week ago, sunday. useful for replaying back past week's data
    '''
    # days of week, mon = 0, sun = 6
    dt = dt - datetime.timedelta(days=5)

    while dt.weekday() != 6:
        dt = dt - datetime.timedelta(days=1)

    return datetime.datetime(dt.year, dt.month, dt.day)

def begin_year():
    return datetime.now().date().replace(month=1, day=1)

def begin_month():
    return datetime.date.today().replace(day=1)

def date_range(from_dt, to_dt, exclude_weekend=True):
    from datetime import timedelta
    dates =  [from_dt + timedelta(days=x) for x in range((to_dt-from_dt).days + 1)]

    if exclude_weekend:
        return sorted([d for d in dates if d.weekday() not in [5, 6]], reverse=True)
    return sorted([d for d in dates],  reverse=True)

DAYS=["Mon","Tues","Wed","Thu","Fri","Sat","Sun"]
def day_of_week(dt):
    return DAYS[dt.weekday()]

def is_weekend(dt):
    d = day_of_week(dt)
    return d in ["Sat", "Sun"]

def epoch_ms_to_datetime(ticks_ms, gmt=True):
    """
    :param ticks_ms:  milliseconds from unix epoch
    :param gmt:  default assuming ticks_ms is from gmt
    :return:
    """
    ms = ticks_ms / 1000.0
    if gmt:
        return datetime.datetime.utcfromtimestamp(ms)
    return datetime.datetime.fromtimestamp(ms)

def is_date(v):
    return isinstance(v, (datetime.date, datetime.datetime))