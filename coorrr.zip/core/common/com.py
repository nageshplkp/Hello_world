import os
import sys
import threading
import traceback
import logging

from core.common.util import isWindows

__IS_PYTHON_COM_LOADED = False

# Anaconda and possibly other distributions have a bug in PyWin32, the `pythoncom` module
# can't be loaded because some required DLLs are located in the wrong place, so they
# aren't found. This code forces Windows to load them with the full path so that
# subsequent imports work correctly

if isWindows() and not __IS_PYTHON_COM_LOADED:
    try:
        import _win32sysloader
        pywintypes_filename = "pywintypes%d%d.dll" % (sys.version_info[0], sys.version_info[1])
        pywintypes_found = _win32sysloader.GetModuleFilename(pywintypes_filename)
        if not pywintypes_found:
            pywintypes_found = _win32sysloader.LoadModule(
                os.path.join(sys.prefix, 'lib', 'site-packages', 'win32', pywintypes_filename))
        import pythoncom
    except Exception as ex:
        logging.warn('Unable to load pythoncom: %s', ex.message)
        logging.warn(traceback.format_exc())
    __IS_PYTHON_COM_LOADED = True


class ComThreadSafe(object):

    def __enter__(self):
        if threading.currentThread().getName() != 'MainThread':
            pythoncom.CoInitialize()

    def __exit__(self, *args):
        if threading.currentThread().getName() != 'MainThread':
            pythoncom.CoUninitialize()
