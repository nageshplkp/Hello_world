from core.opensource.pythonjsonlogger.jsonlogger import JsonFormatter, RESERVED_ATTRS
from logging.handlers import DatagramHandler
import logging


class UdpHandler(DatagramHandler):
    def __init__(self, server, port, *args, **kwargs):
        super(UdpHandler, self).__init__(server, port)
        self.formatter = JsonFormatter(*args, **kwargs)
        self.formatter._required_fields += RESERVED_ATTRS

    def makePickle(self, record):
        record_formatted = self.formatter.format(record)
        return record_formatted.encode('utf-8')

    @staticmethod
    def install_as_root(server, port, remove_others=False, *args, **kwargs):
        handler = UdpHandler(server, port, *args, **kwargs)
        root_logger = logging.getLogger('')

        if remove_others:
            root_logger.handlers = []

        root_logger.addHandler(handler)
        return handler
