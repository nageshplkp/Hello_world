"""
The objective of this module is to simplify the interface to generate charts using matplotlib
which can be easily included in an email or converted to HTML
"""

import base64
import copy
import io
import json
import smtplib
import urllib
import uuid
from xml.sax.saxutils import escape

import matplotlib.pyplot as plt
from matplotlib.figure import Figure

from core.chart.line import line_chart_style, plot_line
from core.chart.styles import make_palette_from_win
from core.common.util import dict_merge
from core.reporting.common.elems import AdaptablePimReportElem
from core.reporting.simple_email import RawHTML, ReportMessageElement
from core.reporting.common.xl_abstract import XlExportable


class EasyLine(AdaptablePimReportElem, XlExportable):
    """
    Accepts a dataframe and generates a matplotlib Figure.
    Easy functions to save as file, convert to HTML, embed in email
    Internally makes use of the existing codebase to generate the chart. The objective is to simplify that interface.
    """

    DEF_PALETTE = make_palette_from_win((117, 234, 0),    (0, 0, 255),        (255, 0, 0),
                                        (184, 204, 228),  (166, 166, 166),    (255, 204, 102))

    DEF_CHART_STYLE = line_chart_style(show_x_label=False, xgrid=False, ygrid=True,
                                       line_width=1.0, px_width=450, px_height=300, legend_font_size=8.0,
                                       tick_font_size=8.0, despine=True,
                                       dpi=100, palette=DEF_PALETTE)

    def __init__(self, df, default_style=None):
        self.df = df
        self.cstyle = copy.deepcopy(default_style or self.DEF_CHART_STYLE)

    def x(self, col):
        """Set this column as the x-axis """
        dict_merge(self.cstyle, {'x_axis': col})
        return self

    def line(self, width=None, stylesbycol={}):
        """
        Set line properties

        :param width: set the line width
        :param stylesbycol: dictionary of col names and style ['-' | '--' | '-.' | ':']
        """
        if width is not None:
            dict_merge(self.cstyle, {'line_width': width})
        if stylesbycol:
            dict_merge(self.cstyle, {'line_styles_dict': stylesbycol})
        return self

    def line_effects(self, effects, cols = []):
        """
        set line effects

        :param effects: list of path effects from matplotlib.patheffects or core.chart.chart_effects
        :param cols: list of columns for which this effect should be applied to
        """
        if effects:
            x_col = self.cstyle.get('x_axis')
            cols = cols or [c for c in self.df.columns]
            cols = [c for c in cols if c != x_col]
            d = {}
            for col in cols:
                d[col] = effects
            dict_merge(self.cstyle, {'line_effects_dict': d})
        return self

    def title(self, text=None, color=None, size=None, weight=None):
        if text:
            dict_merge(self.cstyle, {'title': text})
        if color:
            dict_merge(self.cstyle, {'title_color': color})
        if size:
            dict_merge(self.cstyle, {'title_font_size': size})
        if weight:
            dict_merge(self.cstyle, {'title_font_weight': weight})
        return self

    def showlabelx(self, show=True):
        dict_merge(self.cstyle, {'show_x_label': show})
        return self

    def _set_x_or_y(self, formatstr, x_or_y, value):
        dict_merge(self.cstyle, {formatstr % x_or_y[0]: value})
        dict_merge(self.cstyle, {formatstr % x_or_y[-1]: value})
        return self

    def tick(self, x_or_y='x', length=None, rotation=None, fontsize=None, formatter=None):
        """
        Set properties of the ticks

        :param x_or_y: x, y or xy
        :param length: length of the tick
        :param rotation: angle of the tick label - 'horizontal', 30, 90 etc
        :param formatter: can be a string or can be an instance of matplotlib.ticker.Formatter such as DateFormatter
        """
        if rotation is not None:
            self._set_x_or_y('%s_tick_rotation', x_or_y, rotation)
        if length is not None:
            self._set_x_or_y('%s_tick_length', x_or_y, length)
        if fontsize is not None:
            dict_merge(self.cstyle, {'tick_font_size': fontsize})
        if formatter is not None:
            self._set_x_or_y('%s_tick_format', x_or_y, formatter)
        return self

    def limit(self, x_or_y='x', limit=None):
        return self._set_x_or_y('%s_lim', x_or_y, limit)

    def gridline(self, x_or_y='x', show=True):
        """
        Show grid lines on x axis or y axis or both

        :param x_or_y: x, y or xy
        :param show: True or False
        """
        return self._set_x_or_y('%sgrid', x_or_y, show)

    def step(self, x_or_y='x', value=None):
        """
        Distance between ticks

        :param x_or_y: x, y or xy
        :param value: The step size
        """
        return self._set_x_or_y('%sstep', x_or_y, value)

    def despine(self, top=False, right=False, bottom=True, left=True):
        """Hides the top and right spines. Spines are the axis lines"""
        dict_merge(self.cstyle, {'despine': {'top': top, 'right': right, 'bottom': bottom, 'left': left}})
        return self

    def spine_pos(self, type='l', position=None):
        """
        Position the spine

        :param type: l for left, t for top, r for right, b for bottom, can be combined as well
        :param position: matplotlib.spines.Spine.set_position - 'center', 'zero' etc
        """
        if 'l' in type:
            dict_merge(self.cstyle, {'y_spine_position': position})
        if 't' in type:
            dict_merge(self.cstyle, {'x_top_spine_position': position})
        if 'r' in type:
            dict_merge(self.cstyle, {'y_right_spine_position': position})
        if 'b' in type:
            dict_merge(self.cstyle, {'x_spine_position': position})
        return self

    def chartsize(self, width, height):
        dict_merge(self.cstyle, {'px_width': width})
        dict_merge(self.cstyle, {'px_height': height})
        return self

    def legend(self, anchor=None, loc=None, fontsize=None, ncols=None, exclude=set()):
        """
        Customize legends

        :param anchor: Specify any arbitrary location for the legend in tuple (x, y). Valid ->(0,0) to (1,1)
        :param loc: from matplotlib.pyplot.legend
        :param fontsize: font size
        :param ncols: The number of columns that the legend has. Default is 1.
        :param exclude: The columns to be excluded from the legend
        """
        if anchor is not None:
            dict_merge(self.cstyle, {'legend_anchor': anchor})
        if loc is not None:
            dict_merge(self.cstyle, {'legend_loc': loc})
        if fontsize is not None:
            dict_merge(self.cstyle, {'legend_font_size': fontsize})
        if ncols is not None:
            dict_merge(self.cstyle, {'legend_columns': ncols})
        if exclude:
            dict_merge(self.cstyle, {'exclude_from_legend': exclude})
        return self

    def dpi(self, value):
        dict_merge(self.cstyle, {'dpi': value})
        return self

    def fig(self, as_report_element=False, close=False):
        styles = line_chart_style(self.cstyle, as_email_report=as_report_element)
        fig = plot_line(self.df, **styles)
        if close and isinstance(fig, Figure):
            plt.close(fig)
        return fig

    def sendmail(self, from_addr, to_addrs, subject):
        from core.reporting.simple_email import create_report_message
        msg = create_report_message(self.as_report_element(mode='EMAIL'))
        msg['Subject'] = subject
        msg['From'] = from_addr
        msg['To'] = ','.join(to_addrs)
        smtp = smtplib.SMTP('mailhost.pimco.com')
        smtp.sendmail(from_addr, to_addrs, msg.as_string())

    def _repr_html_(self):
        return self.to_html()

    def _get_as_bytes_io(self):
        img_data = io.BytesIO()
        self.fig(close=True).savefig(img_data, format='png', bbox_inches='tight')
        img_data.seek(0)
        return img_data

    def to_html(self):
        """
        Returns an img tag with a base64 encoded image that can be used as a web page. Can't be used in
        emails as the email clients won't understand"""
        uri = 'data:image/png;base64,' + urllib.quote(base64.b64encode(self._get_as_bytes_io().read()))
        return '<img src = "%s"/>' % uri

    def as_report_element(self, mode='HTML', **kwargs):
        """ mode can be HTML, RML or EMAIL """
        if mode == 'EMAIL':
            return self.fig(True)
        elif mode == 'RML':
            from core.reporting.pdf.PimcoFlowables.image import PdfImage
            uid = str(uuid.uuid4())
            PdfImage.GLOBAL_FIG_INSTANCES[uid] = {'fig': self.fig()}  # bad design. need a better solution
            params = {'uid': uid}
            return ReportMessageElement('plugInFlowable', escape(json.dumps(params)),
                                        module="core.reporting.pdf.PimcoFlowables.image",
                                        function='get_pdf_image')
        else:
            return RawHTML(self.to_html())

    def to_ws(self, ws, **params):
        """
        Exports easyline to the given worksheet

        :param ws: instance of openpyxl workseet
        :param params: optional dictionary containing the following attributes
                        start_row: The row to start exporting?. defaults to 2
                        start_col: The column to start exporting. defaults to 2
        :return: worksheet
        """
        import openpyxl
        from openpyxl.utils import get_column_letter

        idx_row, idx_col = params.get('start_row', 2), params.get('start_col', 2)
        img = openpyxl.drawing.image.Image(self._get_as_bytes_io())
        ws.add_image(img, '%s%s' % (get_column_letter(idx_col), idx_row))
        return ws


def demo():
    from core.chart.easychart import EasyLine
    import numpy as np
    import pandas as pd
    x = np.linspace(-np.pi, np.pi, 256, endpoint=True)
    df = pd.DataFrame({'pi': x, 'cos': np.cos(x), 'sin': np.sin(x)})
    el = EasyLine(df).x('pi').showlabelx().title('Sin and Cos curves', 'red').gridline('xy').step('y', 0.25) \
    .chartsize(600,300).legend(anchor=(.1, .8)).line(stylesbycol={'cos': '--'})\
        .spine_pos('lb','zero')
    # el.sendmail('barath.balachandran@pimco.com', ['barath.balachandran@pimco.com'], 'easyline')
    # with open(r'c:\working\newtest.html', 'wb') as f:
    #     f.write('<html><body>%s</body></html>' % el.to_html())

    el2 = EasyLine(df).x('pi').showlabelx().title('Second Sin and Cos curves', 'red').gridline('xy').step('y', 0.25) \
        .chartsize(600,300).legend(anchor=(.1, .8)).line(stylesbycol={'cos': '--'}) \
        .spine_pos('lb','zero')

    from core.reporting.pimreport import PimReport
    pr = PimReport().inc(el).linebreak().inc(el2)
    pr.sendmail('barath.balachandran@pimco.com', ['barath.balachandran@pimco.com'], 'easyline')

if __name__ == '__main__':
    demo()