import numpy as np

def toNearestFraction(number, unit):
    decpart = np.mod(number, 1)
    decpart_units = decpart / unit
    int_part = np.int(number - decpart)
    int_units = np.int(decpart_units)
    return int_part + int_units * unit

def unitPriceLabelFormat(value, unit):
    """
    Generate a vlaue in unit format. 32nds 64ths etc.
    @param value:
    @param unit:
    @return:
    """
    decpart = np.mod(value, 1)
    decpart_units = decpart / unit
    decpart_units_remainder = np.mod(decpart_units, 1)
    if decpart_units_remainder == 0:
        decpart_units_sign = ''
    elif decpart_units_remainder < 0.5:
        decpart_units_sign = '-'
    else:
        decpart_units_sign = '+'

    int_part = np.int(value - decpart)
    int_units = np.int(decpart_units - decpart_units_remainder)
    in_unit_format = str(int_part) + ' ' + str(int_units) + decpart_units_sign
    return in_unit_format

def formatBondPrice32nds(tick_val, tick_pos):
    return unitPriceLabelFormat(tick_val, 1.0 / 32.0)

def buildPricePriceTicks(values, unit, major_line_cnt):
    """
    Build bond price tick labels.
    @param values:
    @param unit:
    @param major_line_cnt:
    @return:
    """
    y_max, y_min = values.max(), values.min()
    dy = y_max - y_min
    padding = max(unit, dy * 0.1)
    y_max = toNearestFraction(y_max + padding, unit)
    y_min = toNearestFraction(y_min - padding, unit)
    # Have at least major_line_cnt divisiion
    y_tick_step = max(unit, toNearestFraction((y_max - y_min) / major_line_cnt, unit))
    print "Tick step: " + str(y_tick_step)

    # Ensure a full setp is visible on top of the chart
    if (y_max - values.max()) < y_tick_step:
        y_max = y_max + y_tick_step
    if ( values.min() - y_min < y_tick_step):
        y_min = y_min - y_tick_step
    tick = y_min
    yticks = []
    while tick <= (y_max):
        yticks.append(tick)
        tick = tick + y_tick_step
    return yticks


def buildBondPrice32ndsTicks(values, major_line_cnt=8):
    return buildPricePriceTicks(values, 1.0 / 32.0, major_line_cnt)

