import collections

from .styles import get_table_style, get_core_style
from core.reporting.simple_email import ReportMessageElement, HTMLTable, HTMLTableHeader, _Div, RawHTML
from core.reporting.simple_email import HTMLTableRow, HTMLTableCell, Style
from .slider import slider_chart
from core.common import util

import numpy as np
import pandas as pd
import itertools
import datetime as pydt
import cStringIO as StringIO

__TABLE_CSS = get_table_style()
__CORE_CSS = get_core_style()

__DEFAULT_FORMATS = {
    int: "%i",
    float: "%.4f",
    pydt.date: "%Y-%m-%d",
    pydt.datetime: "%Y-%m-%d",
}


def __format_date(fmt, dt):
    return dt.strftime(fmt)


def __format_default(fmt, val):
    return fmt % val


__FORMAT_FUNC = {
    pydt.date: __format_date,
    pydt.datetime: __format_date,
}


def __get_value_type(val):
    t = type(val)

    if isinstance(val, np.floating):
        t = float

    if isinstance(val, np.integer):
        t = int

    if isinstance(val, np.bool_):
        t = bool

    return t


def is_nan_or_nat(v):
    try:
        if np.isnan(v):
            return True
    except:
        pass

    try:
        if np.isinf(v):
            return True
    except:
        pass

    if isinstance(v, pd.tslib.NaTType):
        return True
    return False


def format_value(val, col_formatter=None, row_tuple=None, index=None):
    if isinstance(val, ReportMessageElement):
        return val

    if isinstance(val, pd.tslib.Timestamp):
        val = val.to_datetime()

    if col_formatter is not None:
        if isinstance(col_formatter, basestring):
            if val is None:
                return RawHTML('&nbsp;')
            if is_nan_or_nat(val):
                return RawHTML('&nbsp;')
            else:
                t = __get_value_type(val)
                func = __FORMAT_FUNC.get(t, __format_default)
                return func(col_formatter, val)
        else:
            return col_formatter(val, row_tuple, index)
    else:
        if val is None:
            return RawHTML('&nbsp;')
        if is_nan_or_nat(val):
            return RawHTML('&nbsp;')

        t = __get_value_type(val)

        fmt = __DEFAULT_FORMATS.get(t)
        if fmt is not None:
            func = __FORMAT_FUNC.get(t, __format_default)
            return func(fmt, val)
        return str(val)


def __cell_class(i, l, el, table_class, addl_clas=None,r=None, t=None):
    if i == 0:
        ord = '-first'
    elif i == l - 1:
        ord = '-last'
    else:
        ord = ''

    if r is not None and t is not None:
        if r == 0:
            ord += '-row-first'
        elif r == len(t)-1:
            ord += '-row-last'

    addl_clas = ('-' + addl_clas) if addl_clas else ''
    return '%s-%s%s%s' % (table_class, el, ord, addl_clas)


def __row_class(i, l, use_alt, table_class, addl_class=None):
    if i == 0:
        ord = '-first'
    elif i == l - 1:
        ord = '-last'
    else:
        ord = ''

    if use_alt and i % 2 == 1:
        ord = '%s-alt' % ord

    addl_class = ('-' + addl_class) if addl_class else ''
    return '%s-tr%s%s' % (table_class, ord, addl_class)


def __get_column_style(col_name, col_index, row_index, col_value, styles_dict):
    all_style = styles_dict.get('all')
    style = styles_dict.get(col_name)

    while True:
        if callable(style):
            style = style(col_name, col_index, row_index, col_value)

        if style is None:
            if all_style is None:
                break
            style = all_style
            all_style = None
        else:
            break

    return style


def __get_row_style(row_index, row, style):
    if callable(style):
        return style(row_index, row)
    else:
        return style


def __get_cell_value(headers, row_index, row, col_index, col_name, value):
    if callable(value):
        return value(headers, row_index, row, col_index, col_name)
    return value


def in_cell_slider_chart(min_field, max_field, series_fields, series_markers, series_colors,
                         marker_edge_color='black', marker_size=None, background='white',
                         line_color='black', transparent=False, px_width=200, px_height=20, dpi=100):
    def chart(headers, row_index, row, col_index, col_name):
        assert isinstance(headers, (list, tuple))
        min_index = headers.index(min_field)
        max_index = headers.index(max_field)
        series_indices = [headers.index(c) for c in series_fields]

        min = row[min_index]
        max = row[max_index]
        series_vals = map(row.__getitem__, series_indices)

        return slider_chart(min, max, series_vals, markers=series_markers, marker_colors=series_colors,
                            marker_edge_color=marker_edge_color, marker_size=marker_size, background=background,
                            line_color=line_color, px_width=px_width, px_height=px_height, dpi=dpi,
                            transparent=transparent,
                            as_email_report=True)

    return chart


def const_column(const_val):
    def inner(headers, row_index, row, col_index, col_name):
        return const_val

    return inner


@util.explicit_param_checker
def df_table_def(df,
                 include_index=False,
                 index_name=None,
                 custom_formats=None,
                 index_format=None,
                 show_headers=True,
                 alternate_rows=True,
                 return_raw=False,
                 table_css_class='pd-dataframe',
                 numeric_column_align=None,
                 column_align=None,
                 header_styles=None,
                 column_styles=None,
                 header_row_style=None,
                 row_style=None,
                 custom_columns=None,
                 custom_headers=None,
                 column_order=None,
                 table_style=None,
                 **kwargs):
    if df is None:
        raise Exception("Must specify source dataframe for the table")

    params = kwargs.pop('__explicit_params', dict())
    params['df'] = df
    del params['__explicit_params']
    return params


def joined_df_tables(*tables, **kwargs):
    data_rows = []
    for t in tables:
        df = t.pop('df')
        rows = __df_table_core(df, emit_table_tag=False, **t)
        data_rows.extend(rows)
    return HTMLTable(css_class=kwargs.get('table_css_class', 'pd-dataframe'), rows=data_rows,
                     style=kwargs.get('table_style'))


def df_table(df,
             include_index=False,
             index_name=None,
             custom_formats=None,
             show_headers=True,
             alternate_rows=True,
             return_raw=False,
             table_css_class='pd-dataframe',
             numeric_column_align=None,
             column_align=None,
             header_styles=None,
             column_styles=None,
             header_row_style=None,
             row_style=None,
             custom_columns=None,
             custom_headers=None,
             column_order=None,
             table_style=None,
             extra_header_rows=[],
             extra_header_styles={},
             cell_class_fn=None,
             ):
    '''
    Generates html table out of dataframe, similar to DataFrame.to_html()
    :param df: Dataframe
    :type df: pd.DataFrame
    :return: HTMLTable or raw html
    '''

    result = __df_table_core(df, include_index, index_name, custom_formats, show_headers, alternate_rows,
                             table_css_class, numeric_column_align, column_align, header_styles, column_styles,
                             header_row_style, row_style, custom_columns, custom_headers, column_order, table_style,
                             extra_header_rows=extra_header_rows, extra_header_styles=extra_header_styles,
                             cell_class_fn=cell_class_fn)

    if return_raw:
        buf = StringIO.StringIO()
        result.render(buf, {}, {})
        return buf.getvalue()

    return result


num_dtypes = {'i', 'u', 'f'}


def get_cell_class_and_align(column_name, include_index, index_name, custom_columns, column_align,
                             numeric_column_align, df):
    col = None if column_name in custom_columns else (
        df.index if include_index and column_name == index_name else df[column_name])
    if col is not None:
        css_class = ('numeric-cell' if col.dtype.kind in num_dtypes else None)
        cur_align = column_align if isinstance(column_align, basestring) \
            else (column_align.get(column_name, column_align.get('default')) if column_align else 'center')
        cur_num_align = numeric_column_align if isinstance(numeric_column_align, basestring) \
            else (numeric_column_align.get(column_name, numeric_column_align.get('default')) if numeric_column_align else 'right')

        align = (cur_num_align if col.dtype.kind in num_dtypes else cur_align)
    else:
        css_class = None
        align = column_align
    return css_class, align


def __df_table_core(df=None,
                    include_index=False,
                    index_name=None,
                    custom_formats=None,
                    show_headers=True,
                    alternate_rows=True,
                    table_css_class='pd-dataframe',
                    numeric_column_align=None,
                    column_align=None,
                    header_styles=None,
                    column_styles=None,
                    header_row_style=None,
                    row_style=None,
                    custom_columns=None,
                    custom_headers=None,
                    column_order=None,
                    table_style=None,
                    emit_table_tag=True,
                    extra_header_rows=[],
                    extra_header_styles={},
                    cell_class_fn=None,
                    ):
    table_css_class = table_css_class or 'pd-dataframe'
    cell_class_fn = cell_class_fn or __cell_class
    columns = list(df.columns)
    if custom_columns is None:
        custom_columns = dict()

    if custom_headers is None:
        custom_headers = dict()

    if index_name is None:
        index_name = df.index.name

    for k, v in custom_columns.iteritems():
        if not callable(v):
            raise Exception(
                "Custom columns are functions which take row_index, row, col_index, col_name as arguments and return ReportElement. %s is not." % k)
    if column_order is None:
        column_order = (([index_name] + columns) if include_index else columns) + custom_columns.keys()
    headers = column_order
    data = itertools.izip(*[
        (df.index if include_index and x == index_name else (itertools.repeat(custom_columns[x], len(df))
                                                             if x in custom_columns else df[x]))
        for x in column_order
        ])
    custom_formats = custom_formats or dict()
    custom_formats = [custom_formats.get(x) for x in headers]

    # if include_index:
    #     custom_formats = [index_format] + custom_formats

    # def transform_data(row_tuple):
    #     row_tuple = [format_value(x, col_formatter=custom_formats[i], row_tuple=row_tuple, index=i) for i, x in
    #                  enumerate(row_tuple)]
    #     return row_tuple
    #
    # data = itertools.imap(transform_data, data)

    css_classes, column_align = zip(*[get_cell_class_and_align(c, include_index, index_name,
                                                               custom_columns, column_align,
                                                               numeric_column_align, df)
                                      for c in headers])

    # css_classes = [('numeric-cell' if df[x].dtype.kind in num_dtypes else None) for x in headers]
    # column_align = [(numeric_column_align if df[x].dtype.kind in num_dtypes else column_align) for x in headers]
    # # css_classes = [None] * len(columns)
    # if include_index:
    #     css_classes = ['numeric-cell' if df.index.dtype.kind in num_dtypes else None] + css_classes
    #     column_align = [numeric_column_align if df.index.dtype.kind in num_dtypes else column_align] + css_classes
    #     # css_classes = [None] + columns
    col_count = len(headers)
    header_styles = __normalize_styles(header_styles, headers)
    column_styles = __normalize_styles(column_styles, headers)
    header_class = HTMLTableHeader if emit_table_tag else HTMLTableCell

    header_rows     = []
    for extra_header_row in extra_header_rows:
        this_header = [x if isinstance(x, (list, tuple)) else (x,1) for x in extra_header_row]
        extra_hdr_def_style = extra_header_styles.get('all') or header_styles.get('all')
        header_row = HTMLTableRow(
            [header_class(h, colspan=colspan,
                          css_class=cell_class_fn(i, len(this_header), 'th', table_css_class, None,
                                                  r=len(header_rows), t=header_rows),
                          style=Style.update_style(extra_header_styles.get(h, extra_hdr_def_style)))
             for i, (h, colspan) in enumerate(this_header)], style=header_row_style)
        header_rows.append(header_row)

    header_row = HTMLTableRow(
        [header_class(custom_headers.get(h, h),
                      css_class=cell_class_fn(i, col_count, 'th', table_css_class, css_classes[i],
                                              r=len(header_rows), t=header_rows),
                      style=Style.update_style(header_styles.get(h, header_styles.get('all')),
                                               text_align=column_align[i]))
         for i, h in enumerate(headers)], style=header_row_style)
    header_rows.append(header_row)
    data = list(data)
    row_count = len(data)
    data_rows = [
        HTMLTableRow([HTMLTableCell(format_value(v, custom_formats[j], r, j),
                                    css_class=cell_class_fn(j, col_count, 'td', table_css_class, css_classes[j],r=i, t=data),
                                    style=Style.update_style(__get_column_style(headers[j], j, i, v, column_styles),
                                                             text_align=column_align[j]))
                      for j, v in
                      [(j_, __get_cell_value(headers, i, r, j_, headers[j_], v_)) for j_, v_ in enumerate(r)]],
                     css_class=__row_class(i, row_count, alternate_rows, table_css_class),
                     style=__get_row_style(i, r, row_style))
        for i, r in enumerate(data)
        ]
    if not show_headers:
        header_rows = None
    if emit_table_tag:
        result = HTMLTable(header=header_rows, rows=data_rows, css_class=table_css_class, style=table_style)
        #result = _Div(result, css_class=table_css_class + '-wrapper')
    else:
        if show_headers:
            result = [header_row] + data_rows
        else:
            result = data_rows
    return result


def __normalize_styles(styles, headers):
    if styles is None:
        styles = dict()
    elif not isinstance(styles, (dict, list, tuple)):
        styles = dict(all=styles)
    elif isinstance(styles, (list, tuple)):
        c = dict()
        for i, h in enumerate(headers):
            if i >= len(styles):
                break
            c[h] = styles[i]
        styles = c
    return styles


def create_stats_frame(df, columns=None, date_col='ASOF_DATE', item_column_name='Bond', cusips=None):
    columns = columns or df.columns
    if isinstance(columns, collections.Mapping):
        columns_rename = columns
        columns = columns.keys()
    else:
        columns_rename = collections.OrderedDict([(x, x) for x in columns])

    item = columns
    item_name = [columns_rename[x] for x in columns]

    last_valid = df.apply(pd.Series.last_valid_index)
    current = [df.iloc[last_valid[b]][b] for b in columns]

    # current = map(lambda x: current[x], bond)

    min_vals = df.min().to_dict()
    min_vals = map(min_vals.__getitem__, item)

    max_vals = df.max().to_dict()
    max_vals = map(max_vals.__getitem__, item)

    min_idx = map(lambda x: df[x].idxmin(), item)
    max_idx = map(lambda x: df[x].idxmax(), item)

    min_date = map(lambda x: df[date_col].iloc[x], min_idx)
    max_date = map(lambda x: df[date_col].iloc[x], max_idx)

    avg_vals = df.mean()
    avg_vals = map(avg_vals.__getitem__, item)

    std_dev = df.std(ddof=0)
    std_dev = map(std_dev.__getitem__, item)

    zscore = [(a - m) / s for a, m, s in zip(current, avg_vals, std_dev)]

    frame_columns = [
        (item_column_name, item_name),
        ('Current', current),
        ('Avg', avg_vals),
        ('Min', min_vals),
        ('MinDate', min_date),
        ('Max', max_vals),
        ('MaxDate', max_date),
        ('Std Dev', std_dev),
        ('Z Score', zscore)
    ]

    if cusips is not None:
        cusip_column = [cusips.get(c, '') for c in columns]
        frame_columns.insert(1, ('CUSIP', cusip_column))

    frame = collections.OrderedDict(frame_columns)

    return pd.DataFrame(data=frame)
