import matplotlib.patches as patches
import matplotlib.patheffects as patheffects

import numpy as np


def line_effect_shadow(offset=(2, 1), alpha=.2):
    return [patheffects.Normal(), patheffects.SimpleLineShadow(offset=offset, alpha=alpha)]


def line_effect_fill(offset=(0, 0), alpha=.2):
    return [patheffects.Normal(), PimPathPatchEffect(offset=offset, alpha=alpha)]


def line_effect_fill_and_shadow(fill_offset=(0, 0), shadow_offset=(2, 1), fill_alpha=.2, shadow_alpha=.2):
    return [patheffects.Normal(), patheffects.SimpleLineShadow(offset=shadow_offset, alpha=shadow_alpha),
            PimPathPatchEffect(offset=fill_offset, alpha=fill_alpha)]


class PimPathPatch(patches.PathPatch):
    def __init__(self, path, **kwargs):
        super(PimPathPatch, self).__init__(path, **kwargs)


class PimPathPatchEffect(patheffects.AbstractPathEffect):
    """
    Draws a :class:`~matplotlib.patches.PathPatch` instance whose Path
    comes from the original PathEffect artist.

    """

    def __init__(self, offset=(0, 0), **kwargs):
        """
        Parameters
        ----------
        offset : pair of floats
            The offset to apply to the path, in points.
        **kwargs :
            All keyword arguments are passed through to the
            :class:`~matplotlib.patches.PathPatch` constructor. The
            properties which cannot be overridden are "path", "clip_box"
            "transform" and "clip_path".
        """
        super(PimPathPatchEffect, self).__init__(offset=offset)
        self.patch = PimPathPatch([], **kwargs)

    def draw_path(self, renderer, gc, tpath, affine, rgbFace):
        affine = self._offset_transform(renderer, affine)
        if tpath.vertices is not None:
            vc = tpath.vertices.copy()
            vc = vc[~np.isnan(vc).any(axis=1)]
            if len(vc) > 0:
                vc = np.vstack(([[vc[0][0], 0]], vc, [vc[-1][0], 0]))
        else:
            vc = []
        self.patch._path = tpath.__class__(
            vc if tpath.vertices is not None else [],
            tpath.codes.copy() if tpath.codes is not None else None,
            _interpolation_steps=tpath._interpolation_steps)

        self.patch.set_transform(affine)
        self.patch.set_clip_box(gc._cliprect)
        self.patch.set_clip_path(gc._clippath)
        self.patch.draw(renderer)
