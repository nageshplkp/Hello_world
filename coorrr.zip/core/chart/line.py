import seaborn as sns
import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas
import numpy as np
import os
from matplotlib.font_manager import FontManager
from core.common import util
from matplotlib.ticker import FormatStrFormatter, Formatter
import matplotlib.patches as mpatch
import collections
from .chart_effects import PimPathPatchEffect
from matplotlib.patheffects import Normal
from matplotlib.cbook import ls_mapper
from .styles import make_palette_from_win

sns.set()
sns.set_color_codes()


@util.explicit_param_checker
def line_chart_style(base_style=None,
                     title=None, title_font_size=None, title_color=None, title_font_weight=None,
                     show_x_label=True,
                     xgrid=False, ygrid=False, xstep=None, ystep=None,
                     line_width=None,
                     legend_anchor=(1.05, 1),
                     legend_loc=2,
                     legend_font_size=FontManager.get_default_size(),
                     legend_columns=1,
                     exclude_from_legend=set(),
                     tick_font_size=FontManager.get_default_size(),
                     x_tick_rotation='horizontal',
                     y_tick_rotation='horizontal',
                     x_tick_length=None, y_tick_length=None,
                     swap_y_tick_side=False,
                     x_lim=None, y_lim=None, y_lim_right=None,
                     x_tick_format=None, y_tick_format=None, y_right_tick_format=None,
                     spine_colors=None,
                     spine_colors_right=None,
                     x_spine_position=None,
                     x_top_spine_position=None,
                     y_spine_position=None,
                     y_right_spine_position=None,
                     line_styles_dict=None,
                     line_effects_dict=None,
                     palette=None,
                     despine=True,
                     dpi=100,
                     px_width=320,
                     px_height=200,
                     as_email_report=False,
                     **kwargs):
    base_style = base_style or dict()
    base_style = base_style.copy()

    params = kwargs.pop('__explicit_params', dict())
    base_style.update(params)
    if '__explicit_params' in base_style:
        del base_style['__explicit_params']

    return base_style


def plot_line(df, x_axis=None,
              title=None, title_font_size=None, title_color=None, title_font_weight=None,
              show_x_label=True,
              xgrid=False, ygrid=False, xstep=None, ystep=None,
              line_width=None,
              legend_anchor=(1.05, 1),
              legend_loc=2,
              legend_font_size=FontManager.get_default_size(),
              legend_columns=1,
              exclude_from_legend=set(),
              tick_font_size=FontManager.get_default_size(),
              x_tick_rotation='horizontal',
              y_tick_rotation='horizontal',
              x_tick_length=None, y_tick_length=None,
              swap_y_tick_side=False,
              x_lim=None, y_lim=None,
              x_tick_format=None, y_tick_format=None,
              spine_colors=None,
              x_spine_position=None,
              x_top_spine_position=None,
              y_spine_position=None,
              y_right_spine_position=None,
              palette=None,
              line_styles_dict=None,
              line_effects_dict=None,
              despine=True,
              dpi=100, px_width=320, px_height=200,
              png_name=None,
              as_email_report=False):
    '''
    Creates a line chart out of pandas.DataFrame
    :param df: pandas.DataFrame to plot
    :type df: pandas.DataFrame
    :param png_name: If not none, will save to specified png file
    :type png_name: basestring
    :param dpi: Dots-per-inch to use for rendering
    :type dpi: int
    :param px_width: Width of the plot in pixels (does not include legend or axes)
    :type px_width: int
    :param px_height: Height of the plot in pixels (does not include legend or axes)
    :type px_height: int
    :param x_axis: If not none, will use specified dataframe column as X axis. Will use index otherwise.
    :type x_axis: basestring
    :param despine: Remove top and right borders
    :type despine: bool
    :return: Subplot representing this dataframe
    :param title: Chart title
    :param show_x_label: Show label for X axis
    :param xgrid: Show vertical grid lines
    :param xstep: Vertical grid line step
    :param ygrid: Show horizontal grid lines
    :param ystep: Horizontal grid line step
    :param legend_loc: Legend location (from matplotlib.pyplot)
    :param legend_anchor: Legend location withing chart ( can be outside of bounds). (0,0) is lower left corner, (1,1) is upper right.
    :param as_email_report: return Chart component for email report instead of matplotlib figure
    '''

    assert isinstance(df, pandas.DataFrame)
    if as_email_report:
        from core.common.util import extract_params
        from core.reporting.simple_email import _CoreChart
        args, kwargs = extract_params(plot_line, locals())
        kwargs.pop('as_email_report')
        return _CoreChart(plot_line, args, kwargs, 'png_name')

    with sns.axes_style('ticks'):
        sub_plot = __plot_lines_single(df, line_styles_dict, line_width, x_axis)

        sub_plot.get_figure().set_size_inches(px_width / float(dpi), px_height / float(dpi))

        if show_x_label:
            sub_plot.get_axes().set_xlabel(x_axis or 'index')
        else:
            sub_plot.get_axes().set_xlabel(None).set_visible(False)

        handles, labels = sub_plot.get_figure().get_axes()[0].get_legend_handles_labels()
        if spine_colors:
            ax = sub_plot.get_figure().get_axes()[0]
            __set_spine_colors(ax, spine_colors)

        if line_effects_dict is not None:
            axes = sub_plot.get_axes()
            for i, c in enumerate(df.columns):
                effects = line_effects_dict.get(c)
                if effects:
                    axes.lines[i].set_path_effects(effects)

        if palette is None:
            palette = sns.color_palette()
            palette = sns.color_palette(palette, n_colors=len(handles))

        for i, c in enumerate(handles):
            c.set_color(palette[i])

        handles, labels = __process_legend_exclusions(handles, labels, exclude_from_legend)

        legend = sub_plot.legend(handles, labels,
                                 bbox_to_anchor=legend_anchor, loc=legend_loc, fontsize=legend_font_size,
                                 ncol=legend_columns if legend_columns > 0 else len(handles))

        for h in legend.legendHandles:
            if h._path_effects:
                pe = h._path_effects
                pim_path_patch = [e for e in pe if isinstance(e, PimPathPatchEffect)]
                pim_path_patch = pim_path_patch[0] if pim_path_patch else None
                pe = [e for e in pe if isinstance(e, Normal)]

                if pim_path_patch:
                    h.set_ydata(h.get_ydata() * 2)
                    pe += [pim_path_patch]
                h._path_effects = pe
        __format_grid_single(sub_plot, x_lim, x_tick_format, xgrid, xstep, y_lim, y_tick_format, ygrid, ystep)

        extra_artits = (legend,)
        if title:
            extra_artits += (__make_title(sub_plot.get_figure(), title, title_color, title_font_size,
                                          title_font_weight),)

        __format_spines_single(sub_plot.get_figure().get_axes()[0], despine, sub_plot.get_figure(),
                               tick_font_size, x_tick_rotation, y_tick_rotation,
                               x_spine_position, x_top_spine_position,
                               y_spine_position, y_right_spine_position,
                               x_tick_length, y_tick_length,
                               swap_y_tick_side)

        if png_name:
            sub_plot.get_figure().savefig(png_name, dpi=dpi, format='png', bbox_extra_artists=extra_artits,
                                          bbox_inches='tight')

        return sub_plot.get_figure()


def plot_line_mult_scale(df, x_axis=None,
                         main_scale=None,
                         second_scale=None,
                         title=None, title_font_size=None, title_color=None, title_font_weight=None,
                         show_x_label=True,
                         xgrid=False, ygrid=False, ygrid_right=False,
                         xstep=None, ystep=None, ystep_right=None,
                         line_width=None,
                         legend_anchor=(1.05, 1), legend_loc=2,
                         legend_font_size=FontManager.get_default_size(),
                         legend_columns=1,
                         exclude_from_legend=set(),
                         tick_font_size=FontManager.get_default_size(),
                         x_tick_rotation='horizontal',
                         y_tick_rotation='horizontal',
                         x_tick_length=None, y_tick_length=None,
                         swap_y_tick_side=False,
                         x_lim=None, y_lim=None, y_lim_right=None,
                         x_tick_format=None, y_tick_format=None, y_right_tick_format=None,
                         spine_colors=None,
                         spine_colors_right=None,
                         x_spine_position=None,
                         x_top_spine_position=None,
                         y_spine_position=None,
                         y_right_spine_position=None,
                         line_styles_dict=None,
                         line_effects_dict=None,
                         palette=None,
                         despine=False,
                         dpi=100, px_width=320, px_height=200,
                         png_name=None,
                         as_email_report=False):
    '''
    Creates a line chart out of pandas.DataFrame. Supports two data scales (One graduated on the left, the other on the right)
    :param df: pandas.DataFrame to plot
    :type df: pandas.DataFrame
    :param main_scale: Columns shown on left scale
    :param second_scale: Columns shown on right scale
    :param png_name: If not none, will save to specified png file
    :type png_name: basestring
    :param dpi: Dots-per-inch to use for rendering
    :type dpi: int
    :param px_width: Width of the plot in pixels (does not include legend or axes)
    :type px_width: int
    :param px_height: Height of the plot in pixels (does not include legend or axes)
    :type px_height: int
    :param x_axis: If not none, will use specified dataframe column as X axis. Will use index otherwise.
    :type x_axis: basestring
    :param despine: Remove top and right borders
    :type despine: bool
    :return: Subplot representing this dataframe
    :param title: Chart title
    :param show_x_label: Show label for X axis
    :param xgrid: Show vertical grid lines
    :param xstep: Vertical grid line step
    :param ygrid: Show horizontal grid lines
    :param ystep: Horizontal grid line step
    :param legend_loc: Legend location (from matplotlib.pyplot)
    :param legend_anchor: Legend location withing chart ( can be outside of bounds). (0,0) is lower left corner, (1,1) is upper right.
    :param as_email_report: return Chart component for email report instead of matplotlib figure
    '''
    assert isinstance(df, pandas.DataFrame)

    main_scale = main_scale or []
    second_scale = second_scale or []

    if as_email_report:
        from core.common.util import extract_params
        from core.reporting.simple_email import _CoreChart
        args, kwargs = extract_params(plot_line_mult_scale, locals())
        kwargs.pop('as_email_report')
        return _CoreChart(plot_line_mult_scale, args, kwargs, 'png_name')

    with sns.axes_style('ticks'):

        main_scale, second_scale = __resolve_scales(df, main_scale, second_scale, x_axis)

        fig, ax1 = plt.subplots()
        fig.set_size_inches(px_width / float(dpi), px_height / float(dpi))

        index_series = df[x_axis] if x_axis else df.index

        __plot_single_scale_ms(df, ax1, main_scale, index_series, line_effects_dict, line_styles_dict, line_width)

        if show_x_label:
            ax1.set_xlabel(x_axis or 'index')

        if spine_colors:
            __set_spine_colors(ax1, spine_colors)

        ax2 = ax1.twinx()
        __plot_single_scale_ms(df, ax2, second_scale, index_series, line_effects_dict, line_styles_dict, line_width)

        if spine_colors_right:
            __set_spine_colors(ax2, spine_colors_right)

        ax2.yaxis.tick_right()
        ax2.yaxis.set_ticks_position('right')

        handles, labels = zip(*(zip(*ax1.get_legend_handles_labels()) + zip(*ax2.get_legend_handles_labels())))

        # legend1 = ax1.legend(bbox_to_anchor=(1.05, 1), loc=2)
        # legend2 = ax2.legend(bbox_to_anchor=(1.05, 1.25), loc=1)

        if palette is None:
            palette = sns.color_palette()
            palette = sns.color_palette(palette, n_colors=len(handles))
        for i, c in enumerate(handles):
            c.set_color(palette[i])

        handles, labels = __process_legend_exclusions(handles, labels, exclude_from_legend)

        legend = ax1.legend(handles, labels, loc=legend_loc, bbox_to_anchor=legend_anchor, fontsize=legend_font_size,
                            ncol=legend_columns if legend_columns > 0 else len(handles))

        __format_grid_ms(ax1, ax2, x_lim, x_tick_format, xgrid, xstep, y_lim, y_lim_right, y_right_tick_format,
                         y_tick_format, ygrid, ygrid_right, ystep, ystep_right)

        extra_artits = (legend,)
        if title:
            extra_artits += (__make_title(fig, title, title_color, title_font_size, title_font_weight),)

        __format_spines_ms(ax1, ax2, despine, fig, tick_font_size, x_tick_rotation, y_tick_rotation,
                           x_spine_position, x_top_spine_position,
                           y_spine_position, y_right_spine_position,
                           x_tick_length, y_tick_length)

        if png_name:
            fig.savefig(png_name, dpi=dpi, format='png', bbox_extra_artists=extra_artits,
                        bbox_inches='tight')
        return fig


def __process_legend_exclusions(handles, labels, exclude_from_legend):
    if exclude_from_legend == 'all':
        exclude_from_legend = set(labels)
    if exclude_from_legend:
        handles_labels = [(x, y) for x, y in zip(handles, labels) if y not in exclude_from_legend]
        if handles_labels:
            handles, labels = zip(*handles_labels)
        else:
            handles, labels = [], []
    return handles, labels


def __format_grid_single(sub_plot, x_lim, x_tick_format, xgrid, xstep, y_lim, y_tick_format, ygrid, ystep):
    if ygrid:
        sub_plot.get_figure().get_axes()[0].yaxis.grid()
    if xgrid:
        sub_plot.get_figure().get_axes()[0].xaxis.grid()
    if x_lim:
        sub_plot.get_figure().get_axes()[0].set_xlim(left=x_lim[0], right=x_lim[1])
    if y_lim:
        sub_plot.get_figure().get_axes()[0].set_ylim(bottom=y_lim[0], top=y_lim[1])
    if xstep:
        start, stop = sub_plot.get_figure().get_axes()[0].get_xlim()
        sub_plot.get_figure().get_axes()[0].xaxis.set_ticks(np.arange(start, stop, xstep))
    if ystep:
        start, stop = sub_plot.get_figure().get_axes()[0].get_ylim()
        sub_plot.get_figure().get_axes()[0].yaxis.set_ticks(np.arange(start, stop, ystep))
    if x_tick_format:
        sub_plot.get_figure().get_axes()[0].xaxis.set_major_formatter(x_tick_format
                                                                      if isinstance(x_tick_format, Formatter)
                                                                      else FormatStrFormatter(x_tick_format)
                                                                      )
    if y_tick_format:
        sub_plot.get_figure().get_axes()[0].yaxis.set_major_formatter(y_tick_format
                                                                      if isinstance(y_tick_format, Formatter)
                                                                      else FormatStrFormatter(y_tick_format))


def __make_title(fig, title, title_color, title_font_size, title_font_weight, **kwargs):
    if title_color is not None:
        kwargs['color'] = title_color
    if title_font_size is not None:
        kwargs['fontsize'] = title_font_size
    if title_font_weight is not None:
        kwargs['weight'] = title_font_weight
    title_artist = fig.suptitle(title, **kwargs)
    return title_artist


def __plot_lines_single(df, line_styles_dict, line_width, x_axis):
    sub_plot = df.plot(x=x_axis, style=line_styles_dict)
    if line_width is not None:
        if isinstance(line_width, collections.Mapping):
            for i, c in enumerate(df.columns):
                if c in line_width:
                    sub_plot.get_axes().lines.set_linewidth(line_width[c])
        elif isinstance(line_width, basestring) or not isinstance(line_width, collections.Sequence):
            for ss in sub_plot.get_axes().lines:
                ss.set_linewidth(line_width)
        else:
            for i, ss in enumerate(sub_plot.get_axes().lines):
                ss.set_linewidth(line_width[i if i < len(line_width) else -1])
    return sub_plot


def __set_spine_colors(ax, spine_colors):
    if isinstance(spine_colors, tuple) and len(spine_colors) > 0 \
            and any(isinstance(x, collections.Sequence) for x in spine_colors):
        if len(spine_colors) == 2:
            if spine_colors[0]:
                ax.spines['left'].set_color(spine_colors[0])
                ax.spines['right'].set_color(spine_colors[0])
            if spine_colors[1]:
                ax.spines['top'].set_color(spine_colors[1])
                ax.spines['bottom'].set_color(spine_colors[1])
        else:
            if spine_colors[0]:
                ax.spines['left'].set_color(spine_colors[0])
            if spine_colors[2]:
                ax.spines['right'].set_color(spine_colors[2])
            if spine_colors[3]:
                ax.spines['top'].set_color(spine_colors[3])
            if spine_colors[1]:
                ax.spines['bottom'].set_color(spine_colors[1])
    else:
        ax.spines['left'].set_color(spine_colors)
        ax.spines['right'].set_color(spine_colors)
        ax.spines['top'].set_color(spine_colors)
        ax.spines['bottom'].set_color(spine_colors)


def __format_spines_single(ax1, despine, fig, tick_font_size, x_tick_rotation, y_tick_rotation,
                           x_spine_position, x_top_spine_position,
                           y_spine_position, y_right_spine_position,
                           x_tick_length, y_tick_length,
                           swap_y_tick_side=False):
    ds_kwargs = {}

    if despine:
        if isinstance(despine, collections.Mapping):
            ds_kwargs = despine
        elif isinstance(despine, collections.Sequence):
            keys = ['top', 'right', 'left', 'bottom'][:len(despine)]
            ds_kwargs = dict(zip(keys, despine))
        else:
            ds_kwargs = dict(top=True, left=swap_y_tick_side, bottom=False, right=not swap_y_tick_side)

    sns.despine(fig, **ds_kwargs)

    if swap_y_tick_side:
        ax1.yaxis.set_ticks_position('right')

    if x_spine_position is not None:
        ax1.spines['bottom'].set_position(x_spine_position)
    if x_top_spine_position is not None:
        ax1.spines['top'].set_position(x_top_spine_position)

    if y_spine_position is not None:
        ax1.spines['left'].set_position(y_spine_position)
    if y_right_spine_position is not None:
        ax1.spines['right'].set_position(y_right_spine_position)

    for tick in ax1.xaxis.get_major_ticks():
        tick.label.set_fontsize(tick_font_size)
        tick.label.set_rotation(x_tick_rotation)
        if x_tick_length is not None:
            tick._apply_params(size=x_tick_length)
            if not x_tick_length:
                tick._apply_params(pad=1.0)

    for tick in ax1.yaxis.get_major_ticks():
        if swap_y_tick_side:
            tick.label2.set_fontsize(tick_font_size)
            tick.label2.set_rotation(y_tick_rotation)
        else:
            tick.label.set_fontsize(tick_font_size)
            tick.label.set_rotation(y_tick_rotation)
        if y_tick_length is not None:
            tick._apply_params(size=y_tick_length)
            if not y_tick_length:
                tick._apply_params(pad=1.0)


def __format_spines_ms(ax1, ax2, despine, fig, tick_font_size, x_tick_rotation, y_tick_rotation,
                       x_spine_position, x_top_spine_position,
                       y_spine_position, y_right_spine_position,
                       x_tick_length, y_tick_length, ):
    __format_spines_single(ax1, despine, fig, tick_font_size, x_tick_rotation, y_tick_rotation,
                           x_spine_position, x_top_spine_position,
                           y_spine_position, x_tick_length, y_tick_length,
                           None)
    if x_spine_position is not None:
        ax2.spines['bottom'].set_position(x_spine_position)
    if x_top_spine_position is not None:
        ax2.spines['top'].set_position(x_top_spine_position)
    if y_right_spine_position is not None:
        ax2.spines['right'].set_position(y_right_spine_position)

    for tick in ax2.yaxis.get_major_ticks():
        tick.label2.set_fontsize(tick_font_size)
        tick.label2.set_rotation(y_tick_rotation)
    ax2.yaxis.set_ticks_position('right')


def __format_grid_ms(ax1, ax2, x_lim, x_tick_format, xgrid, xstep, y_lim, y_lim_right, y_right_tick_format,
                     y_tick_format, ygrid, ygrid_right, ystep, ystep_right):
    if ygrid:
        ax1.yaxis.grid()
    if ygrid_right:
        ax2.yaxis.grid()
        for l in ax2.get_ygridlines():
            l.set_linestyle('dashdot')
    if xgrid:
        ax1.xaxis.grid()
    if x_lim:
        ax1.set_xlim(left=x_lim[0], right=x_lim[1])
    if y_lim:
        ax1.set_ylim(bottom=y_lim[0], top=y_lim[1])
    if y_lim_right:
        ax2.set_ylim(bottom=y_lim_right[0], top=y_lim_right[1])
    if xstep:
        start, stop = ax1.get_xlim()
        ax1.xaxis.set_ticks(np.arange(start, stop, xstep))
    if ystep:
        start, stop = ax1.get_ylim()
        ax1.yaxis.set_ticks(np.arange(start, stop, ystep))
    if ystep_right:
        start, stop = ax2.get_ylim()
        ax2.yaxis.set_ticks(np.arange(start, stop, ystep_right))
    if x_tick_format:
        ax1.xaxis.set_major_formatter(x_tick_format
                                      if isinstance(x_tick_format, Formatter)
                                      else FormatStrFormatter(x_tick_format))
    if y_tick_format:
        ax1.yaxis.set_major_formatter(y_tick_format
                                      if isinstance(y_tick_format, Formatter)
                                      else FormatStrFormatter(y_tick_format))
    if y_right_tick_format:
        ax2.yaxis.set_major_formatter(y_right_tick_format
                                      if isinstance(y_right_tick_format, Formatter)
                                      else FormatStrFormatter(y_right_tick_format))


def __resolve_scales(df, main_scale, second_scale, x_axis):
    if not second_scale:
        second_scale = []
    if not main_scale:
        main_scale = [x for x in df.colums if x != x_axis and x not in second_scale]
    second_scale = [x for x in df.columns if x != x_axis and x in second_scale and x not in main_scale]
    return main_scale, second_scale


def __plot_single_scale_ms(df, ax, columns, index_series, line_effects_dict, line_styles_dict, line_width):
    for x in columns:
        s1 = df[x]
        plot_args = dict(label=x)
        if line_styles_dict and x in line_styles_dict:
            plot_args['linestyle'] = line_styles_dict[x]
        lines = ax.plot(index_series, s1, **plot_args)

        if line_effects_dict and x in line_effects_dict:
            effects = line_effects_dict[x]
            lines[-1].set_path_effects(effects)

        if line_width is not None:
            if isinstance(line_width, collections.Mapping) and x in line_width:
                lines[-1].set_linewidth(line_width[x])
            else:
                lines[-1].set_linewidth(line_width)
