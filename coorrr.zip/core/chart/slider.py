import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import collections
import seaborn as sns


def slider_chart(min_value, max_value, data_points, markers=None, marker_colors=None, marker_edge_color='black',
                 marker_size=None, background='white', line_color='black', px_width=200, px_height=10, dpi=100,
                 transparent=False,
                 png_name=None, as_email_report=False):

    if as_email_report:
        from core.common.util import extract_params
        from core.reporting.simple_email import _CoreChart
        args, kwargs = extract_params(slider_chart, locals())
        kwargs.pop('as_email_report')
        return _CoreChart(slider_chart, args, kwargs, 'png_name')

    fig, ax = plt.subplots()

    if markers is None:
        markers = ['o'] * len(data_points)
    if isinstance(markers, basestring):
        markers = [markers] * len(data_points)

    if not isinstance(markers, collections.Sequence):
        raise Exception("Markers must be a collection")

    if marker_colors is None:
        marker_colors = sns.color_palette(n_colors=len(data_points))
    else:
        marker_colors = sns.color_palette(marker_colors, n_colors=len(data_points))

    for i, dp in enumerate(data_points):
        args = dict(marker = markers[i], mfc=marker_colors[i])
        if marker_size is not None:
            args['markersize'] = marker_size
        if (marker_edge_color or line_color) is not None:
            args['markeredgecolor'] = marker_edge_color or line_color
        ax.plot([dp], [0], **args)

    ax.set_xlim(min_value, max_value)
    ax.set_ylim(-0.01, 0.01)
    ax.patch.set_color(background)
    ax.yaxis.set_ticks([0.0])
    ax.yaxis.set_ticklabels([''])
    ax.xaxis.set_ticks([])
    ax.xaxis.set_ticklabels([])

    ax.spines['left'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    ax.spines['bottom'].set_visible(False)

    ax.grid(b=True, which='major', axis='y', color=line_color, linestyle='-', linewidth=1)
    fig.set_size_inches(px_width / float(dpi), px_height / float(dpi))

    if png_name:
        fig.savefig(png_name, dpi=dpi, format='png', bbox_inches='tight', pad_inches=0, transparent=transparent)
    return fig