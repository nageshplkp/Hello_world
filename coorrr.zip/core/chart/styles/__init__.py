import os
import os.path

import sass

__all__ = ['get_table_style']


def make_palette_from_win(*l):
    return [(r / 255.0, g / 255.0, b / 255.0) for r, g, b in l]


BLUE_TABLE_STYLE = dict(
    alternate_background='#f2f5f8',
    table_border_color='#9cc0e0',
    cell_border='white',
    background='#e4e9f1'
)

DARK_BLUE_TABLE_STYLE = dict(
    alternate_background='#dadde8',
    table_border_color='#5c9ecc',
    cell_border='white',
    background='#c7c9da'
)

GREEN_TABLE_STYLE = dict(
    alternate_background='#f1f0ee',
    table_border_color='#c4bd97',
    cell_border='white',
    background='#eae7e3'
)

DEFAULT_TABLE_STYLE = dict(
    alternate_background='lightgrey',
    cell_border='black',
    background='white',
    table_border_color='black'
)

CREDIT_LINE_CHART_STYLE = dict(
    line_width=[1.5, .7, .7], x_tick_rotation='vertical',
    palette=make_palette_from_win((55, 96, 146), (149, 179, 215), (55, 96, 146)),
    show_x_label=False,
    ygrid=True, tick_font_size=7.0, swap_y_tick_side=True, x_spine_position='zero',
    legend_font_size=7.0, legend_loc=9, legend_columns=0,
    despine=dict(top=True, left=True, right=True, bottom=False),
    spine_colors=make_palette_from_win((55, 96, 146))[0],
    y_tick_length=0,
    legend_anchor=(0., 1.02, 1., .102))

def make_html_from_win(r, g, b):
    return '#%02x%02x%02x' % (r, g, b)


def get_custom_table_style(table_class_name,
                           font_size='9.25pt',
                           background='white',
                           alternate_background='lightgrey',
                           table_border_style='solid',
                           table_border_width='1px',
                           table_border_color='black',
                           cell_border='black',
                           cell_padding='2pt',
                           cell_border_style='solid',
                           cell_border_width='1px'):
    with open(os.path.join(os.path.dirname(__file__), "table_template.css")) as f:
        s =  f.read()

    import re
    exp = re.compile(r'{{(\w+)}}')

    repl_dict = dict(table_class_name=table_class_name,
                     font_size=font_size,
                     background=background,
                     alternate_background=alternate_background,
                     table_border_style=table_border_style,
                     table_border_width=table_border_width,
                     table_border_color=table_border_color,
                     cell_border=cell_border,
                     cell_padding=cell_padding,
                     cell_border_style=cell_border_style,
                     cell_border_width=cell_border_width)

    s = exp.sub(lambda x: repl_dict.get(x.group(1)), s)
    return s


def get_table_style():
    return get_tables_css() + '\n\n' + get_custom_table_style('pd-dataframe', **DEFAULT_TABLE_STYLE)


def get_tables_css():
    with open(os.path.join(os.path.dirname(__file__), "tables.css")) as f:
        style = f.read()
    return style


def get_core_style():
    with open(os.path.join(os.path.dirname(__file__), "core.css")) as f:
        return f.read()


def get_reset_css():
    with open(os.path.join(os.path.dirname(__file__), "jupyter_reset.css")) as f:
        style = f.read()
    return style


def get_pretty_tbl_style(tbl_cls_name, **kwargs):

    def variableoverrides(path):
        if path == 'variableoverrides':
            return [(path, '\n'.join(['$%s: %s;' % (k, v) for k, v in kwargs.iteritems() if v is not None]))]

    kwargs['tbl_cls_name'] = tbl_cls_name
    template_file = os.path.join(os.path.dirname(__file__), "prettytable.scss")
    with open(template_file) as f:
        txt = f.read()
    return sass.compile(string=txt, importers=[(0, variableoverrides)], output_style='compressed')

