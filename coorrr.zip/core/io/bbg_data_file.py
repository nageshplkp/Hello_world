def write(path, value_table, fields, prec=15, fields_header_exclude=[], file_headers = []):
    with open(path, 'w+') as f:
        f.write('START-OF-FILE\n')
        for header in file_headers:
            f.write(header[0])
            f.write('=')
            f.write(header[1])
            f.write('\n')
        f.write('START-OF-FIELDS\n')
        for field in fields:
            if field not in fields_header_exclude:
                f.write(field)
        f.write('END-OF-FIELDS\n')
        f.write('START-OF-DATA\n')
        i = 0
        for line in value_table:
            if len(line) != len(fields):
                raise Exception('All lines must contain same number of fields. Line %d does not.' % i)
            i += 1
            first = True
            for value in line:
                if not first:
                    f.write('|')

                if value is not None:
                    if isinstance(value, (str, unicode)):
                        if '|' in value:
                            value = value.replace('|', '_')
                    elif isinstance(value, float):
                        value = ('%0.' + str(prec) + 'f') % value
                    else:
                        value = str(value)
                    f.write(value)
                first = False
            f.write('\n')

        f.write('END-OF-DATA\n')
        f.write('END-OF-FILE\n')


def write_dicts(path, dicts, fields=None, fields_rename=None, prec=15, fields_header_exclude=[], file_headers = []):
    if fields is None:
        fields = dicts[0].keys()

    fields_rename = {} or fields_rename
    with open(path, 'w+') as f:
        f.write('START-OF-FILE\n')
        for header in file_headers:
            f.write(header[0])
            f.write('=')
            f.write(header[1])
            f.write('\n')
        f.write('START-OF-FIELDS\n')
        for field in fields:
            if field not in fields_header_exclude:
                f.write(fields_rename.get(field, field))
                f.write('\n')
        f.write('END-OF-FIELDS\n')
        f.write('START-OF-DATA\n')
        i = 0
        for line in dicts:
            first = True
            for field in fields:
                value = line.get(field)
                if not first:
                    f.write('|')

                if value is not None:
                    if isinstance(value, (str, unicode)):
                        if '|' in value:
                            value = value.replace('|', '_')
                    elif isinstance(value, float):
                        value = ('%0.' + str(prec) + 'f') % value
                    else:
                        value = str(value)
                    f.write(value)
                first = False
            f.write('\n')

        f.write('END-OF-DATA\n')
        f.write('END-OF-FILE\n')


def read(path, line_transformer=None):
    read_fields = False
    read_data = False
    fields = ['SECURITY', 'ERROR CODE', 'NUM FLDS']
    data = []
    line_transformer = line_transformer or (lambda f, l: [x.strip() for x in l.split('|')])

    with open(path, 'r') as f:

        while True:
            line = f.readline()
            if not line:
                break

            line = line.strip()
            if line.startswith('#'):
                continue

            if read_fields:
                if line == 'END-OF-FIELDS':
                    read_fields = False
                    continue

                fields.append(line)
                continue

            if read_data:
                if line == 'END-OF-DATA':
                    read_data = False
                    continue
                data.append(line_transformer(fields, line))
                continue

            if line == 'START-OF-FIELDS':
                read_fields = True
            if line == 'START-OF-DATA':
                read_data = True

    return fields, data


def read_dicts(path):
    return read(path, lambda f, l: dict(zip(f, [x.strip() for x in l.split('|')])))
