import os, shutil, sys, tempfile, logging
import collections
from distutils.dir_util import copy_tree


def create_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)


def create_file(path):
    if not os.path.exists(path):
        try:
            open(path, 'w').close()
        except Exception as ex:
            logging.error('err creating file %s ' % path)


def join(path1, path2):
    return os.path.join(path1, path2)


def read(path):
    if os.path.exists(path):
        with open(path) as fp:
            lines = fp.readlines()

        if len(lines) == 1:
            return lines[0].strip()
        else:
            return lines


def readflat(path, mode='r'):
    if os.path.exists(path):
        with open(path, mode) as f:
            return f.read()


def write(path, lines, line_break=False):
    create_file(path)
    with open(path, 'w') as fp:
        if isinstance(lines, collections.Iterable):
            if line_break:
                fp.writelines(os.linesep.join(lines))
            else:
                for line in lines:
                    fp.write(line)
        else:
            fp.write(lines)


def list_files(dir, recursive=False):
    for top, dirs, files in os.walk(dir):
        for f in files:
            yield os.path.join(top, f)
        if not recursive:
            dirs[:] = []

def list_dirs(dir):
    if not exists(dir):
        return []

    return [x[0] for x in os.walk(dir)]


def copy_file(src, dest_dir):
    create_dir(dest_dir)
    shutil.copy(src, dest_dir)

def copy_dir(src_dir, dest_dir):
    create_dir(dest_dir)
    copy_tree(src_dir, dest_dir)


def delete_dir(path):
    if os.path.exists(path):
        shutil.rmtree(path)


def delete_file(path):
    if os.path.exists(path):
        os.remove(path)


def exists(path):
    return os.path.exists(path)


def can_create_file(path):
    try:
        tempfile.TemporaryFile(dir=path)
        return True
    except OSError:
        return False


def chmod(path, mask=0o777):
    os.chmod(path, mask)
