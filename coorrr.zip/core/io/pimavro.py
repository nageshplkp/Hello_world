from avro.io import DatumWriter, AvroTypeException, INT_MIN_VALUE, INT_MAX_VALUE, LONG_MIN_VALUE, LONG_MAX_VALUE


class PimDatumWriter(DatumWriter):
    """
    This class was created to fix an existing bug were the order in which the unions were
    written is incorrect. for example, {"type":"map","values":["boolean", "long","double"]}
    For more information, see the following

    https://stackoverflow.com/questions/29063229/apache-avro-distinguish-double-and-long-in-union-values
    http://apache-avro.679487.n3.nabble.com/Python-Union-Behavior-not-consistent-td3570352.html
    """

    def write_union(self, writers_schema, datum, encoder):
        """
        Curious? - compare this code with the base class
        """
        # resolve union
        index_of_schema = -1
        for i, candidate_schema in enumerate(writers_schema.schemas):
            if validate(candidate_schema, datum):  # override validate with our stuff
                index_of_schema = i
        if index_of_schema < 0:
            raise AvroTypeException(writers_schema, datum)

        # write data
        encoder.write_long(index_of_schema)
        self.write_data(writers_schema.schemas[index_of_schema], datum, encoder)


def validate(expected_schema, datum):
    """
    This was taken from avro.io module to modify the float/double matching logic. Compare this code with the
    original to find out more
    """
    schema_type = expected_schema.type
    if schema_type == 'null':
        return datum is None
    elif schema_type == 'boolean':
        return isinstance(datum, bool)
    elif schema_type == 'string':
        return isinstance(datum, basestring)
    elif schema_type == 'bytes':
        return isinstance(datum, str)
    elif schema_type == 'int':
        return ((isinstance(datum, int) or isinstance(datum, long)) and not isinstance(datum, bool)
                and INT_MIN_VALUE <= datum <= INT_MAX_VALUE)
    elif schema_type == 'long':
        return ((isinstance(datum, int) or isinstance(datum, long)) and not isinstance(datum, bool)
                and LONG_MIN_VALUE <= datum <= LONG_MAX_VALUE)
    elif schema_type in ['float', 'double']:
        return isinstance(datum, float)
    elif schema_type == 'fixed':
        return isinstance(datum, str) and len(datum) == expected_schema.size
    elif schema_type == 'enum':
        return datum in expected_schema.symbols
    elif schema_type == 'array':
        return (isinstance(datum, list) and
                False not in [validate(expected_schema.items, d) for d in datum])
    elif schema_type == 'map':
        return (isinstance(datum, dict) and
                False not in [isinstance(k, basestring) for k in datum.keys()] and
                False not in
                [validate(expected_schema.values, v) for v in datum.values()])
    elif schema_type in ['union', 'error_union']:
        return True in [validate(s, datum) for s in expected_schema.schemas]
    elif schema_type in ['record', 'error', 'request']:
        return (isinstance(datum, dict) and
                False not in
                [validate(f.type, datum.get(f.name)) for f in expected_schema.fields])
