import logging
import socket
import subprocess


def exec_cmd(command, args=None):

    command = [command]
    command = command + args.split(' ') if args else command

    print(command)

    proc = subprocess.Popen(command,  shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (out, err) = proc.communicate()

    if err:
        logging.error('%s  %s ' % (socket.gethostname(), err))

    return out.strip() if out else None


