'''
Created on Jan 6, 2016

@author: sumgowda
'''
from reportlab.graphics.charts.legends import Legend
from reportlab.graphics.charts.barcharts import VerticalBarChart
from core.reporting.pdf.charts import bar_chart_colors, colors
from reportlab.graphics.shapes import Drawing, _DrawingEditorMixin, String
from reportlab.graphics.charts.textlabels import Label
from reportlab.graphics.samples.excelcolors import *
from reportlab.graphics.charts.barcharts import HorizontalBarChart
class ClusteredBar(_DrawingEditorMixin, Drawing):
    def __init__(self, width=200, height=150, *args, **kw):
        Drawing.__init__(self, width, height, *args, **kw)
        self._add(self, HorizontalBarChart(), name='chart', validate=None, desc="The main chart")
        self.chart.width = 115
        self.chart.height = 80
        self.chart.x = 30
        self.chart.y = 40
        self.chart.bars[0].fillColor = color01
        self.chart.bars[1].fillColor = color02
        self.chart.bars[2].fillColor = color03
        self.chart.bars[3].fillColor = color04
        self.chart.bars[4].fillColor = color05
        self.chart.bars[5].fillColor = color06
        self.chart.bars[6].fillColor = color07
        self.chart.bars[7].fillColor = color08
        self.chart.bars[8].fillColor = color09
        self.chart.bars[9].fillColor = color10
        self.chart.fillColor = backgroundGrey
        self.chart.barLabels.fontName = 'Helvetica'
        self.chart.valueAxis.labels.fontName = 'Helvetica'
        self.chart.valueAxis.labels.fontSize = 6
        self.chart.valueAxis.forceZero = 1
        self.chart.data = [(100, 150, 180), (125, 180, 200)]
        self.chart.groupSpacing = 15
        self.chart.valueAxis.avoidBoundFrac = 1
        self.chart.valueAxis.gridEnd = 80
        self.chart.valueAxis.tickDown = 3
        self.chart.valueAxis.visibleGrid = 1
        self.chart.categoryAxis.categoryNames = ['North', 'South', 'Central']
        self.chart.categoryAxis.tickLeft = 3
        self.chart.categoryAxis.labels.fontName = 'Helvetica'
        self.chart.categoryAxis.labels.fontSize = 6
        self.chart.categoryAxis.labels.dx = -3
        self._add(self, Label(), name='Title', validate=None, desc="The title at the top of the chart")
        self.Title.fontName = 'Helvetica-Bold'
        self.Title.fontSize = 7
        self.Title.x = 100
        self.Title.y = 135
        self.Title._text = 'Chart Title'
        self.Title.maxWidth = 180
        self.Title.height = 20
        self.Title.textAnchor = 'middle'
        self._add(self, Legend(), name='Legend', validate=None, desc="The legend or key for the chart")
        self.Legend.colorNamePairs = [(color01, 'Widgets'), (color02, 'Sprockets')]
        self.Legend.fontName = 'Helvetica'
        self.Legend.fontSize = 7
        self.Legend.x = 153
        self.Legend.y = 85
        self.Legend.dxTextSpace = 5
        self.Legend.dy = 5
        self.Legend.dx = 5
        self.Legend.deltay = 5
        self.Legend.alignment = 'right'
        self._add(self, Label(), name='XLabel', validate=None, desc="The label on the horizontal axis")
        self.XLabel.fontName = 'Helvetica'
        self.XLabel.fontSize = 7
        self.XLabel.x = 85
        self.XLabel.y = 10
        self.XLabel.textAnchor = 'middle'
        self.XLabel.maxWidth = 100
        self.XLabel.height = 20
        self.XLabel._text = "X Axis"
        self._add(self, Label(), name='YLabel', validate=None, desc="The label on the vertical axis")
        self.YLabel.fontName = 'Helvetica'
        self.YLabel.fontSize = 7
        self.YLabel.x = 12
        self.YLabel.y = 80
        self.YLabel.angle = 90
        self.YLabel.textAnchor = 'middle'
        self.YLabel.maxWidth = 100
        self.YLabel.height = 20
        self.YLabel._text = "Y Axis"
        self._add(self, 0, name='preview', validate=None, desc=None)

class ClusteredColumn(_DrawingEditorMixin, Drawing):
    def __init__(self, width=200, height=150, *args, **kw):
        Drawing.__init__(self, width, height, *args, **kw)
        self._add(self, VerticalBarChart(), name='chart', validate=None, desc="The main chart")
        self.chart.width = 115
        self.chart.height = 80
        self.chart.x = 30
        self.chart.y = 40
        self.chart.bars[0].fillColor = color01
        self.chart.bars[1].fillColor = color02
        self.chart.bars[2].fillColor = color03
        self.chart.bars[3].fillColor = color04
        self.chart.bars[4].fillColor = color05
        self.chart.bars[5].fillColor = color06
        self.chart.bars[6].fillColor = color07
        self.chart.bars[7].fillColor = color08
        self.chart.bars[8].fillColor = color09
        self.chart.bars[9].fillColor = color10
        self.chart.fillColor = backgroundGrey
        self.chart.barLabels.fontName = 'Helvetica'
        self.chart.valueAxis.labels.fontName = 'Helvetica'
        self.chart.valueAxis.labels.fontSize = 7
        self.chart.valueAxis.forceZero = 1
        self.chart.data = [(100, 150, 180), (125, 180, 200)]
        self.chart.groupSpacing = 15
        self.chart.valueAxis.avoidBoundFrac = 1
        self.chart.valueAxis.gridEnd = 115
        self.chart.valueAxis.tickLeft = 3
        self.chart.valueAxis.visibleGrid = 1
        self.chart.categoryAxis.categoryNames = ['North', 'South', 'Central']
        self.chart.categoryAxis.tickDown = 3
        self.chart.categoryAxis.labels.fontName = 'Helvetica'
        self.chart.categoryAxis.labels.fontSize = 7
        self._add(self, Label(), name='Title', validate=None, desc="The title at the top of the chart")
        self.Title.fontName = 'Helvetica-Bold'
        self.Title.fontSize = 7
        self.Title.x = 100
        self.Title.y = 135
        self.Title._text = 'Chart Title'
        self.Title.maxWidth = 180
        self.Title.height = 20
        self.Title.textAnchor = 'middle'
        self._add(self, Legend(), name='Legend', validate=None, desc="The legend or key for the chart")
        self.Legend.colorNamePairs = [(color01, 'Widgets'), (color02, 'Sprockets')]
        self.Legend.fontName = 'Helvetica'
        self.Legend.fontSize = 7
        self.Legend.x = 153
        self.Legend.y = 85
        self.Legend.dxTextSpace = 5
        self.Legend.dy = 5
        self.Legend.dx = 5
        self.Legend.deltay = 5
        self.Legend.alignment = 'right'
        self._add(self, Label(), name='XLabel', validate=None, desc="The label on the horizontal axis")
        self.XLabel.fontName = 'Helvetica'
        self.XLabel.fontSize = 7
        self.XLabel.x = 85
        self.XLabel.y = 10
        self.XLabel.textAnchor = 'middle'
        self.XLabel.maxWidth = 100
        self.XLabel.height = 20
        self.XLabel._text = "X Axis"
        self._add(self, Label(), name='YLabel', validate=None, desc="The label on the vertical axis")
        self.YLabel.fontName = 'Helvetica'
        self.YLabel.fontSize = 7
        self.YLabel.x = 12
        self.YLabel.y = 80
        self.YLabel.angle = 90
        self.YLabel.textAnchor = 'middle'
        self.YLabel.maxWidth = 100
        self.YLabel.height = 20
        self.YLabel._text = "Y Axis"
        self._add(self, 0, name='preview', validate=None, desc=None)
        
class PimcoVerticalBarChart(_DrawingEditorMixin,Drawing):

    def __init__(self , **kwargs):
        width , height = 400,400
        if 'width' in kwargs:
            width = kwargs['width']
        if 'height' in kwargs:
            height = kwargs['height']

        #calcualte % by which all values msut be reduced
        percent = ( ( width / 400) + ( height ) / 400 ) / 2
        apply(Drawing.__init__,(self,width,height))
        self.__legend = None
        self.__label = None
        self._add(self,VerticalBarChart(),name='chart',validate=None,desc=None)
        
        self.chart.y = height * .20
        self.chart.width = width * .80
        self.chart.height = height * .80
        # 20% goes to legend
        self.chart.x = width * .10
        
        # self.categoryAxis.labels.boxAnchor = 'ne'
        self.chart.valueAxis.visibleAxis = 1
        self.chart.valueAxis.valueMin = 0
        self.chart.barLabelFormat = '%d'
        self.chart.barLabels.dx = 0
        self.chart.barLabels.dy = 10 * percent
        self.chart.barLabels.fontSize = 10 * percent
        self.chart.categoryAxis.visibleTicks = 1
        self.chart.categoryAxis.labels.dx = -4
        self.chart.categoryAxis.labels.dy = -4
        self.chart.categoryAxis.labels.angle = 45
        self.chart.barWidth = 2
        self.chart.categoryAxis.labels.fontSize = 10 * percent
        self.chart.valueAxis.labels.fontSize = 10 * percent
        self.chart.valueAxis.strokeWidth = 0
        self.chart.categoryAxis.strokeWidth = 0
        self.chart.bars.strokeWidth = 0
        items = bar_chart_colors.split()
        for i, color_name in enumerate(items):
            self.chart.bars[i].fillColor = colors.toColor(color_name)
        
        # legend
        self._add(self,Legend(),name='legend',validate=None,desc=None)
        self.legend.alignment = 'right'
        self.legend.columnMaximum = 1
        self.legend.dx = 20 * percent
        self.legend.dxTextSpace = 4
        self.legend.dy = 10 * percent
        self.legend.fontSize = 10 * percent
        self.legend.strokeColor = None
        self.legend.strokeWidth = 0
        self.legend.subCols.minWidth = 20
        self.legend.variColumn = 1
        self.legend.x = width * .05
        self.legend.y = height * .08
        self.legend.deltay = 20 
        
    def set_legends(self, legend):
        self.__legend = legend

    def get_legends(self):
        return self.__legend

    def set_label(self, label):
        self.__label = label

    def get_label(self):
        return self.__label
    
    def setData(self , df, properties):
        legendNames = df.columns
        chartData =  []
        for col in df.columns:
            chartData.append( df[col].tolist())
        self.chart.data = chartData
        self.chart.categoryAxis.categoryNames = df.index.astype(str).tolist()
        indexName = df.index.name
        items = bar_chart_colors.split()
        for i, color_name in enumerate(items):
            self.legend.colorNamePairs = [ (colors.toColor(items[i]) , legndName) for i , legndName in enumerate(legendNames) ]
        self.chart._flipXY = 0
        if 'type' in properties:
            if properties['type'] == 'horizontal':
                self.chart._flipXY = 1
                
class PimcoHorizontalBarChart(_DrawingEditorMixin,Drawing):

    def __init__(self , **kwargs):
        width , height = 400,400
        if 'width' in kwargs:
            width = kwargs['width']
        if 'height' in kwargs:
            height = kwargs['height']
            
        apply(Drawing.__init__,(self,width,height))
        self.__legend = None
        self.__label = None
        self._add(self,HorizontalBarChart(),name='chart',validate=None,desc=None)
        self.chart.x = 30
        self.chart.y = 30
        self.chart.width = width * .80
        self.chart.height = height -30
        
        # self.categoryAxis.labels.boxAnchor = 'ne'
        self.chart.valueAxis.visibleAxis = 1
        self.chart.valueAxis.valueMin = 0
        self.chart.barLabelFormat = '%0.2f'
        self.chart.barLabels.dx = 6
        self.chart.barLabels.dy = 1
        self.chart.barLabels.fontSize = 6
        self.chart.categoryAxis.visibleTicks = 1
        self.chart.categoryAxis.labels.dx = -10
        self.chart.categoryAxis.labels.dy = -10
        self.chart.categoryAxis.labels.angle = 45
        self.chart.barWidth = 3
        self.chart.categoryAxis.labels.fontSize = 7
        items = bar_chart_colors.split()
        for i, color_name in enumerate(items):
            self.chart.bars[i].fillColor = colors.toColor(color_name)
        
        
        
        # legend
        self._add(self,Legend(),name='legend',validate=None,desc=None)
        self.legend.alignment = 'right'
        self.legend.columnMaximum = 10
        self.legend.dx = 20
        self.legend.dxTextSpace = 8
        self.legend.dy = 6
        self.legend.fontSize = 10
        self.legend.strokeColor = None
        self.legend.strokeWidth = 0
        self.legend.subCols.minWidth = 55
        self.legend.variColumn = 1
        self.legend.x = width * .80
        self.legend.y = self.chart.height
        self.legend.deltay = 10
        

    def set_legends(self, legend):
        self.__legend = legend

    def get_legends(self):
        return self.__legend

    def set_label(self, label):
        self.__label = label

    def get_label(self):
        return self.__label
    
    def setData(self , df, properties):
        legendNames = df.columns
        chartData =  []
        for col in df.columns:
            chartData.append( df[col].tolist())
        self.chart.data = chartData
        self.chart.categoryAxis.categoryNames = df.index.astype(str).tolist()
        items = bar_chart_colors.split()
        for i, color_name in enumerate(items):
            self.legend.colorNamePairs = [ (colors.toColor(items[i]) , legndName) for i , legndName in enumerate(legendNames) ]
            
from reportlab.platypus.flowables import Flowable
from reportlab.lib import colors
class TableDataBar(Flowable):
    def __init__(self, width, height=0, maxvalue=100 , minvalue=0 , value=50, color='red', fontsize=7, tableStyle=None):
        Flowable.__init__(self)
        self.width = width
        self.height = height
        self.value = value
        self.maxvalue = maxvalue
        self.minvalue = minvalue
        self.fontsize = fontsize
        self.tableStyle = tableStyle or [ ]
    #----------------------------------------------------------------------
    def __repr__(self):
        return "Line(w=%s)" % self.width
 
    #----------------------------------------------------------------------
    def draw(self):
        '''
        when tableStyle exists need to calculate the width and height accordingly
        '''
        
        # self.canv.linearGradient(0, 0,self.width, self.height, (colors.red, colors.white))
        self.canv.setFillColor(colors.lightblue)
        try:
            # calculate length to draw
            widthToDraw = self.width * (self.value - self.minvalue) / (self.maxvalue - self.minvalue) 
            self.canv.rect(0, 0, widthToDraw, self.height , fill=1, stroke=False)
            # self.canv.linearGradient(0, 0,widthToDraw, self.height, (colors.red, colors.white), extend=False)
            if self.value:
                self.canv.setFillColor(colors.black)
                self.canv.setFontSize(self.fontsize)
                self.canv.drawString(self.width / 3, self.height / 3 , str(self.value))
        except:
            print "Object cannot be rendered"
        
