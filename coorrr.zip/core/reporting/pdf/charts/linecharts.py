'''
Created on Dec 8, 2015

@author: sumgowda
'''
from reportlab.graphics.charts.axes import XValueAxis, YValueAxis, AdjYValueAxis, NormalDateXValueAxis
from reportlab.graphics.charts.lineplots import LinePlot , AreaLinePlot

from reportlab.graphics.charts.textlabels import Label
from reportlab.graphics.charts.utils import seconds2str

from reportlab.graphics.charts.piecharts import Pie , LegendedPie
from reportlab.graphics.shapes import Group
from core.reporting.pdf.charts import line_chart_colors, colors, timeto2str, mkTimeTuple , default_font_size , \
            default_font_name , default_chart_font_size
from reportlab.graphics.charts.axes import XValueAxis, YValueAxis, AdjYValueAxis, NormalDateXValueAxis
from reportlab.graphics.charts.legends import Legend
from reportlab.graphics.shapes import Drawing, _DrawingEditorMixin, String 
from reportlab.graphics.charts.lineplots import ScatterPlot
from reportlab.graphics.samples.excelcolors import *
from reportlab.graphics.widgets.markers import makeMarker
from core.reporting.pdf.charts import get_x_ticks, mkTimeTuple, getYearEndXticks, timeto2strMonthYear , timeto2strYear
from reportlab.graphics.charts.utils import mktime
from bs4 import BeautifulSoup , BeautifulStoneSoup  
from core.reporting.parser import isValid
from core.reporting.parser import parseChartStyleElements
    
class PimcoLineChart(_DrawingEditorMixin, Drawing):
    
    def __init__(self, width=200, height=150,xmlStyleTag= None, *args, **kw):
        Drawing.__init__(self, width, height, *args, **kw)
        self._add(self, width, name='drawwidth', validate=None, desc="TotalWidth of Draw Object")
        self._add(self, height, name='drawheight', validate=None, desc="Total Height of Draw Object")
        self._add(self, LinePlot(), name='chart', validate=None, desc="The main chart")
        colorItems = line_chart_colors.split()
        self._add(self, colorItems, name='colorItems', validate=None, desc="List Of color Attributes")
        self._add(self, None, name='Legend', validate=None, desc="The legend or key for the chart")
        self.chart.__legend = None
        self.chart.__label = None
        
        self.chart.x = .10 * width
        self.chart.y = .20 * height
        self.chart.width = width * .80
        self.chart.height = height * 0.70
        
        self.chart.lineLabelNudge = 0
        # self.yValueAxis.valueMin = 0
        self.chart.xValueAxis.joinAxisMode = "bottom"
        self.chart.yValueAxis.joinAxisMode = "left"
        self.chart.yValueAxis.labels.fontSize = default_chart_font_size
        # self.yValueAxis.labelTextFormat = format_data_axis
        self.chart.xValueAxis.labels.dy = -10
        self.chart.xValueAxis.labels.dx = -10
        self.chart.xValueAxis.strokeColor = colors.lightgrey
        self.chart.yValueAxis.strokeColor = colors.lightgrey
        
        self.chart.xValueAxis.strokeWidth = 0.25
        self.chart.yValueAxis.strokeWidth = 0.25
        self.chart.yValueAxis.tickLeft = 2
        self.chart.yValueAxis.tickRight = 0
        self.chart.yValueAxis.visibleGrid = False
        self.chart.xValueAxis.visibleGrid = False
        self.chart.yValueAxis.gridStrokeWidth = 0.25
        self.chart.yValueAxis.gridStrokeColor = colors.lightgrey
        self.chart.xValueAxis.gridStrokeWidth = 0.25
        self.chart.xValueAxis.gridStrokeColor = colors.lightgrey
        
        self.chart.joinedLines = 1
        self.chart.xValueAxis.labels.angle = 20
        self.chart.xValueAxis.valueStep = 1
        self.chart.xValueAxis.labelTextFormat = timeto2str
        self.chart.xValueAxis.minimumTickSpacing = 0
        self.chart.xValueAxis.strokeWidth = 0
        self.chart.xValueAxis.origShiftIPC = 0
        self.chart.xValueAxis.origShiftMin = 0
        self.chart.xValueAxis.maximumTicks = 10
        self.chart.xValueAxis.labels.fontSize = default_chart_font_size
        
        # enable grid
        for i, color_name in enumerate(self.colorItems):
            self.chart.lines[i].strokeColor = colors.toColor(color_name)
    
    """
    """
    def setTitle(self , title="", x1=0 , y1=0):
        self._add(self, Label(), name='Title', validate=None, desc="The title at the top of the chart")
        self.Title.fontName = default_font_name
        self.Title.fontSize = default_chart_font_size
        self.Title.y = self.drawheight * .95
        self.Title._text = title
        self.Title.x = self.drawwidth * .50
        self.Title.maxWidth = self.chart.width
        self.Title.height = 5
        self.Title.textAnchor = 'middle'
    
    def setLegend(self, legendNames=[]):
        self._add(self, ChartLegend(), name='Legend', validate=None, desc="The legend or key for the chart")
        items = self.colorItems
        self.Legend.colorNamePairs = [ (colors.toColor(items[i]) , legndName) for i , legndName in enumerate(legendNames) ]
        self.Legend.fontName = default_font_name
        self.Legend.fontSize = default_chart_font_size
        self.Legend.x = self.drawwidth * .30
        self.Legend.y = self.drawheight * .10
    
    def setData(self, pdDataFrame, properties = {}):
        table_data = [ ]
        # filter if any point has nan
        pdDataFrame = pdDataFrame.dropna(thresh=len(pdDataFrame.columns))
        
        series = properties.get('series', [])
        if series:
            drop_labels = []
            for each in pdDataFrame.columns:
                if each not in series:
                    drop_labels.append(each)
            
            if drop_labels:
                for col in drop_labels: 
                    del pdDataFrame[col]
        
        index_data = pdDataFrame.index
        dateformatfunc = timeto2strMonthYear
        if 'xaxisformat' in properties:
            axisformat = properties['xaxisformat']
            if axisformat == 'YYYY':
                dateformatfunc = timeto2strYear
        
        catNames = [ val.strftime("%d/%m/%Y") for val in index_data if val.year > 1970]
        indexCatNames = [ mktime(mkTimeTuple(val)) for val in catNames ]
            
        
        tt = mkTimeTuple(catNames[0])
        start = mktime(mkTimeTuple(catNames[0]))
        end = mktime(mkTimeTuple(catNames[-1]))
        self.chart.xValueAxis.valueMin = start
        self.chart.xValueAxis.valueMax = end
        self.chart.xValueAxis.labelTextFormat = dateformatfunc
        # self.chart.xValueAxis.valueSteps = getYearEndXticks(catNames)
        xticks = get_x_ticks(catNames)
        self.chart.xValueAxis.valueSteps = xticks
        
        if 'skipxaxis' in properties:
           self.chart.xValueAxis.visibleAxis = 0
           self.chart.xValueAxis.visibleTicks = 0
           self.chart.xValueAxis.visible = 0
        # check if data has nan or invalid values
        
        yMax = pdDataFrame.max(numeric_only=True).max()
        yMin = pdDataFrame.min(numeric_only=True).max()
        
        # self.chart.yValueAxis.valueSteps = 
        self.chart.yValueAxis.valueMin = yMin
        self.chart.yValueAxis.valueMax = yMax
        
        for column in pdDataFrame.columns:
            table_data.append(zip(indexCatNames, pdDataFrame[column]))
        
        self.chart.data = table_data
        
        legend = pdDataFrame.columns
        
        
        if 'hidelegends' not in properties or not properties['hidelegends']:
            self.setLegend(legend)
    
    def setYAxisAlignment(self, align='left'):
        if align and align == 'right':
            self.chart.yValueAxis.joinAxisMode = "right"
            self.chart.yValueAxis.tickRight = 5
            self.chart.yValueAxis.tickLeft = 0
            self.chart.yValueAxis.labels.dx = 10
            self.chart.yValueAxis.visibleGrid = True
            self.chart.yValueAxis.gridStrokeDashArray = (1, 1)
            
    """
    Set the properties needed for chart rendering, this will be custom list of properties
    """
    def setProperties(self, properties={}):
        self._add(self, properties, name='chartProperties', validate=None, desc="Properties of your chart, defined in template ")
        if 'YAXISALIGN' in properties:
            self.setYAxisAlignment(properties['YAXISALIGN'])
            
    
        
""" 
Rendes an area chart
Templaets
"""
class PimcoAreaChart(PimcoLineChart):
    '''we're given data in the form [(X1,Y11,..Y1M)....(Xn,Yn1,...YnM)]'''  # '
    def __init__(self, width=200, height=150, xmlStyleTag = None,*args, **kw):
        PimcoLineChart.__init__(self, width=width, height=height, *args, **kw)
        self.chart._inFill = 1
        # self.chart.reversePlotOrder = 1
        
        # self.data = [(1,20,100,30),(2,11,50,15),(3,15,70,40)]
    
            
class PimcoAreaLineChart(PimcoAreaChart):
    
    def __init__(self, width=200, height=150, *args, **kw):
        PimcoAreaChart.__init__(self, width, height, *args, **kw)
        self._add(self, PimcoLineChart(width, height, *args, **kw), name='LineChart', validate=None, desc="The Area chart")
        
    def setData(self, pdDataFrame):
        colorItems = line_chart_colors.split()
        # Every column should have data for charts
        pdDataFrame = pdDataFrame.dropna(thresh=len(pdDataFrame.columns))
        index_data = pdDataFrame.index 
        catNames = [ val.strftime("%d/%m/%Y") for val in index_data if val.year > 1970]
        indexCatNames = [ mktime(mkTimeTuple(val)) for val in catNames ]
        tt = mkTimeTuple(catNames[0])
        start = mktime(mkTimeTuple(catNames[0]))
        end = mktime(mkTimeTuple(catNames[-1]))
        self.chart.xValueAxis.valueMin = start
        self.chart.xValueAxis.valueMax = end
        yMax = pdDataFrame.max(numeric_only=True).max()
        yMin = pdDataFrame.min(numeric_only=True).max()
        
        # self.chart.yValueAxis.valueSteps = 
        self.LineChart.chart.yValueAxis.valueMin = yMin
        self.LineChart.chart.yValueAxis.valueMax = yMax
        # self.chart.yValueAxis.valueSteps = [ ]
        self.chart.yValueAxis.valueMin = yMin
        self.chart.yValueAxis.valueMax = yMax
        
        self.chart.xValueAxis.valueMin = start
        self.chart.xValueAxis.valueMax = end
        self.chart.xValueAxis.visibleTicks = 0
        self.chart.xValueAxis.visibleLabels = 0
        self.chart.yValueAxis.visibleTicks = 0
        self.chart.yValueAxis.visibleLabels = 0
        table_data = [ ]
        colorIdx = 0
        columnsVisited = []
        idx = 0
        if 'areachartcolumns' in self.chartProperties:
            for idx, column in enumerate(self.chartProperties['areachartcolumns'].split(",")):
                table_data.append(zip(indexCatNames, pdDataFrame[column]))
                self.chart.lines[idx].strokeColor = colors.toColor(self.colorItems[colorIdx])
                colorIdx += 1
                columnsVisited.append(column)
            self.chart.data = table_data
        idy = 0
        lineData = []
        if 'linechartcolumns' in self.chartProperties:
            for idy, column in enumerate(self.chartProperties['linechartcolumns'].split(",")):
                lineData.append(zip(indexCatNames, pdDataFrame[column]))
                self.LineChart.chart.lines[idy].strokeColor = colors.toColor(self.colorItems[colorIdx])
                colorIdx += 1
                columnsVisited.append(column)
            self.LineChart.chart.data = lineData
        
        # if arear and line chart columns are not specified make everythign as aear chart 
        for column in pdDataFrame.columns:
            if column not in columnsVisited:
                table_data.append(zip(indexCatNames, pdDataFrame[column]))
                self.chart.lines[idx].strokeColor = colors.toColor(self.colorItems[colorIdx])
                idx += 1
                colorIdx += 1
            
        self.chart.data = table_data
            
        self.chart.xValueAxis.labelTextFormat = timeto2strMonthYear
        displayXTicks = getYearEndXticks(catNames)
        displayXTicks = get_x_ticks(catNames)
        self.chart.xValueAxis.valueSteps = displayXTicks
        self.LineChart.chart.xValueAxis.valueSteps = displayXTicks 
        self.LineChart.chart.xValueAxis.labelTextFormat = timeto2strMonthYear 
        legend = pdDataFrame.columns
        if not self.Legend:
            self.setLegend(legend)
            
    def setYAxisAlignment(self, align='left'):
        if align and align == 'right':
            self.chart.yValueAxis.visible = False
            self.LineChart.chart.yValueAxis.joinAxisMode = "right"
            self.LineChart.chart.yValueAxis.tickRight = 5
            self.LineChart.chart.yValueAxis.tickLeft = 0
            self.LineChart.chart.yValueAxis.labels.dx = 15
            self.LineChart.chart.yValueAxis.visibleGrid = True
            self.LineChart.chart.yValueAxis.gridStrokeDashArray = (1, 1)            
        if align and align == 'both':
            self.chart.yValueAxis.visible = True
            self.LineChart.chart.yValueAxis.joinAxisMode = "right"
            self.LineChart.chart.yValueAxis.tickRight = 5
            self.LineChart.chart.yValueAxis.tickLeft = 0
            self.LineChart.chart.yValueAxis.labels.dx = 15
            self.LineChart.chart.yValueAxis.visibleGrid = True
            self.LineChart.chart.yValueAxis.gridStrokeDashArray = (1, 1)
    
    '''
    Call this to set properties
    
    '''
    def setProperties(self, properties={}):
        self._add(self, properties, name='chartProperties', validate=None, desc="Properties of your chart, defined in template ")
       
        if 'colors' in properties:
            colorItems = properties['colors'].split()
            self._add(self, colorItems, name='colorItems', validate=None, desc="List Of color Attributes")
            
        if 'YAXISALIGN' in properties:
            self.setYAxisAlignment(properties['YAXISALIGN'])
            
from reportlab.graphics.charts.legends import LineLegend
class ChartLegend(LineLegend):

    def __init__(self, legend_names=[ ]):
        LineLegend.__init__(self)
        self.alignment = 'right'
        self.x = 30
        self.y = 0
        self.dy = 2
        self.deltax = 30
        self.deltay = 0
        self.fontSize = 8
        self.dxTextSpace = 4
        self.columnMaximum = 1
        self.variColumn = 1
        # items = '0xFF0000 0x0000FF 0x00FF00 0xFF9900 0xCC00CC 0x00CCCC 0x33FF00 0x990000 0x000066 0x555555'.split()[:len(legend_names )]
        items = line_chart_colors.split()[:len(legend_names)]
        legend_dict = dict(zip(items , legend_names))
        if len(legend_names) > 3 : self.columnMaximum = 3
        
        items = map(lambda i: (colors.toColor(i), str(legend_dict[i])), items)
        
        self.colorNamePairs = items
        
    def draw(self):
        # print self.colorNamePairs
        if self.colorNamePairs:
            return LineLegend.draw(self)
        return Group()

class PimcoLineChartTwoAxis(PimcoLineChart):

    def __init__(self , width, height, xmlStyleTag = None ,*args, **kw):
        PimcoLineChart.__init__(self, width=width, height=height, *args, **kw)
        #self._add(self, PimcoLineChart(), name='leftchart', validate=None, desc="The main chart")
        self._add(self, PimcoLineChart(width=width, height=height, *args, **kw), name='rightchart', validate=None, desc="The main chart")
        self._add(self, xmlStyleTag, name='xmlStyleTag', validate=None, desc="Xml Tag that contains styles")
        # move y-axis to right
        self.rightchart.chart.yValueAxis.joinAxisMode = "right"
        # make x-axis go to the bottom
        self.rightchart.chart.xValueAxis.joinAxisMode = "bottom"
        # turn off ticks
        self.rightchart.chart.yValueAxis.tickRight = 2
        self.rightchart.chart.yValueAxis.tickLeft = 0
        self.rightchart.chart.yValueAxis.labels.dx = 10
        self.rightchart.chart.yValueAxis.visibleGrid = False
        self.rightchart.chart.xValueAxis.visibleGrid = False
        self.apply_custom_config(kw)
        
    def apply_custom_config(self, kwargs):
        self.chart.yValueAxis.labels.fontSize = default_chart_font_size
        #self.rightchart.chart.yValueAxis.labels.fontSize = default_chart_font_size
        self.chart.yValueAxis.labels.fontSize = default_chart_font_size
        self.chart.xValueAxis.labels.fontSize = default_chart_font_size
        
        if 'fontSize' in kwargs:
            fontSize = int(kwargs['fontSize'])
            self.rightaxis.yValueAxis.labels.fontSize = fontSize
            self.yValueAxis.labels.fontSize = fontSize
            self.xValueAxis.labels.fontSize = fontSize
        
        if 'x' in kwargs:
            self.x = kwargs['x']
        if 'y' in kwargs:
            self.y = kwargs['y']
        
        if 'width' in kwargs:
            self.width = kwargs['width']
        if 'height' in kwargs:
            self.height = kwargs['height']
                
    def set_legends(self, legend):
        self.__legend = legend

    def get_legends(self):
        return self.__legend

    def set_label(self, label):
        self.__label = label
        
    def setData(self,df,properties):
        properties = {}
        if hasattr(self,'xmlStyleTag'):
            properties = parseChartStyleElements(self.xmlStyleTag)
        colorItems = line_chart_colors.split()
        noOfLeftColors  = 0
        legendNames = []
        leftProperties = {}
        rightProperties = {}
        if 'xaxisformat' in properties:
            rightProperties['xaxisformat'] = properties['xaxisformat']
            leftProperties['xaxisformat'] = properties['xaxisformat']
            
        if 'leftseries' in properties:
            
            leftProperties['series'] = properties['leftseries']
            legendNames += properties['leftseries']
            noOfLeftColors = len(properties['leftseries'])
            leftProperties['hidelegends'] = True
            PimcoLineChart.setData(self,df,leftProperties)
            
        if 'rightseries' in properties:
            
            rightProperties['series'] = properties['rightseries']
            rightProperties['hidelegends'] = True
            legendNames += properties['rightseries']
            rightProperties['skipxaxis'] = True
            
            for i, color_name in enumerate(self.rightchart.colorItems[noOfLeftColors:]):
                self.rightchart.chart.lines[i].strokeColor = colors.toColor(color_name)
            self.rightchart.setData(df,rightProperties)
        
        if 'title' in properties:
            PimcoLineChart.setTitle(self, properties['title'])
            
        PimcoLineChart.setLegend(self,legendNames)


class LineChartWithMarkers(_DrawingEditorMixin, Drawing):
    def __init__(self, width=200, height=150, *args, **kw):
        Drawing.__init__(self, width, height, *args, **kw)
        self._add(self, LinePlot(), name='chart', validate=None, desc="The main chart")
        self.chart.width = 115
        self.chart.height = 80
        self.chart.x = 30
        self.chart.y = 40
        self.chart.lines[0].strokeColor = color01
        self.chart.lines[1].strokeColor = color02
        self.chart.lines[2].strokeColor = color03
        self.chart.lines[3].strokeColor = color04
        self.chart.lines[4].strokeColor = color05
        self.chart.lines[5].strokeColor = color06
        self.chart.lines[6].strokeColor = color07
        self.chart.lines[7].strokeColor = color08
        self.chart.lines[8].strokeColor = color09
        self.chart.lines[9].strokeColor = color10
        self.chart.lines[0].symbol = makeMarker('FilledSquare')
        self.chart.lines[1].symbol = makeMarker('FilledDiamond')
        self.chart.lines[2].symbol = makeMarker('FilledStarFive')
        self.chart.lines[3].symbol = makeMarker('FilledTriangle')
        self.chart.lines[4].symbol = makeMarker('FilledCircle')
        self.chart.lines[5].symbol = makeMarker('FilledPentagon')
        self.chart.lines[6].symbol = makeMarker('FilledStarSix')
        self.chart.lines[7].symbol = makeMarker('FilledHeptagon')
        self.chart.lines[8].symbol = makeMarker('FilledOctagon')
        self.chart.lines[9].symbol = makeMarker('FilledCross')
        self.chart.fillColor = backgroundGrey
        self.chart.lineLabels.fontName = default_font_name
        self.chart.xValueAxis.labels.fontName = default_font_name
        self.chart.xValueAxis.labels.fontSize = 7
        self.chart.xValueAxis.forceZero = 0
        self.chart.data = [((0, 50), (100, 100), (200, 200), (250, 210), (300, 300), (400, 500)), ((0, 150), (100, 200), (200, 300), (250, 200), (300, 400), (400, 600))]
        self.chart.xValueAxis.avoidBoundFrac = 1
        self.chart.xValueAxis.gridEnd = 115
        self.chart.xValueAxis.tickDown = 3
        self.chart.xValueAxis.visibleGrid = 1
        self.chart.yValueAxis.tickLeft = 3
        self.chart.yValueAxis.labels.fontName = default_font_name
        self.chart.yValueAxis.labels.fontSize = 7
        self._add(self, Label(), name='Title', validate=None, desc="The title at the top of the chart")
        self.Title.fontName = default_font_name
        self.Title.fontSize = 7
        self.Title.x = 100
        self.Title.y = 135
        self.Title._text = 'Chart Title'
        self.Title.maxWidth = 180
        self.Title.height = 20
        self.Title.textAnchor = 'middle'
        self._add(self, Legend(), name='Legend', validate=None, desc="The legend or key for the chart")
        self.Legend.colorNamePairs = [(color01, 'Widgets'), (color02, 'Sprockets')]
        self.Legend.fontName = default_font_name
        self.Legend.fontSize = 7
        self.Legend.x = 153
        self.Legend.y = 85
        self.Legend.dxTextSpace = 5
        self.Legend.dy = 5
        self.Legend.dx = 5
        self.Legend.deltay = 5
        self.Legend.alignment = 'right'
        self._add(self, Label(), name='XLabel', validate=None, desc="The label on the horizontal axis")
        self.XLabel.fontName = 'Helvetica'
        self.XLabel.fontSize = 7
        self.XLabel.x = 85
        self.XLabel.y = 10
        self.XLabel.textAnchor = 'middle'
        self.XLabel.maxWidth = 100
        self.XLabel.height = 20
        self.XLabel._text = "X Axis"
        self._add(self, Label(), name='YLabel', validate=None, desc="The label on the vertical axis")
        self.YLabel.fontName = 'Helvetica'
        self.YLabel.fontSize = 7
        self.YLabel.x = 12
        self.YLabel.y = 80
        self.YLabel.angle = 90
        self.YLabel.textAnchor = 'middle'
        self.YLabel.maxWidth = 100
        self.YLabel.height = 20
        self.YLabel._text = "Y Axis"
        self.chart.yValueAxis.forceZero = 1
        self.chart.xValueAxis.forceZero = 1
        self._add(self, 0, name='preview', validate=None, desc=None)
        
class ScatterLines(_DrawingEditorMixin, Drawing):
    def __init__(self, width=200, height=150, *args, **kw):
        Drawing.__init__(self, width, height, *args, **kw)
        self._add(self, ScatterPlot(), name='chart', validate=None, desc="The main chart")
        self.chart.width = 115
        self.chart.height = 800
        self.chart.x = 30
        self.chart.y = 40
        self.chart.lines[0].strokeColor = color01
        self.chart.lines[1].strokeColor = color02
        self.chart.lines[2].strokeColor = color03
        self.chart.lines[3].strokeColor = color04
        self.chart.lines[4].strokeColor = color05
        self.chart.lines[5].strokeColor = color06
        self.chart.lines[6].strokeColor = color07
        self.chart.lines[7].strokeColor = color08
        self.chart.lines[8].strokeColor = color09
        self.chart.lines[9].strokeColor = color10
        self.chart.lines[0].symbol = None
        self.chart.lines[1].symbol = None
        self.chart.lines[2].symbol = None
        self.chart.lines[3].symbol = None
        self.chart.lines[4].symbol = None
        self.chart.lines[5].symbol = None
        self.chart.lines[6].symbol = None
        self.chart.lines[7].symbol = None
        self.chart.lines[8].symbol = None
        self.chart.lines[9].symbol = None
        self.chart.fillColor = backgroundGrey
        self.chart.lineLabels.fontName = 'Helvetica'
        self.chart.xValueAxis.labels.fontName = 'Helvetica'
        self.chart.xValueAxis.labels.fontSize = 7
        self.chart.xValueAxis.forceZero = 0
        self.chart.data = [((100, 100), (200, 200), (250, 210), (300, 300), (400, 500)), ((100, 200), (200, 300), (250, 200), (300, 400), (400, 600))]
        self.chart.xValueAxis.avoidBoundFrac = 1
        self.chart.xValueAxis.gridEnd = 115
        self.chart.xValueAxis.tickDown = 3
        self.chart.xValueAxis.visibleGrid = 1
        self.chart.yValueAxis.tickLeft = 3
        self.chart.yValueAxis.labels.fontName = 'Helvetica'
        self.chart.yValueAxis.labels.fontSize = 7
        self._add(self, Label(), name='Title', validate=None, desc="The title at the top of the chart")
        self.Title.fontName = 'Helvetica-Bold'
        self.Title.fontSize = 7
        self.Title.x = 100
        self.Title.y = 135
        self.Title._text = 'Chart Title'
        self.Title.maxWidth = 180
        self.Title.height = 20
        self.Title.textAnchor = 'middle'
        self._add(self, Legend(), name='Legend', validate=None, desc="The legend or key for the chart")
        self.Legend.colorNamePairs = [(color01, 'Widgets'), (color02, 'Sprockets')]
        self.Legend.fontName = 'Helvetica'
        self.Legend.fontSize = 7
        self.Legend.x = 153
        self.Legend.y = 85
        self.Legend.dxTextSpace = 5
        self.Legend.dy = 5
        self.Legend.dx = 5
        self.Legend.deltay = 5
        self.Legend.alignment = 'right'
        self.chart.lineLabelFormat = None
        self.chart.xLabel = 'X Axis'
        self.chart.y = 30
        self.chart.yLabel = 'Y Axis'
        self.chart.yValueAxis.gridEnd = 115
        self.chart.yValueAxis.visibleGrid = 1
        self.chart.yValueAxis.labelTextFormat = '%d'
        self.chart.yValueAxis.forceZero = 1
        self.chart.xValueAxis.forceZero = 1
        self.chart.joinedLines = 1
        self._add(self, 0, name='preview', validate=None, desc=None)


class Scatter(_DrawingEditorMixin, Drawing):
    def __init__(self, width=200, height=150, *args, **kw):
        Drawing.__init__(self, width, height, *args, **kw)
        self._add(self, ScatterPlot(), name='chart', validate=None, desc="The main chart")
        self.chart.width = 115
        self.chart.height = 80
        self.chart.x = 30
        self.chart.y = 40
        self.chart.lines[0].strokeColor = color01
        self.chart.lines[1].strokeColor = color02
        self.chart.lines[2].strokeColor = color03
        self.chart.lines[3].strokeColor = color04
        self.chart.lines[4].strokeColor = color05
        self.chart.lines[5].strokeColor = color06
        self.chart.lines[6].strokeColor = color07
        self.chart.lines[7].strokeColor = color08
        self.chart.lines[8].strokeColor = color09
        self.chart.lines[9].strokeColor = color10
        self.chart.fillColor = backgroundGrey
        self.chart.lineLabels.fontName = 'Helvetica'
        self.chart.xValueAxis.labels.fontName = 'Helvetica'
        self.chart.xValueAxis.labels.fontSize = 7
        self.chart.xValueAxis.forceZero = 0
        self.chart.data = [((100, 100), (200, 200), (250, 210), (300, 300), (400, 500)), ((100, 200), (200, 300), (250, 200), (300, 400), (400, 600))]
        self.chart.xValueAxis.avoidBoundFrac = 1
        self.chart.xValueAxis.gridEnd = 115
        self.chart.xValueAxis.tickDown = 3
        self.chart.xValueAxis.visibleGrid = 1
        self.chart.yValueAxis.tickLeft = 3
        self.chart.yValueAxis.labels.fontName = 'Helvetica'
        self.chart.yValueAxis.labels.fontSize = 7
        self._add(self, Label(), name='Title', validate=None, desc="The title at the top of the chart")
        self.Title.fontName = 'Helvetica-Bold'
        self.Title.fontSize = 7
        self.Title.x = 100
        self.Title.y = 135
        self.Title._text = 'Chart Title'
        self.Title.maxWidth = 180
        self.Title.height = 20
        self.Title.textAnchor = 'middle'
        self._add(self, Legend(), name='Legend', validate=None, desc="The legend or key for the chart")
        self.Legend.colorNamePairs = [(color01, 'Widgets'), (color02, 'Sprockets')]
        self.Legend.fontName = 'Helvetica'
        self.Legend.fontSize = 7
        self.Legend.x = 153
        self.Legend.y = 85
        self.Legend.dxTextSpace = 5
        self.Legend.dy = 5
        self.Legend.dx = 5
        self.Legend.deltay = 5
        self.Legend.alignment = 'right'
        self.chart.lineLabelFormat = None
        self.chart.xLabel = 'X Axis'
        self.chart.y = 30
        self.chart.yLabel = 'Y Axis'
        self.chart.yValueAxis.labelTextFormat = '%d'
        self.chart.yValueAxis.forceZero = 1
        self.chart.xValueAxis.forceZero = 1


        self._add(self, 0, name='preview', validate=None, desc=None)
