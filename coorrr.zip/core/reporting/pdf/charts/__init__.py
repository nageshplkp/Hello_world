from reportlab.lib import colors

'''
Define all the constants and defaults in this file, and then import them where ever needed 
'''

default_font_name = 'Times-Roman'
default_font_size = 8
default_chart_font_size = 6
bar_chart_colors = '0xB14949 0xE5EAEC 0x5C97CC 0xE7A614 0x959C51 0xB15C12 0x948671 0x174A7C 0x629081 0xAD8505 0x58595B 0x8E0C3A 0xC8B18B 0x5E9732 0x008576'
#line_chart_colors = '0xB14949 0xE5EAEC 0x5C97CC 0xE7A614 0x959C51 0xB15C12 0x948671 0x174A7C 0x629081 0xAD8505 0x58595B 0x8E0C3A 0xC8B18B 0x5E9732 0x008576'
line_chart_colors = '0x5C97CC 0xE7A614 0x959C51 0xB15C12 0x948671 0x174A7C 0x629081 0xAD8505 0x58595B 0x8E0C3A 0xC8B18B 0x5E9732 0x008576'

from reportlab.graphics.charts.utils import  mktime
import calendar
from datetime import datetime
from dateutil.relativedelta import relativedelta, FR
def mkTimeTuple(timeString):
    "Convert a 'dd/mm/yyyy' formatted string to a tuple for use in the time module."

    lista = [0] * 9
    dd, mm, yyyy = list(map(int, timeString.split('/')))
    lista[:3] = [yyyy, mm, dd]

    return tuple(lista)

def getYearEndXticks(catNames):
    if not catNames: return []
    x_axis = []
    noof_cat = len(catNames)
    next_value = 0
    add_last = False
    includedDates = [ ]
    ind = noof_cat / 12
    for idx , name in enumerate(catNames):
        mkt = mkTimeTuple(name)
        if str(mkt[0]) + str(mkt[1]) not in includedDates and mkt[1] == 12:
            includedDates.append(str(mkt[0]) + str(mkt[1]))
            xtick = mktime(mkt)
            x_axis.append(xtick)
            next_value += ind
    return x_axis

def get_x_ticks(catNames):
    if not catNames: return []
    x_axis = []
    noof_cat = len(catNames)
    ind = noof_cat / 12
    next_value = 0
            
    for idx , name in enumerate(catNames):
        xtick = mktime(mkTimeTuple(name))
        if idx == next_value:
            x_axis.append(xtick)
            next_value += ind
    
    return x_axis

from time import gmtime, strftime

def timeto2str(seconds, date_format='%d-%b-%Y'):
    "Convert a date string into the number of seconds since the epoch."
    return strftime(date_format, gmtime(seconds))

def timeto2strMonthYear(seconds, date_format='%b-%Y'):
    "Convert a date string into the number of seconds since the epoch."
    return strftime(date_format, gmtime(seconds))

def timeto2strYear(seconds, date_format='%Y'):
    "Convert a date string into the number of seconds since the epoch."
    return strftime(date_format, gmtime(seconds))