'''
Created on Nov 16, 2015
Base table for PIMCO pdfreport tables
@author: sumgowda
'''
from reportlab.platypus import Table
import math
from core.reporting.pdf.charts.barcharts import PimcoVerticalBarChart, TableDataBar
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Image
from core.reporting.parser import isValid, parseProperties, parseStyleElements
import logging, os
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus.paragraph import Paragraph
import numpy as np
from pandas import MultiIndex
from pandas import DataFrame
import pandas as pd
from core.reporting.util import getLinearSegmentedColormap
from core.reporting.pdf.paragraph import ParaStyles, CreatePara
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_LEFT, TA_RIGHT
from core.reporting.pdf.charts import default_chart_font_size
seqColorsNames = ['ExclRdYlGn', 'RdGn', 'Blues', 'BuGn', 'BuPu', 'GnBu',
                  'Greens', 'Greys', 'Oranges', 'OrRd',
                  'PuBu', 'PuBuGn', 'PuRd', 'Purples',
                  'RdPu', 'Reds', 'YlGn', 'YlGnBu',
                  'YlOrBr', 'YlOrRd', 'afmhot', 'autumn',
                  'bone', 'cool', 'copper', 'gist_heat',
                  'gray', 'hot', 'pink', 'spring',
                  'summer', 'winter', 'BrBG', 'bwr',
                  'coolwarm', 'PiYG', 'PRGn', 'PuOr',
                  'RdBu', 'RdGy', 'RdYlBu', 'RdYlGn',
                  'Spectral', 'seismic', 'Accent', 'Dark2',
                  'Paired', 'Pastel1', 'Pastel2', 'Set1',
                  'Set2', 'Set3', 'gist_earth', 'terrain',
                  'ocean', 'gist_stern', 'brg', 'CMRmap',
                  'cubehelix', 'gnuplot', 'gnuplot2', 'gist_ncar',
                  'nipy_spectral', 'rainbow', 'gist_rainbow', 'hsv', ]

from reportlab.lib import colors

tableStyleNames = {'default':
    [
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.Color(1, 1, 1, 1)),
        ('INNERGRID', (0, 0), (-1, -1), 0.15, colors.Color(1, 1, 1, 1)),
        ('BOX', (0, 0), (-1, -1), 0.15, colors.Color(1, 1, 1, 1)),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('FONTSIZE', (0, 0), (-1, -1), 6),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        # ('FONT', (0, 1), (-1, -1), 'Frutiger'),
    ],
    'emptytable': [
        # ('TEXTCOLOR', (0, 0), (-1, -1), colors.Color(1, 1, 1, 1)),
        ('INNERGRID', (0, 0), (-1, -1), 0.15, colors.Color(1, 1, 1, 1)),
        ('BOX', (0, 0), (-1, -1), 0.15, colors.Color(1, 1, 1, 1)),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('FONTSIZE', (0, 0), (-1, -1), 6),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        # ('FONT', (0, 1), (-1, -1), 'Frutiger'),
    ],
}


class BasicTable(Table, object):
    def __init__(self, *args, **kw):
        super(BasicTable, self).__init__(*args, **kw)


'''
Creates html based tables
'''


class PyPimcoTable(object):
    def __init__(self, df, fontName='', *args, **kw):
        self.headerData = []
        if isinstance(df, list):
            df = DataFrame(df)
        self.dfdata = df
        # keep a copy of original

        self._origdf = df.copy()
        self.noofheaders = 1
        self.fontName = fontName

    '''
    Default data formatting function
    '''

    def _formatData(self, data, formatStr='{0:.2f}', header=False, format='pdf', headerFormat=[],
                    is_bold=False,
                    is_image=False, iWidth=0.09, iHeight=0.09):
        try:

            if is_image and data:
                # get icons dir
                import core
                fileName = data
                if not os.path.exists(fileName):
                    iconsDIr = os.path.dirname(core.__file__) + '/reporting/icons/'
                    fileName = '%s%s.png' % (iconsDIr, data)
                    if not os.path.exists(fileName): return ''

                I = Image('%s%s.png' % (iconsDIr, data), hAlign='LEFT', kind='absolute')
                I.drawHeight = iHeight * inch
                I.drawWidth = iWidth * inch
                return I
            if data == 'nan': return ''
            if math.isnan(data):
                return ''
            return formatStr.format(data)
        except:
            # for an string types wrap so that text does not overlap
            styles = getSampleStyleSheet()
            styleN = styles["BodyText"]
            if is_bold:
                styleN = styles["Heading1"]
                styleN.leading = 5
            styleN.fontSize = int(self.properties.get('fontsize', 6) or 6)
            styleN.spaceBefore = 0
            styleN.wordWrap = 'LTR'
            styleN.spaceAfter = 0
            styleN.leftIndent = 3
            styleN.rightIndent = 0
            styleN.alignment = TA_CENTER
            styleN.splitLongWords = 0
            if header:
                hc = self.headerColor
                txtcolor = colors.white
                if headerFormat:
                    hc = headerFormat.get('bgcolor')
                    txtcolor = headerFormat.get('text-color')
                    if 'leading' in headerFormat:
                        styleN.leading = int(headerFormat['leading'])
                styleN.backColor = hc
                styleN.textColor = txtcolor
                if data and data.find("Unnamed") >= 0: data = ""
                if not data: data = ""
                if format == 'pdf':
                    p = Paragraph(data, styleN)
                    return p
                return data
                # if isinstance(data,str)  or isinstance(data,unicode):
            return data

    def _setProperties(self):
        for k, v in parseProperties(self.properties).items():
            setattr(self, k, v)

    '''
    Parse the table style elments
    '''

    def parseTableStyleElements(self, styleelelemnt, df=None):
        styles = {}
        formatStyles = {}
        styleList = []
        datastyles = []
        headerFormat = None
        styleElements = parseStyleElements(styleelelemnt)
        noofindexitems = 0
        if self.includeIndex:
            noofindexitems = 1
        if isinstance(self._origdf.index, MultiIndex):
            noofindexitems = len(self._origdf.index.names)
        if styleElements:
            if 'headerdata' in styleElements and styleElements['headerdata']:
                # print styleElements['headerdata']
                HeaderStyles = []  # just add col spans for now
                self.headerData = []
                for rowidx, each in enumerate(styleElements['headerdata']):
                    row_data = []
                    startIdx = 0
                    endIndex = 0
                    for td in each:
                        value = td['value']
                        row_data.append(value)
                        if 'colspan' in td.get('attrs', {}):
                            colspan = int(td['attrs']['colspan'])
                            for idx in range(colspan - 1):
                                row_data.append('')
                            endIndex = startIdx + colspan - 1
                            HeaderStyles.append(('SPAN', (startIdx, rowidx), (endIndex, rowidx)))
                        else:
                            endIndex += 1
                        if 'fontsize' in td.get('attrs', {}):
                            try:
                                HeaderStyles.append(('FONTSIZE', (startIdx, rowidx), (endIndex, rowidx),
                                                     int(td.get('attrs').get('fontsize'))))
                            except:
                                logging.info("Invalid font size %s" % (td.get('attrs').get('fontsize')))

                        startIdx = endIndex + 1

                    self.headerData.append(row_data)
                styleList += HeaderStyles

            if getattr(self, 'headerData'):
                self.noofheaders = self.noofheaders + len(self.headerData)

            if 'highlighthigh' in styleElements and styleElements['highlighthigh']:
                highlightStyles = []
                for rowidx, each in enumerate(styleElements['highlighthigh']):
                    color = each.get('color', 'red')
                    startrow = int(each.get('startrow', 0))
                    startcol = int(each.get('startcol', 0))
                    endrow = int(each.get('endrow', -1))
                    endcol = int(each.get('endcol', -1))
                    threshhold = each.get('threshhold')

                    for idx in range(len(self._origdf.index)):
                        for idy in range(len(self._origdf.columns)):
                            if (idx >= startrow and (idx <= endrow or endrow == -1) and idy >= startcol and (
                                            idy <= endcol or endcol == -1)):
                                value = self.dfdata.iloc[idx, idy]
                                if value >= float(threshhold):
                                    highlightStyles.append(
                                        ('BACKGROUND', (idy + noofindexitems, idx + self.noofheaders),
                                         (idy + noofindexitems, idx + self.noofheaders), color))

                datastyles += highlightStyles

            if 'highlightlow' in styleElements and styleElements['highlightlow']:
                highlightStyles = []
                for rowidx, each in enumerate(styleElements['highlightlow']):
                    color = each.get('color', 'red')
                    startrow = int(each.get('startrow', 0))
                    startcol = int(each.get('startcol', 0))
                    endrow = int(each.get('endrow', -1))
                    endcol = int(each.get('endcol', -1))
                    threshhold = each.get('threshhold')

                    for idx in range(len(self._origdf.index)):
                        for idy in range(len(self._origdf.columns)):
                            if (idx >= startrow and (idx <= endrow or endrow == -1) and idy >= startcol and (
                                            idy <= endcol or endcol == -1)):
                                value = self._origdf.iloc[idx, idy]
                                if value <= float(threshhold):
                                    highlightStyles.append(
                                        ('BACKGROUND', (idy + noofindexitems, idx + self.noofheaders),
                                         (idy + noofindexitems, idx + self.noofheaders), color))

                datastyles += highlightStyles

            if 'bgcolor' in styleElements and styleElements['bgcolor']:
                highlightStyles = []
                for rowidx, each in enumerate(styleElements['bgcolor']):
                    color = each.get('color', 'red')
                    startrow = int(each.get('startrow', 0))
                    startcol = int(each.get('startcol', 0))
                    endrow = int(each.get('endrow', -1))
                    endcol = int(each.get('endcol', -1))
                    threshhold = each.get('threshhold')

                    for idx in range(len(self._origdf.index)):
                        for idy in range(len(self._origdf.columns)):
                            if (idx >= startrow and (idx <= endrow or endrow == -1) and idy >= startcol and (
                                            idy <= endcol or endcol == -1)):
                                highlightStyles.append(('BACKGROUND', (idy + noofindexitems, idx + self.noofheaders),
                                                        (idy + noofindexitems, idx + self.noofheaders), color))

                datastyles += highlightStyles

            if 'numberformat' in styleElements and styleElements['numberformat']:
                # they can have mutiple ones
                for each in styleElements['numberformat']:
                    startrow = int(each.get('startrow', 0))
                    startcol = int(each.get('startcol', 0))
                    endrow = int(each.get('endrow', -1))
                    endcol = int(each.get('endcol', -1))
                    formatStr = each.get('format', "")
                    for idx, row in enumerate(self._origdf.iterrows()):
                        for idy, cell in enumerate(self._origdf.columns):
                            if (idx >= startrow and (idx <= endrow or endrow == -1) and idy >= startcol and (
                                            idy <= endcol or endcol == -1)):
                                try:
                                    if not pd.isnull(self._origdf.iloc[idx, idy]):
                                        self.dfdata.iloc[idx, idy] = formatStr.format(self._origdf.iloc[idx, idy])
                                    else:
                                        self.dfdata.iloc[idx, idy] = ''
                                except:
                                    # logging.info("Uanable to set format for " + str(self.dfdata.iloc[idx,idy]) + " at " + str(idx) + "," + str(idy))
                                    pass

            if 'highlightneg' in styleElements and styleElements['highlightneg']:
                highlightStyles = []
                for rowidx, each in enumerate(styleElements['highlightneg']):
                    color = each.get('color', 'red')
                    startrow = int(each.get('startrow', 0))
                    startcol = int(each.get('startcol', 0))
                    endrow = int(each.get('endrow', -1))
                    endcol = int(each.get('endcol', -1))
                    threshhold = each.get('threshhold')
                    formatStr = each.get('format')
                    for idx in range(len(self._origdf.index)):
                        for idy in range(len(self._origdf.columns)):
                            if (idx >= startrow and (idx <= endrow or endrow == -1) and idy >= startcol and (
                                            idy <= endcol or endcol == -1)):
                                value = self._origdf.iloc[idx, idy]
                                if value <= 0:
                                    try:
                                        highlightStyles.append(
                                            ('TEXTCOLOR', (idy + noofindexitems, idx + self.noofheaders),
                                             (idy + noofindexitems, idx + self.noofheaders), color))
                                        if not pd.isnull(self._origdf.iloc[idx, idy]):
                                            self.dfdata.iloc[idx, idy] = formatStr.format(self._origdf.iloc[idx, idy])
                                        else:
                                            self.dfdata.iloc[idx, idy] = ''
                                    except:
                                        try:
                                            if self.includeIndex:
                                                self.dfdata.iloc[idx, idy] = formatStr.format(
                                                    int(self._origdf.iloc[idx, idy]))
                                        except:
                                            pass

                datastyles += highlightStyles

            if 'heatmap' in styleElements and styleElements['heatmap']:
                # they can have mutiple ones
                for each in styleElements['heatmap']:

                    startrow = int(each.get('startrow', 0))
                    startcol = int(each.get('startcol', 0))
                    endrow = int(each.get('endrow', len(df.index)))

                    if endrow == -1:
                        endrow = len(self._origdf.index)

                    endcol = int(each.get('endcol', len(self._origdf.columns)))
                    if endcol == -1:
                        endcol = len(self._origdf.columns)

                    gradiantname = each.get('gradiantname', "RdYlGn")

                    if isinstance(self._origdf.index, MultiIndex):
                        startcol = startcol - len(self._origdf.index.names)
                        endcol = endcol - len(self._origdf.index.names)

                    subdf = self._origdf.iloc[startrow:endrow, startcol:endcol]
                    # update the row col id
                    for eachStyle in self._seaborntableColor(subdf, gradientname=gradiantname, lightness=0.0):
                        datastyles.append((eachStyle[0],
                                           (eachStyle[1][0] + startcol + noofindexitems,
                                            eachStyle[1][1] + startrow + self.noofheaders),
                                           (eachStyle[2][0] + startcol + noofindexitems,
                                            eachStyle[2][1] + startrow + self.noofheaders), eachStyle[3]))

            if 'span' in styleElements and styleElements['span']:

                # they can have mutiple ones
                for each in styleElements['span']:

                    startrow = int(each.get('startrow', 0))
                    startcol = int(each.get('startcol', 0))
                    endrow = int(each.get('endrow', len(df.index)))

                    if endrow == -1:
                        endrow = len(self._origdf.index)

                    endcol = int(each.get('endcol', len(self._origdf.columns)))
                    if endcol == -1:
                        endcol = len(self._origdf.columns)

                    if isinstance(self._origdf.index, MultiIndex):
                        startcol = startcol - len(self._origdf.index.names)

                    styleList.append(('SPAN', (startcol + noofindexitems, startrow),
                                      (endcol + noofindexitems, endrow)))

            if 'box' in styleElements and styleElements['box']:

                # they can have mutiple ones
                for each in styleElements['box']:

                    startrow = int(each.get('startrow', 0))
                    startcol = int(each.get('startcol', 0))
                    endrow = int(each.get('endrow', len(df.index)))
                    if each.get('value'):
                        thickness = float(each.get('value', 0.15) or 0.15)
                    else:
                        thickness = float(each.get('thickness', 0.15) or 0.15)

                    color = each.get('color') or colors.black

                    if endrow == -1:
                        endrow = len(df.index)
                    endcol = int(each.get('endcol', len(self._origdf.columns)))
                    if endcol == -1:
                        endcol = len(self._origdf.columns)
                    if isinstance(self._origdf.index, MultiIndex):
                        startcol = startcol - len(self._origdf.index.names)
                    styleList.append(('BOX', (startcol, startrow),
                                      (endcol, endrow), thickness, color))

            if 'leftpadding' in styleElements and styleElements['leftpadding']:
                for each in styleElements['leftpadding']:
                    startrow = int(each.get('startrow', 0))
                    startcol = int(each.get('startcol', 0))
                    endrow = int(each.get('endrow', len(df.index)))
                    endcol = int(each.get('endcol', len(self._origdf.columns)))
                    value = int(each.get('value', 0))
                    if isinstance(self._origdf.index, MultiIndex):
                        startcol = startcol - len(self._origdf.index.names)

                    styleList.append(('LEFTPADDING', (startcol, startrow),
                                      (endcol, endrow), value))

            if 'rightpadding' in styleElements and styleElements['rightpadding']:
                for each in styleElements['rightpadding']:
                    startrow = int(each.get('startrow', 0))
                    startcol = int(each.get('startcol', 0))
                    endrow = int(each.get('endrow', len(df.index)))
                    endcol = int(each.get('endcol', len(self._origdf.columns)))
                    value = int(each.get('value', 0))
                    if isinstance(self._origdf.index, MultiIndex):
                        startcol = startcol - len(self._origdf.index.names)

                    styleList.append(('RIGHTPADDING', (startcol, startrow),
                                      (endcol, endrow), value))

            if 'innergrid' in styleElements and styleElements['innergrid']:
                for each in styleElements['innergrid']:
                    startrow = int(each.get('startrow', 0))
                    startcol = int(each.get('startcol', 0))
                    endrow = int(each.get('endrow', len(df.index)))
                    endcol = int(each.get('endcol', len(self._origdf.columns)))
                    if each.get('value'):
                        thickness = float(each.get('value', 0.15) or 0.15)
                    else:
                        thickness = float(each.get('thickness', 0.15) or 0.15)
                    color = each.get('color') or colors.black
                    if isinstance(self._origdf.index, MultiIndex):
                        startcol = startcol - len(self._origdf.index.names)

                    styleList.append(('INNERGRID', (startcol, startrow), (endcol, endrow), thickness, color))

            if 'lineabove' in styleElements and styleElements['lineabove']:
                for each in styleElements['lineabove']:
                    startrow = int(each.get('startrow', 0))
                    startcol = int(each.get('startcol', 0))
                    endrow = int(each.get('endrow', len(df.index)))
                    endcol = int(each.get('endcol', len(self._origdf.columns)))
                    if each.get('value'):
                        thickness = float(each.get('value', 0.15) or 0.15)
                    else:
                        thickness = float(each.get('thickness', 0.15) or 0.15)
                    color = each.get('color') or colors.black
                    if isinstance(self._origdf.index, MultiIndex):
                        startcol = startcol - len(self._origdf.index.names)

                    styleList.append(('LINEABOVE', (startcol, startrow), (endcol, endrow), thickness, color))

            if 'linebelow' in styleElements and styleElements['linebelow']:
                for each in styleElements['linebelow']:
                    startrow = int(each.get('startrow', 0))
                    startcol = int(each.get('startcol', 0))
                    endrow = int(each.get('endrow', len(df.index)))
                    endcol = int(each.get('endcol', len(self._origdf.columns)))
                    if each.get('value'):
                        thickness = float(each.get('value', 0.15) or 0.15)
                    else:
                        thickness = float(each.get('thickness', 0.15) or 0.15)
                    color = each.get('color') or colors.black
                    if isinstance(self._origdf.index, MultiIndex):
                        startcol = startcol - len(self._origdf.index.names)

                    styleList.append(('LINEBELOW', (startcol, startrow), (endcol, endrow), thickness, color))

            if 'grid' in styleElements and styleElements['grid']:
                for each in styleElements['grid']:
                    startrow = int(each.get('startrow', 0))
                    startcol = int(each.get('startcol', 0))
                    endrow = int(each.get('endrow', len(df.index)))
                    endcol = int(each.get('endcol', len(self._origdf.columns)))
                    if each.get('value'):
                        thickness = float(each.get('value', 0.15) or 0.15)
                    else:
                        thickness = float(each.get('thickness', 0.15) or 0.15)

                    color = each.get('color') or colors.black
                    if isinstance(self._origdf.index, MultiIndex):
                        startcol = startcol - len(self._origdf.index.names)

                    styleList.append(('GRID', (startcol, startrow), (endcol, endrow), thickness, color))

        if 'align' in self.properties and self.properties['align']:
            highlightStyles = []
            alignValues = self.properties['align'].split(',')
            for idx, row in enumerate(self.dfdata.iterrows()):
                for idy, cell in enumerate(self.dfdata.columns):
                    alignVal = alignValues[idy] if idy < len(alignValues) else alignValues[-1]
                    if alignVal.upper() == 'RIGHT':
                        highlightStyles.append(('ALIGN', (idy + noofindexitems, idx + self.noofheaders),
                                                (idy + noofindexitems, idx + self.noofheaders), 'RIGHT'))
                    if alignVal.upper() == 'LEFT':
                        highlightStyles.append(('ALIGN', (idy + noofindexitems, idx + self.noofheaders),
                                                (idy + noofindexitems, idx + self.noofheaders), 'LEFT'))

            datastyles += highlightStyles

        if 'headerformat' in styleElements and styleElements['headerformat']:
            for each in styleElements['headerformat']:
                headerFormat = each
                bgcolor = each.get('bgcolor')
                textColor = each.get('bgcolor')
                styleList.append(('BACKGROUND', (0, 0), (-1, self.noofheaders), bgcolor))
                # styleList.append(('TEXTCOLOR', (0, 0), (-1, self.noofheaders), textColor))
        if 'imagecolumns' in styleElements and styleElements['imagecolumns']:
            styles['imagecolumns'] = styleElements['imagecolumns']

        if self.fontName:
            styleList += [('FONT', (0, 1), (-1, -1), self.fontName)]

        styles['styleList'] = styleList
        styles['formatStyles'] = formatStyles
        styles['datastyles'] = datastyles
        styles['styleElements'] = styleElements
        styles['headerFormats'] = headerFormat

        return styles

    def _seaborntableColor(self, df, gradientname='RdYlGn', lightness=.2):
        '''
        '''
        if not gradientname:
            gradientname = 'RdYlGn'

        colorGradent_styles = []
        range_selected = df
        startrow, endrow, startcol, endcol = 0, len(range_selected.index) + 1, 0, len(range_selected.columns) + 1

        allData = []
        valueColorMap = {}

        allData = [each for each in allData if not np.isnan(each)]
        valueColorMap = {}
        if gradientname in seqColorsNames:
            a, valueColorMap = getLinearSegmentedColormap(df, gradientname, lightness)

        for row in range(startrow, endrow):
            for col in range(startcol, endcol):
                try:
                    color = valueColorMap.get(df.iat[row, col], None)
                    if color:
                        colorGradent_styles.append(('BACKGROUND', (col, row), (col, row), color), )
                except:
                    continue

        return colorGradent_styles


class EmptyDataTable(Table, PyPimcoTable):
    '''
    This is data table that has not data source , but the data is specified in html table format
    '''

    def __init__(self, htmltableElement=None,fontName=''):
        '''
        htmltableElement : the element in template that has the data in html table format
        '''
        table_data = []
        styles = []
        colwidths = None
        rowheights = None
        self.fontName = fontName
        if htmltableElement:
            parentAttrs = htmltableElement.attrs
            if 'fontsize' in htmltableElement.attrs:
                styles.append(('FONTSIZE', (0, 0), (-1, -1), int(htmltableElement.attrs.get('fontsize'))))

            for thead in htmltableElement.find_all('thead'):
                for tr in thead.find_all('tr'):
                    row_data = []
                    for td in tr.find_all('th'):
                        row_data.append("".join(td.contents))
                    table_data.append(row_data)

            tbody = htmltableElement.find_all('tbody')
            if not tbody: tbody = htmltableElement
            rowSpan = -1
            for idr, tr in enumerate(tbody.find_all('tr')):
                row_data = []
                row_spanData = []
                for idx, td in enumerate(tr.find_all('td')):
                    # make sure you also use parent attributes like align for example
                    cellattrs = td.attrs
                    attrs = parentAttrs.copy()
                    attrs.update(cellattrs)
                    noofcolumns = 0
                    # what if tble has nexted table tags cannot just convert to empty table, may be we can force people to not next
                    paracontents = "".join([str(each) for each in td.contents])
                    paraStyle = ParaStyles['Default'].clone(name="Default")

                    if 'style' in attrs:
                        for eachstyle in attrs.get('style', '').split(';'):
                            if eachstyle and len(eachstyle.split(':')) == 2:
                                prop, value = eachstyle.split(':')
                                attrs[prop.lower()] = value
                                # since we have 2 options text-align or align overrited the parent
                                if prop.lower() == 'text-align':
                                    attrs['align'] = value

                    if 'fontsize' in attrs:
                        value = attrs['fontsize']
                        styles.append(('fontsize', (idx, idr), (idx, idr), int(value)))

                    if 'justify' in attrs or 'align' in attrs or 'text-align' in attrs:
                        justvalue = attrs.get('text-align') or attrs.get('justify') or attrs.get('align')
                        if justvalue.strip().upper() == 'CENTER':
                            styles.append(('ALIGN', (idx, idr), (idx, idr), 'CENTER'))
                        if justvalue.strip().upper() == 'RIGHT':
                            styles.append(('ALIGN', (idx, idr), (idx, idr), 'RIGHT'))
                        if justvalue.strip().upper() == 'LEFT':
                            styles.append(('ALIGN', (idx, idr), (idx, idr), 'LEFT'))

                    if 'bgcolor' in attrs:
                        styles.append(
                            ('BACKGROUND', (idx, len(table_data)), (idx, len(table_data) + 1), attrs.get('bgcolor')), )

                    if 'rowspan' in attrs:
                        rowSpan = idr
                        noofcolumns = int(attrs['rowspan'])
                        styles.append(('SPAN', (idx, idr), (idx, idr + noofcolumns - 1)))
                        # styles.append( ('ALIGN', (idx ,idr), (idx  , idr + noofcolumns-1) , 'CENTER' ) )

                    # paraStyle.alignment = TA_LEFT
                    row_data.append(CreatePara(paracontents, paraAttrs=attrs))
                    # row_data.append(  paracontents )
                    if 'colspan' in attrs:
                        noofcolumns = int(attrs['colspan'])
                        for idx in range(noofcolumns):
                            row_data.append("")

                # before appending
                if len(table_data) > 0 and len(row_data) < len(table_data[-1]) and rowSpan != -1:
                    row_data += ['' for idx in range(len(table_data[-1]) - len(row_data))]

                table_data.append(row_data)

            if 'rowheights' in htmltableElement.attrs:
                rowheights = [float(each) * inch for each in htmltableElement.attrs['rowheights'].split(',')]
                if len(rowheights) == 1:
                    rowheights = rowheights * (len(table_data))

            if 'colwidths' in htmltableElement.attrs:
                colwidths = [float(each) * inch for each in htmltableElement.attrs['colwidths'].split(',')]
                if len(colwidths) == 1:
                    colwidths = colwidths * len(table_data[0])

            if 'border' in htmltableElement.attrs:
                styles.append(('BOX', (0, 0), (-1, -1), 0.25, colors.black))
                styles.append(('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black))

        self.data = table_data

        super(EmptyDataTable, self).__init__(self.data, rowHeights=rowheights, colWidths=colwidths)
        tableStyles = tableStyleNames.get('emptytable') + styles
        if self.fontName:
            tableStyles += [('FONT', (0, 1), (-1, -1), self.fontName)]
        self.setStyle(tableStyles)


'''

This is specialized table for pdf reports
'''


class DataTable(Table, PyPimcoTable):
    def __init__(self, df=None, style=None, properties={}, styleXmlElement=None, parser=None, fontName='',
                 *args, **kw):
        self.myparser = parser
        self.headerColor = '#5C97CC'
        self.alterColor = ('#D2DDEC', '#EAEFF6')

        self.dataStyles = []
        self.properties = properties
        self.fontName = fontName
        self._setProperties()
        if isinstance(df, list):
            df = DataFrame(df)
        PyPimcoTable.__init__(self, df)
        styleXmlElement = styleXmlElement or {}
        self.setData(df, style, properties, styleXmlElement)
        if 'rowheights' in self.properties:
            rowHeights = [float(each) * 72 for each in self.properties['rowheights'].split(",")]
            if len(rowHeights) == 1:
                self.rowHeights = rowHeights * len(self.data)
            elif len(rowHeights) > 1:
                self.rowHeights = rowHeights + [rowHeights[-1]] * (len(self.data) - len(rowHeights))
        else:
            # need to compute
            self.rowHeights = None
        super(DataTable, self).__init__(self.data, rowHeights=self.rowHeights, colWidths=self.colWidths,
                                        repeatRows=self.noofheaders)
        self.setStyle(self.style)

    def setData(self, df=None, style=None, properties={}, styleXmlElement=None):

        rowHeights, colWidths = None, None
        try:
            columns = df.columns.tolist()
        except:
            pass
            return
        self.alterColor = [self.alterColor[0]] * self.groupbackground + [self.alterColor[1]] * self.groupbackground
        styleList = []

        if self.noofheaders > 1:
            # there are mutiple headers so make sure all pandas auto generated header columns are removed
            idxUnnamed = [idx for idx, row in enumerate(columns) if row.find('Unnamed') < 0]
            totalColumns = len(columns)
            start = 0
            for idx in idxUnnamed:
                if idx != start:
                    styleList.append(('SPAN', (start, 0), (idx - 1, 0)))
                start = idx
            if idx < totalColumns:
                styleList.append(('SPAN', (start, 0), (totalColumns - 1, 0)))

        styleList += tableStyleNames.get(self.stylename)
        if self.fontName:
            styleList += [('FONT', (0, 1), (-1, -1), self.fontName)]
        if 'border' in properties:
            styleList.append(('BOX', (0, 0), (-1, -1), 0.25, colors.black))
            styleList.append(('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black))

        if 'fontsize' in properties:
            styleList.append(('FONTSIZE', (0, 0), (-1, -1), int(properties.get('fontsize'))))

        styles = self.parseTableStyleElements(styleXmlElement, df=df)
        rows_data = self.dfdata.values.tolist()
        if getattr(self, 'headerData'):
            rows_data = self.headerData + rows_data

        formatStyles = styles.get('formatStyles', {})
        if self.includeIndex:
            styleList.append(('ALIGN', (0, self.noofheaders), (0, -1), 'LEFT'))

        styleList += [('BACKGROUND', (0, 0), (-1, self.noofheaders - 1), self.headerColor),
                      ('ROWBACKGROUNDS', (0, self.noofheaders), (-1, -1), self.alterColor)]
        styleList += [('TEXTCOLOR', (0, 0), (-1, self.noofheaders - 1), colors.white)]
        if self.includeIndex:
            columns = df.index.names + columns

        wrapText = False
        if 'word-wrap' in properties and properties['word-wrap'].lower() == 'true':
            wrapText = True
        is_bold = False
        if 'bold-header' in properties and properties['bold-header'].lower() == 'true':
            is_bold = True
        columnData = [[self._formatData(each,
                                        formatStr=formatStyles.get(str(rowidx) + "_" + str(colidx), self.floatformat),
                                        header=wrapText,
                                        headerFormat=styles.get('headerFormats'),
                                        is_bold=is_bold) for
                       colidx, each in enumerate(row)] \
                      for rowidx, row in enumerate(rows_data[:self.noofheaders - 1] + [columns])]
        imageColumnsIdx = []
        iWidth = 0.09
        iHeight = 0.09
        if 'imagecolumns' in styles:
            for eachImageCol in styles['imagecolumns']:
                imageColumnsIdx += [list(self.dfdata.columns).index(name.strip()) for name in
                                    eachImageCol['columnnames'].split(",") if name.strip()]
                if 'width' in eachImageCol:
                    iWidth = float(eachImageCol['width'])
                if 'height' in eachImageCol:
                    iHeight = float(eachImageCol['height'])
        for eachColIdx in imageColumnsIdx:
            styles['styleList'] = styles.get('styleList', []) + [('VALIGN', (eachColIdx, self.noofheaders),
                                                                  (eachColIdx, -1), 'BOTTOM')]
        rows_data = [[self._formatData(cell, formatStr=formatStyles.get(
            str(rowidx + self.noofheaders - 1) + "_" + str(colidx), self.floatformat), is_bold=is_bold,
                                       is_image=colidx in imageColumnsIdx, iWidth=iWidth, iHeight=iHeight) \
                      for colidx, cell in enumerate(row)] for rowidx, row in
                     enumerate(rows_data[self.noofheaders - 1:])]

        if self.includeIndex:
            indexValues = df.index.tolist()

            if isinstance(df.index, MultiIndex):
                indexValues = []
                previndex = []
                for i in df.index:
                    if set(previndex) == set(i):
                        indexValues.append(['' for i in list(i)])
                    else:
                        previndex = i
                        indexValues.append(list(i))

                # indexValues =  [ list(i) for i in df.index ]
                rows_data = [indexValues[idx] + each for idx, each in enumerate(rows_data)]

            else:
                rows_data = [[indexValues[idx]] + each for idx, each in enumerate(rows_data)]

        rows_data = columnData + rows_data

        if self.databarcolumn:
            if self.databarcolumn.isdigit():
                colindex = int(self.databarcolumn)
            maxvalue = max([each[colindex - 1] for each in rows_data[1:]])
            minvalue = min([each[colindex - 1] for each in rows_data[1:]])
            h = rowHeights[colindex - 1]
            w = colWidths[colindex - 1]
            for idx, each in enumerate(rows_data):

                # if there is padding Frame width should be reduced
                mapAttr = {'LEFTPADDING': 6,
                           'RIGHTPADDING': 6,
                           'BOTTOMPADDING': 3,
                           'TOPPADDING': 3,
                           }
                for eachSt in styleList:
                    if eachSt[0] in mapAttr:
                        mapAttr[eachSt[0]] = eachSt[3]

                subW = mapAttr['LEFTPADDING'] + mapAttr['RIGHTPADDING']
                subH = mapAttr['TOPPADDING'] + mapAttr['BOTTOMPADDING']
                l = TableDataBar(w - subW, h - subH, value=each[colindex - 1], minvalue=minvalue, maxvalue=maxvalue)
                imageF = KeepInFrame(w - subW, h - subH, content=[l])
                if idx != 0:
                    each[colindex - 1] = imageF
                    # each.append(imageF )
        self.data = rows_data
        # t = Table(rows_data,rowHeights= rowHeights, colWidths = colWidths)
        if 'rowheights' in properties:
            rowHeights = [float(each) * inch for each in properties['rowheights'].split(',')]
            if len(rowHeights) == 1:
                rowHeights = rowHeights * (len(rows_data))

        self.rowHeights = rowHeights
        colWidths = None
        if 'colwidths' in properties:
            colWidths = [float(each) * inch for each in properties['colwidths'].split(',')]
            if len(colWidths) == 1:
                colWidths = colWidths * len(colWidths)

        self.colWidths = colWidths
        self.style = styleList + styles.get('styleList', []) + styles.get('datastyles', [])


class MutiDataTable(Table, PyPimcoTable):
    '''
    This used when we have mutiple data source as tables
    '''

    def __init__(self, dfs=None, styles=None, properties=None, fontName='Helvetica', **kw):
        self.dfs = dfs
        self.styles = styles
        self.properties = properties
        self.colWidths = None
        self.rowHeights = None
        self.render()
        self.noofheaders = 1
        super(MutiDataTable, self).__init__(self.data, self.colWidths, self.rowHeights)
        self.setStyle(self.style)

    def render(self):
        all_data = []
        all_styles = []
        shiftvalue = 0
        rowheights = []
        for idx, dfRo in enumerate(self.dfs):
            df = dfRo.copy(deep=True)
            styleXmlElement = None
            if self.styles:
                styleXmlElement = self.styles[idx]

            dtB = DataTable(df, styleXmlElement=styleXmlElement, properties=self.properties)
            all_data += dtB.data

            tempStyles = self._shiftStyle(dtB.style, shiftByValue=shiftvalue + idx, startrow=0,
                                          endrow=len(dtB.data) - 1)

            datastyles = self._shiftStyle(dtB.dataStyles, shiftByValue=shiftvalue + idx, startrow=0,
                                          endrow=len(dtB.data) - 1, additionalrowspace=dtB.noofheaders,
                                          additionalcolspace=1)

            all_styles += tempStyles + datastyles
            shiftvalue += len(dtB.data) - 1
            if dtB.rowHeights:
                rowheights += dtB.rowHeights

        self.data = all_data
        self.style = all_styles

        if 'rowheights' in self.properties:
            rowHeights = [float(each) * 72 for each in self.properties['rowheights'].split(",")]
            if len(rowHeights) == 1:
                self.rowHeights = rowHeights * len(all_data)
            elif len(rowHeights) > 1:
                self.rowHeights = rowHeights + [rowHeights[-1]] * (len(all_data) - len(rowHeights))
        else:
            # need to compute
            pass

        if rowheights:
            self.rowHeights = rowheights

        if 'colwidths' in self.properties:
            colwidths = [float(each) * 72 for each in self.properties['colwidths'].split(",")]
            if len(colwidths) == 1:
                self.colWidths = colwidths * len(all_data[0])
            elif len(rowHeights) == 1:
                self.colWidths = colwidths + [colwidths[-1]] * (len(all_data[0]) - len(colwidths))
        else:
            # need to compute
            pass

    def _shiftStyle(self, stylesToShift, shiftByValue=0, startrow=0, endrow=0, additionalrowspace=0,
                    additionalcolspace=0):
        styles = []
        for each in stylesToShift:
            if each[0] in ['BACKGROUND', 'ROWBACKGROUNDS', 'TEXTCOLOR', 'ALIGN', 'VALIGN', 'FONTSIZE', 'TOPPADDING']:
                if shiftByValue == 0:
                    styles.append((each[0], (each[1][0] + additionalcolspace, each[1][1] + additionalrowspace),
                                   (each[2][0] + additionalcolspace,
                                    endrow + additionalrowspace if each[2][1] == -1  else each[2][
                                                                                              1] + additionalrowspace),
                                   each[3]))
                elif shiftByValue > 1:
                    styles.append((each[0], (each[1][0] + additionalcolspace,
                                             shiftByValue + each[1][1] + additionalrowspace if each[1][
                                                                                                   1] != 0  else shiftByValue + additionalrowspace),
                                   (each[2][0] + additionalcolspace,
                                    shiftByValue + endrow + additionalrowspace if each[2][1] == -1  else shiftByValue +
                                                                                                         each[2][
                                                                                                             1] + additionalrowspace),
                                   each[3]))
            if each[0] in ['INNERGRID', 'BOX']:
                if shiftByValue == 0:
                    styles.append((each[0], (each[1][0], each[1][1]),
                                   (each[2][0], endrow if each[2][1] == -1  else each[2][1]), each[3], each[4]))
                else:
                    styles.append((each[0], (each[1][0], each[1][1] + shiftByValue), (
                        each[2][0], shiftByValue + endrow if each[2][1] == -1  else shiftByValue + each[2][1])
                                   , each[3], each[4]))
            if each[0] in ['SPAN']:
                if shiftByValue == 0:
                    styles.append(
                        (each[0], (each[1][0], each[1][1]), (each[2][0], endrow if each[2][1] == -1  else each[2][1])))
                elif shiftByValue > 1:
                    styles.append(
                        (each[0], (each[1][0], shiftByValue + each[1][1] if each[1][1] != 0  else shiftByValue),
                         (each[2][0], shiftByValue + endrow if each[2][1] == -1  else shiftByValue + each[2][1])))
            else:
                # print each
                pass
        return styles
