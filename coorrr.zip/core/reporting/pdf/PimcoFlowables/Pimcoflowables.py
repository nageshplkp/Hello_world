'''
Created on Mar 4, 2016

@author: sumgowda
'''
from reportlab.platypus.flowables import Flowable, KeepInFrame
from reportlab.lib import colors
from reportlab.lib.units import inch, cm

class Portrait(Flowable):
    def draw(self):
        pass

class Landscape(Flowable):
    
    def draw(self):
        pass
    
class DrawingFlowable(Flowable):
    """"
    This class creates a drawing object in pdf which enables to put any custom drawing stuff 
    """
    
    def __init__(self):
        Flowable.__init__(self)

    def __repr__(self):
        return "Drawing (w=%s ,h=%s)" % (self.width , self.height)
 
    #----------------------------------------------------------------------
    def drawGrid(self, xlist, ylist):
        self.canv.grid(xlist, ylist)
    
    def drawLine(self, x1, y1, x2, y2):
        self.canv.line(x1, y1, x2, y2)
    
    def drawLines(self, linelist):
        self.canv.lines(linelist)
        
    def drawArc(self, x1, y1, x2, y2):
        self.canv.arc(x1, y1, x2, y2)
    
    def drawRect(self, x, y, width, height, stroke=1, fill=0):
        self.canv.rect(x, y, width, height, stroke=1, fill=0)
    
    def drawEllipse(self, x1, y1, x2, y2, stroke=1, fill=0):
        self.canv.ellipse(x1, y1, x2, y2, stroke=1, fill=0)
        
    def drawWedge(self, x1, y1, x2, y2, startAng, extent, stroke=1, fill=0):
        self.canv.wedge(x1, y1, x2, y2, startAng, extent, stroke=1, fill=0)
        
    def drawircle(self, x_cen, y_cen, r, stroke=1, fill=0):
        self.canv.circle(x_cen, y_cen, r, stroke=1, fill=0) 
        
    def drawRoundRect(self, x, y, width, height, radius, stroke=1, fill=0):
        self.canv.roundRect(x, y, width, height, radius, stroke=1, fill=0)
    
    def drawString(self, x, y, text):
        self.canv.drawString(x, y, text)
     
    def drawCentredString(self, x, y, text):
        self.canv.drawCentredString(x, y, text)
    
    """
    dict of key and values with addition properties like color etc
    """
    def setDrawProperties(self, properties={}):
        if 'backgroundcolor' in properties:
            cl = colors.toColor(properties['backgroundcolor'])
            self.canv.setFillColorRGB(cl)
            
        if 'textcolor' in properties:
            cl = colors.toColor(properties['textcolor'])
            self.canv.setFillColorRGB(cl)
        
        if 'width' in properties:
            width = float(properties.get('width', 3)) * inch
            self.width = width
        if 'height' in properties:
            height = float(properties.get('height', 2)) * inch
            self.height = height
    
    """
    Degree by which to rotate
    """
    def rotate(self, degree):
        self.canv.rotate(degree)
        

class DrawString(Flowable):
    
    def __init__(self):
        Flowable.__init__(self)

    def __repr__(self):
        return "Drawing (w=%s ,h=%s)" % (self.width , self.height)
    
    """
    dict of key and values with addition properties like color etc
    """
    def setDrawProperties(self, properties={}, text=''):
        self.string = text
        self.backgroundcolor = colors.white
        if 'backgroundcolor' in properties:
            cl = colors.toColor(properties['backgroundcolor'])
            cl = colors.toColor(cl)
            self.backgroundcolor = cl
        
        self.textcolor = colors.black   
        if 'textcolor' in properties:
            cl = colors.toColor(properties['textcolor'])
            cl = colors.toColor(cl)
            self.textcolor = cl
        
        if 'width' in properties:
            width = float(properties.get('width', 3)) * inch
            self.width = width
        if 'height' in properties:
            height = float(properties.get('height', 2)) * inch
            self.height = height
        self.rotate = None
        if 'rotate' in properties:
            rotate = properties.get('rotate', 0)
            self.rotate = int(rotate)
            
        self.x = 0
        if 'x' in properties:
            x = properties.get('x', 0)
            self.x = float(x) * inch
            
        self.y = 0
        if 'y' in properties:
            x = properties.get('y', 0)
            self.y = float(x) * inch
            
        self.stroke = 0
        if 'boundary' in properties:
            self.stroke = 1
            
    def draw(self):
        cl = self.backgroundcolor
        # if cl != colors.white:
        self.canv.setFillColorRGB(cl.red, cl.green, cl.blue)
        self.canv.rect(0, 0, self.width, self.height, stroke=self.stroke, fill=1)
        cl = self.textcolor
        self.canv.setFillColorRGB(cl.red, cl.green, cl.blue)
        if self.rotate:
            self.canv.rotate(self.rotate)
            self.canv.drawString(self.height / 3, -self.width / 2, self.string)
        else:
            self.canv.drawString(self.x, self.y, self.string)
        

class HeaderFootertString(Flowable):
    '''
    Base class for Header Footer
    Has strign value 
    
    '''
    def __init__(self, stringValue, x=None , y=None):
        Flowable.__init__(self)
        self.stringValue = stringValue
        
    def get(self):
        return self.stringValue
    
    def getX(self):
        return self.x
    
    def getY(self):
        return self.y
    
    def draw(self):
        pass
    
'''
Custom Header class for left header
'''
class HeaderLeftString(Flowable):
    def __init__(self, stringValue):
        Flowable.__init__(self)
        self.stringValue = stringValue
    
    def get(self):
        return self.stringValue
    
    def draw(self):
        pass
    
'''
Custom Header class for Center header
'''
class HeaderCenterString(Flowable):
    def __init__(self, stringValue):
        Flowable.__init__(self)
        self.stringValue = stringValue
    
    def get(self):
        return self.stringValue
    
    def draw(self):
        pass
    
'''
Custom Header class for Right header
'''
class HeaderRightString(Flowable):
    def __init__(self, stringValue):
        Flowable.__init__(self)
        self.stringValue = stringValue
    
    def get(self):
        return self.stringValue
    
    def draw(self):
        pass


from reportlab.platypus.paragraph import Paragraph
from reportlab.lib.styles import getSampleStyleSheet
stylesheet=getSampleStyleSheet()
normalStyle = stylesheet['Normal']
from reportlab.lib.enums import TA_LEFT, TA_RIGHT, TA_CENTER, TA_JUSTIFY

'''
Custom Footer class for Right footer
'''
class FooterRightString(Paragraph):
    def __init__(self, text, style = None , bulletText = None, frags=None, caseSensitive=1, encoding='utf8'):
        if not style:
            style = normalStyle
            style.alignment =  TA_CENTER
        Paragraph.__init__(self, text, style, bulletText = None, frags=None, caseSensitive=1, encoding='utf8')
    


'''
Custom Footer class for Center footer
'''
class FooterCenterString(Paragraph):
    def __init__(self, text, style = None , bulletText = None, frags=None, caseSensitive=1, encoding='utf8'):
        if not style:
            style = normalStyle
            style.alignment =  TA_CENTER
        Paragraph.__init__(self, text, style, bulletText = None, frags=None, caseSensitive=1, encoding='utf8')
    
    
'''
Custom Footer class for Left footer
'''
class FooterLeftString(Paragraph):
    def __init__(self, text, style = None , bulletText = None, frags=None, caseSensitive=1, encoding='utf8'):
        if not style:
            style = normalStyle
            style.alignment =  TA_CENTER
        Paragraph.__init__(self, text, style, bulletText = None, frags=None, caseSensitive=1, encoding='utf8')
"""
Draws horisontal line in pdf report based on widht and height given
Use html hr tag 
<hr height=".1"  width="8"></hr>
height and width given in inches
defaults to 8 inch width and 0.1 inch height 
"""

class HorizontalLine(Flowable):
    def __init__(self, width=8 * inch, height=0.1 * inch):
        Flowable.__init__(self)
        self.x1 = 0
        self.y1 = 0
        self.x2 = width
        self.y2 = height
        
    def draw(self):
        # self.canv.setFillColor(colors.black)
        self.canv.setStrokeColorRGB(colors.black)
        self.canv.line(self.x1, self.y1, self.x2, self.y2)

from reportlab.platypus.paragraph import Paragraph
class SeqPara(Paragraph):
    
    def __init__(self, text, style):
        Paragraph.__init__(self, text, style)
        self.caseSensitive = caseSensitive
        self.encoding = encoding
        self._setup(text, style, bulletText or getattr(style, 'bulletText', None), frags, cleanBlockQuotedText)


class PyKeepInFrame(KeepInFrame):
    def __init__(self, maxWidth, maxHeight, content=[], mergeSpace=1, mode='shrink', name='',hAlign='LEFT',vAlign='BOTTOM', 
                 fakeWidth=None):
        '''
        Extented from main classs
        resizedirection can be 'vert' or 'horiz'
        '''
        self.resizedirection = 'vert'
        KeepInFrame.__init__(self,maxWidth, maxHeight, content, mergeSpace, mode=mode, name=name,hAlign=hAlign,
                             vAlign=vAlign, fakeWidth=fakeWidth)
    
    
    def wrap(self,availWidth,availHeight):
        from reportlab.platypus.doctemplate import LayoutError
        mode = self.mode
        maxWidth = float(min(self.maxWidth or availWidth,availWidth))
        maxHeight = float(min(self.maxHeight or availHeight,availHeight))
        fakeWidth = self.fakeWidth
        from reportlab.platypus.flowables import _listWrapOn
        from reportlab.platypus.frames import _FUZZ
        W, H = _listWrapOn(self._content,maxWidth,self.canv, fakeWidth=fakeWidth)
        if (mode=='error' and (W>maxWidth+_FUZZ or H>maxHeight+_FUZZ)):
            ident = 'content %sx%s too large for %s' % (W,H,self.identity(30))
            #leave to keep apart from the raise
            raise LayoutError(ident)
        elif W<=maxWidth+_FUZZ and H<=maxHeight+_FUZZ:
            self.width = W-_FUZZ      #we take what we get
            self.height = H-_FUZZ
        elif mode in ('overflow','truncate'):   #we lie
            self.width = min(maxWidth,W)-_FUZZ
            self.height = min(maxHeight,H)-_FUZZ
        else:
            def func(x, resizedirection = None):
                x = float(x)
                W, H = _listWrapOn(self._content,x*maxWidth,self.canv, fakeWidth=fakeWidth)
                if not resizedirection:
                    W /= x
                    H /= x
                elif resizedirection =='vert':
                    H /= x
                elif resizedirection =='horiz':
                    W /= x
                return W, H
            W0 = W
            H0 = H
            s0 = 1
            if W>maxWidth+_FUZZ:
                #squeeze out the excess width and or Height
                s1 = W/maxWidth     #linear model
                W, H = func(s1)
                if H<=maxHeight+_FUZZ:
                    self.width = W-_FUZZ
                    self.height = H-_FUZZ
                    self._scale = s1
                    return W,H
                s0 = s1
                H0 = H
                W0 = W
            s1 = H/maxHeight
            W, H = func(s1,self.resizedirection)
            self.width = W-_FUZZ
            self.height = H-_FUZZ
            self._scale = s1
            if H<min(0.95*maxHeight,maxHeight-10) or H>=maxHeight+_FUZZ:
                #the standard case W should be OK, H is short we want
                #to find the smallest s with H<=maxHeight
                H1 = H
                for f in 0, 0.01, 0.05, 0.10, 0.15:
                    #apply the quadratic model
                    s = _qsolve(maxHeight*(1-f),_hmodel(s0,s1,H0,H1))
                    W, H = func(s)
                    if H<=maxHeight+_FUZZ and W<=maxWidth+_FUZZ:
                        self.width = W-_FUZZ
                        self.height = H-_FUZZ
                        self._scale = s
                        break

        return self.width, self.height
