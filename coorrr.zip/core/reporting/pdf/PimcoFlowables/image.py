from pdfrw import PdfReader
from pdfrw.buildxobj import pagexobj
from pdfrw.toreportlab import makerl
from reportlab.platypus import Flowable, Image
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
import cStringIO
from xml.sax.saxutils import unescape
import json


class PdfImage(Flowable):
    """
    PdfImage wraps the first page from a PDF file as a Flowable
    which can be included into a ReportLab Platypus document.
    Based on the vectorpdf extension in rst2pdf (http://code.google.com/p/rst2pdf/)
    Courtesy: https://stackoverflow.com/questions/4690585/is-there-a-matplotlib-flowable-for-reportlab/13870512
    """

    GLOBAL_FIG_INSTANCES = {}

    def __init__(self, filename_or_object, width=None, height=None, kind='direct'):
        # If using StringIO buffer, set pointer to begining
        if hasattr(filename_or_object, 'read'):
            filename_or_object.seek(0)
        page = PdfReader(filename_or_object, decompress=False).pages[0]
        self.xobj = pagexobj(page)
        self.imageWidth = width
        self.imageHeight = height
        x1, y1, x2, y2 = self.xobj.BBox

        self._w, self._h = x2 - x1, y2 - y1
        if not self.imageWidth:
            self.imageWidth = self._w
        if not self.imageHeight:
            self.imageHeight = self._h
        self.__ratio = float(self.imageWidth)/self.imageHeight
        if kind in ['direct','absolute'] or width==None or height==None:
            self.drawWidth = width or self.imageWidth
            self.drawHeight = height or self.imageHeight
        elif kind in ['bound','proportional']:
            factor = min(float(width)/self._w,float(height)/self._h)
            self.drawWidth = self._w*factor
            self.drawHeight = self._h*factor

    def wrap(self, aW, aH):
        return self.drawWidth, self.drawHeight

    def drawOn(self, canv, x, y, _sW=0):
        if _sW > 0 and hasattr(self, 'hAlign'):
            a = self.hAlign
            if a in ('CENTER', 'CENTRE', TA_CENTER):
                x += 0.5*_sW
            elif a in ('RIGHT', TA_RIGHT):
                x += _sW
            elif a not in ('LEFT', TA_LEFT):
                raise ValueError("Bad hAlign value " + str(a))

        xobj = self.xobj
        xobj_name = makerl(canv._doc, xobj)

        xscale = self.drawWidth/self._w
        yscale = self.drawHeight/self._h

        x -= xobj.BBox[0] * xscale
        y -= xobj.BBox[1] * yscale

        canv.saveState()
        canv.translate(x, y)
        canv.scale(xscale, yscale)
        canv.doForm(xobj_name)
        canv.restoreState()


def get_image(params):
    params = json.loads(unescape(params))
    data = PdfImage.GLOBAL_FIG_INSTANCES.pop(params['uid'])
    # filename could be a file like object or full path
    return Image(data['filename'], width=data.get('width'), height=data.get('height'),
                 kind=data.get('kind', 'direct'), hAlign=data.get('halign', 'CENTER'))


def get_pdf_image(params):
    import matplotlib.pyplot as plt
    params = json.loads(unescape(params))
    data = PdfImage.GLOBAL_FIG_INSTANCES.pop(params['uid'])
    fig = data['fig']
    img_data = cStringIO.StringIO()
    fig.savefig(img_data, format='PDF', facecolor=fig.get_facecolor(), edgecolor='none',
                bbox_inches=data.get('bbox_inches', 'tight'), pad_inches=data.get('pad_inches'))
    # default edgecolor for the actual figure is white so set it to none
    plt.close(fig)
    # image will remain in vectorized format which means scalable
    return PdfImage(img_data, width=data.get('width'), height=data.get('height'), kind=data.get('kind', 'direct'))
