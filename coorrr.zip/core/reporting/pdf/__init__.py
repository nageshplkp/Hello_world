from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from core import reporting
import os
font_lcation = os.path.join(os.path.dirname(reporting.__file__),"fonts")
for filename in os.listdir(font_lcation ):
    pdfmetrics.registerFont(TTFont(os.path.splitext(filename)[0], os.path.join(font_lcation,filename)))