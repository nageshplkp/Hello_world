'''
Created on Nov 25, 2016

@author: sumgowda
'''
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image

ParaStyles = getSampleStyleSheet()
ParaStyles.add(ParagraphStyle(name='Default',
                              fontSize=7,
                              leading=12)
               )

__all__ = ["ParaStyles"]
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_LEFT, TA_RIGHT

paraIntAttributes = ['fontsize', 'leading', 'leftindent', 'rightindent', 'firstlineindent', 'spacebefore', 'spaceafter',
                     'spacebefore',
                     'spaceafter', 'borderwidth', 'borderpadding', 'allowwidows', 'bulletfontsize', 'bulletindent',
                     'alloworphans']

paraStrAttributes = ['backcolor', 'bordercolor', 'bulletanchor', 'bulletfontname', 'fontname', 'textcolor']


def CreatePara(contents, name='Default', paraAttrs={}):
    """
    return reportlab Parapragh based on attributes provided 
    attrs is dict
    fontName,
    fontSize , 
    leading ,
    leftIndent , 
    rightIndent , 
    firstLineIndent , 
    alignment , 
    spaceBefore , 
    spaceAfter
    bulletFontName'
    bulletFontSize'
    bulletIndent
    textColor
    backColor
    wordWrap
    orderWidth
    borderPadding
    borderColor
    borderRadius
    allowWidows
    allowOrphans
    textTransform
    endDots
    splitLongWords
    underlineProportion
    bulletAnchor
    justifyLastLine
    justifyBreaks
    """
    # make a copy each time else main one will be overwritten
    paraStyle = ParaStyles[name].clone(name="localDefault")
    paraStyle.alignment = TA_JUSTIFY

    for key in paraAttrs.keys():
        if key.lower() in paraIntAttributes:
            value = paraAttrs.get(key.lower())
            paraStyle.__dict__[key.lower] = int(value)

        if key.lower() in paraStrAttributes:
            value = paraAttrs.get(key.lower())
            paraStyle.__dict__[key.lower] = value

    if 'justify' in paraAttrs or 'align' in paraAttrs or 'text-align' in paraAttrs:
        justvalue = paraAttrs.get('text-align') or paraAttrs.get('justify') or paraAttrs.get('align')
        if justvalue.strip().upper() == 'CENTER':
            paraStyle.alignment = TA_CENTER
        if justvalue.strip().upper() == 'RIGHT':
            paraStyle.alignment = TA_RIGHT
        if justvalue.strip().upper() == 'LEFT':
            paraStyle.alignment = TA_LEFT

    return Paragraph(contents.strip().replace('\n', '<br />\n'), paraStyle)
    return contents.strip()


class TOCPara( Paragraph, object ):
    def __init__( self , *args , **kw):
        super( TOCPara , self ).__init__( *args , **kw )
        self._name = ""

from hashlib import sha1
def createTOCHeader(text=''):
    TocStyle = ParagraphStyle(
        name='TOCHeader',
        fontSize=0,
        textColor='white',
    )
    bn = sha1(text ).hexdigest()
    TOP = TOCPara( text+'<a name="%s"/>' % bn , TocStyle )
    TOP._bookmarkName=bn
    return TOP
