'''
Created on Feb 16, 2016

@author: sumgowda
'''
from reportlab.lib.colors import *
import locale
import datetime
from dateutil import parser
from dateutil.relativedelta import relativedelta
from reportlab.lib import colors
pdfnamedColors = colors.getAllNamedColors()

# extend the reportlab linearlyInterpolatedColor to be 3 color gradiant
def linearlyInterpolated3Color(c0, c1, c2, x0, x1, x):
    """
    Linearly interpolates colors. Can handle RGB, CMYK and PCMYK
    colors - give ValueError if colours aren't the same.
    Doesn't currently handle 'Spot Color Interpolation'.
    """

    if c0.__class__ != c1.__class__:
        raise ValueError("Color classes must be the same for interpolation!\nGot %r and %r'" % (c0, c1))
    if x1 < x0:
        x0, x1, c0, c1 = x1, x0, c1, c0  # normalized so x1>x0
    if x < x0 - 1e-8 or x > x1 + 1e-8:  # fudge factor for numerical problems
        raise ValueError("Can't interpolate: x=%f is not between %f and %f!" % (x, x0, x1))
    if x <= x0:
        return c0
    elif x >= x1:
        return c2
    elif x == (x1 - x0) / 2:
        return c1
    cname = c0.__class__.__name__
    dx = float(x1 - x0)
    x = x - x0
    mid = (x1 - x0) / 2
    
    if cname == 'Color':  # RGB
        if x <= mid:
            dx = float(mid - x0)
            r = c0.red + x * (c1.red - c0.red) / dx
            g = c0.green + x * (c1.green - c0.green) / dx
            b = c0.blue + x * (c1.blue - c0.blue) / dx
            a = c0.alpha + x * (c1.alpha - c0.alpha) / dx
        else:
            dx = float(x1 - mid)
            x = x - mid
            r = c1.red + x * (c2.red - c1.red) / dx
            g = c1.green + x * (c2.green - c1.green) / dx
            b = c1.blue + x * (c2.blue - c1.blue) / dx
            a = c1.alpha + x * (c2.alpha - c1.alpha) / dx
        return Color(r, g, b, alpha=a)
    else:
        raise ValueError("Can't interpolate: Unknown color class %s!" % cname)


def format_data(value , default='-' , float_prec='2'):
    if value == None: return default
    try:
        return value.strftime('%Y-%m-%d')
    except:
        pass
    try:
        if float_prec:
            temp = float(locale.format("%." + float_prec + "f", value))
            if temp > 1000:
                return intcomma(float(locale.format("%." + float_prec + "f", value)))
            else:
                return locale.format("%." + float_prec + "f", value)
        else:
            return intcomma(int(value))
    except:
        pass
    try:
        return value.strip()
    except:
        return value
    

def getColorFromStr(colorstr):
    if not colorstr: return
    if isinstance(colorstr, colors.Color): return colorstr
    if colorstr.find('#') == 0:
        return colors.HexColor(colorstr)
    global pdfnamedColors
    return pdfnamedColors.get(colorstr)



import matplotlib.pyplot as plt
import matplotlib.colors as pltcolors
from matplotlib.colors import LinearSegmentedColormap
import colorsys
import seaborn as sns
import numpy as np
class MidpointNormalize(pltcolors.Normalize):
    def __init__(self, vmin=None, vmax=None, midpoint=None, clip=False):
        self.midpoint = midpoint
        pltcolors.Normalize.__init__(self, vmin, vmax, clip)

    def __call__(self, value, clip=None):
        # I'm ignoring masked values and all kinds of edge cases to make a
        # simple example...
        x, y = [self.vmin, self.midpoint, self.vmax], [0, 0.5, 1]
        return np.ma.masked_array(np.interp(value, x, y))

def getLinearSegmentedColormap(df , colorName='', lightness=0.):
    '''Return LinearSegmentedColormap 
    a = getLinearSegmentedColormap(len(s), 'RdYlBu' , 0 )
    
    colorName : 'Blues', 'BuGn', 'BuPu','GnBu',
                   'Greens', 'Greys', 'Oranges', 'OrRd',
                   'PuBu', 'PuBuGn', 'PuRd', 'Purples', 
                   'RdPu', 'Reds', 'YlGn', 'YlGnBu', 
                   'YlOrBr', 'YlOrRd' ,'afmhot', 'autumn', 
                   'bone', 'cool', 'copper', 'gist_heat',
                    'gray', 'hot','pink', 'spring', 
                    'summer', 'winter' , 'BrBG', 'bwr', 
                    'coolwarm', 'PiYG', 'PRGn', 'PuOr',
                    'RdBu', 'RdGy', 'RdYlBu', 'RdYlGn', 
                    'Spectral', 'seismic' , 'Accent', 'Dark2',
                     'Paired', 'Pastel1', 'Pastel2', 'Set1', 
                     'Set2', 'Set3', 'gist_earth', 'terrain', 
                     'ocean', 'gist_stern', 'brg', 'CMRmap', 
                     'cubehelix', 'gnuplot', 'gnuplot2', 'gist_ncar',
                    'nipy_spectral', 'rainbow',  'gist_rainbow', 'hsv'
    
    
    '''
    n_colors = len(df) * len(df.columns)
    def getRgbHsl(h, l, s , lightness=0.5):
        if l + (l * lightness) < 1:
            l = l + (l * lightness)
        return colorsys.hls_to_rgb(h, l, s)
    
    range_selected = df
    allData = []
    for row in range(len(range_selected.index)):
        for col in range(len(range_selected.columns)):
            try:
                val = range_selected.iloc[row, col]
                if type(val) not in (str , unicode):
                    allData.append(range_selected.iloc[row, col])
            except:
                pass
    rng = max(allData) - min(allData)
    low, high, midpoint = 0, 0, np.median(allData)
    # extend lower / upper bounds, compresses color range
    norm = pltcolors.Normalize(min(allData) - (rng * low), max(allData) + (rng * high))

    normed = norm(allData)
    if colorName=='RdGn':
        # Returns rgb palette
        colorsList = sns.diverging_palette(12,120, s=99, l=50, sep=90, n=n_colors, center='light')
        colorsList = [ colorsys.rgb_to_hls(*([r, g, b] )) for (r, g, b, alpha) in colorsList]
        colorsList = [getRgbHsl(*(list(each) + [lightness])) for each in colorsList]
    elif colorName == 'ExclRdYlGn':
        # extend lower / upper bounds, compresses color range
        norm = MidpointNormalize(min(allData) - (rng * low), max(allData) + (rng * high),midpoint =midpoint)
        normed = norm(allData)
        red = pltcolors.hex2color('#F8696B')
        yl = pltcolors.hex2color('#F8E984')
        green = pltcolors.hex2color('#63BE7B')
        colorsList = sns.blend_palette([red, yl, green], n_colors)
    else:
        colorsList = [ colorsys.rgb_to_hls(*x)  for x in sns.color_palette(colorName, n_colors) ]
        colorsList = [ getRgbHsl(* (list(each) + [ lightness]))for each in colorsList ]

    a = LinearSegmentedColormap.from_list(colorName, colorsList)
    c = [ pltcolors.rgb2hex(x) for x in plt.cm.get_cmap(a)(normed)]
    cMaps = dict(zip(allData, c))
    return a , cMaps

