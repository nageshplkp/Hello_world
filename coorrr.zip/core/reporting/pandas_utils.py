'''
Created on Feb 4, 2016

@author: sumgowda
'''
import pandas as pd 
import xlwings
import xlwt
def add_mean(data_frame):
    mean = data_frame.mean(axis=0)
    std = data_frame.std(axis=0)
    mean_plus_std_data = mean + std
    mean_minus_std_data = mean - std
    data_frame['Mean'] = pd.Series(float(mean) , data_frame.index) 
    data_frame['Mean+STD'] = pd.Series(float(mean_plus_std_data) , data_frame.index)
    data_frame['Mean-STD'] = pd.Series(float(mean_minus_std_data) , data_frame.index)
    return data_frame

def dump_data_frame_to_excel(data_frame , pdwriter=None , tabname='' , save=False, index_label=None):
    # writer = pd.ExcelWriter(excelfile, engine='xlsxwriter')
    data_frame.to_excel(pdwriter, sheet_name=tabname)
    if save:
        pdwriter.save()
    
