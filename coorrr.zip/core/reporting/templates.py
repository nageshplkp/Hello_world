'''
Created on Nov 16, 2015

@author: sumgowda
'''
from sys import platform as _platform
from core.reporting.pdf.charts import line_chart_colors, colors, timeto2str, mkTimeTuple, default_font_size, \
    default_font_name, default_chart_font_size
from datetime import datetime
from  reportlab.platypus.tableofcontents import TableOfContents
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, FrameBreak, NextPageTemplate
from reportlab.lib.units import inch, cm
from core.reporting.pdf.charts.tables import BasicTable, DataTable, EmptyDataTable, MutiDataTable
from core.reporting.html.tables import HtmlTable, HtmlMutiTable, EmptyHtmlTable
from core.reporting.html.barchart import HtmlBarChart
from reportlab.pdfgen import canvas
from reportlab.lib import colors
import StringIO, os
from reportlab.graphics.shapes import Image, Drawing, Group, Rect
from reportlab.platypus import Table, Spacer
from reportlab.platypus.flowables import HRFlowable
from reportlab.platypus.paragraph import Paragraph
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY, TA_RIGHT
from core.reporting.parser import isValid
from core.reporting.parser import parsetemplate
from core.reporting.pdf.charts.linecharts import PimcoLineChart, ChartLegend, PimcoLineChartTwoAxis, \
    LineChartWithMarkers, ScatterLines, PimcoAreaLineChart, PimcoAreaChart
from reportlab.graphics.charts.utils import mktime
from reportlab.lib.styles import ParagraphStyle as PS
from reportlab.platypus import Image as FlowImage
from core.reporting.pdf.charts import get_x_ticks, mkTimeTuple, getYearEndXticks, timeto2strMonthYear
from core.reporting.pdf.charts.barcharts import PimcoVerticalBarChart, TableDataBar, PimcoHorizontalBarChart
from reportlab.platypus.flowables import KeepInFrame, PageBreak, KeepTogether
import tempfile
import logging
from bs4.element import NavigableString
import matplotlib, matplotlib.pyplot as plt
from core.reporting.pdf.PimcoFlowables.Pimcoflowables import DrawingFlowable, DrawString, HeaderFootertString, \
    FooterLeftString, FooterCenterString, FooterRightString, HeaderRightString, HeaderCenterString, HeaderLeftString, \
    HorizontalLine, \
    PyKeepInFrame, Portrait, Landscape
import jinja2
from jinja2 import Template as JinjaTempalte
import pandas as pd
import reportlab.rl_settings
from core.reporting.html.linechart import HtmlLineChart
from core.reporting.html import HtmlImage
from core.reporting.pdf.paragraph import CreatePara
# set this to fix a bug with reportlab to automatically resize table width
reportlab.rl_settings.listWrapOnFakeWidth = False
chartMaps = dict(PimcoLineChart=PimcoLineChart,
                 ChartLegend=ChartLegend,
                 PimcoLineChartTwoAxis=PimcoLineChartTwoAxis,
                 LineChartWithMarkers=LineChartWithMarkers,
                 ScatterLines=ScatterLines,
                 PimcoAreaLineChart=PimcoAreaLineChart, PimcoAreaChart=PimcoAreaChart)
'''

'''


class MultiDocTemplate(BaseDocTemplate):
    ''' 
    Class to create pdf, html reports
    
    The purpose of this class is to provide a single entry point for creating diff types of PDF objects 
    The layout of the report will be defined in a template
    
     
    '''

    def __init__(self, templatefile='',
                 inputdata={},
                 templateparams={},
                 dataformat='dict',
                 outputformat='pdf',
                 outputFile=None,
                 width=8.5,
                 height=11,
                 leftmargin=0.3,
                 rightmargin=0.3,
                 topmargin=0.3,
                 bottommargin=0.3,
                 fontName = 'Helvetica',
                 **kw):
        ''' '''

        if templatefile and not os.path.isfile(templatefile):
            raise Exception("Template file not found %s ", templatefile)
        if not templatefile:
            outputText = ''
            self.templatefile = None
        else:
            templateLoader = jinja2.FileSystemLoader(searchpath=[os.path.dirname(templatefile)])
            templateEnv = jinja2.Environment(loader=templateLoader)
            template = templateEnv.get_template(os.path.basename(templatefile))
            outputText = template.render(templateparams)
            self.templatefile = template

        self.outputFile = outputFile
        self.reporttype = outputformat

        if self.reporttype not in ('pdf', 'html'): raise Exception("Unknown outputformat %s, use pdf or html",
                                                                   self.reporttype)
        self.dataformat = dataformat
        if self.dataformat == 'json':
            pass
        else:
            self.inputdata = inputdata

        self.flowables = []
        self.myparser = parsetemplate.ParseTemplate(html_data=outputText)

        self._report = StringIO.StringIO()
        self.pwidth = width * inch
        self.pheight = height * inch
        self.pleftMargin = leftmargin * inch
        self.prightMargin = rightmargin * inch
        self.ptopMargin = topmargin * inch
        self.pbottomMargin = bottommargin * inch
        # temp locaiton to store images
        self.imagestmp = tempfile.mkdtemp()
        self.pagenumber = 1
        self.leftheader = {}
        self.centerheader = {}
        self.rightheader = {}
        self.leftfooter = {}
        self.centerfooter = {}
        self.rightfooter = {}
        self.fontName = fontName

        BaseDocTemplate.__init__(self, self._report,
                                 pagesize=(self.pwidth, self.pheight),
                                 leftMargin=self.pleftMargin,
                                 rightMargin=self.prightMargin,
                                 topMargin=self.ptopMargin,
                                 bottomMargin=self.pbottomMargin,
                                 title="")

        self.autopagenumber = False
        self.ContentHeight, self.ContentWidth = self.pheight - self.ptopMargin - self.pbottomMargin, self.pwidth - self.pleftMargin - self.prightMargin

        self.pagesize = (self.pwidth, self.pheight)
        self.objectsList = []
        self.objectsByName = {}
        self.pageSizes = []
        self.toc = None

    def _addTOCTempalte(self):

        contetntsFrame = Frame(1 * inch, 1 * inch, 6 * inch,
                               9 * inch,
                               id='normal',
                               leftPadding=0,
                               bottomPadding=0,
                               rightPadding=0,
                               topPadding=0,
                               #showBoundary=1,
                               )
        pagesize = (8.5 * inch, 11 * inch)
        if self.pageTemplates:
            self.pageTemplates = [ PageTemplate(id="TOC", frames=[contetntsFrame],
                                               pagesize=pagesize) ] + self.pageTemplates
        else:
            self.addPageTemplates(PageTemplate(id="TOC", frames=[contetntsFrame],
                                           pagesize=pagesize))

    def _getTemplates(self, width, height, left_margin, right_margin, top_margin, bottom_margin, id):

        ContentHeight, ContentWidth = height - top_margin - bottom_margin, \
                                      width - left_margin - right_margin

        contetntsFrame = Frame(left_margin, bottom_margin, ContentWidth,
                               ContentHeight,
                               id='normal',
                               leftPadding=0,
                               bottomPadding=0,
                               rightPadding=0,
                               topPadding=0,
                               #showBoundary=1,
                               )

        footerFramePort = Frame(left_margin, 0, ContentWidth,
                                bottom_margin,
                                id='footer',
                                leftPadding=0,
                                bottomPadding=0,
                                rightPadding=0,
                                topPadding=0,
                                # showBoundary=1,
                                )
        pagesize = (width, height)
        shrinktemplates = PageTemplate(id=id, frames=[contetntsFrame],
                                       pagesize=pagesize)

        return shrinktemplates

    def onFirstPage(self, canvas, document):
        canvas.setFont(self.fontName, 8)
        color = getattr(colors, 'fidlightblue')
        c, m, yel, k = colors.rgb2cmyk(color.red, color.green, color.blue)
        CMYK = colors.CMYKColor(c, m, yel, k)

    def afterDrawPage(self, canv, doc):
        canv.setFont(self.fontName, 8)
        canv.setFillColor(getattr(colors, 'black'))
        pageAccessIndex = canv.getPageNumber() - 1
        # get the size of each page
        if self.toc and canv.getPageNumber() ==1:
            return
        if self.toc:
            pageAccessIndex =  canv.getPageNumber() - 2
        try:
            pagewidth, pageheight, pleftMargin, prightMargin, ptopMargin, pbottomMargin = self.pageSizes[
                pageAccessIndex ]
        except:
            pagewidth, pageheight, pleftMargin, prightMargin, ptopMargin, pbottomMargin = self.pageSizes[-1]

        if self.autopagenumber:
            canv.drawCentredString(pagewidth / 2., inch * 0.1, str(pageAccessIndex + self.pagenumber))

        if self.centerheader.get(pageAccessIndex):
            canv.drawCentredString(pagewidth / 2., pageheight - .2 * inch,
                                   self.centerheader.get(pageAccessIndex))
            pass

        if self.leftheader.get(pageAccessIndex):
            canv.drawString(inch * 0.25, pageheight - .2 * inch, self.leftheader.get(pageAccessIndex))

        if self.rightheader.get(pageAccessIndex):
            canv.drawString(inch * 7, pageheight - .2 * inch, self.rightheader.get(pageAccessIndex))

        if self.centerfooter.get(pageAccessIndex):
            canv.drawCentredString(pagewidth / 2., inch * 0.1, self.centerfooter.get(pageAccessIndex))

        if self.leftfooter.get(pageAccessIndex):
            canv.drawString(inch * 0.25, inch * 0.1, self.leffooter.get(pageAccessIndex))

        if self.rightfooter.get(pageAccessIndex):
            canv.drawString(inch * 7, inch * 0.1, self.rightfooter.get(pageAccessIndex))

    def afterFlowable(self, flowable):
        if flowable.__class__.__name__ == 'TOCPara':
            text = flowable.getPlainText()
            E = [0, text, self.page ]
            bn = getattr(flowable, '_bookmarkName', None)
            if bn is not None: E.append(bn)
            self.notify('TOCEntry', tuple(E))

        if flowable.__class__.__name__ == 'TableOfContents':
            self.handle_nextPageTemplate(self.page)

    def afterPage(self):
        if len(self.pageTemplates) > self.page:
            self.handle_nextPageTemplate(self.page)
        BaseDocTemplate.afterPage(self)

    def build(self, flowables, filename=None, canvasmaker=canvas.Canvas):
        if self.reporttype == 'pdf':
            for eachTemplate in self.pageTemplates:
                eachTemplate.afterDrawPage = self.afterDrawPage
            BaseDocTemplate.build(self, flowables, filename=None, canvasmaker=canvasmaker)

    def __parseTempaltes(self, tempalteTag):
        # for eachpagetempalte
        pageTemplates = self.myparser.getPageTempaltes(tempalteTag)
        for pageTemplate in pageTemplates:
            self.myparser.getProperties(pageTemplate)
            self.myparser.getPageTemplateProperties(pageTemplate)

    def create(self):
        # self.pageTemplates[1].afterDrawPage = self.afterDrawPage
        templateTag = self.myparser.getTemplate()
        styleTag = self.myparser.getStyleSheet()
        if templateTag:
            self.__parseTempaltes(templateTag)

        idx = 0
        htmlContent = ''
        htmlscriptcontent = ''
        self.page_properties = {}
        for idx, page in enumerate(self.myparser.getNextPage()):
            if idx > 0:
                self.flowables.append(PageBreak())
            page_flowables = []
            nonPageFlowables = []
            self.page_properties = self.myparser.getProperties(page)
            pagewidth = self.pwidth
            if 'width' in self.page_properties:
                pagewidth = float(self.page_properties.get('width')) * inch

            pageheight = self.pheight
            if 'height' in self.page_properties:
                pageheight = float(self.page_properties.get('height')) * inch

            pleftMargin = self.pleftMargin
            if 'leftmargin' in self.page_properties:
                pleftMargin = float(self.page_properties.get('leftmargin')) * inch

            prightMargin = self.prightMargin
            if 'rightmargin' in self.page_properties:
                prightMargin = float(self.page_properties.get('rightmargin')) * inch

            ptopMargin = self.ptopMargin
            if 'topmargin' in self.page_properties:
                ptopMargin = float(self.page_properties.get('topmargin')) * inch

            pbottomMargin = self.pbottomMargin
            if 'rightmargin' in self.page_properties:
                pbottomMargin = float(self.page_properties.get('rightmargin')) * inch
            from core.reporting.pdf.paragraph import createTOCHeader
            if 'tocname' in self.page_properties:
                if not self.toc:
                    self.toc = TableOfContents()

                    self.toc.levelStyles = [
                        PS(fontSize=8, name='TOCHeading1', leftIndent=20, firstLineIndent=10,
                           spaceBefore=2, leading=0),
                        PS(fontSize=6, name='TOCHeading2', leftIndent=40, firstLineIndent=2,
                           spaceBefore=2, leading=0),
                    ]
                    self._addTOCTempalte()
                    self.flowables = [ self.toc , PageBreak() ] + self.flowables
                    # self.handle_nextPageTemplate('TOC')
                #self.toc.addEntry(0, self.page_properties.get('tocname'), idx + 1)
                self.flowables.append(createTOCHeader(self.page_properties.get('tocname')))

            self.pageSizes.append((pagewidth, pageheight, pleftMargin, prightMargin, ptopMargin, pbottomMargin))
            templates = self._getTemplates(pagewidth, pageheight,
                                           pleftMargin, prightMargin,
                                           ptopMargin, pbottomMargin,
                                           id='frame_%d' % (idx,)
                                           )

            ContentHeight, ContentWidth = pageheight - ptopMargin - pbottomMargin, \
                                          pagewidth - pleftMargin - prightMargin
            self.addPageTemplates(templates)
            # self.handle_nextPageTemplate('frame_%d' % ( idx ,))

            #self.pagenumber += 1
            elements = self.myparser.getPageContents(page)

            if self.reporttype == 'pdf':
                for ele in elements:
                    fobj = self.createFlowableObject(ele, width=self.ContentWidth, height=self.ContentHeight,
                                                     pageidx=idx)
                    if fobj:
                        page_flowables.append(fobj)

                if self.page_properties.get('mode', 'shrink').lower() == 'shrink':
                    self.flowables.append(
                        KeepInFrame(ContentWidth, ContentHeight, mode='shrink', content=page_flowables,
                                    vAlign='TOP'))
                if self.page_properties.get('mode',
                                            'shrink').lower() == 'overflow':  # this moves the contents to next page

                    self.flowables += page_flowables

                if nonPageFlowables:
                    self.flowables += nonPageFlowables
            elif self.reporttype == 'html':
                for ele in elements:
                    htmlContent += self.createHtmlObject(ele)

        if self.reporttype == 'pdf':
            if self.toc:
                self.handle_nextPageTemplate('TOC')
            MultiDocTemplate.multiBuild(self, self.flowables)
        else:
            self._report.write(htmlContent)

        if self.outputFile:
            file = open(self.outputFile, 'wb+')
            logging.info(self.outputFile + " file created ")
            if self.reporttype == 'pdf':
                file.write(self.read());
            else:
                file.write(
                    """<!DOCTYPE html><html><script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script><body>""" + self.read() + "</body></html>");
            file.close()

    def createFlowableObject(self, element, width=None, height=None, pageidx=None):
        element_name = element.name.upper()
        if element_name == 'TABLE':
            return self.__createTable(element)
        elif element_name == 'HEATMAPTABLE':
            return self.__createTable(element, heatmap=True)
        elif element_name == 'LINECHART':
            return self.__createLineChart(element, width=width, height=height)
        elif element_name in ['PARA']:
            return self.__createPara(element)
        elif element_name == 'DRAWSTRING':
            return self.createDrawString(element)
        elif element_name == 'IMG':
            return self.__createImage(element)
        elif element_name == 'BARCHART':
            return self.__createBarChart(element)
        elif element_name == 'TABLELAYOUT':
            return self.__createLayoutTable(element, width, height)
        elif element_name == 'TWOAXISLINECHART':
            return self.__createTwoAxisLineChart(element)
        elif element_name == 'FRAME':
            return self.__createFrame(element)
        elif element_name == 'HEADER':
            headerContents = self.__parseHeaderContents(element)
            if pageidx is not None:
                self.leftheader[pageidx], self.centerheader[pageidx], self.rightheader[pageidx] = headerContents
            return None
        elif element_name == 'FOOTER':
            footerContents = self.__parseFooterContents(element)
            if pageidx is not None:
                self.leftfooter[pageidx], self.centerfooter[pageidx], self.rightfooter[pageidx] = footerContents
            return None
        elif element_name == 'DRAWING':
            self.parseDrawingContents(element)
        elif element_name == 'HR':
            return self.__parseHrContents(element)
        elif element_name == 'SPACER':
            return self.__parseSpacer(element)

    def createHtmlObject(self, element):
        element_name = element.name.upper()
        if element_name == 'TABLE':
            return self.__createHtmlTable(element)
        elif element_name == 'HEATMAPTABLE':
            return self.__createHtmlTable(element, heatmap=True)
        elif element_name == 'IMG':
            return self.__createHtmlImage(element)
        if element_name == 'TABLELAYOUT':
            return self.__createHtmlLayoutTable(element)
        elif element_name == 'LINECHART':
            return self.__createHtmlLineChart(element)
        elif element_name == 'BARCHART':
            return self.__createHtmlBarChart(element)
        elif element_name == 'FOOTER':
            return self.__parseHtmlFooterContents(element)
        elif element_name == 'METADATA':
            return self.__parseHtmlMetadata(element)
        return ''

    def __parseHtmlMetadata(self, element):
        attrs = element.attrs
        tmp = JinjaTempalte("""\n<!-- <metadata {{properties}} >{{contents}}</metadata> --> """)
        properties = ''
        for key, value in attrs.iteritems():
            properties += ' %s="%s" ' % (key, value)

        return tmp.render(properties=properties, contents="".join(element.contents))

    def __parseSpacer(self, ele):
        properties = self.myparser.getProperties(ele)
        try:
            width = float(properties.get('width')) * inch
        except:
            width = 8 * inch
        try:
            height = float(properties.get('height')) * inch
        except:
            height = 0.1 * inch
        return Spacer(width, height)

    def __parseHrContents(self, ele):
        properties = self.myparser.getProperties(ele)
        try:
            width = float(properties.get('width')) * inch
        except:
            width = 8.25 * inch
        try:
            height = float(properties.get('height')) * inch
        except:
            height = 0.005 * inch
        color = properties.get('color','black')
        return HRFlowable(width=width, thickness=height, lineCap='square', color=color)

    def __parseHeaderFooterSections(self, ele):
        return_str = ''
        for each in ele.contents:
            if isValid(each):
                if each.name.upper() == 'AUTOPAGENUMBER':
                    self.autopagenumber = True
                    if each.contents:
                        self.pagenumber = int("".join(each.contents))
            else:
                return_str += each.strip()
        return return_str

    def __parseHeaderContents(self, ele):
        properties = self.myparser.getProperties(ele)
        left = ele.find("left")
        leftheader, centerheader, rightheader = None, None, None
        if left:
            leftheader = self.__parseHeaderFooterSections(left)

        center = ele.find("center")
        if center:
            centerheader = self.__parseHeaderFooterSections(center)

        right = ele.find("right")
        if right:
            rightheader = self.__parseHeaderFooterSections(right)
        return leftheader, centerheader, rightheader

    def __parseHtmlFooterContents(self, ele):
        properties = self.myparser.getProperties(ele)
        left = ele.find("left")
        contents = '<table width=100%> <col width="33%"/> <col width="33%"/><col width="33%"/>'
        if left:
            contents += '<td>' + self.__parseHeaderFooterSections(left) + '</td>'
        else:
            contents += '<td></td>'

        center = ele.find("center")
        if center:
            contents += '<td>' + self.__parseHeaderFooterSections(center) + '</td>'
        else:
            contents += '<td></td>'

        right = ele.find("right")
        if right:
            contents += '<td>' + self.__parseHeaderFooterSections(right) + '</td>'
        else:
            contents += '<td></td>'
        contents += "</table>"
        return contents

    def __parseFooterContents(self, ele):
        properties = self.myparser.getProperties(ele)
        left = ele.find("left")
        leftfooter, centerfooter, rightfooter = None, None, None
        if left:
            leftfooter = self.__parseHeaderFooterSections(left)

        center = ele.find("center")
        if center:
            centerfooter = self.__parseHeaderFooterSections(center)

        right = ele.find("right")
        if right:
            rightfooter = self.__parseHeaderFooterSections(right)
        return leftfooter, centerfooter, rightfooter

    def __createFrame(self, element):
        properties = self.myparser.getProperties(element)
        width = float(properties.get('width')) * inch
        height = float(properties.get('height')) * inch
        flowableContent = []
        for ele in element.contents:
            if not isValid(ele):
                continue

            obj = self.createFlowableObject(ele)
            if obj:
                if isinstance(obj, list):
                    flowableContent += obj
                else:
                    flowableContent.append(obj)

        return KeepInFrame(width, height, content=flowableContent)

    def __createLayoutTable(self, element, width, height):
        properties = self.myparser.getProperties(element)
        colWidths, rowHeights = None, None
        if 'colwidths' in properties:
            colWidths = [float(row) * inch for row in properties.get('colwidths').split(",")]
        if 'rowheights' in properties:
            rowHeights = [float(row) * inch for row in properties.get('rowheights').split(",")]

        if not element: return
        rows = element.find_all("tr", recursive=False)
        table_data = []
        # check number of columns
        layout_styles = []
        rowid = 0

        borderStyle = [('GRID', (0, 0), (-1, -1), 0.10, colors.black)]
        table_style = [
            ('LEFTPADDING', (0, 0), (-1, -1), 0),
            ('RIGHTPADDING', (0, 0), (-1, -1), 0),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
            ('TOPPADDING', (0, 0), (-1, -1), 0)
        ]

        if 'align' in properties:
            table_style.append(('ALIGN', (0, 0), (-1, -1), properties['align'].upper()))
        else:
            # table_style.append(('ALIGN', (0, 0), (-1, -1), 'CENTER'))
            pass
        if 'valign' in properties:
            table_style.append(('VALIGN', (0, 0), (-1, -1), properties['valign'].upper()))
        else:
            table_style.append(('VALIGN', (0, 0), (-1, -1), 'TOP'))

        if 'border' in properties:
            table_style += borderStyle

        for rowid, row in enumerate(rows):
            each_row = []
            tds = row.find_all("td", recursive=False)
            colid = 0
            for cell in tds:
                # print "create each td", cell.contents
                if isValid(cell):
                    if not cell.contents:
                        each_row.append('')

                    for each_cell_item in cell.contents:
                        if isinstance(each_cell_item, str) and each_cell_item.strip() == '':
                            continue
                        # if a new line withing other tags ignore
                        if isinstance(each_cell_item, NavigableString) and len(cell.contents) > 1:
                            continue

                        attributes = {}
                        if hasattr(cell, 'attrs'):
                            attributes = cell.attrs
                        if isValid(each_cell_item):
                            width = None
                            if colWidths and colid in colWidths:
                                width = colWidths[colid]
                            fobj = self.createFlowableObject(each_cell_item, width=width)
                        else:
                            # is td with strings
                            attributes.update(properties)
                            fobj = self.__getPara(each_cell_item, attributes)

                        if fobj:
                            each_row.append(fobj)

                        if 'colspan' in attributes:
                            layout_styles.append(
                                ('SPAN', (colid, rowid), (colid + int(attributes['colspan']) - 1, rowid)))
                            each_row += ['' for each in range(int(attributes['colspan']) - 1)]
                            colid += int(attributes['colspan']) - 1
                        else:
                            colid += 1

            table_data.append(each_row)

        # table_data[0] = [ '' ,'' ,'']
        t = Table(table_data, colWidths=colWidths, rowHeights=rowHeights)

        table_style += layout_styles
        t.setStyle(table_style)
        t.hAlign = 'CENTER'
        return t

    def __createHtmlLayoutTable(self, element):
        properties = self.myparser.getProperties(element)
        if not element: return
        row = element.find("tr")
        table_data = []
        while row:
            each_row = []
            if not isValid(row):
                row = row.next_sibling
                continue
            cell = row.find("td")

            while cell:
                # print "create each td", cell.contents
                tdAttrs = {}
                if hasattr(cell, 'attrs'):
                    tdAttrs = cell.attrs

                if isValid(cell):
                    for each_cell_item in cell.contents:
                        if isValid(each_cell_item):
                            fobj = self.createHtmlObject(each_cell_item)
                            if fobj:
                                each_row.append({'contents': fobj, 'properties': tdAttrs})

                cell = cell.next_sibling
            table_data.append(each_row)
            row = row.next_sibling

        import uuid
        myuuid = str(uuid.uuid4().get_hex().upper()[0:16])
        layout_id = '_' + myuuid

        if "width" in properties:
            width = "width:" + properties["width"] + ";"
        else:
            width = ""
        if "border" in properties:
            border = "border:" + properties["border"] + ";"
        else:
            border = "border:0px solid white;"

        if "margin" in properties:
            margin = "margin:" + properties["margin"] + ";"
        else:
            margin = "margin:0;"

        tableTempalte = '''
        <style type="text/css">
            td {
              font-family: Calibri, Helvetica, sans-serif;
              font-size: 1em;
               height: 1em;
            }
            .tablelayout_@uuid {
                @border
                border-collapse: collapse;
                @margin
                @width
            }
        </style>
        <table class="tablelayout_@uuid">
            {% for row in tableData %}
                <tr valign="top">
                    {% for cell in row %}
                        <td class="tablelayout_@uuid" {% for k, v in cell.properties.iteritems() %} {{k}}="{{v}}" {% endfor %} >
                            {{cell.contents}}
                        </td>
                    {% endfor %}
                </tr>
            {% endfor %}
        </table>
        '''
        tableTempalte = tableTempalte.replace("@uuid", layout_id)
        tableTempalte = tableTempalte.replace("@width", width)
        tableTempalte = tableTempalte.replace("@border", border)
        tableTempalte = tableTempalte.replace("@margin", margin)
        tmp = JinjaTempalte(tableTempalte)

        return tmp.render(dict(tableData=table_data))

    def __createHtmlBarChart(self, element):
        properties = self.myparser.getProperties(element)
        datasourcename = properties.get('datasource')
        data_table = self.inputdata.get(datasourcename)
        charttype = properties.get('charttype', 'default')
        xmlStyleTag = element.find("style")
        if isinstance(data_table, pd.DataFrame):
            htmlTab = HtmlBarChart(data_table, None, properties, self.myparser, xmlStyleTag=xmlStyleTag)
            return htmlTab.getContent()

        if not data_table:
            logging.error("Missing data source % ", (datasourcename,))
            return
        if not 'data' in data_table or not isinstance(data_table['data'], pd.DataFrame):
            logging.error("Data source % does not have data object that is a pandas dataframe", (datasourcename,))
            return
        htmlchart = HtmlBarChart(data_table['data'], data_table.get('style'), properties, self.myparser,
                                 xmlStyleTag=xmlStyleTag)
        return htmlchart.getContent()

    def __createBarChart(self, element):
        properties = self.myparser.getProperties(element)
        type_name = element.name.upper()
        name = properties.get('name', '')
        datasourcename = properties.get('datasource')
        chat_input_data = self.inputdata.get(datasourcename)
        logging.error("Processing %s , %s " % (type_name, name))
        if not isinstance(chat_input_data, pd.DataFrame) and not chat_input_data:
            logging.error("Data not found %s " % (datasourcename,))
            return

        chartDf = None
        if isinstance(chat_input_data, pd.DataFrame):
            chartDf = chat_input_data
        else:
            chartDf = chat_input_data['data']
        try:
            width = float(properties.get('width', 3)) * inch
            height = float(properties.get('height', 2)) * inch
        except:
            width, height = 3 * inch, 2 * inch

        if 'type' in properties:
            barchat = PimcoHorizontalBarChart(width=width, height=height)
        else:
            barchat = PimcoVerticalBarChart(width=width, height=height)

        barchat.setData(chartDf, properties)
        return barchat

    def __createImage(self, element):
        properties = self.myparser.getProperties(element)
        srcfile = properties.get('src')
        if not os.path.isfile(srcfile):
            logging.error("File not found %s ", (srcfile,))
            return
        try:
            width = float(properties.get('width', 3)) * inch
        except:
            width = 3 * inch
        try:
            height = float(properties.get('height', 2)) * inch
        except:
            height = 2 * inch

        return FlowImage(srcfile, width, height)

    def __createHtmlImage(self, element):
        properties = self.myparser.getProperties(element)
        srcfile = properties.get('src')
        return HtmlImage(srcfile, properties).getContents()

    def createDrawString(self, element):
        properties = self.myparser.getProperties(element)
        text_data = element.string
        dg = DrawString()
        dg.setDrawProperties(properties, text_data)
        return dg

    def __createPara(self, element):
        para_txt = ''
        if element:
            para_txt = element.string

        if element and element.contents:
            para_txt = " ".join([str(each) for each in element.contents])

        properties = self.myparser.getProperties(element)

        return self.__getPara(para_txt, properties)

    def __getPara(self, para_txt, properties):
        alignment = TA_CENTER
        if 'align' in properties:
            align = properties['align']
            if align == 'left':
                alignment = TA_LEFT
            if align == 'right':
                alignment = TA_RIGHT

        fontSize = 7
        if 'fontsize' in properties:
            try:
                fontSize = int(properties['fontsize'])
            except:
                pass

        dis_body_style = PS(name='centered',
                            fontSize=fontSize,
                            textColor=colors.black,
                            fontName=self.fontName,
                            alignment=alignment,
                            spaceAfter=0,
                            )
        para_txt = para_txt.replace('\n', '<br />\n')

        myps = Paragraph(para_txt, dis_body_style)
        return myps

    def __mapPlotLibChart(self, df, width=None, height=None, charttype='line'):
        # need to make this configurable
        axplot = df.plot(figsize=(8, 4))
        tmp = tempfile.NamedTemporaryFile(delete=False)
        axplot.figure.savefig(tmp.name)
        imageF = KeepInFrame(width, height, content=[FlowImage(tmp.name + ".png")])
        return imageF

    def mapPlotLib2AxisChart(self, df, width=None, height=None, leftcolumns=None, rightcolumns=None,
                             chartStyleProps=dict()):
        fig, left = plt.subplots(figsize=(8, 4))

        right = left.twinx()
        for column in leftcolumns:
            left.plot(df.index, df[column])

        for column in rightcolumns:
            right.plot(df.index, df[column])

        if 'XLABEL' in chartStyleProps:
            left.set_xlabel(chartStyleProps.get('XLABEL', ''))
        if 'YLABEL' in chartStyleProps or 'LEFTYLABEL' in chartStyleProps:
            left.set_ylabel(chartStyleProps.get('LEFTYLABEL', chartStyleProps.get('YLABEL', '')))

        if 'RIGHTYLABEL' in chartStyleProps:
            right.set_ylabel(chartStyleProps.get('RIGHTYLABEL', ''))

        if 'TITLE' in chartStyleProps:
            plt.title(chartStyleProps.get('TITLE', ''))

        tmp = tempfile.NamedTemporaryFile(delete=False)
        fig.savefig(tmp.name)
        imageF = KeepInFrame(width, height, content=[FlowImage(tmp.name + ".png")])
        return imageF

    def __createHtmlLineChart(self, element):
        properties = self.myparser.getProperties(element)
        datasourcename = properties.get('datasource')
        data_table = self.inputdata.get(datasourcename)
        charttype = properties.get('charttype', 'default')
        xmlStyleTag = element.find("style")
        if isinstance(data_table, pd.DataFrame):
            htmlTab = HtmlLineChart(data_table, None, properties, self.myparser, xmlStyleTag=xmlStyleTag)
            return htmlTab.getContent()

        if not data_table:
            logging.error("Missing data source % ", (datasourcename,))
            return

        if not 'data' in data_table or not isinstance(data_table['data'], pd.DataFrame):
            logging.error("Data source % does not have data object that is a pandas dataframe", (datasourcename,))
            return
        htmlTab = HtmlLineChart(data_table['data'], data_table.get('style'), properties, self.myparser)
        return htmlTab.getContent()

    def __createLineChart(self, element, width=None, height=None):
        """ Creates a line chart object 
        """
        properties = self.myparser.getProperties(element)
        datasourcename = properties.get('datasource')
        if datasourcename not in self.inputdata:
            logging.error("Missing data source % ", (datasourcename,))
            return

        data_table = self.inputdata.get(datasourcename)
        charttype = properties.get('charttype', 'default')

        df = None

        if isinstance(data_table, pd.DataFrame):
            df = data_table
        elif isinstance(data_table, dict):
            df = data_table['data']
        else:
            logging.error("Data source % does not have data object that is a pandas dataframe", (datasourcename,))
            return

        try:
            if 'width' in properties:
                width = float(properties.get('width', 0)) * inch
            if 'height' in properties:
                height = float(properties.get('height', 0)) * inch
        except:
            width, height = width or 3 * inch, height or 2 * inch

        if charttype == 'matplotlib':
            return self.__mapPlotLibChart(df, width=width, height=height)

        index_data = df.index

        # need to fix ephoc time issue, mktime c code call fails for dates less than 1970
        catNames = [val.strftime("%d/%m/%Y") for val in index_data if val.year > 1970]

        indexCatNames = [mktime(mkTimeTuple(val)) for val in catNames]
        classPtr = PimcoLineChart
        if 'charttype' in properties:
            # returns list for class
            className = properties.get('charttype') or 'PimcoLineChart'
            classPtr = chartMaps.get(className)

        xmlStyleTag = element.find("style")

        chart = classPtr(height=height, width=width, xmlStyleTag=xmlStyleTag)
        chart.setProperties(properties)

        chart.setData(df, properties)
        # chart.setStyleElement(styleelelemnt)

        if 'label' in properties:
            chart.setTitle(properties['label'])
        imageF = KeepInFrame(width, height, content=[chart])
        return imageF

    def __createTwoAxisLineChart(self, element):
        """
        
        """
        properties = self.myparser.getProperties(element)
        datasourcename = properties.get('datasource')
        data_table = self.inputdata.get(datasourcename)
        if not data_table:
            logging.error("Missing data source % ", (datasourcename,))
            return

        leftcolumns = properties.get('leftcolumns')
        rightcolumns = properties.get('rightcolumns')

        if not 'data' in data_table or not isinstance(data_table['data'], pd.DataFrame):
            logging.error("Data source % does not have data object that is a pandas dataframe", (datasourcename,))
            return

        dataFrameTable = data_table['data']

        try:
            width = float(properties.get('width', 3)) * inch
            height = float(properties.get('height', 2)) * inch
        except:
            width, height = 3 * inch, 2 * inch

        if leftcolumns:
            leftcolumns = leftcolumns.split(",")

        if rightcolumns:
            rightcolumns = rightcolumns.split(",")

        styleelelemnt = element.find("style")
        styleproperties = self.__parseChartStyleElements(styleelelemnt)

        return self.mapPlotLib2AxisChart(data_table['data'], width=width, height=height,
                                         leftcolumns=leftcolumns, rightcolumns=rightcolumns,
                                         chartStyleProps=styleproperties)

        # need to fix ephoc time issue, mktime c code call fails for dates less than 1970
        catNames = [val[0].strftime("%d/%m/%Y") for val in data_table.values if val[0].year > 1970]
        chart = PimcoLineChartTwoAxis(width=width, height=height)

        tt = mkTimeTuple(catNames[0])
        start = mktime(mkTimeTuple(catNames[0]))
        end = mktime(mkTimeTuple(catNames[-1]))
        chart.xValueAxis.valueMin = start
        chart.xValueAxis.valueMax = end
        left_table_data = []
        legend = []
        for idx, line in enumerate(left_data_table.to_csv(header=False).split("\n")):
            if line:
                datefprmat = datetime.strptime(line.split(",")[1], "%Y-%m-%d")
                if (datefprmat.year > 1970):
                    table_data.append((mktime(mkTimeTuple(datefprmat.strftime("%d/%m/%Y"))), float(line.split(",")[2])))

        right_table_data = []
        for idx, line in enumerate(right_data_table.to_csv(header=False).split("\n")):
            if line:
                datefprmat = datetime.strptime(line.split(",")[1], "%Y-%m-%d")
                if (datefprmat.year > 1970):
                    right_table_data.append(
                        (mktime(mkTimeTuple(datefprmat.strftime("%d/%m/%Y"))), float(line.split(",")[2])))

        max_y_value_excess = max([row[1] for row in right_table_data])
        min_y_value_excess = min([row[1] for row in right_table_data])
        chart.rightaxis.yValueAxis.valueMax = max_y_value_excess
        chart.rightaxis.yValueAxis.valueMin = min_y_value_excess

        chart.data = [left_table_data, right_table_data]
        chart.xValueAxis.valueSteps = get_x_ticks(catNames)
        legend = ChartLegend(legend)
        chart.set_legends(legend)

        drawing = Drawing(width, height)

        drawing.add(chart)

        return drawing

    # def __createMultiHtmlTable(self,element, heatmap = False):

    def __createHtmlTable(self, element, heatmap=False):
        properties = self.myparser.getProperties(element)
        datasourcename = properties.get('datasource', "")
        if not datasourcename:
            # this must be place holder table
            # Parse the contencts add this to it
            pass
        databarcolumn = properties.get('databarcolumn')
        floatformat = properties.get('floatformat', '{0:.2f}')

        styleelelemnts = element.find_all("style")
        if heatmap and 'gradientname' not in properties:
            properties['gradientname'] = 'RdYlGn'

        dataSourceList = datasourcename.split(",")

        if len(dataSourceList) > 1:
            dfs = []
            for each in dataSourceList:
                if isinstance(self.inputdata.get(each), pd.DataFrame):
                    dfs.append(self.inputdata.get(each))
                elif self.inputdata.get(each) and isinstance(self.inputdata.get(each).get('data'), pd.DataFrame):
                    dfs.append(self.inputdata.get(each).get('data'))

            styles = [self.inputdata.get(each).get('style') for each in dataSourceList \
                      if isinstance(self.inputdata.get(each), dict)]

            htmlTab = HtmlMutiTable(dfs, styles, properties=properties, styleelelemnts=styleelelemnts,
                                    parser=self.myparser)

        else:
            if not datasourcename:
                htmlTab = EmptyHtmlTable(element=element)
                return htmlTab.getContent()

            data_table = self.inputdata.get(datasourcename)
            styleelelemnt = None
            if styleelelemnts:
                styleelelemnt = styleelelemnts[0]
            if isinstance(data_table, pd.DataFrame):
                htmlTab = HtmlTable(data_table, style=None,
                                    properties=properties, styleelelemnt=styleelelemnt,
                                    parser=self.myparser)
            elif 'data' in data_table:
                htmlTab = HtmlTable(data_table['data'], style=data_table.get('style'),
                                    properties=properties, styleelelemnt=styleelelemnt,
                                    parser=self.myparser)

        return htmlTab.getContent()

    def __createFlowable(self, dfs=[], style=None, heatmap=False,
                         width=None, height=None, properties={}, styleXmlElement=None):

        noOfDf = len(dfs)
        if noOfDf == 1:
            return DataTable(df, style, properties=properties, styleXmlElement=styleXmlElement, parser=self.myparser)
        if noOfDf > 1:
            return MutiDataTable(dfs, styles=styles if styles else styleelelemnts, properties=properties)

    def __createTable(self, element, heatmap=False, width=None, height=None):
        '''
        '''
        properties = self.myparser.getProperties(element)
        datasourcename = properties.get('datasource')
        databarcolumn = properties.get('databarcolumn')
        floatformat = properties.get('floatformat', '{0:.2f}')
        data_table = self.inputdata.get(datasourcename)
        styleelelemnt = element.find("style")

        if heatmap and 'gradientname' not in properties:
            properties['gradientname'] = 'RdYlGn'

        class SplitTable(Table):

            def __init__(self, data, colWidths=None, rowHeights=None, repeatRows=0):
                SplitTable.__init__(self, data, colWidths=colWidths, rowHeights=rowHeights,
                                    repeatRows=repeatRows)

            def onSplit(self, T, byRow=1):
                '''
                This method will be called when the Table is split.
                Special purpose tables can override to do special stuff.
                '''
                pass

        if isinstance(data_table, pd.DataFrame):
            mydt = DataTable(data_table, style=None, properties=properties, styleXmlElement=styleelelemnt,
                             parser=self.myparser, fontName = self.fontName)
            rpdt = Table(mydt.data, rowHeights=mydt.rowHeights, colWidths=mydt.colWidths, repeatRows=mydt.noofheaders)
            rpdt.setStyle(mydt.style)
            return rpdt

        if isinstance(data_table, dict):
            mydt = DataTable(data_table['data'], style=data_table.get('style'), properties=properties,
                             styleXmlElement=styleelelemnt, parser=self.myparser, fontName = self.fontName)
            rpdt = Table(mydt.data, rowHeights=mydt.rowHeights, colWidths=mydt.colWidths, repeatRows=mydt.noofheaders)
            rpdt.setStyle(mydt.style)
            return rpdt

        if datasourcename and len(datasourcename.split(",")) > 1:
            # its mutiple data source
            dfs = []
            styles = []
            styleelelemnts = element.find_all("style")
            dictStyleElements = {}
            for each in styleelelemnts:
                if 'datasource' in each.attrs:
                    for dts in each.attrs['datasource'].split(","):
                        dictStyleElements[dts] = each
                else:
                    for sourcename in datasourcename.split(","):
                        dictStyleElements[sourcename] = each

            for eachsource in datasourcename.split(","):
                dfD = self.inputdata.get(eachsource.strip())
                if isinstance(dfD, pd.DataFrame): dfs.append(dfD)
                if isinstance(dfD, dict) and isinstance(dfD.get('data'), pd.DataFrame):
                    dfs.append(dfD.get('data'))
                if eachsource in dictStyleElements:
                    styles.append(dictStyleElements.get(eachsource))

            mydt = MutiDataTable(dfs, styles=styles if styles else styleelelemnts, properties=properties)
            rpdt = Table(mydt.data, rowHeights=mydt.rowHeights, colWidths=mydt.colWidths, repeatRows=mydt.noofheaders)
            rpdt.setStyle(mydt.style)
            return rpdt

        if not data_table:
            mydt = EmptyDataTable(element,self.fontName)
            rpdt = Table(mydt.data)
            return rpdt

    def read(self):
        self._report.seek(0)
        return self._report.read()

    def sendEmail(self, mailFrom, mailTo, subj, msg, mailCc=None, as_html=False, attachments=[]):
        '''
        '''
        from core.common.mail import send_mail
        self._report.seek(0)
        tfile = tempfile.TemporaryFile(mode="wb")
        tfile.write(self._report.read())
        send_mail(mailFrom, mailTo, subj, msg, mailCc=None, attachments=attachments, as_html=as_html)
        tfile.close()

    '''
    Should also except a pandas datafram and be able to create the template data required
    '''

    def __addTable(self, data, properties={}):
        t = BasicTable(data)
        self.flowables.append(t)

    def addLayout(self, layoutName=None, contents=[]):
        '''
        Add an object to the layout
        '''

    def addTable(self, tableName='', df=None,
                 height=None, width=None,
                 isheatmap=False,
                 properties={}):
        '''
        add a data table to the pdf/html report 
        Keyword arguments:
        
        tableName : Provide a Name, used in case it needs to be referenced
        df : pandas dataframe object with data
        style -- Dictionaly of style settings 
        '''

        if len(df) > 1:
            td = MutiDataTable(df, None, properties=properties)
        else:
            if not isinstance(df, pd.DataFrame):
                raise Exception("Needs to be pandas dataframe object")
            td = DataTable(df, None, properties=properties)
        if td:
            self.flowables.append(KeepInFrame(self.pwidth, self.pheight, mode='shrink', content=[td], vAlign='TOP'))

    def addPara(self, contents, properties={}):
        '''
        adds a paragraph
        
        '''
        self.flowables.append(CreatePara(contents, paraAttrs=properties))

    def addPageBreak(self):
        self.flowables.append(PageBreak())

    def addLineChart(self, df, width=400, height=400):

        axplot = df.plot(figsize=(height / inch, width / inch))
        tmp = tempfile.NamedTemporaryFile(delete=False)
        axplot.figure.savefig(tmp.name)
        self.flowables.append(plt.figure())
