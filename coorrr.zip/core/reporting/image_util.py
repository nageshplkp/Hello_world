import math
import os

from PIL import Image


def vertical_slice(image_path, out_name, out_dir, slice_size):
    """
    Slice an image vertically into parts that are 'slice_size' tall

    :param image_path: Path of the image
    :param out_name: The names of the generated image slices
    :param out_dir: Location to generate the files
    :param slice_size: height of the generated images
    :return: list of paths of the generated images
    """
    result          = []
    img             = Image.open(image_path)
    width, height   = img.size
    upper, left     = 0, 0
    slices          = int(math.ceil(height/slice_size))
    count           = 1

    for _ in range(slices):

        # if we are at the end, set the lower bound to be the bottom of the image
        if count == slices:
            lower = height
        else:
            lower = int(count * slice_size)

        bbox = (left, upper, width, lower)
        working_slice = img.crop(bbox)
        upper += slice_size

        # save the slice
        file_path = os.path.join(out_dir, "slice_" + out_name + "_" + str(count)+".png")
        working_slice.save(file_path)
        result.append(file_path)
        count += 1

    return result