''''
Created on Aug 10, 2016

@author: sumgowda
'''
from core.reporting.parser import isValid, parseProperties, parseStyleElements
import numpy as np
from pandas.core.indexing import _maybe_numeric_slice, _non_reducing_slice

from core.reporting.util import getLinearSegmentedColormap
from jinja2 import Template as JinjaTempalte
from pandas.formats.style import _mpl, Styler
from pandas import MultiIndex
import uuid
from itertools import product
import pandas.core.common as com


class DefaultHtmlStyle(Styler):
    csstemplate = JinjaTempalte("""
        <style  type="text/css" >
             .table_{{uuid}} {
                width: {{table_width}};
                {% if border %} border : {{border}};{% endif %}
                {% if bordercollapse %} border-collapse: {{bordercollapse}};{% endif %}
            }
            .th_{{uuid}} {
                color:{{headertextcolor}};
                background-color:{{headercolor}};
                white-space:{{header_white_space}};
                width:{{header_width}};
                text-align:center;
                {% if border %}border : {{border}};{% endif %}
                {% if bordercollapse %}border-collapse: {{bordercollapse}};{% endif %}
            }
        {% for s in table_styles %}
            #td_{{uuid}}{{s.selector}} {
            {% for p,val in s.props %}{{p}}: {{val}};{% endfor %}
            }
        {% endfor %}
        {% for s in cellstyle %}
            #td_{{uuid}}{{s.selector}} {
            {% for p,val in s.props %}{{p}}: {{val}};{% endfor %}
            {% if border %}border : {{border}};{% endif %}
            {% if bordercollapse %}border-collapse: {{bordercollapse}};{% endif %}
            }
        {% endfor %}
        {% for id, values in additionalHeaderProperties.iteritems() %}
            #{{id}} {
            {% for p,val in values %}{{p}}: {{val}};{% endfor %}
            {% if border %}border : {{border}};{% endif %}
            {% if bordercollapse %}border-collapse: {{bordercollapse}};{% endif %}
            }
        {% endfor %}

        </style>
        """)

    tablecontentstemplate = JinjaTempalte("""
        {% if not isInnerTable %}{% if table_attributes == None %}<table class="table_{{uuid}}">{% else %}<table class="table_{{uuid}}" {{ table_attributes }}>{% endif %}{% endif %}
        {% if caption %}<caption>{{caption}}</caption>{% endif %}
        <thead >
            {% if extrastyles %}
                {% if extrastyles.headerdata %}
                     {% for header in extrastyles.headerdata %}
                        <tr>
                            {% for cell in header %}
                                <th class="th_{{uuid}}" {% for k,v in cell.attrs.iteritems() %}{{k}}="{{v}}"{% endfor %} >{{cell.value}}</th>
                            {% endfor %}
                        </tr>
                    {% endfor %}
                {% endif %}
            {% endif %}
            {% for r in head %}
            <tr style="color:{{headercolor}}">
                {% for c in r %}
                {% if loop.index0 %}
                    <{{c.type}}  id="th_{{uuid}}{{c.id}}" class="th_{{uuid}}" >{{c.value}}</{{c.type}}>
                 {% else %}
                        {% if includeIndex %}
                                <{{c.type}} id="th_{{uuid}}{{c.id}}" class="th_{{uuid}}" >{{c.value}}</{{c.type}}>
                        {% endif %}
                 {% endif %}
                {% endfor %}
            </tr>
            {% endfor %}
        </thead>
        <tbody>
            {% for r in body %}
                <tr style="background-color:{{alternateColor[loop.index0]}}" >
                {% for c in r %}
                    {% if includeIndex %}
                        {% if loop.index0 %}
                            <{{c.type}} id="td_{{uuid}}{{c.id}}" >{% else %}<{{c.type}} id="td_{{uuid}}{{c.id}}" rowspan='{{c.rowspan}}'>{% endif %}{{c.display_value}}</{{c.type}} >
                    {% else %}
                        {% if loop.index0 %}
                            <{{c.type}} id="td_{{uuid}}{{c.id}}" rowspan='{{c.rowspan}}' >{{c.display_value}}</{{c.type}}>
                        {% endif %}
                    {% endif %}
                {% endfor %}
            </tr>
            {% endfor %}
        </tbody>
        {% if not isInnerTable %}
        </table>
        {% endif %}
        """)

    def __init__(self, data, precision=None, table_styles=None, uuid=None,
                 caption=None, table_attributes=None, isInnerTable=False,
                 ignoreHeaders=False, includeIndex=False,
                 headerWrap='normal', headerWidth='auto', alternateColor=['#D2DDEC', '#EAEFF6'],
                 tableWidth='auto'):

        Styler.__init__(self, data, precision, table_styles, uuid,
                        caption, table_attributes)

        self.table_width = tableWidth
        self.headercolor = '#5C97CC'
        self.headertextcolor = 'white'
        self.noofheaders = 0
        self.header_width = headerWidth
        self.header_white_space = headerWrap
        self.table_width = tableWidth
        self.alternateColor = alternateColor
        self.altColorRepeatCount = 1
        self.isInnerTable = isInnerTable
        self.ignoreHeaders = ignoreHeaders
        self.includeIndex = includeIndex
        self.myuuid = uuid

    def setAdditionalStyle(self, addstyles={}):
        self.addstyles = addstyles

    def render(self, properties={}):
        """
        Overriden function 
        Using this I can add more custom styles
        """
        self._compute()
        d = self._translate()
        # hack as it does not add ide to index columns so all css missing
        newbody = []

        indexselectors = []
        if self.includeIndex:
            for idr, row in enumerate(d['body']):
                newrow = []
                for idc, col in enumerate(row):
                    # if id is missing add one for index
                    if not col.get('id'):
                        id = 'row%d' % (idr) + "_indexcol"
                        col['id'] = id
                        indexselectors.append({'selector': id, 'props': [['white-space', ' nowrap']]})
                    newrow.append(col)
                newbody.append(newrow)
            d['body'] = newbody
            d['cellstyle'] = d['cellstyle'] + indexselectors

        newhead = []
        for idr, row in enumerate(d['head']):
            newheadrow = []
            for idc, col in enumerate(row):
                if not col.get('id'):
                    id = col.get('class')
                    col['id'] = id.replace(' ','')
                newheadrow.append(col)
            newhead.append(newheadrow)
        d['head'] = newhead

        # filter out empty styles, every cell will have a class
        # but the list of props may just be [['', '']].
        # so we have the neested anys below
        trimmed = [x for x in d['cellstyle']
                   if any(any(y) for y in x['props'])]
        d['cellstyle'] = trimmed
        additionalProperties = {}
        additionalHeaderProperties = {}
        noofindexitems = 0
        if self.includeIndex:
            noofindexitems = 1
        if isinstance(self.data.index, MultiIndex):
            noofindexitems = len(self.data.index.names)

        no_rows = len(self.data)

        if 'align' in properties and properties['align']:
            alignValues = properties['align'].split(',')

            for idx in range(no_rows):
                if self.includeIndex:
                    iddexid = 'row%s_indexcol' % (idx)
                    additionalProperties.setdefault(iddexid, []).append(['text-align', 'center'])

                for idy in range(len(self.data.columns)):
                    id = 'row%s_col%s' % (idx, idy)
                    if self.includeIndex:
                        idy = idy + 1
                    additionalProperties.setdefault(id, []).append(
                        ['text-align', alignValues[idy] if idy < len(alignValues) else alignValues[-1]])

        if 'highlightlow' in properties and properties['highlightlow']:
            # they can have mutiple ones
            for each in properties['highlightlow']:
                color = each.get('color', 'red')
                startrow = int(each.get('startrow', 0))
                startcol = int(each.get('startcol', 0))
                endrow = int(each.get('endrow', -1))
                endcol = int(each.get('endcol', -1))
                threshhold = each.get('threshhold')
                for idx in range(no_rows):
                    for idy, cell in enumerate(self.data.columns):
                        if (idx >= startrow and (idx <= endrow or endrow == -1) and idy >= startcol and (
                                        idy <= endcol or endcol == -1)):
                            id = 'row%s_col%s' % (idx, idy)
                            value = self.data.iloc[idx, idy]
                            if value <= float(threshhold):
                                additionalProperties.setdefault(id, []).append(['background-color', color])

        # set BG color
        if 'bgcolor' in properties and properties['bgcolor']:
            for each in properties['bgcolor']:
                color = each.get('color', 'red')
                startrow = int(each.get('startrow', 0))
                startcol = int(each.get('startcol', 0))
                endrow = int(each.get('endrow', -1))
                endcol = int(each.get('endcol', -1))
                for idx in range(no_rows):
                    for idy in range(len(self.data.columns)):
                        if (idx >= startrow and (idx <= endrow or endrow == -1) and idy >= startcol and (
                                        idy <= endcol or endcol == -1)):
                            id = 'row%s_col%s' % (idx, idy)
                            additionalProperties.setdefault(id, []).append(['background-color', color])

        if 'highlighthigh' in properties and properties['highlighthigh']:
            # they can have mutiple ones
            for each in properties['highlighthigh']:
                color = each.get('color', 'red')
                startrow = int(each.get('startrow', 0))
                startcol = int(each.get('startcol', 0))
                endrow = int(each.get('endrow', -1))
                endcol = int(each.get('endcol', -1))
                threshhold = each.get('threshhold')
                for idx in range(no_rows):
                    for idy in range(len(self.data.columns)):
                        if (idx >= startrow and (idx <= endrow or endrow == -1) and idy >= startcol and (
                                        idy <= endcol or endcol == -1)):
                            id = 'row%s_col%s' % (idx, idy)
                            value = self.data.iloc[idx, idy]
                            if value >= float(threshhold):
                                additionalProperties.setdefault(id, []).append(['background-color', color])

        if 'highlightneg' in properties and properties['highlightneg']:
            # they can have mutiple ones
            for each in properties['highlightneg']:
                color = each.get('color', 'red')
                startrow = int(each.get('startrow', 0))
                startcol = int(each.get('startcol', 0))
                endrow = int(each.get('endrow', -1))
                endcol = int(each.get('endcol', -1))
                formatStr = each.get('format', "")
                for idx, row in enumerate(self.data.iterrows()):
                    for idy, cell in enumerate(self.data.columns):
                        if (idx >= startrow and (idx <= endrow or endrow == -1) and idy >= startcol and (
                                        idy <= endcol or endcol == -1)):
                            id = 'row%s_col%s' % (idx, idy)
                            value = self.data.iloc[idx, idy]
                            if value < 0:
                                additionalProperties.setdefault(id, []).append(['color', color])
                                if formatStr:
                                    d['body'][idx][idy + 1]['display_value'] = formatStr.format(value)

        if 'numberformat' in properties and properties['numberformat']:

            # they can have mutiple ones
            for each in properties['numberformat']:
                startrow = int(each.get('startrow', 0))
                startcol = int(each.get('startcol', 0))
                endrow = int(each.get('endrow', -1))
                endcol = int(each.get('endcol', -1))
                formatStr = each.get('format', "")
                for idx in range(no_rows):
                    for idy in range(len(self.data.columns)):
                        if (idx >= startrow and (idx <= endrow or endrow == -1) and idy >= startcol and (
                                        idy <= endcol or endcol == -1)):
                            # as index is part of the data , the columns will be off by 1
                            value = self.data.iloc[idx, idy]
                            try:
                                d['body'][idx][idy + 1]['display_value'] = formatStr.format(value)
                            except:
                                d['body'][idx][idy + 1]['display_value'] = d['body'][idx][idy + 1]['value']

        if 'heatmap' in properties and properties['heatmap']:
            # they can have mutiple ones
            for each in properties['heatmap']:
                startrow = int(each.get('startrow', 0))
                startcol = int(each.get('startcol', 0))
                lightness = int(each.get('lightness', 0))
                endrow = int(each.get('endrow', no_rows))
                if endrow == -1:
                    endrow = no_rows
                endcol = int(each.get('endcol', len(self.data.columns)))
                if endcol == -1:
                    endcol = len(self.data.columns)

                # chekc if index in mutiindex
                if isinstance(self.data.index, MultiIndex):
                    startcol = startcol - len(self.data.index.names)
                formatStr = each.get('format', "")
                gradiantname = each.get('gradiantname', "RdYlGn")
                subdf = self.data.iloc[startrow:endrow, startcol:endcol]
                a, cMaps = getLinearSegmentedColormap(subdf, colorName=gradiantname or "RdYlGn", lightness=lightness)

                for idx in range(no_rows):
                    for idy in range(len(self.data.columns)):
                        try:
                            color = cMaps.get(subdf.iat[idx, idy], None)
                            if color:
                                if self.includeIndex:
                                    id = 'row%s_col%s' % (idx + startrow + self.noofheaders - 1, idy + startcol)
                                else:
                                    id = 'row%s_col%s' % (idx + startrow + self.noofheaders - 1, idy + startcol - 1)
                                additionalProperties.setdefault(id, []).append(['background-color', color])
                        except:
                            continue

        if 'span' in properties and properties['span']:

            # they can have mutiple ones
            for each in properties['span']:

                startrow = int(each.get('startrow', 0))
                endrow = int(each.get('endrow', len(self.data.index)))
                if endrow == -1:
                    endrow = len(self.data.index)

                startcol = int(each.get('startcol', 0))

                endcol = int(each.get('endcol', len(self.data.columns)))
                if endcol == -1:
                    endcol = len(self.data.columns)

                if not self.ignoreHeaders:
                    startrow = startrow -1

                if not self.includeIndex:
                    startcol = startcol + 1
                    endcol = endcol + 1

                if isinstance(self.data.index, MultiIndex):
                    startcol = startcol - len(self.data.index.names)

                if startcol == endcol:
                    oldProd = d['body'][startrow][startcol ]
                    oldProd['rowspan'] =  endrow - startrow
                    d['body'][startrow][startcol ] = oldProd
                    for delrow in range(startrow+1,endrow):
                        d['body'][delrow] = d['body'][delrow][startcol:]

        for each in properties.get('leftpadding', []) or []:
            startrow = int(each.get('startrow', 0))
            startcol = int(each.get('startcol', 0))
            endrow = int(each.get('endrow', len(self.data.index)))
            endcol = int(each.get('endcol', len(self.data.columns)))
            if endrow == -1:
                endrow = len(self.data.index)
            if endcol == -1:
                endcol = len(self.data.columns)

            value = each.get('value', '') + 'px'
            if isinstance(self.data.index, MultiIndex):
                startcol = startcol - len(self.data.index.names)

            for idx in range(no_rows):
                for idy in range(len(self.data.columns)):
                    if (idx + self.noofheaders >= startrow and idx + self.noofheaders  <= endrow
                        and idy >= startcol and idy <= endcol ):
                        id = 'row%s_col%s' % (idx , idy )
                        additionalProperties.setdefault(id, []).append(['padding-left', value])


        for each in properties.get('rightpadding', []) or []:
            startrow = int(each.get('startrow', 0))
            startcol = int(each.get('startcol', 0))
            endrow = int(each.get('endrow', len(self.data.index)))
            endcol = int(each.get('endcol', len(self.data.columns)))
            value = each.get('value', '') + 'px'
            if isinstance(self.data.index, MultiIndex):
                startcol = startcol - len(self.data.index.names)
            if endrow == -1:
                endrow = len(self.data.index)
            if endcol == -1:
                endcol = len(self.data.columns)
            for idx in range(no_rows):
                for idy in range(len(self.data.columns)):
                    if (idx + self.noofheaders >= startrow and idx + self.noofheaders  <= endrow
                        and idy >= startcol and idy <= endcol ):
                        id = 'row%s_col%s' % (idx , idy )
                        additionalProperties.setdefault(id, []).append(['padding-right', value])

        for each in properties.get('grid', []) or []:
            startrow = int(each.get('startrow', 0))
            startcol = int(each.get('startcol', 0))
            endrow = int(each.get('endrow', len(self.data.index)))
            endcol = int(each.get('endcol', len(self.data.columns)))

            if endrow == -1:
                endrow = len(self.data.index)

            if endcol == -1:
                endcol = len(self.data.columns)

            if isinstance(self.data.index, MultiIndex):
                startcol = startcol - len(self.data.index.names)

            for idx in range(no_rows):
                for idy in range(len(self.data.columns)):
                    if (idx + self.noofheaders >= startrow and idx + self.noofheaders  <= endrow
                        and idy >= startcol and idy <= endcol ):
                        if self.includeIndex:
                            id = 'row%s_col%s' % (idx , idy )
                        else:
                            id = 'row%s_col%s' % (idx , idy )

                        additionalProperties.setdefault(id, []).append(['border-top', '1px solid black'])
                        additionalProperties.setdefault(id, []).append(['border-bottom', '1px solid black'])
                        additionalProperties.setdefault(id, []).append(['border-left', '1px solid black'])
                        additionalProperties.setdefault(id, []).append(['border-right', '1px solid black'])
                        additionalProperties.setdefault(id, []).append(['border-collapse', 'collapse'])
        # keep box at the end as its thicker border
        if 'box' in properties and properties['box']:
            # they can have mutiple ones
            for each in properties['box']:
                startrow = int(each.get('startrow', 0))
                startcol = int(each.get('startcol', 0))
                endrow = int(each.get('endrow', len(self.data.index)))
                if endrow == -1:
                    endrow = len(self.data.index)
                endcol = int(each.get('endcol', len(self.data.columns)))
                if endcol == -1:
                    endcol = len(self.data.columns)
                if isinstance(self.data.index, MultiIndex):
                    startcol = startcol - len(self.data.index.names)

                for idx in range(no_rows):
                    for idy in range(len(self.data.columns)):
                        if self.includeIndex:
                            id = 'row%s_col%s' % (idx + self.noofheaders , idy +1 )
                        else:
                            id = 'row%s_col%s' % (idx , idy  )
                        # this could be for header
                        if startrow == 0:
                            id = 'th_%scol_headinglevel%dcol%d' % ( self.uuid , idx ,  idy )
                            if idx == startrow and idy >= startcol and  idy <= endcol: #-1 assuming most of data frams have one headers
                                additionalHeaderProperties.setdefault(id, []).append(['border-top', '3px solid black'])
                            if idx == endrow - 1 and idy >= startcol and  idy <= endcol:
                                additionalHeaderProperties.setdefault(id, []).append(['border-bottom', '3px solid black'])
                            if idy == startcol and idx >= startrow and idx <= endrow :
                                additionalHeaderProperties.setdefault(id, []).append(['border-left', '3px solid black'])
                            if idy == endcol and idx >= startrow and idx <= endrow  :
                                additionalHeaderProperties.setdefault(id, []).append(['border-right', '3px solid black'])

                        else:
                            if idx == startrow - 1 and idy >= startcol and  idy <= endcol: #-1 assuming most of data frams have one headers
                                additionalProperties.setdefault(id, []).append(['border-top', '3px solid black'])
                            if idx == endrow - 1 and idy >= startcol and  idy <= endcol:
                                additionalProperties.setdefault(id, []).append(['border-bottom', '3px solid black'])
                            if idy == startcol and idx >= startrow - 1 and idx <= endrow - 1  :
                                additionalProperties.setdefault(id, []).append(['border-left', '3px solid black'])
                            if idy == endcol and idx >= startrow - 1 and idx <= endrow - 1  :
                                additionalProperties.setdefault(id, []).append(['border-right', '3px solid black'])
                            additionalProperties.setdefault(id, []).append(['border-collapse', 'collapse'])

        borderprop = ''
        if 'border' in properties and properties['border']:
            borderprop = properties['border']

        bordercollapse = ""
        if 'border-collapse' in properties and properties['border-collapse']:
            bordercollapse = properties['border-collapse']

        newCellStyles = []
        for each in d['cellstyle']:
            if each['selector'] in additionalProperties:
                each['props'] = each['props'] + additionalProperties.get(each['selector'])
            newCellStyles.append(each)

        d['cellstyle'] = newCellStyles
        d['extrastyles'] = self.addstyles

        d['headercolor'] = self.headercolor
        d['headertextcolor'] = self.headertextcolor
        d['header_width'] = self.header_width
        d['header_white_space'] = self.header_white_space
        d['table_width'] = self.table_width
        d['border'] = borderprop
        d['bordercollapse'] = bordercollapse
        d['additionalHeaderProperties'] = additionalHeaderProperties
        n_of_rows = len(self.data)
        d['alternateColor'] = []
        while len(d['alternateColor']) < n_of_rows:
            d['alternateColor'] += [self.alternateColor[0]] * self.altColorRepeatCount + [self.alternateColor[
                                                                                              1]] * self.altColorRepeatCount

        d['altColorRepeatCount'] = self.altColorRepeatCount
        d['isInnerTable'] = self.isInnerTable
        d['includeIndex'] = self.includeIndex
        if self.ignoreHeaders and d['head']:
            del d['head']

        return self.csstemplate.render(**d), self.tablecontentstemplate.render(**d)

    def format(self, formatter, subset=None):
        """
        Override as pands style does not handle strings
        Format the text display value of cells.

        .. versionadded:: 0.18.0

        Parameters
        ----------
        formatter: str, callable, or dict
        subset: IndexSlice
            An argument to ``DataFrame.loc`` that restricts which elements
            ``formatter`` is applied to.

        Returns
        -------
        self : Styler

        Notes
        -----

        ``formatter`` is either an ``a`` or a dict ``{column name: a}`` where
        ``a`` is one of

        - str: this will be wrapped in: ``a.format(x)``
        - callable: called with the value of an individual cell

        The default display value for numeric values is the "general" (``g``)
        format with ``pd.options.display.precision`` precision.

        Examples
        --------

        >>> df = pd.DataFrame(np.random.randn(4, 2), columns=['a', 'b'])
        >>> df.style.format("{:.2%}")
        >>> df['c'] = ['a', 'b', 'c', 'd']
        >>> df.style.format({'C': str.upper})
        """
        if subset is None:
            row_locs = range(len(self.data))
            col_locs = range(len(self.data.columns))
        else:
            subset = _non_reducing_slice(subset)
            if len(subset) == 1:
                subset = subset, self.data.columns

            sub_df = self.data.loc[subset]
            row_locs = self.data.index.get_indexer_for(sub_df.index)
            col_locs = self.data.columns.get_indexer_for(sub_df.columns)
        from collections import defaultdict, MutableMapping
        if isinstance(formatter, MutableMapping):
            for col, col_formatter in formatter.items():
                # formatter must be callable, so '{}' are converted to lambdas
                col_formatter = self._maybe_wrap_formatter(col_formatter)
                col_num = self.data.columns.get_indexer_for([col])[0]

                for row_num in row_locs:
                    self._display_funcs[(row_num, col_num)] = col_formatter
        else:
            # single scalar to format all cells with
            locs = product(*(row_locs, col_locs))
            for i, j in locs:
                formatter = self._maybe_wrap_formatter(formatter)
                self._display_funcs[(i, j)] = formatter
        return self

    def _maybe_wrap_formatter(self, formatter):
        def local(x):
            if type(x) in [str, unicode]:
                return x
            else:
                return formatter.format(x)

        if com.is_string_like(formatter):
            return local
        elif callable(formatter):
            return formatter
        else:
            msg = "Expected a template string or callable, got {} instead".format(
                formatter)
        raise TypeError(msg)


class WuGreyHtmlStyle(DefaultHtmlStyle):
    def __init__(self, data, precision=None, table_styles=None, uuid=None,
                 caption=None, table_attributes=None, isInnerTable=False,
                 ignoreHeaders=False, includeIndex=False, tableWith="auto"):
        Styler.__init__(self, data, precision, table_styles, uuid,
                        caption, table_attributes)
        self.headercolor = '#404040'
        self.headertextcolor = 'white'
        self.alternateColor = ['#FFFFFF', '#CCCCCC']
        self.altColorRepeatCount = 2
        self.isInnerTable = isInnerTable
        self.ignoreHeaders = ignoreHeaders
        self.includeIndex = includeIndex
        self.tableWidth = tableWith


'''
This is specialized table for pdf reports
'''
from bs4 import BeautifulSoup
import json


class HtmlTable:
    def __init__(self, df, *args, **kw):
        '''
        '''
        self.df = df
        self.headerColor = '#5C97CC'
        self.headerWrap = 'normal'
        self.headerWidth = 'auto'
        self.tableWidth = 'auto'

        self.alterColor = ('#D2DDEC', '#EAEFF6')
        self.properties = {}
        self.htmlcontent = ''
        self.styleXmlElement = None
        self.styleXmlElements = None
        self.styleXmlElementsDict = {}
        self.isInnerTable = False
        self.myuuid = str(uuid.uuid4().get_hex().upper()[0:16])
        if kw is not None:
            if 'uuid' in kw and kw['uuid']:
                self.myuuid = kw['uuid']

            if 'parser' in kw:
                self.myparser = kw['parser']
            else:
                self.myparser = None

            if 'headerColor' in kw:
                self.headerColor = kw['headercolor']

            if 'alterColor' in kw:
                self.alterColor = kw['alterColor']
            if 'styleelelemnts' in kw:
                self.styleXmlElements = kw['styleelelemnts']
                for each in self.styleXmlElements:
                    sourcename = each.attrs.get('datasource')
                    if sourcename:
                        self.styleXmlElementsDict[sourcename] = each

            if 'styleelelemnt' in kw:
                self.styleXmlElement = kw['styleelelemnt']

            if 'properties' in kw:
                self.properties = kw['properties']

                if 'headerwidth' in self.properties:
                    self.headerWidth = self.properties['headerwidth']
                if 'headerwrap' in self.properties:
                    self.headerWrap = self.properties['headerwrap']

                if 'rowcolor1' in self.properties and 'rowcolor2' in self.properties:
                    self.alterColor = (self.properties['rowcolor1'], self.properties['rowcolor2'])
                if 'alternatecolors' in self.properties:
                    self.alterColor = (self.properties['rowcolor1'], self.properties['rowcolor2'])

                if 'width' in self.properties:
                    self.tableWidth = self.properties['width']

                if 'border' in self.properties:
                    self.border = self.properties['border']

            if 'style' in kw:
                self.style = kw['style']
            if 'isInnerTable' in kw:
                self.isInnerTable = True
        self._getProperties()
        self._render()

    def _getProperties(self):
        for k, v in parseProperties(self.properties).items():
            setattr(self, k, v)

    def _parseStyleElelemnts(self, df, styleXmlElement):
        return parseStyleElements(styleXmlElement)

    def _getLinearSegmentedColormap(self, df, gradientname, lightness=.2):
        a, cMaps = None, {}
        if gradientname:
            a, cMaps = getLinearSegmentedColormap(self.df, gradientname, lightness=.2)
        return a, cMaps

    def setWidth(self, ele, colorMap={}):
        if ele in colorMap:
            return 'background-color:%s;white-space: nowrap;word-wrap:normal;' % colorMap.get(ele)
        return 'white-space: nowrap;'

    def _render(self):

        groupbackground = int(self.groupbackground)
        noofheaders = int(self.noofheaders)
        addProperties = {}

        if self.styleXmlElement:
            addProperties = self._parseStyleElelemnts(self.df, self.styleXmlElement)

        a, cMaps = self._getLinearSegmentedColormap(self.df, self.gradientname)

        from pandas.formats.style import Styler
        myStyler = DefaultHtmlStyle(self.df, ignoreHeaders=self.ignoreHeaders, includeIndex=self.includeIndex,
                                    headerWrap=self.headerWrap, headerWidth=self.headerWidth,
                                    alternateColor=self.alterColor,
                                    tableWidth=self.tableWidth, isInnerTable=self.isInnerTable)
        if self.stylename == 'WhGr':
            myStyler = WuGreyHtmlStyle(self.df, ignoreHeaders=self.ignoreHeaders, includeIndex=self.includeIndex,
                                       tableWith=self.tableWidth)

        myStyler.set_uuid(self.myuuid)
        myStyler.noofheaders = noofheaders
        self.properties.update(addProperties)
        myStyler.setAdditionalStyle(self.properties)
        self.stylecontents, self.tablecontents = myStyler.format(self.floatformat).applymap(self.setWidth, subset=None,
                                                                                            colorMap=cMaps).render(
            self.properties)
        self.htmlcontent = self.stylecontents + self.tablecontents

    def getContent(self):
        return self.htmlcontent


class EmptyHtmlTable:
    def __init__(self, element=None):
        self.element = element
        self.htmlcontent = ''
        self.render()

    def render(self):
        self.htmlcontent = str(self.element)

    def getContent(self):
        return self.htmlcontent


class HtmlMutiTable(HtmlTable):
    def __init__(self, dfs=None, styles=None, **kw):
        self.dfs = dfs
        self.styles = styles
        HtmlTable.__init__(self, None, **kw)

    def _render(self):
        groupbackground = int(self.groupbackground)
        noofheaders = int(self.noofheaders)
        addProperties = {}
        uuid = ''
        stylecontents = []
        tablecontents = []
        for idx, dfRo in enumerate(self.dfs):
            df = dfRo.copy(deep=True)
            isInnerTable = True
            baseTable = HtmlTable(df, style=None,
                                  styleelelemnt=self.styleXmlElements[idx] if idx < len(
                                      self.styleXmlElements) else None,
                                  properties=self.properties, parser=self.myparser, isInnerTable=isInnerTable)
            if not uuid:
                uuid = baseTable.myuuid
            baseTable._render()
            stylecontents.append(baseTable.stylecontents)
            tablecontents.append(baseTable.tablecontents)

        self.htmlcontent = "".join(stylecontents) + "<table class='table_%s'>" % (uuid) + "".join(
            tablecontents) + "</table>"

    def getContent(self):
        return self.htmlcontent
