import base64


def image_to_html(img_file_name, img_type='png'):
    '''
    Convert an image from a file to base64 encoded string suitable for embedding as text.
    @param img_file_name:
    @param img_type:
    @return:
    '''
    pngdata = base64.b64encode(open(img_file_name,'rb').read())
    return 'data:image/%s;base64,%s' % (img_type, pngdata)
