'''
Created on Aug 10, 2016

@author: sumgowda
'''
from jinja2 import Template as JinjaTempalte
import json , uuid
from core.reporting.parser import parseChartStyleElements
from reportlab.lib.units import inch, cm
from core.reporting.pdf.charts import line_chart_colors
'''
This is specialized table for html reports
'''
        
class HtmlLineChart:
    
    def __init__(self , df=None , style=None , properties={}, parser=None, xmlStyleTag = None , *args , **kw):
        self.myparser = parser
        self.headerColor = '#5C97CC'
        self.alterColor = ('#D2DDEC' , '#EAEFF6')
        from random import choice
        
        from string import ascii_uppercase
        self.id = ''.join(choice(ascii_uppercase) for i in range(6))
        self.width = '900px'
        self.height = '500px'
        self.htmltemplate = JinjaTempalte("""
       <script>
       google.charts.load('current', {'packages':['corechart']});
        function drawChart{{id}}() {
        var data = google.visualization.arrayToDataTable({{data}});

        var options = {
          title: '{{title}}',
          curveType: 'function',
          legend: { position: 'bottom' },
          hAxis : { gridlines : {color: 'white' } , format: 'yyyy',},
          vAxis : { gridlines : {color: 'white'} , format: '0' ,
                   direction: -1, 
                   slantedText: true, 
                   slantedTextAngle: 90 },
          {% if vAxisOption %}
              vAxes : {{vAxisOption}} ,
          {% endif %}
          {% if seriesProperties %} 
          series : {{seriesProperties}} ,
          {% endif %}
          colors: {{colors}},
        };

        var chart = new google.visualization.LineChart(document.getElementById('linechart{{id}}'));

        chart.draw(data, options);
      }
      google.charts.setOnLoadCallback(drawChart{{id}});
</script>
<div id="linechart{{id}}" style="width: {{width}}; height: {{height}}"></div> 
""")
        self.setData(df, style, properties , xmlStyleTag = xmlStyleTag)
        
    def setData(self, df=None , style=None , properties={}, xmlStyleTag=None):
        stylename = properties.get('stylename', 'default')
        gradientname = properties.get('gradientname', None)
        chartXmlProperties = parseChartStyleElements(xmlStyleTag)
        databarcolumn = properties.get('databarcolumn')
        floatformat = properties.get('floatformat', '{0:.2f}')
        databarcolumn = properties.get('databarcolumn')
        noofheaders = properties.get('noofheaders', 1)
        groupbackground = properties.get('groupbackground', 1)
        groupbackground = int(groupbackground)
        indexData = [ each.strftime('%Y %d %m') for each in df.index.tolist() ]
        jsonData = json.dumps(indexData)
        data = []
        if 'rightseries' in chartXmlProperties or 'leftseries' in chartXmlProperties:
            columns =  chartXmlProperties.get('leftseries', [] ) + chartXmlProperties.get('rightseries', [] ) 
            for idx , row in df.iterrows():
                rowData = [ 'Date(%d,%d,%d)' % ( idx.year , idx.month , idx.day) ,]
                for col in columns:
                    rowData.append( row[col] )
                data.append( rowData )
                
        vAxisOption = {0: {'logScale': 0},
            1: {'logScale': 0
                }               
                       }
        
        seriesProperties = {}
        seriesIdx = 0
        if 'leftseries' in chartXmlProperties:
            for idx, col in enumerate(chartXmlProperties.get('leftseries', [] )):
                seriesProperties[seriesIdx] = { 'targetAxisIndex':0 }
                seriesIdx += 1
                
        if 'rightseries' in chartXmlProperties:
            for idx, col in enumerate(chartXmlProperties.get('rightseries', [] )):
                seriesProperties[seriesIdx] = { 'targetAxisIndex':1 }
                seriesIdx += 1
        
        
        if 'rightseries' not in  chartXmlProperties or 'leftseries' not in chartXmlProperties:
            columns = list(df.columns)
            for idx , row in df.iterrows():
                data += [ [ 'Date(%d,%d,%d)' % ( idx.year , idx.month , idx.day) , ] + list(row.values)  ]
        columns= [ { 'id':'date' ,'type': 'date','label': 'asof_date'}] + columns
        data = [ columns ] + data
        data = json.dumps(data)
        title = chartXmlProperties.get('title')
        if 'width' in  properties:
            self.width = properties['width'] +'in'
        if 'height' in  properties:
            self.height = properties['height'] + 'in'
        self.htmlcontent = self.htmltemplate.render({'labels' : jsonData ,
                                                     'data':data, 'id' : self.id , 
                                                     'width' : self.width , 'height' : self.height , 
                                                     'title' : title , 'vAxisOption' : vAxisOption,
                                                     'seriesProperties' : seriesProperties,
                                                     'colors': line_chart_colors.replace('0x','#').split()})
        
    def getContent(self):
        return self.htmlcontent
        
    

