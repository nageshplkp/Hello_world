

class HtmlImage:
    
    def __init__(self, src='' , properties={}):
        self.src = src
        self.properties = properties
        
    def getContents(self):
        propertiesStr = ''
        for k, v in self.properties.items():
            propertiesStr += " %s='%s' " % (k, v)
        htmlString = "<img src='%s' %s /> " % (self.src , propertiesStr) 
        return htmlString
