'''
Created on Aug 10, 2016

@author: sumgowda
'''
from jinja2 import Template as JinjaTempalte
import json , uuid
from core.reporting.parser import parseChartStyleElements
from reportlab.lib.units import inch, cm
from core.reporting.pdf.charts import line_chart_colors, bar_chart_colors
'''
This is specialized table for html reports
'''
        
class HtmlBarChart:
    
    def __init__(self , df=None , style=None , properties={}, parser=None, xmlStyleTag = None , *args , **kw):
        self.myparser = parser
        from random import choice
        from string import ascii_uppercase
        self.id = ''.join(choice(ascii_uppercase) for i in range(6))
        self.width = '900px'
        self.height = '500px'
        self.htmltemplate = JinjaTempalte("""
       <script>
       google.charts.load('current', {'packages':['corechart']});
        function drawChart{{id}}() {
        var data = google.visualization.arrayToDataTable({{data}});
        
        var options{{id}} = {
          chart: {
            //title: '{{title}}',
            //subtitle: 'Sub {{title}}',
            
          },
          {% if chartwidth %}
              width:{{chartwidth}},
         {% endif %}
         {% if chartheight %}
              height:{{chartheight}},
         {% endif %}
          bars: '{{type}}',// Required for Material Bar Charts.
          colors: {{colors}},
          legend: 'bottom',
        };
        
        var barChart{{id}} = new google.visualization.{{charType}}(document.getElementById('barchart{{id}}'));
        barChart{{id}}.draw(data, options{{id}});
          
      
        //var chart = new google.charts.Bar(document.getElementById('barchart{{id}}'));

        //chart.draw(data, options{{id}});
      }
      google.charts.setOnLoadCallback(drawChart{{id}});
</script>
<div id="barchart{{id}}" style="width: {{chartwidth}}px; height: {{chartheight}}px"></div> 
""")
        self.setData(df, style, properties , xmlStyleTag = xmlStyleTag)
        
    def setData(self, df=None , style=None , properties={}, xmlStyleTag=None):
        stylename = properties.get('stylename', 'default')
        gradientname = properties.get('gradientname', None)
        chartXmlProperties = parseChartStyleElements(xmlStyleTag)
        databarcolumn = properties.get('databarcolumn')
        floatformat = properties.get('floatformat', '{0:.2f}')
        databarcolumn = properties.get('databarcolumn')
        noofheaders = properties.get('noofheaders', 1)
        groupbackground = properties.get('groupbackground', 1)
        groupbackground = int(groupbackground)
        data = [ [ df.index.name ] +  df.columns.tolist() ]  
        for idx, each in enumerate([ list(each) for each in df.values ] ):
            data.append( [ str(df.index[idx]) ] + each)
        chartwidth , chartheight = None , None
        
        if 'width' in  properties:
            self.width = properties['width'] +'in'
            chartwidth = float(properties['width']) * 1.75 * inch
        if 'height' in  properties:
            self.height = properties['height'] + 'in'
            chartheight = float(properties['height'])  * 1.5*  inch
        title = chartXmlProperties.get('title')
        vAxisOption = {0: {'logScale': 0},
            1: {'logScale': 0
                }               
                       }
        type = properties.get('type','vertical')
        charType = 'BarChart'
        if type =='vertical':
            charType = 'ColumnChart'
            
        self.htmlcontent = self.htmltemplate.render({'labels' : "" ,
                                                     'data':data, 'id' : self.id , 
                                                     'width' : self.width , 'height' : self.height , 
                                                     'title' : title , 'vAxisOption' : vAxisOption,
                                                     'type' : properties.get('type','vertical'),
                                                     'charType' : charType,
                                                     'chartheight' : chartheight , 'chartwidth': chartwidth,
                                                     'colors': bar_chart_colors.replace('0x','#').split()})
        
    def getContent(self):
        return self.htmlcontent
        
    

