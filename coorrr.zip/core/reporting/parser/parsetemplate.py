'''
Created on Nov 16, 2015

@author: sumgowda
'''
from bs4 import BeautifulSoup
import bs4
from core.reporting.parser import flowable_types
'''

'''
class ParseTemplate:
    
    def __init__(self, html_data="" , filename=None):
        if filename:
            f = open(filename, 'r')
            self.soup = BeautifulSoup("".join(f.readlines()), 'html.parser')
        else:
            self.soup = BeautifulSoup(html_data, 'html.parser')
    
    def getNextPage(self):
        for page in self.soup.findAll('page'):
            yield page
            
    def getProperties(self, element):
        return element.attrs
    
    def getTemplate(self):
        '''
        returns tempalte tag
        Can have only one per report
        '''
        return self.soup.find('template')
    
    def getStyleSheet(self):
        '''
        returns StyleSheet tag
        Can have only one per report
        '''
        return self.soup.find('stylesheet')
    
    def getPageTempaltes(self, templateTag):
        pageTempaltes = []
        for element in templateTag.contents:
            element_type = element.name or ''
            if element_type.upper() == 'PAGETEMPALTE' :
                pageTempaltes.append(element)
        return pageTempaltes
    
    def getTemplateProperties(self, templateeElement):
        pass
        
    def getDocument(self):
        return self.soup.find('document')
        
    def getPageContents(self, page):
        return_elements = []
        for element in page.contents:
            element_type = element.name or ''
            if element_type.upper() in flowable_types :
                return_elements.append(element)
        return return_elements
    
    def getPageTemplateProperties(self, pageTempalteTag):
        localparser = BeautifulSoup(pageTempalteTag, 'xml')
        for each in localparser.contents:
            if isValid(each):
                print each
                
    
