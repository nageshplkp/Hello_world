flowable_types = ['TABLE', 'LINECHART', 'PARA', 'IMG', 'BARCHART', 'TABLELAYOUT', 'TWOAXISLINECHART', 'FRAME', 'HEADER',
                  'FOOTER', 'STYLE',
                  'GRADIENT', "NEXTFRAME", "DRAWING", "PARAM", "PARASTYLE", "EVALSTRING", 'DRAWSTRING', 'HR', 'SPACER',
                  'METADATA',
                  'BOOKMARK', 'HEATMAPTABLE', 'MULTITABLE']
tempaltePageTags = ['TEMPLATE', 'PAGETEMPALTE']
header_footer_sections = ['LEFTSECTION', 'RIGHTSECTION', 'CENTERSECTION', 'PAGENUMBER']

initTags = ['DOCINIT', 'REGISTERTTFONT']
from bs4.element import Tag, NavigableString
from bs4 import BeautifulSoup, BeautifulStoneSoup


def isValid(ele):
    """ Checks i tag is valid """
    return isinstance(ele, Tag)


def parseProperties(properties={}):
    '''
    Parse proterties from dict
    returns a dict of values
    '''
    gradientname = properties.get('gradientname', None)
    stylename = properties.get('stylename', 'default')
    floatformat = properties.get('floatformat', '{0:.2f}')
    databarcolumn = properties.get('databarcolumn')
    noofheaders = properties.get('noofheaders', 1)
    groupbackground = properties.get('groupbackground', 1)
    datasourcename = properties.get('datasource')
    dataSourceList = ( datasourcename or '').split(",")
    ignoreHeaders = True if properties.get('ignoreheaders') == 'true' else False
    includeIndex = True if properties.get('includeindex') == 'true' else False
    nogaps = True if properties.get('nogaps') == 'true' else False
    return dict(stylename=stylename,
                gradientname=gradientname,
                databarcolumn=databarcolumn,
                floatformat=floatformat,
                noofheaders=noofheaders,
                datasourcename=datasourcename,
                groupbackground=groupbackground,
                dataSourceList=dataSourceList,
                ignoreHeaders=ignoreHeaders,
                includeIndex=includeIndex,
                nogaps=nogaps,
                )


def parseStyleElements(styleXmlElement):
    '''
    This parses all the elements and properties defined in style element
    This should be used by both html and pdf
    '''
    ele = styleXmlElement
    if not ele:
        return {}
    contantsStr = ele.contents
    if isinstance(ele.contents, list):
        contantsStr = "".join(str(each) for each in ele.contents)
    soup = BeautifulSoup(contantsStr, 'lxml')
    headerData = []
    styleProperties = {}
    headText = soup.find_all('thead')
    for head in soup.find_all('thead'):
        theadrow = []
        hasTh = False

        for tr in head.find_all('tr'):
            for each in tr.find_all('th'):
                hasTh = True
                label = ''
                if each.contents:
                    label = str(each.contents[0])

                attrs = each.attrs
                propDict = {'value': label, 'attrs': attrs}
                theadrow.append(propDict)

        if not theadrow:
            # check in case user has provided it as just th under thead section
            for each in head.find_all('th'):
                hasTh = True
                label = ''
                if each.contents:
                    label = str(each.contents[0])

                attrs = each.attrs
                propDict = {'value': label, 'attrs': attrs}
                theadrow.append(propDict)

        headerData.append(theadrow)

    styleProperties['headerdata'] = headerData

    def getAttrs(attrs):
        prodDict = {}
        prodDict['color'] = attrs.get('color')
        prodDict['startrow'] = attrs.get('startrow', 0)
        prodDict['startcol'] = attrs.get('startcol', 0)
        prodDict['endrow'] = attrs.get('endrow', -1)
        prodDict['endcol'] = attrs.get('endcol', -1)
        prodDict['threshhold'] = attrs.get('threshhold')
        prodDict['format'] = attrs.get('format')
        prodDict['gradiantname'] = attrs.get('gradiantname')
        prodDict['value'] = attrs.get('value')
        prodDict['bgcolor'] = attrs.get('bgcolor')
        prodDict['text-color'] = attrs.get('text-color')
        prodDict['leading'] = attrs.get('leading')
        prodDict['width'] = attrs.get('width')
        prodDict['height'] = attrs.get('height')
        prodDict['columnnames'] = attrs.get('columnnames')
        prodDict['thickness'] = attrs.get('thickness')
        return prodDict

    bgColorList = []
    for bgcolor in soup.find_all('bgcolor'):
        bgColorList.append(getAttrs(bgcolor.attrs))
    styleProperties['bgcolor'] = bgColorList

    spanProperties = []
    for span in soup.find_all('span'):
        spanProperties.append(getAttrs(span.attrs))
    styleProperties['span'] = spanProperties

    heatmapList = []
    for heatmap in soup.find_all('heatmap'):
        heatmapList.append(getAttrs(heatmap.attrs))
    styleProperties['heatmap'] = heatmapList

    highlightLowData = []
    for highLow in soup.find_all('highlightlow'):
        highlightLowData.append(getAttrs(highLow.attrs))

    styleProperties['highlightlow'] = highlightLowData

    highlightHighData = []
    for highHi in soup.find_all('highlighthigh'):
        highlightHighData.append(getAttrs(highHi.attrs))

    styleProperties['highlighthigh'] = highlightHighData
    highlightNegData = []
    for highHi in soup.find_all('highlightneg'):
        highlightNegData.append(getAttrs(highHi.attrs))

    styleProperties['highlightneg'] = highlightNegData

    formatData = []
    for formatTag in soup.find_all('formatdatapct'):
        attrs = formatTag.attrs
        attrs['format'] = "{0:.0f}%"
        formatData.append(getAttrs(attrs))

    for formatTag in soup.find_all('formatdata'):
        attrs = formatTag.attrs
        if 'format' in attrs and attrs['format']:
            formatData.append(getAttrs(attrs))
    styleProperties['numberformat'] = formatData
    # more to follow

    boundaryData = []
    for everyboundary in soup.find_all('box'):
        boundaryData.append(getAttrs(everyboundary.attrs))
    styleProperties['box'] = boundaryData

    leftPaddingData = []
    for padding in soup.find_all('leftpadding'):
        leftPaddingData.append(getAttrs(padding.attrs))
    styleProperties['leftpadding'] = leftPaddingData

    lineaboveData = []
    for padding in soup.find_all('lineabove'):
        lineaboveData.append(getAttrs(padding.attrs))
    styleProperties['lineabove'] = lineaboveData

    innergridData = []
    for innergridTag in soup.find_all('innergrid'):
        innergridData.append(getAttrs(innergridTag.attrs))
    styleProperties['innergrid'] = innergridData

    gridData = []
    for gridTag in soup.find_all('grid'):
        gridData.append(getAttrs(gridTag.attrs))
    styleProperties['grid'] = gridData

    headerFormat = []
    for headerFormatTag in soup.find_all('headerformat'):
        headerFormat.append(getAttrs(headerFormatTag.attrs))
    styleProperties['headerformat'] = headerFormat

    headerFormat = []
    for headerFormatTag in soup.find_all('imagecolumns'):
        headerFormat.append(getAttrs(headerFormatTag.attrs))
    styleProperties['imagecolumns'] = headerFormat

    return styleProperties


def parseChartStyleElements(xmlStyleTag):
    chartProperties = dict()
    if xmlStyleTag:
        # check why styleelelemnt.contents returns strings
        contantsStr = ''
        if isinstance(xmlStyleTag.contents, list):
            contantsStr = "".join(str(each) for each in xmlStyleTag.contents)
        soup = BeautifulSoup(contantsStr, 'lxml')
        leftSeries = soup.find('leftseries')
        if leftSeries:
            chartProperties['leftseries'] = [each.strip() for each in leftSeries.contents[0].strip().split(",")]

        rightSeries = soup.find('rightseries')

        if rightSeries:
            chartProperties['rightseries'] = [each.strip() for each in rightSeries.contents[0].strip().split(",")]

        xaxisformat = soup.find('x-axisformat')
        if xaxisformat:
            chartProperties['xaxisformat'] = xaxisformat.contents[0].strip()

        title = soup.find('title')
        if title:
            chartProperties['title'] = title.contents[0].strip()
    return chartProperties