import os
import six


class XlExportable(object):

    def to_xlsx(self, filename, **params):
        """
        Exports element to an excel file

        :param filename: full path of the excel file
        :param params: optional dictionary containing the following attributes
                        sheet: optional. name of the sheet or instance of a worksheet. defaults to active sheet
                        start_row: The row to start exporting?. defaults to 2
                        start_col: The column to start exporting. defaults to 2
                        save: True/False. Default is True. Save the workbook or not
                        overwrite: True/False. Default is False. If True, file will be overwritten if it exists
        :return: workbook
        """
        from openpyxl import Workbook, load_workbook
        p_save      = params.get('save', True)
        p_overwrite = params.get('overwrite', True)
        if isinstance(filename, Workbook):
            wb = filename
        elif os.path.exists(filename) and not p_overwrite:
            wb = load_workbook(filename=filename)
        else:
            wb = Workbook()
        wb = self.to_wb(wb, **params)
        if p_save:
            wb.save(filename)
        return wb

    def to_wb(self, wb, **params):
        """
        Exports element to the given workbook

        :param wb: instance of openpyxl workbook
        :param params: optional dictionary containing the following attributes
                        sheet: optional. name of the sheet or instance of a worksheet. defaults to active sheet
                        start_row: The row to start exporting?. defaults to 2
                        start_col: The column to start exporting. defaults to 2
        :return: instance of workbook
        """
        ws = params.get('sheet', wb.active)
        if isinstance(ws, six.string_types):
            ws = wb[ws] if ws in wb.sheetnames else wb.create_sheet(ws)
        self.to_ws(ws, **params)
        return wb

    def to_ws(self, ws, **params):
        """
        Exports element to the given worksheet

        :param ws: instance of openpyxl workseet
        :param params: optional dictionary containing the following attributes
                        start_row: The row to start exporting?. defaults to 2
                        start_col: The column to start exporting. defaults to 2
        :return: worksheet
        """
        raise NotImplementedError()