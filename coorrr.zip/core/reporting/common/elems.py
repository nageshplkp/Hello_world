from core.reporting.simple_email import ReportMessageElement, RawHTML


class AdaptablePimReportElem(object):
    """
    For use as an element inside a container such as PimReport and PrettyTable. The idea is
    to generate an output based on a given mode. Mode values supported are HTML, EMAIL and RML

    This class represents a single element or a hierarchy of elements and can produce
    an instance of ReportMessageElement based on the mode.

    The container would call the as_report_element method to get what it needs. At the minimum,
    sub classes are expected to override the as_report_element method if you want to change the
    customize the element's behavior
    """

    def __init__(self, name=None, *children, **attrs):
        self.name       = name
        self.attrs      = attrs
        self.children   = list(children)
        # could be a string or AdaptablePimReportElem instances such as this one, PrettyTable, PimReport etc

    def add_child(self, elem):
        self.children.append(elem)

    def get_last_child(self):
        return self.children and self.children[-1] or None

    @staticmethod
    def _create_rme_child(child, mode):
        rme = child
        if isinstance(child, AdaptablePimReportElem):
            rme = child.as_report_element(mode=mode, include_common_css=False, sassit=mode != 'EMAIL')
        return rme

    def _create_rme_children(self, mode):
        return [self._create_rme_child(child, mode) for child in self.children]

    def _create_rme(self, mode):
        elem = ReportMessageElement(self.name, **self.attrs)
        elem.elements = self._create_rme_children(mode)
        return elem

    def as_report_element(self, mode, **kwargs):
        """ mode can be HTML, RML or EMAIL """
        return self._create_rme(mode)


class PimReportChildrenOnlyElem(AdaptablePimReportElem):
    """
    This one is for convenience. Does not represent anything by itself.
    Its just a collection of child elements.
    """

    def _create_rme(self, mode):
        elem = ReportMessageElement(None, children_only=True)
        elem.elements = self._create_rme_children(mode)
        return elem


class RawParaRML(RawHTML):
    """
    To represent an element that is a sub element of the para element in RML
    Its used by prettytable to differentiate between enclosing this inside a para element in RML.
    """
    pass
