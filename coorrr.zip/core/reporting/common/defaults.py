import types

from core.common.util import dict_merge


class DefaultsConfig(object):
    """
    A base class for defining configurations and ability to add configuration objects. For example::

        cfg1 = DefaultsConfig(NUMERIC_PREC=6)
        cfg2 = DefaultsConfig(HDR_FG='YELLOW')
        combined = cfg1 + cfg2

    More examples: see PrettyTableConfig and PimReportXlConfig
    """

    def __init__(self, **kwargs):
        for kwarg, val in kwargs.iteritems():
            setattr(self, kwarg, val)

    def as_dict(self):  # this is fragile. returns a dictionary of the above properties
        d = {}
        for key, value in self.__dict__.items():
            if not isinstance(value, (types.FunctionType, types.MethodType)) and not key.startswith('_'):
                d[key] = getattr(self, key)
        return d

    def __add__(self, other):
        return self.__class__(**dict_merge(self.as_dict(), other.as_dict()))
