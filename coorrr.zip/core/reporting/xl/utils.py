from openpyxl.styles import PatternFill
from openpyxl.styles import Side
from xhtml2pdf.util import getColor, getSize

from core.reporting.enum import BorderMechanism


def xl_color(color):
    """
    converts an html color to a format that Excel understands

    :param color: html color
    """
    return getColor(color).hexval()[2:]


def xl_v_align(v_align):
    """
    Converts an html vertical alignment value to what Excel understands

    :param v_align: html vertical alignment value
    """
    return 'center' if v_align and v_align.lower() == 'middle' else v_align


def xl_apply_border(ws, params):
    mechanism       = params['mechanism']
    side            = Side(params['border_style'], color=xl_color(params['color']))
    start_row       = params['start_row']
    end_row         = params['end_row']
    start_col       = params['start_col']
    end_col         = params['end_col']
    _cell_getter    = params.get('cell_getter') or ws.cell

    def add_side(c_temp, s_temp, s_which):
        c_temp.border = c_temp.border.copy(**{s_which: s_temp})

    if mechanism == BorderMechanism.BOX:
        for i in range(start_col, end_col + 1):
            add_side(_cell_getter(column = i, row = start_row), side, 'top')
            add_side(_cell_getter(column = i, row = end_row), side, 'bottom')
        for i in range(start_row, end_row + 1):
            add_side(_cell_getter(column = start_col, row = i), side, 'left')
            add_side(_cell_getter(column = end_col, row = i), side, 'right')
    else:
        for i in range(start_row, end_row + 1):
            for j in range(start_col, end_col + 1):

                if mechanism in (BorderMechanism.TOP, BorderMechanism.GRID):
                    add_side(_cell_getter(column = j, row = i), side, 'top')

                if mechanism in (BorderMechanism.RIGHT, BorderMechanism.GRID, BorderMechanism.INNER_GRID):
                    if not (j == end_col and mechanism == BorderMechanism.INNER_GRID):
                        add_side(_cell_getter(column = j, row = i), side, 'right')

                if mechanism in (BorderMechanism.BOTTOM, BorderMechanism.GRID, BorderMechanism.INNER_GRID):
                    if not (i == end_row and mechanism == BorderMechanism.INNER_GRID):
                        add_side(_cell_getter(column = j, row = i), side, 'bottom')

                if mechanism in (BorderMechanism.LEFT, BorderMechanism.GRID):
                    add_side(_cell_getter(column = j, row = i), side, 'left')


def xl_apply_bg(ws, params):
    start_row       = params['start_row']
    end_row         = params['end_row']
    start_col       = params['start_col']
    end_col         = params['end_col']
    colors          = map(xl_color, params['colors'])
    # colors          = [PatternFill(start_color=_, end_color=_, fill_type='solid') for _ in colors]
    colors          = [PatternFill(patternType='solid', fgColor=_) for _ in colors]
    _cell_getter    = params.get('cell_getter') or ws.cell
    for i in range(start_row, end_row + 1):
        for j in range(start_col, end_col + 1):
            _cell_getter(column = j, row = i).fill = colors[(i - start_row) % len(colors)]   # cycle color by rows


def xl_apply_fg(ws, params):
    start_row       = params['start_row']
    end_row         = params['end_row']
    start_col       = params['start_col']
    end_col         = params['end_col']
    color           = xl_color(params['color'])
    _cell_getter    = params.get('cell_getter') or ws.cell
    for i in range(start_row, end_row + 1):
        for j in range(start_col, end_col + 1):
            c = _cell_getter(column = j, row = i)
            c.font = c.font.copy(color=color)


def xl_apply_font(ws, params):
    start_row       = params['start_row']
    end_row         = params['end_row']
    start_col       = params['start_col']
    end_col         = params['end_col']
    _cell_getter    = params.get('cell_getter') or ws.cell
    for i in range(start_row, end_row + 1):
        for j in range(start_col, end_col + 1):
            c = _cell_getter(column = j, row = i)
            xl_apply_font_to_cell(c, params)


def xl_apply_font_to_cell(c, params):
    font_family     = params.get('font_family')
    font_family     = font_family and font_family.split(',')[0].strip()
    bold, italic    = params.get('bold'), params.get('italic')
    font_size       = getSize(params.get('font_size'), None)
    kwargs          = {}
    if bold is not None:
        kwargs['bold'] = bold
    if italic is not None:
        kwargs['italic'] = italic
    if font_family:
        kwargs['name'] = font_family
    if font_size:
        kwargs['size'] = font_size
    if kwargs:
        kwargs['scheme'] = None
        c.font = c.font.copy(**kwargs)


def xl_apply_align(ws, params):
    start_row       = params['start_row']
    end_row         = params['end_row']
    start_col       = params['start_col']
    end_col         = params['end_col']
    _cell_getter    = params.get('cell_getter') or ws.cell
    kwargs          = {}
    if params.get('h_align') is not None:
        kwargs['horizontal'] = params['h_align']
    if params.get('v_align') is not None:
        kwargs['vertical'] = params['v_align']
    if params.get('wrap_text') is not None:
        kwargs['wrap_text'] = params['wrap_text']
    if kwargs:
        for i in range(start_row, end_row + 1):
            for j in range(start_col, end_col + 1):
                c = _cell_getter(column = j, row = i)
                c.alignment = c.alignment.copy(**kwargs)