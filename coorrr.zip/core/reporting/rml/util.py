from xhtml2pdf.util import getSize
from reportlab.lib.pagesizes import LETTER


def get_frame_size(params, def_margin='0.3in'):
    """
    Based on the page size and margins, calculate the frame size

    :param params: dictionary with PAGE_SIZE, MARGIN_LEFT, MARGIN_RIGHT, MARGIN_TOP, MARGIN_BOTTOM
    :return: returns the frame's x1, y1, width, height values
    """
    ps_w, ps_h = params.get('PAGE_SIZE', LETTER)
    ps_w, ps_h = getSize(ps_w), getSize(ps_h)
    l_margin = getSize(params.get('MARGIN_LEFT', def_margin))
    r_margin = getSize(params.get('MARGIN_RIGHT', def_margin))
    t_margin = getSize(params.get('MARGIN_TOP', def_margin))
    b_margin = getSize(params.get('MARGIN_BOTTOM', def_margin))
    return l_margin, b_margin, ps_w - (l_margin + r_margin), ps_h - (t_margin + b_margin)