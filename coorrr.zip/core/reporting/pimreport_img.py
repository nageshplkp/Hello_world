import base64
import io
import json
import urllib
import uuid
from xml.sax.saxutils import escape

import six
from PIL import Image as PILImage
from xhtml2pdf.util import getSize, dpi96

from core.reporting.common.elems import AdaptablePimReportElem
from core.reporting.common.xl_abstract import XlExportable
from core.reporting.simple_email import Image as EmailImage
from core.reporting.simple_email import ReportMessageElement, _CoreChart, RawHTML


class PimReportImg(AdaptablePimReportElem, XlExportable):
    """
    This element represents an image.
    Pass a file like object or the absolute path of a file as a string
    """

    def __init__(self, img_file, width=None, height=None, align=None):
        self.img            = img_file
        self.width          = width
        self.height         = height
        self.align          = align
        self.pdf_halign     = (self.align or 'left').upper()
        super(PimReportImg, self).__init__()

    def _get_img_file(self):
        if hasattr(self.img, 'read'):
            self.img.seek(0)
        return self.img

    def _get_img_contents(self):
        if isinstance(self.img, six.string_types):
            with open(self.img, 'rb') as f:
                return f.read()
        else:
            self.img.seek(0)
            return self.img.read()

    def _repr_html_(self):
        return self.to_html()

    def to_html(self):
        uri = 'data:image/png;base64,' + urllib.quote(base64.b64encode(self._get_img_contents()))
        attr_align = attr_style= ''
        if self.align:
            attr_align = self.align and 'align="%s"' % self.align or ''
            margin = '0 auto' if self.align == 'center' else ('0 auto 0 0' if self.align == 'left' else '0 0 0 auto')
            attr_style = 'style="margin: %s"' % margin
        return '<img src = "%s" width="%s" height="%s" %s %s/>' % (uri, self.width, self.height, attr_align, attr_style)

    def to_ws(self, ws, **params):
        """
        Exports figure to the given worksheet

        :param ws: instance of openpyxl workseet
        :param params: optional dictionary containing the following attributes
                        start_row: The row to start exporting?. defaults to 2
                        start_col: The column to start exporting. defaults to 2
        :return: worksheet
        """
        import openpyxl
        from openpyxl.utils import get_column_letter

        idx_row, idx_col = params.get('start_row', 2), params.get('start_col', 2)
        img = openpyxl.drawing.image.Image(self._get_img_file())
        ws.add_image(img, '%s%s' % (get_column_letter(idx_col), idx_row))
        return ws

    def _create_rme(self, mode):
        if mode == 'RML':
            w, h = self.width, self.height
            if not (w or h):    # PDF needs proper width, height
                with PILImage.open(self._get_img_file()) as pi:
                    w, h = '%spx' % pi.width, '%spx' % pi.height
            from core.reporting.pdf.PimcoFlowables.image import PdfImage
            uid     = str(uuid.uuid4())
            data    = dict(filename=self._get_img_file(), width=getSize(w, None),
                           height=getSize(h, None), halign=self.pdf_halign)
            PdfImage.GLOBAL_FIG_INSTANCES[uid] = data
            return ReportMessageElement('plugInFlowable', escape(json.dumps({'uid': uid})),
                                        module="core.reporting.pdf.PimcoFlowables.image",
                                        function='get_image')
        elif mode == 'EMAIL':
            attrs = {}
            if self.align:
                attrs['align'] = self.align
            return EmailImage(self._get_img_file(), width=self.width, height=self.height, **attrs)
        else:
            return RawHTML(self.to_html(), children_only=True)


class PimReportFig(PimReportImg):
    """
    This element represents a matplotlib figure
    """

    def __init__(self, fig, width=None, height=None, bbox_inches='tight', pad_inches=None):
        self.fig            = fig
        self.width          = width
        self.height         = height
        self.bbox_inches    = bbox_inches
        self.pad_inches     = pad_inches
        super(PimReportFig, self).__init__(None, width=width, height=height)

    def _get_img_contents(self):
        return self._get_img_file().read()

    def _get_img_file(self):
        img_data = self._save_fig(io.BytesIO())
        img_data.seek(0)
        return img_data

    def _save_fig(self, f_name):
        self.fig.savefig(f_name, format='png', bbox_inches=self.bbox_inches, pad_inches=self.pad_inches)
        return f_name

    def _create_rme(self, mode):
        if mode == 'RML':
            from core.reporting.pdf.PimcoFlowables.image import PdfImage
            uid     = str(uuid.uuid4())
            data    = dict(fig=self.fig, width=getSize(self.width, None), height=getSize(self.height, None),
                           bbox_inches=self.bbox_inches, pad_inches=self.pad_inches)
            PdfImage.GLOBAL_FIG_INSTANCES[uid] = data
            return ReportMessageElement('plugInFlowable', escape(json.dumps({'uid': uid})),
                                        module="core.reporting.pdf.PimcoFlowables.image",
                                        function='get_pdf_image')
        elif mode == 'EMAIL':
            def temp_fn(*args, **kwargs):
                self._save_fig(kwargs['png_name'])
                return self.fig
            chart_kwargs = {}
            if self.width and self.height:
                chart_kwargs['px_width'] = getSize(self.width) / dpi96
                chart_kwargs['px_height'] = getSize(self.height) / dpi96
            return _CoreChart(temp_fn, [], chart_kwargs, 'png_name')

        return super(PimReportFig, self)._create_rme(mode)

