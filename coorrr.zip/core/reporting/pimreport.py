import StringIO
import os
import smtplib
import tempfile
import uuid
from collections import namedtuple
from functools import partial

import preppy
import sass
from xhtml2pdf.util import getSize
from z3c.rml import rml2pdf

from core.chart.styles import get_core_style, get_reset_css
from core.common import util
from core.common.util import dict_merge
from core.reporting import simple_email
from core.reporting.common.elems import AdaptablePimReportElem, PimReportChildrenOnlyElem, RawParaRML
from core.reporting.pimreport_img import PimReportFig
from core.reporting.enum import BorderMechanism
from core.reporting.prettytable.exporter.html import PrettyTableHtmlGenerator
from core.reporting.prettytable.utils import html_to_pdf_font_name
from core.reporting.simple_email import RMLTableLayout, RawHTML
from core.reporting.simple_email import ReportMessageElement as RME
from core.reporting.simple_email import TableLayout, LayoutElement, html_to_pdf, Style
from core.reporting.simple_email import _Html, _Body, create_report_message

__all__ = ['PimReport', 'ParaStyle']


class PimReport(AdaptablePimReportElem):
    """
    Quickly design a report and export it to HTML or PDF or send an email. Example::

        doc = PimReport()
        doc.para('hai this is a paragraph')

    Commands can be chained together::

        doc.para('this is the first paragraph').bold('this is a bold paragraph')

    Parent/Child elements can be nested using the "with" context manager::

        with doc.para('this comes first'):
            doc.bold('this text will be bold within the paragraph')

    The report's layout can be designed using the tabular grid layout features::

        with doc.grid(col_widths=['250px', '250px', '250px']):
            with doc.gridrow():
                doc.gridcell('this cell spans three cols', colspan=3)
            with doc.gridrow():
                with doc.gridcell():
                    doc.para('this is a paragraph inside the first column cell')
                with doc.gridcell():
                    doc.para('this is a paragraph inside the second column cell')
                with doc.gridcell():
                    doc.para('this is a paragraph inside the third column cell')

    """

    def __init__(self, stylesheets=[]):
        self._stylesheets   = [get_core_style()] + stylesheets
        self.root_elem      = PimReportChildrenOnlyElem()
        self.current_elem   = self.root_elem
        self.line           = partial(self.tag, 'HR')

    def __enter__(self):
        last_added_elem     = self.current_elem.get_last_child()
        last_added_elem.parent_elem = self.current_elem
        self.current_elem   = last_added_elem

    def __exit__(self, exc_type, exc_value, traceback):
        if exc_value is None:
            self.current_elem = self.current_elem.parent_elem

    def add_child(self, child):
        if self == child:
            raise Exception('Element cannot be its own child')
        if isinstance(child, AdaptablePimReportElem):
            child.parent_elem = self.current_elem  # only required for tbl grid elements
        self.current_elem.add_child(child)

    def get_started(self):
        """
        Convenience method to save typing. Returns a reference to the tag and txt methods
        """
        return self, self.tag, self.txt

    def tag(self, tag_name, *texts, **kwargs):
        """
        Opens up a context to automatically represent the items within the context as the children of this element.
        Basically, this opens up a XML tag and this can be nested. XML attributes can be supplied as keyword arguments
        1 or more strings can be passed that will be included between the tags

        As 'class' is a reserved python keyword, use "css_class" as a keyword argument to pass in a css class.

        Example::

            with tag('p', 'Content1', 'Content2', title = "I'm a tooltip"):
                txt("This is a paragraph")

            # <p title="I'm a tooltip">Content1Content2This is a paragraph</p>

        To save typing the html tag, helper methods such as para, title, line, linebreak, bold, italic etc are available
        For example, doc.para() is available to replace tag('p')
        """
        self.add_child(AdaptablePimReportElem(tag_name, *texts, **kwargs))
        return self

    def txt(self, *texts, **kwargs):
        """
        Add 0 or more strings between the tags
        the strings are escaped for use as text in xml documents, that is,

        Example::

            username = 'Dave'
            with tag('h1'):
                txt('Hello, ', username, '!')
        """
        b, u, i = kwargs.get('b', False), kwargs.get('u', False), kwargs.get('i', False)
        e = texts
        if b:
            e = [AdaptablePimReportElem('b', *e)]
        if u:
            e = [AdaptablePimReportElem('u', *e)]
        if i:
            e = [AdaptablePimReportElem('i', *e)]
        if any([b, u, i]):
            if not isinstance(self.current_elem, Para) and not self.current_elem.name in ['p', 'b', 'i', 'u']:
                e = [Para('p', *e)]
        map(self.add_child, e)
        return self

    def raw(self, *texts):
        """
        Add 1 or more safe XML string that is already escaped
        """
        for txt in texts:
            self.add_child(RawHTML(txt, children_only=True))
        return self

    def inc(self, *other_docs):
        """
        Includes 1 or more PimReport, PrettyTable, EasyLine instances. This can be used to modularize and reuse code

        Example::

            doc_hdr, tag, txt = PimReport().get_started()
            with tag('h1'):
                txt('This is the common header')

            doc, tag, txt = PimReport().get_started()
            with tag('body'):
                doc.inc(doc_hdr)
                tag('p', 'This is the content!)
        """
        map(self.add_child, other_docs)
        return self

    def grid(self, align=None, cell_align=None, cell_valign=None, col_widths=[], borders=[], **attrs):
        """
        Grid layout using tables.

        :param align: Align the table w.r.t its parent - left, center or right
        :param cell_align: Align the cell contents - left, center or right
        :param cell_valign: Vertically align the cell contents - top, middle, bottom
        :param col_widths: list of col widths. Specify it for consistent looks in HTML and PDF
        :param borders: list of border spec (dict) see below
        :param attrs:

        border spec dict contains information on where and how to draw the border. Row and col indexes can be
        specified as negative indexes also. For example::

            {'start_row': 0, 'end_row': -1, 'start_col': 0, 'end_col': -1, 'mechanism': BorderMechanism.BOX,
             'color': 'red', 'thickness': '1px'}
        """
        self.add_child(TblGrid(align=align, cell_align=cell_align, cell_valign=cell_valign, col_widths=col_widths,
                borders=borders, **attrs))
        return self

    def gridrow(self):
        """
        Represents a horizontal row on a grid layout. Example::

        bdoc = PimReport()
        with bdoc.grid():
            with bdoc.gridrow():
                bdoc.gridcell(pt1)
                bdoc.gridcell(pt2)

        """
        self.add_child(TblGridRow())
        return self

    def gridcell(self, content=[], rowspan=None, colspan=None, valign=None, align=None,
                 background=None, padding=None, **attrs):
        """
        Represents a cell on the grid layout. Use rowspan and colspan to make it span across rows and cols.
        Can contain one or more elements including another PimReport

        :param content: one or more elements including string, PrettyTable, PimReport, EasyLine instances
        :param rowspan:
        :param colspan:
        :param valign: Vertically align the cell contents - top, middle, bottom
        :param align: Align the cell contents - left, center or right
        :param background: background color
        :param padding: cell padding as a string (applies to all sides) or a dictionary {'l': '5px', 'r': '5px'}
        :param attrs:
        """
        if not isinstance(self.current_elem, TblGridRow):
            raise Exception('gridcell can be used only within a gridrow')
        content = [content] if not isinstance(content, (list, tuple)) else content
        self.add_child(TblGridCell(*content, rowspan=rowspan, colspan=colspan, valign=valign, align=align,
                    background=background, padding=padding, **attrs))
        return self

    def gridcellempty(self, rowspan=None, colspan=None, **attrs):
        with self.gridcell([], rowspan=rowspan, colspan=colspan, **attrs):
            EmptySpace()
        return self

    def fig(self, fig, width=None, height=None, bbox_inches='tight', pad_inches=None, **kwargs):
        """
        Add a matplotlib figure to the doc
        """
        self.add_child(PimReportFig(fig, width=width, height=height, bbox_inches=bbox_inches,
                                    pad_inches=pad_inches, **kwargs))
        return self

    def _para(self, tag, *texts, **kwargs):
        self.add_child(Para(tag, *texts, **kwargs))
        return self

    def para(self, *texts, **kwargs):
        return self._para('p', *texts, **kwargs)

    def _para_child(self, tag, *texts, **kwargs):
        tag_kwargs = kwargs.pop('tag_kwargs', {})
        if not isinstance(self.current_elem, Para) and not self.current_elem.name in ['p', 'b', 'i', 'u']:
            self.add_child(Para('p', *[AdaptablePimReportElem(tag, *texts, **tag_kwargs)], **kwargs))
            return self
        return self.tag(tag, *texts, **tag_kwargs)

    def bold(self, *texts, **kwargs):
        return self._para_child('b', *texts, **kwargs)

    def italic(self, *texts, **kwargs):
        return self._para_child('i', *texts, **kwargs)

    def underline(self, *texts, **kwargs):
        return self._para_child('u', *texts, **kwargs)

    def sup(self, *texts, **kwargs):
        return self._para_child('sup', *texts, **kwargs)

    def sub(self, *texts, **kwargs):
        return self._para_child('sub', *texts, **kwargs)

    def linebreak(self):
        return self._para_child('br', tag_kwargs=dict(closing_tag=False))

    def pagebreak(self):
        self.add_child(PageBreak())
        return self

    def spacer(self, length):
        self.add_child(Spacer(length))
        return self

    def title_xl(self, *texts, **kwargs):
        return self._para('h1', *texts, **kwargs)

    def title_l(self, *texts, **kwargs):
        return self._para('h2', *texts, **kwargs)

    def title(self, *texts, **kwargs):
        return self._para('h3', *texts, **kwargs)

    def subtitle(self, *texts, **kwargs):
        return self._para('h4', *texts, **kwargs)

    def subtitle_s(self, *texts, **kwargs):
        return self._para('h5', *texts, **kwargs)

    def subtitle_xs(self, *texts, **kwargs):
        return self._para('h6', *texts, **kwargs)

    @staticmethod
    def get_raw_elem(txt):
        return RawParaRML(txt, children_only=True)

    def as_report_elements(self, mode, **kwargs):
        return [self.as_report_element(mode, **kwargs)]

    def as_report_element(self, mode, **kwargs):
        return self.root_elem.as_report_element(mode, **kwargs)

    def to_html(self):
        """
        Returns HTML
        """
        buf     = StringIO.StringIO()
        css_txt = '\n'.join([get_reset_css(), '\n'] + self._stylesheets)
        root    = _Html(_Body(*self.as_report_elements(mode='HTML')), stylesheets=css_txt)
        root.render(buf, None, {})
        return buf.getvalue()

    def to_rml(self):
        buf     = StringIO.StringIO()
        elem    = self.as_report_element(mode='RML')
        elem.render(buf, None, {})
        return buf.getvalue()

    def sendmail(self, from_addr, to_addrs, subject, attachments=[]):
        """Use this method to send an email"""
        css_txt         = '\n'.join([get_reset_css(), '\n'] + self._stylesheets)
        msg             = create_report_message(*self.as_report_elements(mode='EMAIL'),
                                                stylesheets=css_txt, attachments=attachments)
        msg['Subject']  = subject
        msg['From']     = from_addr
        msg['To']       = ','.join(to_addrs)
        smtp            = smtplib.SMTP('mailhost.pimco.com')
        smtp.sendmail(from_addr, to_addrs, msg.as_string())

    def to_pdf(self, filename=None, delete=False, pdf_params={}):
        """
        Converts to PDF

        :param filename: Optional. If given, should be Full path. PDF be saved to this path.
        :param delete: Will delete the file after exporting
        :param pdf_params: A dictionary of parameters that can be passed to the default RML template
                            - PAGE_SIZE - simple measurement ("in" (inch), "cm", "mm", and "pt") pair that
                                          specifies the page size. Optionally you can also specify a the
                                          name of a page size, such as A4, letter, or legal.
                                          Examples: "(4in, 6in)" and "LEGAL" and etc
        :return: The full path of the newly created PDF file
        """
        temp_file = None
        if not filename:
            temp_file = tempfile.NamedTemporaryFile(suffix='.pdf', delete=False)
            filename = temp_file.name
        try:
            self.to_pdf_via_rml(filename or temp_file.name, pdf_params=pdf_params)
        finally:
            if delete:
                os.unlink(filename)
                return
        return filename

    def to_pdf_via_phantom(self, filename):
        """Saves in PDF format"""
        html_file_name = os.tempnam() + '.html'
        with open(html_file_name, "w+") as buf:
            buf.write(self.to_html())
        html_to_pdf(filename, html_file_name, paper_format='Letter', orientation='portrait')
        os.unlink(html_file_name)

    def to_pdf_via_rml(self, filename, pdf_params = {}):
        templ_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'rml', 'preppy_templates')
        template  = preppy.getModule('pt_standalone.prep', directory=templ_dir, savePyc=False)
        rml_txt   = template.get([self.to_rml()], pdf_params)
        with open(filename, 'wb') as pdfFile:
            pdfFile.write(rml2pdf.parseString(rml_txt).read())

    def _repr_html_(self):
        """ for jupyter """
        buf         = StringIO.StringIO()
        root        = self.as_report_element(mode='HTML')
        root.render(buf, None, {})
        body_txt    = buf.getvalue()
        css_txt     = '\n'.join([get_reset_css(), '\n'] + self._stylesheets)
        cls_name    = 'a%s' % str(uuid.uuid4()).split('-')[-1]
        css_txt     = sass.compile(string='.%s {%s}' % (cls_name, css_txt))
        output      = '<span class="%s"><style type="text/css">%s</style>\n%s</span>' % (cls_name, css_txt, body_txt)
        return output


class Para(AdaptablePimReportElem):

    def __init__(self, tag, *texts, **attrs):
        self.style = attrs.pop('style', None)
        self.tag_map = {'RML': {'p': 'para'}}
        self.tag = tag
        super(Para, self).__init__(None, *texts, **attrs)

    def _create_rme(self, mode):
        attrs = {}
        if self.style and isinstance(self.style, ParaStyle):
            attrs = self.style.get_attrs(mode)
        if mode in ('HTML', 'EMAIL'):
            x = dict(attrs)
            x.update(self.attrs)
            attrs = x
        tag = self.tag_map.get(mode, {}).get(self.tag, self.tag)
        elem = RME(tag, **attrs)
        elem.elements = self._create_rme_children(mode)
        return elem


class EmptySpace(AdaptablePimReportElem):

    def _create_rme(self, mode):
        if mode == 'RML':
            return ''
        return RME('&nbsp;', children_only=True)


class PageBreak(AdaptablePimReportElem):

    def _create_rme(self, mode):
        if mode == 'RML':
            # return RME('condPageBreak', height='20in', closing_tag=False)
            return RME('nextPage', closing_tag=False)
        return simple_email.PageBreak(is_visible=False)


class Spacer(AdaptablePimReportElem):

    def __init__(self, length):
        self.length = length
        super(Spacer, self).__init__()

    def _create_rme(self, mode):
        if mode == 'RML':
            # return RME('condPageBreak', height='20in', closing_tag=False)
            return RME('spacer', length=getSize(self.length), closing_tag=False)
        return RME('table', RME('tr', RME('td', RawHTML('&nbsp;'), style='font-size:%s;line-spacing:0;' % self.length)))


class TblGrid(AdaptablePimReportElem):

    def __init__(self, align=None, cell_align=None, cell_valign=None, col_widths=[], borders=[], **attrs):
        super(TblGrid, self).__init__(None, **attrs)
        self.alignment = align
        self.cell_valign = cell_valign
        self.cell_align = cell_align
        self.col_widths = [col_widths] if not isinstance(col_widths, (list, tuple)) else col_widths
        self.borders = borders

    def _create_rme_children(self, mode):
        # discard the rows and adopt row's children as its own
        rows = super(TblGrid, self)._create_rme_children(mode)
        return [child for row in rows for child in row.elements]

    def _create_rme(self, mode):
        children = self._create_rme_children(mode)
        self._assign_indices(children)
        self._prepare_styles(mode, children)
        attrs = self._get_tbl_attrs(mode, children)
        if mode == 'RML':
            return RMLTableLayout(*children, **attrs)
        else:
            return TableLayout(*children, **attrs)

    @staticmethod
    def _make_grid_perfect(elements, repeat=True):
        elements = sorted(elements, key=lambda x: (x.col, x.row))
        min_row  = min(x.row for x in elements)
        max_row  = max((x.row + x.rowspan - 1) for x in elements)
        row_cnt  = max_row - min_row + 1
        data     = [[] for x in xrange(row_cnt)]
        for el in elements:
            new_grid = [[repeat and el or None] * el.colspan for _ in range(el.rowspan)]
            new_grid[0][0] = el
            for i, x in enumerate(new_grid):
                data[el.row - 1 + i].extend(x)
        return data

    @staticmethod
    def _assign_indices(elements):
        # assign proper row and col indices to all elements taking rowspan/colspan into consideration
        data     = TblGrid._make_grid_perfect(elements, repeat=False)
        for i, r in enumerate(data):
            for j, e in enumerate(r):
                if e:
                    e.row, e.col = i+1, j+1

    def _get_tbl_attrs(self, mode, children):
        attrs = dict(self.attrs)
        align = self.alignment or PimReportDefaults.TBL_LAYOUT_ALIGN
        if mode == 'RML':
            style_elements = [  # default styles
                RME('blockLeftPadding', start="0,0", stop="-1,-1", length="0"),
                RME('blockRightPadding', start="0,0", stop="-1,-1", length="0"),
                RME('blockTopPadding', start="0,0", stop="-1,-1", length="0"),
                RME('blockBottomPadding', start="0,0", stop="-1,-1", length="0"),
            ]
            style_elements += self._get_rml_border_styles()
            attrs['style_elements'] = style_elements
            attrs['alignment'] = align
            attrs['col_widths'] = [getSize(x) for x in self.col_widths]
        else:
            attrs['col_widths'] = self.col_widths
            margin = '0 auto' if align == 'center' else ('0 auto 0 0' if align == 'left' else '0 0 0 auto')
            attrs['style'] = 'margin: %s' % margin  # for browser
            attrs['align'] = align  # for email
        return attrs

    def _prepare_styles(self, mode, children):
        if mode in ('HTML', 'EMAIL'):
            self._prepare_html_border_styles(children)

    def _get_rml_border_styles(self):
        style_elements = []
        for b_spec in self.borders:
            d = {'start':       '%s,%s' % (b_spec['start_col'], b_spec['start_row']),
                 'stop':        '%s,%s' % (b_spec['end_col'], b_spec['end_row']),
                 'thickness':   getSize(b_spec['thickness']),
                 'kind':        BorderMechanism.get_rml_kind(b_spec['mechanism']),
                 'colorName':   b_spec['color']}
            style_elements.append(RME('lineStyle', **d))
        return style_elements

    def _prepare_html_border_styles(self, elements):
        data = self._make_grid_perfect(elements)
        for i, r in enumerate(data):
            for j, e in enumerate(r):
                for b_spec in self.borders:
                    cell_info = dict(row_idx=i, col_idx=j, df_row_count=len(data), row=r)
                    d = PrettyTableHtmlGenerator._cell_border_cb(b_spec, cell_info)
                    s = e.attributes.get('style', Style()) + Style(**d)
                    e.attributes['style'] = s


class TblGridRow(AdaptablePimReportElem):

    def __init__(self, **attrs):
        super(TblGridRow, self).__init__(None, **attrs)

    def _create_rme_children(self, mode):
        self.row_idx = self.parent_elem.children.index(self)+1   # including this
        children = super(TblGridRow, self)._create_rme_children(mode)
        for j, le in enumerate(children):
            le.row, le.col = self.row_idx, j    # preliminary indices. not accurate
        return children


class TblGridCell(AdaptablePimReportElem):

    def __init__(self, *elements, **attrs):
        self.rowspan = attrs.pop('rowspan', 1)
        self.colspan = attrs.pop('colspan', 1)
        self.align   = attrs.pop('align', None)
        self.valign  = attrs.pop('valign', None)
        self.bg      = attrs.pop('background', None)
        self.padding = attrs.pop('padding', None)
        super(TblGridCell, self).__init__(None, *elements, **attrs)

    def _create_rme(self, mode):
        content = RME(None, *self._create_rme_children(mode), children_only=True)
        le = LayoutElement(0, 0, content, rowspan=self.rowspan, colspan=self.colspan)
        self._parse_layout_elem_attrs(mode, le)
        return le

    def _parse_layout_elem_attrs(self, mode, le):
        # default styles goes here as well as override styles
        grid_elem  = self.parent_elem.parent_elem
        valign     = self.valign or grid_elem.cell_valign or PimReportDefaults.TBL_LAYOUT_CELL_VALIGN
        align      = self.align or grid_elem.cell_align or PimReportDefaults.TBL_LAYOUT_CELL_ALIGN
        if mode == 'RML':
            le.attributes = {'vAlign': valign, 'align': align}  # control what goes in as attributes
            le.attributes['para']  = dict_merge(le.attributes.get('para', {}), {'alignment': align})
            if self.bg:
                le.attributes['background'] = self.bg
            if self.padding:
                if isinstance(self.padding, dict):
                    padding = dict([(x+'Padding', getSize(self.padding.get(x[0])))
                                    for x in ['left', 'right', 'top', 'bottom'] if x[0] in self.padding])
                else:
                    padding = dict([(x+'Padding', getSize(self.padding)) for x in ['left', 'right', 'top', 'bottom']])
                le.attributes.update(padding)
        else:
            padding = {}
            if self.padding:
                if isinstance(self.padding, dict):
                    padding = dict(('padding_'+x, self.padding) for x in ['left', 'right', 'top', 'bottom'])
                else:
                    padding = {'padding': self.padding}
            style_attrs = {'vertical_align': valign}
            style_attrs.update(padding)
            le.attributes = self.attrs  # pass through all the attributes
            s = le.attributes.get('style', Style()) + Style(**style_attrs)
            if self.bg:
                s += Style(background=self.bg)
            le.attributes['style'] = s
            le.align = align


Font = namedtuple('Font', ['family', 'size', 'weight', 'style'])


class PimReportDefaults(object):

    DOC_FONT        = Font('Calibri, Helvetica, Arial, sans-serif', '14px', 'normal', 'normal')
    LINE_HEIGHT     = 1.2
    PDF_FONT_SCALE  = -0.12
    TBL_LAYOUT_ALIGN        = "left"
    TBL_LAYOUT_CELL_VALIGN  = "top"
    TBL_LAYOUT_CELL_ALIGN   = "left"


class BaseStyle(object):

    @util.explicit_param_checker
    def __init__(self, **kwargs):
        self.params = kwargs.pop('__explicit_params', dict())
        del self.params['__explicit_params']

    def __add__(self, other):
        d = dict(self.params)
        d.update(dict(other.params))
        return self.__class__(**d)

    def as_rml_attributes(self):
        return {}

    def as_html_attributes(self):
        return {}

    def get_attrs(self, mode):
        if mode == 'RML':
            return self.as_rml_attributes()
        return self.as_html_attributes()


class ParaStyle(BaseStyle):

    @util.explicit_param_checker
    def __init__(self, font=None, color=None, background=None, text_align=None, line_height=None, **kwargs):
        d = dict(locals())
        del d['self']
        d = dict((k, v) for k, v in d.iteritems() if v is not None)  # filter out None
        d.update(d.pop('kwargs'))
        super(ParaStyle, self).__init__(**d)

    def as_rml_attributes(self):
        attrs = {}
        if self.params.get('font') or self.params.get('line_height'):
            f           = self.params.get('font') or PimReportDefaults.DOC_FONT
            lh          = self.params.get('line_height') or PimReportDefaults.LINE_HEIGHT
            font_size   = getSize(f.size)
            font_size   = font_size + (font_size * PimReportDefaults.PDF_FONT_SCALE)
            adjusted_lh = max(1.2, float(lh))
            leading     = font_size * adjusted_lh
            attrs['fontName']   = html_to_pdf_font_name(f.family, f.weight, f.style)
            attrs['fontSize']   = font_size
            attrs['leading']    = leading
        if self.params.get('background'):
            attrs['backColor'] = self.params['background']
        if self.params.get('color'):
            attrs['textColor'] = self.params['color']
        if self.params.get('text_align'):
            attrs['alignment'] = self.params['text_align']
        return attrs

    def as_html_attributes(self):
        d = {}
        if self.params.get('font'):
            d['font_family'] = self.params['font'].family
            d['font_weight'] = self.params['font'].weight
            d['font_style'] = self.params['font'].style
            d['font_size'] = self.params['font'].size
        others = ['background', 'color', 'text_align']
        for other in others:
            if other in self.params:
                d[other] = self.params[other]
        return {'style': Style(**d)}

