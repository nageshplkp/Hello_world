"""
The objective of this module is to simplify the interface to generate HTML tables from pandas data frames
"""

import os
import smtplib
import sys
from functools import partial

import matplotlib.colors
import numpy as np
import preppy
import seaborn
import six

from core.chart.styles import get_core_style, get_tables_css, get_reset_css, make_html_from_win
from core.chart.table import Style, is_nan_or_nat
from core.common.util import dict_merge
from core.reporting.common.defaults import DefaultsConfig
from core.reporting.common.elems import AdaptablePimReportElem
from core.reporting.enum import TableSection, BorderMechanism
from core.reporting.prettytable.utils import _normalize_idx_range
from core.reporting.simple_email import RawHTML
from core.reporting.common.xl_abstract import XlExportable

EPSILON = sys.float_info.epsilon


class PrettyTableDefaults(object):
    """
    Global default values for PrettyTable. Setting these fields will apply to all pretty tables.
    """
    NUMERIC_PREC                = 2
    NUMERIC_SHOW_COMMA          = False
    NUMERIC_AS_PERCENT          = False
    NUMERIC_SHOW_NEG_BRACKET    = False
    NUMERIC_SHOW_POSITIVE_SIGN  = False
    NUMERIC_NAN_AS_SPACE        = False
    NUMERIC_ZERO_SYMBOL         = None
    BASE_FONT_SIZE              = '14px'
    TBL_FG                      = 'black'
    TBL_BG                      = 'white'
    TBL_FONT_FMLY               = 'Calibri, Helvetica, Arial, sans-serif'
    TBL_FONT_SIZE               = '14px'
    TBL_FONT_WGHT               = 'normal'
    TBL_FONT_STYL               = 'normal'
    CELL_PADDING                = '2px'
    CELL_VALIGN                 = 'middle'
    CELL_ALIGN                  = 'center'
    CELL_ALIGN_NUM              = 'right'
    LINE_HEIGHT                 = '1.2'
    ALT_ROW_BG                  = None
    SHOW_HEADERS                = True
    HDR_BG                      = None
    HDR_FG                      = None
    HDR_ALIGN                   = None
    HDR_FONT_WGT                = None
    TBL_BORDERS                 = [(BorderMechanism.GRID, 'black', '1px')]
    HDR_BORDERS                 = []  # list of tuples (MECHANISM, COLOR, THICKNESS)
    BDY_BORDERS                 = []  # list of tuples (MECHANISM, COLOR, THICKNESS)
    REPEAT_HDRS                 = True
    PDF_FONT_SCALE              = -0.12  # between 0 and 1. Fonts appears bigger in PDF. Scale down


class PrettyTableConfig(DefaultsConfig, PrettyTableDefaults):
    """
    Represents the default settings that can be applied on a pretty table. The objects can be added together as well::

        cfg1 = PrettyTableConfig(NUMERIC_PREC=6)
        cfg2 = PrettyTableConfig(HDR_FG='YELLOW')
        PrettyTable(df, cfg = cfg1 + cfg2)
    """
    pass

# Preset CONFIGS
CFG_DEFAULT = PrettyTableConfig(
    TBL_BG='#e4e9f1', ALT_ROW_BG='#f2f5f8',
    HDR_BG='#5C97CC', HDR_FG='white', HDR_ALIGN='center',
    TBL_BORDERS=[(BorderMechanism.INNER_GRID, 'white', '1px'),
                 (BorderMechanism.BOX, '#9cc0e0', '1px')],
    HDR_BORDERS=[(BorderMechanism.BOX, '#9cc0e0', '1px')]
)
CFG_SIMPLE = PrettyTableConfig(HDR_BG='#5C97CC', HDR_FG='white')
CFG_GREEN = PrettyTableConfig(
    TBL_BG='#C6DFB5', ALT_ROW_BG='#E7EFDE',
    HDR_BG='#73AA42', HDR_FG='white', HDR_ALIGN='center',
    TBL_BORDERS=[(BorderMechanism.INNER_GRID, 'white', '1px'),
                 (BorderMechanism.BOX, '#9cc0e0', '1px')]
)


class PrettyTable(AdaptablePimReportElem, XlExportable):
    """
    Accepts dataframe objects and generates pretty looking HTML tables. Can send emails as well.
    Use the default configuration to quickly output a pretty HTML table.

    The following can be easily achieved with PrettyTable

    * Show/hide header
    * Highlight a column
    * set precision on numeric columns
    * set format string on columns
    * conditional styling based on cell values. For example, can be used to show negative values in red
    * set table background, header background, foreground, column alignment
    * set border at various levels
    * heatmap

    Usage::

        html = PrettyTable(df).col_highlight('yellow', ['col3', 'col4']).\\
                col_numeric(prec=2, ['col3']).to_html()
    """

    def __init__(self, dfs, cfg=None):
        """
        :param dfs: List of dataframes
        :param cfg: An instance of PrettyTableConfig. See CFG_DEFAULT
        """
        self.dfs        = dfs if isinstance(dfs, (list, tuple)) else [dfs]
        self.cfg        = cfg or CFG_DEFAULT
        self.configs    = dict([(id(df), {}) for df in self.dfs])
        self.set_defaults()

    def set_defaults(self):
        table_style = {
            'show_headers' : self.cfg.SHOW_HEADERS,
            'repeat_headers': self.cfg.REPEAT_HDRS,
            'table_style'  : {
                'background'              : self.cfg.TBL_BG,
                'font_size'               : self.cfg.TBL_FONT_SIZE,
                'font_weight'             : self.cfg.TBL_FONT_WGHT,
                'font_family'             : self.cfg.TBL_FONT_FMLY,
                'font_style'              : self.cfg.TBL_FONT_STYL,
                'cell_padding'            : self.cfg.CELL_PADDING,
                'line_height'             : self.cfg.LINE_HEIGHT,
                'vertical_align'          : self.cfg.CELL_VALIGN,
                'text_align'              : self.cfg.CELL_ALIGN,
            },
        }
        for df in self.dfs:
            dict_merge(self.configs[id(df)], table_style)
            cols = self._getcolnames(df, numericonly=True, num_dtypes={'f'})
            if cols:
                self.col_numeric(cols=cols, dfs=df)
        for mechanism, color, thickness in self.cfg.TBL_BORDERS:
            self.border(0, -1, 0, -1, thickness=thickness, color=color, mechanism=mechanism,
                        section=TableSection.ALL, dfs=self.dfs)
        for mechanism, color, thickness in self.cfg.BDY_BORDERS:
            self.border(0, -1, 0, -1, thickness=thickness, color=color, mechanism=mechanism,
                        section=TableSection.BODY, dfs=self.dfs)
        for mechanism, color, thickness in self.cfg.HDR_BORDERS:
            self.border(0, -1, 0, -1, thickness=thickness, color=color, mechanism=mechanism,
                        section=TableSection.HDR, dfs=self.dfs)
        if self.cfg.TBL_FG and self.cfg.TBL_FG.lower() != 'black':
            self.fg(0, -1, 0, -1, color=self.cfg.TBL_FG, section=TableSection.ALL, dfs=self.dfs)
        if self.cfg.SHOW_HEADERS:
            if self.cfg.HDR_BG:
                self.bg(0, -1, 0, -1, colors=self.cfg.HDR_BG, section=TableSection.HDR, dfs=self.dfs)
            if self.cfg.HDR_FG:
                self.fg(0, -1, 0, -1, color=self.cfg.HDR_FG, section=TableSection.HDR, dfs=self.dfs)
            if self.cfg.HDR_ALIGN:
                self.alignment(0, -1, 0, -1, self.cfg.HDR_ALIGN, section=TableSection.HDR, dfs=self.dfs)
            if self.cfg.HDR_FONT_WGT:
                self.font(0, -1, 0, -1, weight=self.cfg.HDR_FONT_WGT, section=TableSection.HDR, dfs=self.dfs)
        if self.cfg.ALT_ROW_BG:
            self.bg(0, -1, 0, -1, colors=[self.cfg.TBL_BG, self.cfg.ALT_ROW_BG], section=TableSection.BODY,
                    dfs=self.dfs)

    def on_insert_defaults(self, df, cfg):
        # gets called by generator
        # default numeric align
        cols = self._getcolnames(df, numericonly=True, num_dtypes={'f'})
        if cols:
            for i in self._parse_cols_as_indices(df, cols):
                attrs = {'start_row': 0, 'end_row': -1, 'start_col': i, 'end_col': i,
                         'align': self.cfg.CELL_ALIGN_NUM, 'section': TableSection.BODY}
                items = cfg.get('alignment_styles') or []
                items.insert(0, attrs)
                dict_merge(cfg, {'alignment_styles': items})
        return cfg

    def border(self, start_row, end_row, start_col, end_col, thickness=None, color=None,
               mechanism=BorderMechanism.BOX, section=TableSection.ALL, dfs=None):
        """
        Sets the border of the table

        :param start_row: Row index relative to the specified section. Negative index supported
        :param end_row: Row index relative to the specified section. Negative index supported
        :param start_col: Column index relative to the specified section. Negative index supported
        :param end_col: Column index relative to the specified section. Negative index supported
        :param thickness: Line thickness. The units "in" (inch), "cm", "mm", "px" and "pt" are allowed. If no
                          units are specified, the value is given in points.
        :param color: A hex value
        :param mechanism: See BorderMechanism
        :param section: See TableSection
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        attrs = {
            'start_row': start_row, 'end_row': end_row, 'start_col': start_col, 'end_col': end_col,
            'mechanism': mechanism, 'thickness': thickness, 'color': color, 'section': section,
        }
        for df in self._normalize_common_input(dfs):
            items = self.configs[id(df)].get('border_styles') or []
            items.append(attrs)
            dict_merge(self.configs[id(df)], {'border_styles': items})
        return self

    def alignment(self, start_row, end_row, start_col, end_col, align, section=TableSection.ALL, dfs=None):
        """
        Sets text alignment on the table

        :param start_row: Row index relative to the specified section. Negative index supported
        :param end_row: Row index relative to the specified section. Negative index supported
        :param start_col: Column index relative to the specified section. Negative index supported
        :param end_col: Column index relative to the specified section. Negative index supported
        :param align: left, right, center
        :param section: See TableSection
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        attrs = {'start_row': start_row, 'end_row': end_row, 'start_col': start_col, 'end_col': end_col,
                 'align': align, 'section': section}
        for df in self._normalize_common_input(dfs):
            items = self.configs[id(df)].get('alignment_styles') or []
            items.append(attrs)
            dict_merge(self.configs[id(df)], {'alignment_styles': items})
        return self

    def bg(self, start_row, end_row, start_col, end_col, colors, section=TableSection.ALL, dfs=None):
        """
        Sets background on the table

        :param start_row: Row index relative to the specified section. Negative index supported
        :param end_row: Row index relative to the specified section. Negative index supported
        :param start_col: Column index relative to the specified section. Negative index supported
        :param end_col: Column index relative to the specified section. Negative index supported
        :param colors: Any color (hex) - pass a list of colors to be used circularly for rows.
                       For example, pass two colors for alternating background rows
        :param section: See TableSection
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        attrs = {'start_row': start_row, 'end_row': end_row, 'start_col': start_col, 'end_col': end_col,
                 'colors': colors if isinstance(colors, (list, tuple)) else [colors], 'section': section}
        for df in self._normalize_common_input(dfs):
            items = self.configs[id(df)].get('bg_styles') or []
            items.append(attrs)
            dict_merge(self.configs[id(df)], {'bg_styles': items})
        return self

    def fg(self, start_row, end_row, start_col, end_col, color, section=TableSection.ALL, dfs=None):
        """
        Sets background on the table

        :param start_row: Row index relative to the specified section. Negative index supported
        :param end_row: Row index relative to the specified section. Negative index supported
        :param start_col: Column index relative to the specified section. Negative index supported
        :param end_col: Column index relative to the specified section. Negative index supported
        :param color: Any color (hex)
        :param section: See TableSection
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        attrs = {'start_row': start_row, 'end_row': end_row, 'start_col': start_col, 'end_col': end_col,
                 'color': color, 'section': section}
        for df in self._normalize_common_input(dfs):
            items = self.configs[id(df)].get('fg_styles') or []
            items.append(attrs)
            dict_merge(self.configs[id(df)], {'fg_styles': items})
        return self

    def padding(self, start_row, end_row, start_col, end_col, length, sides=None,
                section=TableSection.ALL, dfs=None):
        """
        Sets cell padding on the individual cells on the table

        :param start_row: Row index relative to the specified section. Negative index supported
        :param end_row: Row index relative to the specified section. Negative index supported
        :param start_col: Column index relative to the specified section. Negative index supported
        :param end_col: Column index relative to the specified section. Negative index supported
        :param length: size in pixels
        :param sides: single character strings representing the sides of the cell - "t", "r", "b", '"l"
        :param section: See TableSection
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        sides = sides or ['t','r', 'b', 'l']
        attrs = {'start_row': start_row, 'end_row': end_row, 'start_col': start_col, 'end_col': end_col,
                 'length': length, 'sides': sides, 'section': section}
        for df in self._normalize_common_input(dfs):
            items = self.configs[id(df)].get('padding_styles') or []
            items.append(attrs)
            dict_merge(self.configs[id(df)], {'padding_styles': items})
        return self

    def font(self, start_row, end_row, start_col, end_col, family=None, size=None,
             weight=None, style=None, section=TableSection.ALL, dfs=None):
        """
        Sets font on individual cells on the table

        :param start_row: Row index relative to the specified section. Negative index supported
        :param end_row: Row index relative to the specified section. Negative index supported
        :param start_col: Column index relative to the specified section. Negative index supported
        :param end_col: Column index relative to the specified section. Negative index supported
        :param family: Helvetica, Calibri etc
        :param size: pixels example 12px
        :param weight: normal, bold
        :param style: normal, italic, oblique
        :param section: See TableSection
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        attrs = {'start_row': start_row, 'end_row': end_row, 'start_col': start_col, 'end_col': end_col,
                 'font_family': family, 'font_size': size, 'font_weight': weight,
                 'font_style': style, 'section': section}
        for df in self._normalize_common_input(dfs):
            items = self.configs[id(df)].get('font_styles') or []
            items.append(attrs)
            dict_merge(self.configs[id(df)], {'font_styles': items})
        return self

    def col_highlight(self, color, cols=None, dfs=None):
        """
        Highlights an entire column(s)

        :param color: Any color
        :param cols: Optional. One or more columns as a list. If not given, all columns will be selected
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        for df in self._normalize_common_input(dfs):
            for i in self._parse_cols_as_indices(df, cols):
                self.bg(0, -1, i, i, [color], section=TableSection.BODY, dfs=df)
        return self

    def col_align(self, align, cols=None, dfs=None):
        """
        Aligns the text on one or  more column(s)

        :param align: left, center, right
        :param section: See TableSection
        :param cols: Optional. One or more columns as a list. If not given, all columns will be selected
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        for df in self._normalize_common_input(dfs):
            for i in self._parse_cols_as_indices(df, cols):
                self.alignment(0, -1, i, i, align, section=TableSection.BODY, dfs=df)
        return self

    def col_width(self, width=None, cols=None, dfs=None):
        """
        Set width on one or more columns

        :param width: example: 10px, 20px, auto etc
        :param cols: Optional. One or more columns as a list. If not given, all columns will be selected
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        for df in self._normalize_common_input(dfs):
            items = self.configs[id(df)].get('column_widths') or []
            items.append({'width': width, 'col_names': self._parse_cols(df, cols)})
            dict_merge(self.configs[id(df)], {'column_widths': items})
        return self

    def col_widths(self, widths, dfs=None):
        """
        Set variable widths on all the columns

        :param widths: A list of column widths in the table. example: 10px, 20px, auto etc
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        for df in self._normalize_common_input(dfs):
            items = self.configs[id(df)].get('column_widths') or []
            for i, df_col in enumerate(self._parse_cols(df)):
                items.append({'width': widths[i % len(widths)], 'col_names': [df_col]})
            dict_merge(self.configs[id(df)], {'column_widths': items})
        return self

    def col_numeric(self, prec=None, addcomma=None, as_percent=None, neg_bracket=None, showsign=False,
                    nan_space=None, cols=[], rows=[], dfs=None, zero_symbol=None):
        """
        Format numeric columns easily

        :param prec: an integer
        :param addcomma: formats number with comma separator
        :param as_percent: displays as percentage values
        :param neg_bracket: shows negative numbers inside a bracket. Valid values are

                            - False or None: This is the default. Does not display brackets
                            - True: Displays brackets on negative numbers. Ex: (-20.05)
                            - ``"--"``: Displays brackets on negative numbers and also removes the sign. Ex: (20.05).
                              Note that when you export to excel, excel always removes the negative sign

        :param showsign: displays a positive sign + on positive numbers
        :param cols: Optional. One or more columns as a list. If not given, all columns will be selected
        :param rows: Optional. One or more row indices as a list. If not given, all rows will be selected
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        :param zero_symbol: Optional. a single char string. Will be displayed instead of a zero
        """
        prec        = prec if prec is not None else self.cfg.NUMERIC_PREC
        addcomma    = addcomma if addcomma is not None else self.cfg.NUMERIC_SHOW_COMMA
        as_percent  = as_percent if as_percent is not None else self.cfg.NUMERIC_AS_PERCENT
        neg_bracket = neg_bracket if neg_bracket is not None else self.cfg.NUMERIC_SHOW_NEG_BRACKET
        showsign    = showsign if showsign is not None else self.cfg.NUMERIC_SHOW_POSITIVE_SIGN
        nan_space   = nan_space if nan_space is not None else self.cfg.NUMERIC_NAN_AS_SPACE
        zero_symbol = zero_symbol if zero_symbol is not None else self.cfg.NUMERIC_ZERO_SYMBOL
        comma       = addcomma and ',' or ''
        num_type    = as_percent and '%' or 'f'
        sign        = showsign and '+' or ''
        fstr        = '{:%s%s.%s%s}' % (sign, comma, prec, num_type)
        fstr_neg    = '(%s)' % fstr
        xl_fstr     = '%s0%s%s' % ('#,##' if addcomma else '',
                                   ''.join(['.'] + ['0'] * prec if prec else []),
                                   '%' if as_percent else '')
        xl_fstr_pos = '%s%s' % ('+' if showsign else '', xl_fstr)
        xl_fstr_neg = '(%s%s)' % ('+' if showsign else '', xl_fstr)
        xl_fstr_items = [xl_fstr_pos]
        if neg_bracket:
            xl_fstr_items.append(xl_fstr_neg)
        if zero_symbol is not None:
            xl_fstr_items.append(zero_symbol)
        xl_fstr     = ';'.join(xl_fstr_items)
        dfs         = self._normalize_common_input(dfs)
        rows_parsed = {}
        for df in dfs:
            rows_parsed[id(df)] = self._parse_rows(df, TableSection.BODY, rows, with_hdr=False)

        def set_numeric_helper(x, row, col_idx, row_idx, df):
            if nan_space:
                space_txt = nan_space if isinstance(nan_space, six.string_types) else '&#x0020;'
                if x is None or is_nan_or_nat(x):
                    return RawHTML(space_txt, children_only=True)
            if x is not None:
                if rows_parsed.get(id(df)) and row_idx not in rows_parsed[id(df)]:
                    return str(x)  # don't format if row_idx is given and don't match
                if x == 0 and zero_symbol:
                    return zero_symbol
                if neg_bracket and x < 0:
                    if neg_bracket == '--':
                        x = abs(x)
                    return fstr_neg.format(x)
                return fstr.format(x)
            return x

        def set_numeric_helper_xl(x, row, col_idx, row_idx, df):
            if rows:
                if rows_parsed.get(id(df)) and row_idx not in rows_parsed[id(df)]:
                    return
            return xl_fstr, x

        for df in dfs:
            df_cols = self._parse_cols(df, cols, numericonly=True)
            self.col_formatstr(set_numeric_helper, cols=df_cols, dfs=df)
            self.col_formatstr_xl(set_numeric_helper_xl, cols=df_cols, dfs=df)
        return self

    def col_order(self, cols=None, dfs=None):
        """
        Specify the order of the columns

        :param cols: Optional. One or more columns as a list. If not given, all columns will be selected
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        for df in self._normalize_common_input(dfs):
            dict_merge(self.configs[id(df)], {'column_order': cols})
        return self

    def col_formatstr(self, formatstr=None, cols=None, dfs=None):
        """
        Set any valid format string for formatting column contents

        :param formatstr: Any valid format string
        :param cols: Optional. One or more columns as a list. If not given, all columns will be selected
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        # if not cols:
        #     raise Exception('cols cannot be empty')
        for df in self._normalize_common_input(dfs):
            df_cols = self._parse_cols(df, cols)
            dict_merge(self.configs[id(df)], {'custom_formats': dict([(col, formatstr) for col in df_cols])})
        return self

    def col_formatstr_xl(self, formatstr, cols=None, dfs=None):
        """
        Set any valid format string for formatting column contents. Only applicable for excel output

        :param formatstr: Any valid format string (https://www.ablebits.com/office-addins-blog/2016/07/07/custom-excel-number-format/)
        :param cols: Optional. One or more columns as a list. If not given, all columns will be selected
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        for df in self._normalize_common_input(dfs):
            df_cols = self._parse_cols(df, cols)
            dict_merge(self.configs[id(df)], {'xl_number_formats': dict([(col, formatstr) for col in df_cols])})
        return self

    def col_border(self, thickness=None, color=None,
                   mechanism=BorderMechanism.BOX, section=TableSection.ALL, cols=None, dfs=None):
        """
        Sets the border of the table

        :param thickness: Line thickness. The units "in" (inch), "cm", "mm", "px" and "pt" are allowed. If no
                          units are specified, the value is given in points.
        :param color: A hex value
        :param mechanism: See BorderMechanism
        :param section: See TableSection
        :param cols: Optional. One or more columns as a list. If not given, all columns will be selected
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        for df in self._normalize_common_input(dfs):
            for i in self._parse_cols_as_indices(df, cols):
                self.border(0, -1, i, i, thickness=thickness, color=color, mechanism=mechanism, section=section, dfs=df)
        return self

    def hdr_bg(self, color=None, cols=None, rows=None, dfs=None):
        """
        Set the background of the header. Pass cols if you want to set the background of a specific column header

        :param color: any color
        :param cols: Optional. One or more columns as a list. If not given, all columns will be selected
        :param rows: Optional. One or more row indices as a list. If not given, all rows will be selected
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        for df in self._normalize_common_input(dfs):
            for i in self._parse_cols_as_indices(df, cols):
                if rows:
                    for j in rows:  # do it for each row
                        self.bg(j, j, i, i, color, section=TableSection.HDR, dfs=df)
                else:
                    self.bg(0, -1, i, i, color, section=TableSection.HDR, dfs=df)
        return self

    def hdr_fg(self, color=None, cols=None, rows=None, dfs=None):
        """
        Set the background of the header. Pass cols if you want to set the background of a specific column header

        :param color: any color
        :param cols: Optional. One or more columns as a list. If not given, all columns will be selected
        :param rows: Optional. One or more row indices as a list. If not given, all rows will be selected
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        for df in self._normalize_common_input(dfs):
            for i in self._parse_cols_as_indices(df, cols):
                if rows:
                    for j in rows:  # do it for each row
                        self.fg(j, j, i, i, color, section=TableSection.HDR, dfs=df)
                else:
                    self.fg(0, -1, i, i, color, section=TableSection.HDR, dfs=df)
        return self

    def hdr_align(self, align, cols=None, rows=None, dfs=None):
        """
        Aligns the text on one or  more column(s)

        :param align: left, center, right
        :param cols: Optional. One or more columns as a list. If not given, all columns will be selected
        :param rows: Optional. One or more row indices as a list. If not given, all rows will be selected
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        for df in self._normalize_common_input(dfs):
            for i in self._parse_cols_as_indices(df, cols):
                if rows:
                    for j in rows:  # do it for each row
                        self.alignment(j, j, i, i, align, section=TableSection.HDR, dfs=df)
                else:
                    self.alignment(0, -1, i, i, align, section=TableSection.HDR, dfs=df)
        return self

    def hdr_addmore(self, row, dfs=None):
        """
        Add extra header rows. row is a list of tuples (text, colspan)
        Example 2 header cols spanning 2 cols each: row --> [('Head1', 2), ('Head2', 2)]

        :param row: A list of two element tuples (text, colspan)
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        dfs = self._normalize_common_input(dfs)
        for df in dfs:
            rows = self.configs[id(df)].get('extra_header_rows', [])
            rows.insert(0, row)
            dict_merge(self.configs[id(df)], {'extra_header_rows': rows})
        return self

    def hdr_add_single(self, texts, dfs=None):
        """
        Add single cell header rows that span all columns.

        :param texts: A string (applies the same on all dataframes) or a list of strings corresponding to dfs params.
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        dfs = self._normalize_common_input(dfs)
        if isinstance(texts, six.string_types):
            texts = [texts] * len(dfs)
        if len(dfs) != len(texts):
            raise Exception('Please specify a header for each dataframe')
        for i, df in enumerate(dfs):
            self.hdr_addmore([(texts[i], len(df.columns) + int(self.configs[id(df)].get('inc_idx', False)))], dfs=df)
        return self

    def hdr_txt_override(self, col_map, dfs=None):
        """
        Specify custom header texts if the dataframe column names needs to be overridden

        :param col_map: a dictionary of column name to header text mapping
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        for df in self._normalize_common_input(dfs):
            dict_merge(self.configs[id(df)], {'custom_headers': col_map})
        return self

    def row_bg(self, color=None, rows=[], dfs=None):
        """
        Sets the background of entire rows based on row indexes

        :param color: Any color
        :param rows: Indexes of the rows. Starts with 0. First row is 0. Example [0,1,2] is first three rows
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        if color and rows:
            for df in self._normalize_common_input(dfs):
                for i in rows:
                    self.bg(i, i, 0, -1, [color], section=TableSection.BODY, dfs=df)
        return self

    def row_border(self, thickness=None, color=None,
                   mechanism=BorderMechanism.BOX, section=TableSection.ALL, rows=[], dfs=None):
        """
        Sets the border of the table
        :param thickness: Line thickness. The units "in" (inch), "cm", "mm", "px" and "pt" are allowed. If no
                          units are specified, the value is given in points.
        :param color: A hex value
        :param mechanism: See BorderMechanism
        :param section: See TableSection
        :param rows: Optional. One or more rows as a list. If not given, all columns will be selected
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        for df in self._normalize_common_input(dfs):
            for i in rows:
                self.border(i, i, 0, -1, thickness=thickness, color=color, mechanism=mechanism, section=section, dfs=df)
        return self

    def tbl_font(self, family=None, size=None, weight=None, style=None, dfs=None):
        """
        Set font family

        :param family:
        :param size:
        :param weight: normal, bold
        :param style: normal, italic, oblique
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        d = {}
        dict_merge(d, {'font_size': size} if size is not None else {})
        dict_merge(d, {'font_family': family} if family is not None else {})
        dict_merge(d, {'font_weight': weight} if family is not None else {})
        dict_merge(d, {'font_style': style} if family is not None else {})
        dfs = self._normalize_common_input(dfs)
        for df in dfs:
            dict_merge(self.configs[id(df)], {'table_style': d})
        return self

    def tbl_bg(self, colors=None, section=TableSection.ALL, dfs=None):
        """
        Set background of the entire table

        :param colors: Any color (hex) - pass a list of colors to be used circularly for rows.
                       For example, pass two colors for alternating background rows
        :param section: See TableSection
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        for df in self._normalize_common_input(dfs):
            self.bg(0, -1, 0, -1, colors, section=section, dfs=df)
        return self

    def tbl_caption(self, caption, dfs=None):
        """
        Specify a caption/header for the table

        :param caption: A caption string
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        dfs = self._normalize_common_input(dfs)
        for df in dfs:
            dict_merge(self.configs[id(df)], {'caption': caption})
        return self

    def tbl_shrink(self, line_height='1', dfs=None):
        dfs = self._normalize_common_input(dfs)
        for df in dfs:
            dict_merge(self.configs[id(df)], {'table_style': {'line_height': line_height}})
        return self

    def tbl_border(self, thickness=None, color=None,
                   mechanism=BorderMechanism.BOX, section=TableSection.ALL, dfs=None):
        """
        Sets the border of the table
        :param thickness: Line thickness. The units "in" (inch), "cm", "mm", "px" and "pt" are allowed. If no
                          units are specified, the value is given in points.
        :param color: A hex value
        :param mechanism: See BorderMechanism
        :param section: See TableSection
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        return self.border(0, -1, 0, -1, thickness=thickness, color=color,
                           mechanism=mechanism, section=section, dfs=dfs)

    def cell_applyfn(self, fns, cols=None, dfs=None):
        """
        Apply your own style function on cells. Your style functions should accept the following parameters and should
        return an instance of Style (core.reporting.simple_email) or should return a css key value pair dictionary::

            yourfn(col_name, col_index, row_index, col_value)

        Your function will get access to the col name, col index, row index and col value and you can take decisions
        based on this input.
        Example fn to show negative numbers in red::

            cell_applyfn(StyleFns.NEGATIVE_FG('red'), ['col'])

        :param fns: yourfn(col_name, col_index, row_index, col_value)
        :param cols: Optional. One or more columns as a list. If not given, all columns will be selected
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        fns = list(fns) if isinstance(fns, (list, tuple)) else [fns]
        dfs = self._normalize_common_input(dfs)
        for df in dfs:
            df_cols = self._parse_cols(df, cols)
            ex_fns = self.configs[id(df)].get('column_styles_fn', {})   # to chain functions
            dict_merge(self.configs[id(df)], {'column_styles_fn':
                                                  dict([(col, ex_fns.get(col, []) + fns) for col in df_cols])})
        return self

    def cell_heatmap(self, palette, midpoints=None, cols=None, dfs=None):
        """
        Apply heatmap. A palette can be a list with one or more colors or can be a standard seaborn palette name
        or matplotlib palette name (http://matplotlib.org/examples/color/colormaps_reference.html). To compose
        a new palette, colors can be specified. Colors can be specified in multiple forms:

            1) a letter from the set 'rgbcmykw'
            2) a hex color string, like '#00FFFF'
            3) a standard matplotlib color name, like 'aqua'
            4) a tuple of r, g, b values. between 0 and 1

        :param palette: list of two or more colors or the name of palette from matplotlib / seaborn
        :param midpoints: list of zero or more midpoint values from the dataset to use when mapping colors
                            Or pass "median" (default value) to use the median as a single midpoint value
                            or pass "median_auto" to to use multiple midpoints based on number of colors
                            or pass "nil" to not use midpoints at all
                            for ex: if you specify 5 colors, three midpoints will be determined
        :param cols: Optional. One or more columns as a list. If not given, all columns will be selected
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.

        Examples::

            PrettyTable(df).cell_heatmap(palette=['red', 'YELLOW', 'green']) # can be color names
            PrettyTable(df).cell_heatmap(palette=['#F8696B', '#F8E984', '#63BE7B']) # can be a hex value
            PrettyTable(df).cell_heatmap(palette='RdYlGn') # a palette from matplotlib

        You can compose a custom palette using seaborn::

            import seaborn as sns
            pal=sns.diverging_palette(12,120, s=99, l=50, sep=90, n=1000, center='light')
            PrettyTable([df]).cell_heatmap(palette=pal, midpoints='nil')    #  no midpoints

        """
        def _heatmap_bg_fn(min_pt, max_pt, mid_pts, colors, col_name, col_index, row_index, col_value):
            if col_value is not None and not np.isnan(col_value):
                r, g, b = _map_value_to_rgb(min_pt, max_pt, mid_pts, col_value, colors)
                color = make_html_from_win(r, g, b)
                return Style(background=color) if color else {}
            return {}

        def _calc_mid_points(colors, all_vals, median):
            medians = []
            if len(colors) <= 3:
                medians = [median]
            else:
                no_of_parts = len(colors) - 1
                all_vals = all_vals[~np.isnan(all_vals)]    # ignore nan
                splits = np.array_split(np.sort(all_vals.flatten()), no_of_parts)
                for i, arr in enumerate(splits):
                    if i > 0:
                        arr1, arr2 = splits[i-1], splits[i]
                        len1, len2 = len(arr1), len(arr2)
                        if len1 == len2:
                            medians.append((arr1.max() + arr2.min())/2.0)
                        elif len1 > len2:
                            medians.append(arr1.max())
                        else:
                            medians.append(arr2.min())
            return medians

        dfs         = self._normalize_common_input(dfs)
        colors      = _parse_colors(palette)
        for df in dfs:
            df_cols     = self._parse_cols(df, cols, numericonly=True)
            all_values  = df[df_cols].values
            mid_pts     = midpoints or 'median'
            min_val, max_val, median_val = np.nanmin(all_values), np.nanmax(all_values), np.nanmedian(all_values)
            if np.NaN in [min_val, max_val, median_val]:
                return  # don't apply
            if not isinstance(mid_pts, (list, tuple)):
                if mid_pts == 'median':
                    mid_pts = [median_val]
                elif mid_pts == 'median_auto':
                    mid_pts = _calc_mid_points(colors, all_values, median_val)
                else:
                    mid_pts = []
            self.cell_applyfn(fns=partial(_heatmap_bg_fn, min_val, max_val, mid_pts, colors), cols=df_cols, dfs=df)
        return self

    def idx_show(self, show=True, index_name=None, dfs=None):
        """
        Includes the index column of the dataframe on the output

        :param show: True or False
        :param dfs: Optional. One or more dataframe objects as a list. If not given, the first dataframe will be used.
        """
        d = {}
        dict_merge(d, {'inc_idx': show})
        dict_merge(d, {'index_name': index_name} if index_name is not None else {})
        dfs = self._normalize_common_input(dfs)
        for df in dfs:
            dict_merge(self.configs[id(df)], d)
        return self

    def _normalize_common_input(self, dfs):
        return dfs if isinstance(dfs, (list, tuple)) else (dfs is not None and [dfs] or self.dfs)

    def _parse_rows(self, df, section, rows, with_hdr=True):
        # depending on the section, it will determine the correct row indexes (includes hdr)
        return_rows     = []
        df_row_count    = len(df)
        hdr_row_count   = 0
        if with_hdr and self.configs[id(df)].get('show_headers', True):
            hdr_row_count = len(self.configs[id(df)].get('extra_header_rows') or [])
        for row in rows:
            start_row, end_row      = row, row
            start_row, end_row      = _normalize_idx_range(section, start_row, end_row, hdr_row_count, df_row_count)
            start_row, end_row, _   = slice(start_row, end_row).indices(hdr_row_count + df_row_count)
            return_rows.append(start_row)
        return return_rows

    def _parse_cols_as_indices(self, df, cols=None):
        col_map = self._get_col_idx_map(df)
        if cols:
            if isinstance(cols[0], six.integer_types):
                return cols
            else:
                return [col_map[c] for c in cols]
        return sorted(col_map.values())

    def _parse_cols(self, df, cols=None, numericonly=False):
        if cols:
            if isinstance(cols[0], int):
                colnames = self._getcolnames(df)
                return [colnames[i] for i in cols]
            return cols
        return self._getcolnames(df, numericonly=numericonly)

    def _getcolnames(self, df, numericonly=False, num_dtypes=None):
        num_dtypes  = num_dtypes or {'i', 'u', 'f'}
        inc_idx     = self.configs[id(df)].get('inc_idx')
        idx_name    = self.configs[id(df)].get('index_name', df.index.name) or ''
        cols        = [df[c] for c in df.columns]
        col_names   = (inc_idx and [idx_name] or []) + [c.name for c in cols]
        if numericonly:
            col_names = [c.name for c in cols if c.dtype.kind in num_dtypes]
            if inc_idx and df.index.dtype.kind in num_dtypes:
                col_names = [idx_name] + col_names
        return col_names

    def _get_col_idx_map(self, df):
        return dict((x, i) for i, x in enumerate(self._getcolnames(df)))

    def _repr_html_(self, **kwargs):
        return self.to_html(sassit=True)

    def to_html(self, include_common_css=True, sassit=False, mode='HTML', as_report_element=False):
        """Use this method to produce HTML output"""
        from core.reporting.prettytable.exporter.html import PrettyTableHtmlGenerator
        return PrettyTableHtmlGenerator(self).to_html(sassit, mode=mode, as_report_element=as_report_element)

    def to_rml(self):
        """Use this method to produce RML output"""
        from core.reporting.prettytable.exporter.rml import PrettyTableRmlGenerator
        return PrettyTableRmlGenerator(self).to_rml()

    def to_pdf(self, filename):
        self.to_pdf_via_rml(filename)

    def to_pdf_via_rml(self, filename):
        from z3c.rml import rml2pdf
        templ_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../rml', 'preppy_templates')
        templ_dir = os.path.normpath(templ_dir)
        template  = preppy.getModule('pt_standalone.prep', templ_dir)
        rml_txt   = template.get([self.to_rml()], {})
        with open(filename, 'wb') as pdfFile:
            pdfFile.write(rml2pdf.parseString(rml_txt).read())

    def to_ws(self, ws, **params):
        """
        Exports PrettyTable to an excel worksheet. See to_xlsx and to_wb methods as well

        :param ws: instance of openpyxl workseet
        :param params: optional dictionary containing the following attributes
                        start_row: The row to start exporting?. defaults to 2
                        start_col: The column to start exporting. defaults to 2
        :return: worksheet
        """
        from core.reporting.prettytable.exporter.xl import PrettyTableExcelGenerator
        return PrettyTableExcelGenerator(self).to_ws(ws, **params)

    def as_report_element(self, include_common_css=False, sassit=True, mode='HTML', **kwargs):
        if mode == 'RML':
            return RawHTML(self.to_rml(), children_only=True)
        return self.to_html(include_common_css=include_common_css, sassit=sassit, mode=mode, as_report_element=True)

    def sendmail(self, from_addr, to_addrs, subject):
        """Use this method to send an email"""
        from core.reporting.simple_email import create_report_message
        stylesheets     = [get_reset_css(), get_core_style(), get_tables_css()]
        msg             = create_report_message(self.as_report_element(sassit=False, mode='EMAIL'),
                                                stylesheets=stylesheets)
        msg['Subject']  = subject
        msg['From']     = from_addr
        msg['To']       = ','.join(to_addrs)
        smtp            = smtplib.SMTP('mailhost.pimco.com')
        smtp.sendmail(from_addr, to_addrs, msg.as_string())


# Helpers
def _value_check(val, operator, bg_or_fg, color, col_name, col_index, row_index, col_value):
    style = Style(background=color) if bg_or_fg == 'bg' else Style(color=color)
    if operator == '=':
        truth = col_value == val
    elif operator == '!=':
        truth = col_value != val
    elif operator == '>':
        truth = col_value is not None and col_value > val
    elif operator == '>=':
        truth = col_value is not None and col_value >= val
    elif operator == '<':
        truth = col_value is not None and col_value < val
    elif operator == '<=':
        truth = col_value is not None and col_value <= val
    return style if truth else {}


class StyleFns(object):
    """
    Helper fns - use it in PrettyTable.cell_applyfn method:
    """

    NEG_RED             = staticmethod(partial(_value_check, 0, '<', 'fg', 'red'))
    NEG_HIGHLIGHT       = staticmethod(partial(_value_check, 0, '<', 'bg', 'yellow'))
    BG                  = staticmethod(lambda cond, value, color: partial(_value_check, value, cond, 'bg', color))
    FG                  = staticmethod(lambda cond, value, color: partial(_value_check, value, cond, 'fg', color))
    NEGATIVE_FG         = staticmethod(lambda color: partial(_value_check, 0, '<', 'fg', color))
    NEGATIVE_BG         = staticmethod(lambda color: partial(_value_check, 0, '<', 'bg', color))
    POSITIVE_FG         = staticmethod(lambda color: partial(_value_check, 0, '>=', 'fg', color))
    POSITIVE_BG         = staticmethod(lambda color: partial(_value_check, 0, '>=', 'bg', color))
    EQ_FG               = staticmethod(lambda value, color: partial(_value_check, value, '=', 'fg', color))
    EQ_BG               = staticmethod(lambda value, color: partial(_value_check, value, '=', 'bg', color))
    GT_BG               = staticmethod(lambda value, color: partial(_value_check, value, '>', 'bg', color))
    GT_FG               = staticmethod(lambda value, color: partial(_value_check, value, '>', 'fg', color))
    GTE_BG              = staticmethod(lambda value, color: partial(_value_check, value, '>=', 'bg', color))
    GTE_FG              = staticmethod(lambda value, color: partial(_value_check, value, '>=', 'fg', color))
    LT_BG               = staticmethod(lambda value, color: partial(_value_check, value, '<', 'bg', color))
    LT_FG               = staticmethod(lambda value, color: partial(_value_check, value, '<', 'fg', color))
    LTE_BG              = staticmethod(lambda value, color: partial(_value_check, value, '<=', 'bg', color))
    LTE_FG              = staticmethod(lambda value, color: partial(_value_check, value, '<=', 'fg', color))
    NO_WRAP             = staticmethod(lambda *args, **kwargs: Style(white_space='nowrap'))


def _map_value_to_rgb(min_pt, max_pt, mid_pts, val, colors):
    """
    Used to linearly interpolate a specified range of values over a variably-sized palette of arbitrary colors
    Uses min, max and mid points to interpolate
    similar to matplotlib's LinearSegmentedColormap
    """
    x           = [min_pt] + list(mid_pts) + [max_pt]
    y           = np.linspace(0,1,len(x))
    interp_val  = np.ma.masked_array(np.interp(val, x, y))
    # interp_val= float(val-min_pt) / float(max_pt-min_pt)

    fi = interp_val * (len(colors) - 1)
    i  = int(fi)
    f  = fi - i
    if f < EPSILON:
        return colors[i]
    else:
        (r1, g1, b1), (r2, g2, b2) = colors[i], colors[i+1]
        return int(r1 + f*(r2-r1)), int(g1 + f*(g2-g1)), int(b1 + f*(b2-b1))


def _parse_colors(colors):
    """
    Parses the colors and returns a list of RGB tuple. Colors can be specified in multiple forms:

            1) a letter from the set 'rgbcmykw'
            2) a hex color string, like '#00FFFF'
            3) a standard matplotlib color name, like 'aqua'
            4) a standard seaborn palette name accepted by seaborn.color_palette
            5) a tuple of r, g, b values. between 0 and 1

    :param colors: list of colors
    :return: list of rgb tuples
    """
    parsed_colors = []
    if not isinstance(colors, (list, tuple)):
        colors = [colors]
    for c in colors:
        if isinstance(c, (list, tuple)):
            parsed_colors.append(c)
        elif matplotlib.colors.is_color_like(c):
            parsed_colors.append(matplotlib.colors.colorConverter.to_rgb(c))
        else:
            try:
                parsed_colors.extend(seaborn.color_palette(c))
            except ValueError:
                raise  Exception("Couldn't recognize color: %s" % c)
    return [(pc[0] * 255, pc[1] * 255, pc[2] * 255) for pc in parsed_colors]
