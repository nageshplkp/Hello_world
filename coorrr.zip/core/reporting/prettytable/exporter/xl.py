from functools import partial

from openpyxl.styles import PatternFill
from openpyxl.utils import get_column_letter
from xhtml2pdf.util import getSize, dpi96

from core.chart.table import Style
from core.common.util import dict_merge
from core.reporting.enum import TableSection
from core.reporting.prettytable.exporter.base import PrettyTableOutputGenerator, _resolve_idx_range
from core.reporting.prettytable.utils import df_to_xlsx
from core.reporting.prettytable.utils import html_to_bold_italic
from core.reporting.xl.utils import xl_apply_border, xl_apply_bg, xl_apply_fg, xl_apply_align
from core.reporting.xl.utils import xl_color, xl_v_align, xl_apply_font, xl_apply_font_to_cell


class PrettyTableExcelGenerator(PrettyTableOutputGenerator):

    def to_ws(self, ws, **params):
        """
        Exports PrettyTable to the given worksheet

        :param ws: instance of openpyxl workseet
        :param params: optional dictionary containing the following attributes
                        start_row: The row to start exporting?. defaults to 2
                        start_col: The column to start exporting. defaults to 2
        :return: worksheet
        """

        idx_row, idx_col = params.get('start_row', 2), params.get('start_col', 2)

        for i, df in enumerate(self.pt.dfs):

            cfg_df = dict_merge({}, self.pt.configs.get(id(df)) or {})
            cfg_df = self.pt.on_insert_defaults(df, cfg_df)
            cfg_df['col_order_processed'] = self._get_col_order(df, cfg_df)

            extra_header_rows = cfg_df.get('extra_header_rows', [])
            show_headers = cfg_df.get('show_headers', True)

            additional_info = dict(start_row=idx_row, start_col=idx_col, ws=ws)

            self._apply_default_styles(df, cfg_df, additional_info)
            self._apply_static_styles(df, cfg_df, additional_info)
            df_to_xlsx(df, ws,
                       idx_start         = (idx_row, idx_col),
                       inc_idx           = cfg_df.get('inc_idx', False),
                       idx_name          = cfg_df.get('index_name', ''),
                       show_headers      = show_headers,
                       col_order         = cfg_df['col_order_processed'],
                       extra_header_rows = extra_header_rows,
                       custom_headers    = cfg_df.get('custom_headers', {}),
                       cell_cb           = partial(self._enrich_cell, df, cfg_df),
                       )
            idx_row += len(df) + (len(extra_header_rows) + 1 if show_headers else 0)

        return ws

    def _get_idx_range(self, df, cfg_df, params, additional_info):
        hdr_row_count   = self._len_headers(cfg_df)
        cell_info       = dict(row=[None]*len(cfg_df['col_order_processed']),
                               hdr_row_count=hdr_row_count, df_row_count=len(df))
        start_row, end_row, \
            start_col, end_col  = _resolve_idx_range(params, cell_info)
        start_row, end_row      = start_row + additional_info['start_row'], end_row + additional_info['start_row']
        start_col, end_col      = start_col + additional_info['start_col'], end_col + additional_info['start_col']
        return start_row, end_row, start_col, end_col

    def _apply_default_styles(self, df, cfg_df, additional_info):
        styles = cfg_df.get('table_style') or {}

        # default bg
        if styles['background']:
            params = {'start_row': 0, 'end_row': -1, 'start_col': 0, 'end_col': -1,
                      'colors': [styles['background']], 'section': TableSection.ALL}
            self._apply_cell_bg(df, cfg_df, params, additional_info)

        # default valign
        params = {'start_row': 0, 'end_row': -1, 'start_col': 0, 'end_col': -1,
                  'valign': styles['vertical_align'], 'section': TableSection.ALL}
        self._apply_cell_v_align(df, cfg_df, params, additional_info)

        # default halign
        params = {'start_row': 0, 'end_row': -1, 'start_col': 0, 'end_col': -1,
                  'align': styles['text_align'], 'section': TableSection.ALL}
        self._apply_cell_h_align(df, cfg_df, params, additional_info)

        # default font
        params = {'start_row': 0, 'end_row': -1, 'start_col': 0, 'end_col': -1, 'section': TableSection.ALL,
                  'font_size': styles.get('font_size'), 'font_family': styles.get('font_family'),
                  'font_weight': styles.get('font_weight'), 'font_style': styles.get('font_style')}
        self._apply_cell_font(df, cfg_df, params, additional_info)

    def _apply_static_styles(self, df, cfg_df, additional_info):

        self._apply_cell_span(cfg_df, additional_info)

        for params in cfg_df.get('border_styles', []):
            self._apply_cell_borders(df, cfg_df, params, additional_info)

        for params in cfg_df.get('bg_styles', []):
            self._apply_cell_bg(df, cfg_df, params, additional_info)

        for params in cfg_df.get('fg_styles', []):
            self._apply_cell_fg(df, cfg_df, params, additional_info)

        for params in cfg_df.get('alignment_styles', []):
            self._apply_cell_h_align(df, cfg_df, params, additional_info)

        if not cfg_df.get('column_widths'):
            cfg_df['column_widths'] = [dict(width='auto', col_names=cfg_df['col_order_processed'])]
        else:
            all_col_names = []
            for d in cfg_df['column_widths']:
                all_col_names.extend(d['col_names'])
            missing_col_names = set(cfg_df['col_order_processed']) - set(all_col_names)
            cfg_df['column_widths'].append(dict(width='auto', col_names=missing_col_names))
        self._apply_col_widths(df, cfg_df, additional_info)

    def _apply_cell_span(self, cfg_df, additional_info):
        if self._is_show_header(cfg_df):
            xl_start_row = additional_info['start_row']
            xl_start_col = additional_info['start_col']
            ws           = additional_info['ws']
            for row_idx, extra_header_row in enumerate(self._get_extra_header_rows(cfg_df)):
                col_idx     = 0
                this_header = [x if isinstance(x, (list, tuple)) else (x, 1) for x in extra_header_row]
                for i, (hdr_cell, col_span) in enumerate(this_header):
                    if col_span > 1:
                        ws.merge_cells(start_row=xl_start_row+row_idx, end_row=xl_start_row+row_idx,
                                       start_column=xl_start_col+col_idx, end_column=xl_start_col+col_idx+col_span-1)
                        col_idx = col_idx + col_span

    def _apply_col_widths(self, df, cfg_df, additional_info):
        # https://msdn.microsoft.com/en-us/library/documentformat.openxml.spreadsheet.column(v=office.14).aspx
        # https://bitbucket.org/openpyxl/openpyxl/issues/293/column-width-issue
        ws = additional_info['ws']
        max_digit_width = 6  # there is no proper way to calculate this
        hdrs = cfg_df.get('custom_headers', {})
        hdrs[df.index.name] = cfg_df.get('index_name') or df.index.name or ''
        col_order = cfg_df['col_order_processed']

        def my_len(s):
            return len((s or '').split('\n')[0])

        def float_len(s):
            splits = (s or '').split('.')
            if len(splits) >= 2:
                return len(splits[0]) + len(splits[1][-6:])
            return len(splits[0])

        def calc_no_of_chars(s):
            h = hdrs.get(s.name, s.name) or ''
            if s.dtype.kind == 'f':
                longest_val = s.astype(str).map(float_len).max()
            else:
                longest_val = s.astype(str).map(my_len).max()
            return max(longest_val, len(h))

        for x in cfg_df['column_widths']:
            if x['width'].lower() == 'auto':
                for col in x['col_names']:
                    no_of_chars = calc_no_of_chars(self._get_col_by_name(df, cfg_df, col))
                    calculated_w = abs((no_of_chars * max_digit_width + 3.0)/max_digit_width*256.0)/256.0
                    col_letter = get_column_letter(additional_info['start_col'] + col_order.index(col))
                    ws.column_dimensions[col_letter].width = calculated_w
            else:
                px_w = getSize(x['width']) / dpi96  # points to pixels
                no_of_chars = abs((px_w-5.0)/max_digit_width * 100.0+0.5)/100.0    # character width
                calculated_w = abs((no_of_chars * max_digit_width + 3.0)/max_digit_width*256.0)/256.0
                for col in x['col_names']:
                    col_letter = get_column_letter(additional_info['start_col'] + col_order.index(col))
                    ws.column_dimensions[col_letter].width = calculated_w

    def _apply_cell_borders(self, df, cfg_df, params, additional_info):
        start_row, end_row, start_col, end_col  = self._get_idx_range(df, cfg_df, params, additional_info)
        d = dict(start_row=start_row, start_col=start_col, end_row=end_row, end_col=end_col,
                 mechanism=params['mechanism'], color=params['color'], border_style='thin')
        xl_apply_border(additional_info['ws'], d)

    def _apply_cell_bg(self, df, cfg_df, params, additional_info):
        start_row, end_row, start_col, end_col  = self._get_idx_range(df, cfg_df, params, additional_info)
        d = dict(start_row=start_row, start_col=start_col, end_row=end_row, end_col=end_col, colors=params['colors'])
        xl_apply_bg(additional_info['ws'], d)

    def _apply_cell_fg(self, df, cfg_df, params, additional_info):
        start_row, end_row, start_col, end_col  = self._get_idx_range(df, cfg_df, params, additional_info)
        d = dict(start_row=start_row, start_col=start_col, end_row=end_row, end_col=end_col, color=params['color'])
        xl_apply_fg(additional_info['ws'], d)

    def _apply_cell_h_align(self, df, cfg_df, params, additional_info):
        start_row, end_row, start_col, end_col  = self._get_idx_range(df, cfg_df, params, additional_info)
        d = dict(start_row=start_row, start_col=start_col, end_row=end_row, end_col=end_col,
                 h_align=params['align'], wrap_text=True)
        xl_apply_align(additional_info['ws'], d)

    def _apply_cell_v_align(self, df, cfg_df, params, additional_info):
        start_row, end_row, start_col, end_col  = self._get_idx_range(df, cfg_df, params, additional_info)
        d = dict(start_row=start_row, start_col=start_col, end_row=end_row, end_col=end_col,
                 v_align=xl_v_align(params['valign']))
        xl_apply_align(additional_info['ws'], d)

    def _apply_cell_font(self, df, cfg_df, params, additional_info):
        start_row, end_row, start_col, end_col  = self._get_idx_range(df, cfg_df, params, additional_info)
        b, i = html_to_bold_italic(params.get('font_weight'), params.get('font_style'))
        d = dict(params)
        d.update(dict(start_row=start_row, start_col=start_col, end_row=end_row, end_col=end_col, bold=b, italic=i))
        xl_apply_font(additional_info['ws'], d)

    @staticmethod
    def _apply_number_formats_cb(df, cfg_df, c, cell_info):
        if not cell_info.get('is_hdr'):
            num_format = cfg_df['xl_number_formats'].get(cell_info['col_name'])
            if num_format:
                if callable(num_format):
                    result = num_format(cell_info['val'], cell_info['row'],
                                        cell_info['col_idx'], cell_info['row_idx'], df)
                    if result:  # flexible
                        if len(result) >= 1:
                            num_format = result[0]
                        if len(result) >= 2:
                            c.value = result[1]
                c.number_format = num_format

    def _enrich_cell(self, df, cfg_df, c, cell_info):
        if cfg_df.get('xl_number_formats'):
            self._apply_number_formats_cb(df, cfg_df, c, cell_info)
        self._apply_column_styles_fn(cfg_df, c, cell_info)

    def _apply_column_styles_fn(self, cfg_df, c, cell_info):
        if cell_info.get('is_hdr'):
            return
        css_props = {}
        col_fns_map = cfg_df.get('column_styles_fn') or {}
        fns = col_fns_map.get(cell_info.get('col_name')) or []
        for fn in fns:
            val = fn(cell_info['col_name'], cell_info['col_idx'],
                     cell_info['row_idx'] - cell_info['hdr_row_count'], cell_info['val'])
            if isinstance(val, Style):
                val = val.as_css_props()
            css_props.update(val or {})
        self._apply_css_attr(c, css_props)

    def _apply_css_attr(self, c, css_attr):
        if 'color' in css_attr:
            c.font = c.font.copy(color=xl_color(css_attr['color']))
        if 'background' in css_attr:
            bg_color = xl_color(css_attr['background'])
            c.fill = PatternFill(start_color=bg_color, end_color=bg_color, fill_type='solid')
        font_attrs = ['font-family', 'font-weight', 'font-style', 'font-size']
        params = dict([(a.replace('-', '_'), css_attr.get(a)) for a in font_attrs])
        b, i = html_to_bold_italic(params.get('font_weight'), params.get('font_style'))
        params.update(dict(bold=b, italic=i))
        xl_apply_font_to_cell(c, params)
