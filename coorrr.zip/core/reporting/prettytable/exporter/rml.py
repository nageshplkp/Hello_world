import cgi
import six
import uuid
from cStringIO import StringIO
from functools import partial

from reportlab.lib.utils import simpleSplit
from xhtml2pdf.util import getSize

from core.chart.table import Style
from core.common.util import dict_merge
from core.reporting.enum import TableSection, BorderMechanism
from core.reporting.prettytable.exporter.base import PrettyTableOutputGenerator, _resolve_idx_range
from core.reporting.prettytable.utils import df_to_rml_rows
from core.reporting.prettytable.utils import html_to_pdf_font_name
from core.reporting.simple_email import ReportMessageElement


class PrettyTableRmlGenerator(PrettyTableOutputGenerator):

    def __init__(self, *args, **kwargs):
        super(PrettyTableRmlGenerator, self).__init__(*args, **kwargs)
        self.row_heights = {}
        self.col_widths = {}

    """
    Word wrap doesn't happen inside a td cell in RML. If the test is too long, the text just overflows the  boundary 
    of the cell. In order to enable word wrap, every cell value needs to be wrapped inside a <para> tag. 
    The main thing that makes this slightly more complex than a very simple table is the fact that you must give 
    rowHeights and colWidths to the <blockTable> to use paras. 
    
    In order to handle this behavior - we will wrap cell values inside a <para> tag and the user should specify the 
    column width. Based on the column width, font size and leading, we will automatically calculate the row heights.
    Note: Row height calculation can cause performance issues in large tables.
    """

    def to_rml(self):
        buf = StringIO()
        for i, df in enumerate(self.pt.dfs):
            cfg_df = dict_merge({}, self.pt.configs.get(id(df)) or {})
            cfg_df = self.pt.on_insert_defaults(df, cfg_df)
            style_elements = self._prepare_style_elements(df, cfg_df)
            if style_elements:
                style_id = 's%s' % str(uuid.uuid4()).split('-')[-1]  # unique enough
                style_elements = [ReportMessageElement('blockTableStyle', *style_elements, id=style_id)]
            self._calc_col_widths(df, cfg_df)
            rows = df_to_rml_rows(df,
                                  inc_idx           = cfg_df.get('inc_idx', False),
                                  idx_name          = cfg_df.get('index_name', ''),
                                  show_headers      = cfg_df.get('show_headers', True),
                                  formatter         = cfg_df.get('custom_formats'),
                                  col_order         = cfg_df.get('column_order'),
                                  extra_header_rows = cfg_df.get('extra_header_rows', []),
                                  custom_headers    = cfg_df.get('custom_headers', {}),
                                  attributor        = [partial(self._td_attrib_generator, id(df), cfg_df)],
                                  )
            if cfg_df.get('caption'):
                ReportMessageElement('h4', cgi.escape(cfg_df['caption'])).render(buf, {}, {})
            table_attrs = {'colWidths': self._get_col_widths(df), 'alignment': 'left',
                           'repeatRows': self._calc_repeat_hdrs(cfg_df),
                           'rowHeights': ','.join([ x and '%.2f' % x or 'None' for x in self.row_heights[id(df)]])}
            e = ReportMessageElement('blockTable', *(style_elements + rows), **table_attrs)
            e.render(buf, {}, {})

        return buf.getvalue()

    @staticmethod
    def _calc_repeat_hdrs(cfg_df):
        if cfg_df['repeat_headers'] and cfg_df['show_headers']:
            return len(cfg_df.get('extra_header_rows', [])) + 1
        return 0

    def _calc_col_widths(self, df, cfg_df):
        col_map = {}
        for attrs in cfg_df.get('column_widths', []):
            for col_name in attrs['col_names']:
                col_map[col_name] = getSize(attrs['width']) if attrs['width'] != 'auto' else None
        self.col_widths[id(df)] = dict((col_name, col_map.get(col_name)) for col_name in self.pt._parse_cols(df))

    def _get_col_widths(self, df):
        return ','.join(str(self.col_widths[id(df)].get(col_name)) for col_name in self.pt._parse_cols(df))

    def _calc_row_heights(self, df_id, attributes, cell_info):
        row_heights = self.row_heights.get(df_id)
        if row_heights is None:
            row_heights = [None] * (cell_info['hdr_row_count'] + cell_info['df_row_count'])
            self.row_heights[df_id] = row_heights
        row_idx = cell_info['row_idx']
        val_f = cell_info['val_f']
        if val_f and isinstance(val_f, six.string_types):
            col_name = cell_info.get('col_name')
            if col_name is not None:
                widths = [self.col_widths[df_id][col_name]]
            else:
                widths = [self.col_widths[df_id][x] for x in cell_info.get('span_col_names')]
            if None in widths:
                return
            fn = attributes['para']['fontName']  # assuming these attributes are emitted to every cell para
            fs = attributes['para']['fontSize']
            leading = attributes['para']['leading']
            l_pad = getSize(attributes.get('td', {}).get('leftPadding', self.pt.cfg.CELL_PADDING))
            r_pad = getSize(attributes.get('td', {}).get('rightPadding', self.pt.cfg.CELL_PADDING))
            t_pad = getSize(attributes.get('td', {}).get('topPadding', self.pt.cfg.CELL_PADDING))
            b_pad = getSize(attributes.get('td', {}).get('bottomPadding', self.pt.cfg.CELL_PADDING))
            pad_width = l_pad + r_pad
            pad_height = t_pad + b_pad
            cell_width = sum(widths) - pad_width
            height = row_heights[row_idx] or 0
            this_height = (len(simpleSplit(val_f, fn, fs, cell_width)) * leading) + pad_height
            if this_height > height:
                row_heights[row_idx] = this_height

    def _prepare_style_elements(self, df, cfg_df):
        elements = []
        fns      = []

        elements += self._prep_default_styles(df, cfg_df)
        elements += self._prep_border_styles(df, cfg_df)
        elements += self._prep_span_styles(df, cfg_df)
        elements += self._prep_bg_styles(df, cfg_df)

        for attrs in cfg_df.get('alignment_styles', []):
            fns.append(partial(self._cell_para_attrib, 'alignment', 'align', attrs))

        for attrs in cfg_df.get('fg_styles', []):
            fns.append(partial(self._cell_para_attrib, 'textColor', 'color', attrs))

        for attrs in cfg_df.get('font_styles', []):
            fns.append(partial(self._cell_font_cb, attrs))

        for attrs in cfg_df.get('padding_styles', []):
            fns.append(partial(self._cell_padding_cb, attrs))

        cfg_df['static_cell_styler_fns'] = fns
        cfg_df['dynamic_cell_styler_fns'] = [self._column_styles_fn_caller]
        return elements

    def _prep_default_styles(self, df, cfg_df):
        rme         = ReportMessageElement
        elements    = []
        styles      = cfg_df.get('table_style') or {}

        if styles['background']:
            elements.append(rme('blockBackground', start="0,0", stop="-1,-1", colorName=styles['background']))
        elements.append(rme('blockValign', start="0,0", stop="-1,-1", value=styles['vertical_align']))

        # text alignment needs to go into the paragraph. we could create a paraStyle instead
        a_styles = cfg_df.get('alignment_styles', [])
        a_styles.insert(0, {'start_row': 0, 'end_row': -1, 'start_col': 0, 'end_col': -1,
                            'align': styles['text_align'], 'section': TableSection.ALL})
        cfg_df['alignment_styles'] = a_styles

        # font
        f_styles = cfg_df.get('font_styles') or []
        f_styles.insert(0, {'start_row': 0, 'end_row': -1, 'start_col': 0, 'end_col': -1, 'section': TableSection.ALL,
                            'font_size': styles.get('font_size'), 'font_family': styles.get('font_family'),
                            'font_weight': styles.get('font_weight'), 'font_style': styles.get('font_style')})
        cfg_df['font_styles'] = f_styles

        length = getSize(styles['cell_padding'])
        elements.append(rme('blockLeftPadding', start="0,0", stop="-1,-1", length=length))
        elements.append(rme('blockRightPadding', start="0,0", stop="-1,-1", length=length))
        elements.append(rme('blockTopPadding', start="0,0", stop="-1,-1", length=length))
        elements.append(rme('blockBottomPadding', start="0,0", stop="-1,-1", length=length))

        return elements

    def _prep_border_styles(self, df, cfg_df):
        elements = []
        for attrs in cfg_df.get('border_styles', []):
            start_row, end_row, start_col, end_col = self._resolve_idx_range(df, cfg_df, attrs)
            d = {'start': '%s,%s' % (start_col, start_row), 'stop': '%s,%s' % (end_col, end_row),
                 'thickness': getSize(attrs['thickness']), 'kind': BorderMechanism.get_rml_kind(attrs['mechanism']),
                 'colorName': attrs['color']}
            elements.append(ReportMessageElement('lineStyle', **d))
        return elements

    def _prep_bg_styles(self, df, cfg_df):
        elements = []
        for attrs in cfg_df.get('bg_styles', []):
            start_row, end_row, start_col, end_col = self._resolve_idx_range(df, cfg_df, attrs)
            d = {'start': '%s,%s' % (start_col, start_row), 'stop': '%s,%s' % (end_col, end_row),
                 len(attrs['colors']) > 1 and 'colorsByRow' or 'colorName': ','.join(attrs['colors'])}
            elements.append(ReportMessageElement('blockBackground', **d))
        return elements

    def _prep_span_styles(self, df, cfg_df):
        elements = []
        if self._is_show_header(cfg_df):
            for row_idx, extra_header_row in enumerate(self._get_extra_header_rows(cfg_df)):
                this_header = [x if isinstance(x, (list, tuple)) else (x,1) for x in extra_header_row]
                col_idx = 0
                for i, (hdr_cell, col_span) in enumerate(this_header):
                    if col_span > 1:
                        start = '%s,%s' % (col_idx, row_idx)
                        stop = '%s,%s' % (col_idx + col_span - 1, row_idx)
                        col_idx = col_idx + col_span
                        elements.append(ReportMessageElement('blockSpan', start=start, stop=stop))
        return elements

    def _cell_font_cb(self, params, cell_info):
        d                       = {}
        row_idx, col_idx        = cell_info['row_idx'], cell_info['col_idx']
        start_row, end_row, start_col, end_col = _resolve_idx_range(params, cell_info)
        if start_col <= col_idx <= end_col and start_row <= row_idx <= end_row:
            d['fontName'], d['fontSize'], d['leading'] = self._calc_font(params)
        return d and {'para': d} or {}

    def _cell_padding_cb(self, params, cell_info):
        d                       = {}
        side_map = {'t': 'Top', 'b': 'Bottom', 'l': 'Left', 'r': 'Right'}
        row_idx, col_idx        = cell_info['row_idx'], cell_info['col_idx']
        start_row, end_row, start_col, end_col = _resolve_idx_range(params, cell_info)
        if start_col <= col_idx <= end_col and start_row <= row_idx <= end_row:
            sides = params['sides'] or side_map.keys()
            length = getSize(params['length'])
            for side in sides:
                d['%sPadding'] = length
        return d and {'td': d} or {}

    def _cell_para_attrib(self, attr_name, param_name,  params, cell_info):
        d                       = {}
        row_idx, col_idx        = cell_info['row_idx'], cell_info['col_idx']
        start_row, end_row, start_col, end_col = _resolve_idx_range(params, cell_info)
        if start_col <= col_idx <= end_col and start_row <= row_idx <= end_row:
            d[attr_name] = params[param_name]
        return d and {'para': d} or {}

    def _td_attrib_generator(self, df_id, cfg_df, cell_info):
        attributes = {}
        for fn in cfg_df.get('static_cell_styler_fns', []):
            dict_merge(attributes, fn(cell_info) or {})
        for fn in cfg_df.get('dynamic_cell_styler_fns', []):
            dict_merge(attributes, fn(cfg_df, cell_info) or {})
        self._calc_row_heights(df_id, attributes, cell_info)
        return attributes

    def _column_styles_fn_caller(self, cfg_df, cell_info):
        if cell_info.get('is_hdr'):
            return {}
        attributes = {}
        col_fns_map = cfg_df.get('column_styles_fn') or {}
        fns = col_fns_map.get(cell_info.get('col_name')) or []
        for fn in fns:
            val = fn(cell_info['col_name'], cell_info['col_idx'],
                     cell_info['row_idx'] - cell_info['hdr_row_count'], cell_info['val'])
            if isinstance(val, Style):
                val = self._convert_css_attrs_to_rml(val.as_css_props())
            attributes.update(val or {})
        return attributes

    def _calc_font(self, params):
        font_family = params.get('font_family') or self.pt.cfg.TBL_FONT_FMLY
        font_weight = params.get('font_weight') or self.pt.cfg.TBL_FONT_WGHT
        font_style  = params.get('font_style') or self.pt.cfg.TBL_FONT_STYL
        font_name   = html_to_pdf_font_name(font_family, font_weight, font_style)
        font_size   = getSize(params.get('font_size') or self.pt.cfg.TBL_FONT_SIZE)
        font_size   = font_size + (font_size * self.pt.cfg.PDF_FONT_SCALE)
        lh          = params.get('line_height') or self.pt.cfg.LINE_HEIGHT
        adjusted_lh = max(1.2, float(lh))
        leading     = font_size * adjusted_lh
        return font_name, font_size, leading

    def _convert_css_attrs_to_rml(self, css_attr):
        rml_attr = {'td': {}, 'para': {}}
        if 'color' in css_attr:
            rml_attr['para']['textColor'] = css_attr['color']
        if 'background' in css_attr:
            rml_attr['td']['background'] = css_attr['background']
        font_attrs = ['font-family', 'font-weight', 'font-style', 'font-size', 'line-height']
        if any([(a in css_attr) for a in font_attrs]):
            d = dict([(a.replace('-', '_'), css_attr.get(a)) for a in font_attrs])
            font_name, font_size, leading = self._calc_font(d)
            rml_attr['para']['fontName'] = font_name
            rml_attr['para']['fontSize'] = font_size
            rml_attr['para']['leading'] = leading
        return rml_attr
