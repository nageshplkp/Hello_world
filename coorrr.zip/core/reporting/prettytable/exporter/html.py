import uuid
from cStringIO import StringIO
from functools import partial

import sass

from core.chart.styles import get_pretty_tbl_style, get_reset_css
from core.chart.table import Style
from core.common.util import dict_merge
from core.reporting.enum import BorderMechanism
from core.reporting.prettytable.exporter.base import PrettyTableOutputGenerator, _resolve_idx_range
from core.reporting.prettytable.utils import df_to_html_rows
from core.reporting.simple_email import ReportMessageElement, Span, RawHTML


class PrettyTableHtmlGenerator(PrettyTableOutputGenerator):

    def to_html(self, sassit=False, mode='HTML', as_report_element=False):

        css = []
        elements = []

        for i, df in enumerate(self.pt.dfs):
            tbl_cls_name = 'pt%s' % str(uuid.uuid4()).split('-')[-1]  # unique enough
            cfg_df       = dict_merge({}, self.pt.configs.get(id(df)) or {})
            cfg_df       = self.pt.on_insert_defaults(df, cfg_df)
            css.append(get_pretty_tbl_style(tbl_cls_name, **cfg_df.get('table_style')))
            self._prepare_styler_fns(df, cfg_df)
            rows = df_to_html_rows(df,
                                   inc_idx             = cfg_df.get('inc_idx', False),
                                   idx_name            = cfg_df.get('index_name', None),
                                   show_headers        = cfg_df.get('show_headers', True),
                                   formatter           = cfg_df.get('custom_formats'),
                                   col_order           = cfg_df.get('column_order'),
                                   extra_header_rows   = cfg_df.get('extra_header_rows', []),
                                   custom_headers      = cfg_df.get('custom_headers', {}),
                                   attributor          = [partial(self._cell_style_generator, cfg_df),
                                                          partial(self._cell_class_generator, tbl_cls_name),],
                                   mode                = mode,
                                   )
            if cfg_df.get('caption'):
                elements.append(ReportMessageElement('h4', cfg_df['caption']))
            elements.append(ReportMessageElement('table', *rows, css_class=tbl_cls_name))

        css         = [get_reset_css()] + css
        css_txt     = '\n'.join(css)

        if sassit:
            cls_name = 'a%s' % str(uuid.uuid4()).split('-')[-1]
            css_txt  = sass.compile(string='.%s {%s}' % (cls_name, css_txt))
            style_elem = ReportMessageElement('style', RawHTML(css_txt), type="text/css")
            root_elem = Span(style_elem, *elements, css_class=cls_name)
        else:
            style_elem = ReportMessageElement('style', RawHTML(css_txt), type="text/css")
            root_elem = ReportMessageElement(None, style_elem, *elements, children_only=True)

        if as_report_element:
            return root_elem

        buf = StringIO()
        root_elem.render(buf, {}, {})
        return buf.getvalue()

    @staticmethod
    def _cell_class_generator(tbl_cls_name, *args):
        return {'class': '%s-%s' % (tbl_cls_name, 'cell')}

    @staticmethod
    def _cell_style_generator(cfg_df, cell_info):
        styles = {}
        values = []
        for fn in cfg_df.get('cell_static_styler_fns', []):
            values.append(fn(cell_info) or {})
        for fn in cfg_df.get('cell_dynamic_styler_fns', []):
            values.append(fn(cfg_df, cell_info) or {})
        for val in values:
            val = isinstance(val, Style) and val.as_css_props() or val
            styles.update(val)
        css = Style.as_css_string(Style(**styles).as_css_props())
        return css and {'style': css} or {}

    def _column_styles_fn_caller(self, cfg_df, cell_info):
        if cell_info.get('is_hdr'):
            return {}
        attributes = {}
        col_fns_map = cfg_df.get('column_styles_fn') or {}
        fns = col_fns_map.get(cell_info.get('col_name')) or []
        for fn in fns:
            val = fn(cell_info['col_name'], cell_info['col_idx'],
                     cell_info['row_idx'] - cell_info['hdr_row_count'], cell_info['val'])
            val = isinstance(val, Style) and val.as_css_props() or val
            attributes.update(val or {})
        return attributes

    def _prepare_styler_fns(self, df, cfg_df):
        fns = []
        for attrs in cfg_df.get('border_styles', []):
            fns.append(partial(self._cell_border_cb, attrs))
        for attrs in cfg_df.get('alignment_styles', []):
            fns.append(partial(self._cell_style_cb, 'text_align', 'align', attrs))
        for attrs in cfg_df.get('fg_styles', []):
            fns.append(partial(self._cell_style_cb, 'color', 'color', attrs))
        for attrs in cfg_df.get('bg_styles', []):
            fns.append(partial(self._cell_bg_cb, attrs))
        for attrs in cfg_df.get('padding_styles', []):
            fns.append(partial(self._cell_padding_cb, attrs))
        for attrs in cfg_df.get('font_styles', []):
            fns.append(partial(self._cell_font_cb, attrs))
        for attrs in cfg_df.get('column_widths', []):
            fns.append(partial(self._cell_width_cb, attrs))
        cfg_df['cell_static_styler_fns'] = fns
        cfg_df['cell_dynamic_styler_fns'] = [self._column_styles_fn_caller]

    @staticmethod
    def _cell_style_cb(key_1, key_2, params, cell_info):
        # key_1 - name of the css property
        # key_2 - name of the param
        d                       = {}
        row_idx, col_idx        = cell_info['row_idx'], cell_info['col_idx']
        start_row, end_row, \
        start_col, end_col  = _resolve_idx_range(params, cell_info)
        if start_col <= col_idx <= end_col and start_row <= row_idx <= end_row:
            d[key_1] = params[key_2]
        return d

    @staticmethod
    def _cell_padding_cb(params, cell_info):
        side_map = {'t': 'top', 'b': 'bottom', 'l': 'left', 'r': 'right'}
        d                = {}
        row_idx, col_idx = cell_info['row_idx'], cell_info['col_idx']
        start_row, end_row, start_col, end_col = _resolve_idx_range(params, cell_info)
        if start_col <= col_idx <= end_col and start_row <= row_idx <= end_row:
            sides = params['sides'] or side_map.keys()
            for side in sides:
                d['padding_%s' % side_map[side]] = params['length']
        return d

    @staticmethod
    def _cell_font_cb(params, cell_info):
        d                   = {}
        row_idx, col_idx    = cell_info['row_idx'], cell_info['col_idx']
        start_row, end_row, start_col, end_col = _resolve_idx_range(params, cell_info)
        if start_col <= col_idx <= end_col and start_row <= row_idx <= end_row:
            if params['font_family']:
                d['font_family'] = params['font_family']
            if params['font_size']:
                d['font_size'] = params['font_size']
            if params['font_weight']:
                d['font_weight'] = params['font_weight']
            if params['font_style']:
                d['font_style'] = params['font_style']
        return d

    @staticmethod
    def _cell_bg_cb(params, cell_info):
        d                       = {}
        row_idx, col_idx        = cell_info['row_idx'], cell_info['col_idx']
        start_row, end_row, \
        start_col, end_col  = _resolve_idx_range(params, cell_info)
        colors                  = params['colors']
        if start_col <= col_idx <= end_col and start_row <= row_idx <= end_row:
            d['background'] = colors[(row_idx - start_row) % len(colors)]   # cycle color by rows
        return d

    @staticmethod
    def _cell_width_cb(params, cell_info):
        if cell_info.get('col_name') in params['col_names']:
            return {'width': params['width']}

    @staticmethod
    def _cell_border_cb(params, cell_info):
        d                       = {}
        val                     = "%s %s %s" % (params['thickness'], 'solid', params['color'])
        row_idx, col_idx        = cell_info['row_idx'], cell_info['col_idx']
        mechanism               = params['mechanism']
        start_row, end_row, \
        start_col, end_col  = _resolve_idx_range(params, cell_info)

        if mechanism == BorderMechanism.BOX:
            if row_idx == start_row and start_col <= col_idx <= end_col:
                d['border_top'] = val
            if col_idx == start_col and start_row <= row_idx <= end_row:
                d['border_left'] = val
            if col_idx in [end_col, start_col - 1] and start_row <= row_idx <= end_row:
                d['border_right'] = val
            if row_idx in [end_row, start_row - 1] and start_col <= col_idx <= end_col:
                d['border_bottom'] = val

        if mechanism in [BorderMechanism.TOP, BorderMechanism.GRID]:
            if start_row <= row_idx <= end_row and start_col <= col_idx <= end_col:
                d['border_top'] = val
            if start_row - 1 <= row_idx <= end_row - 1 and start_col <= col_idx <= end_col:
                d['border_bottom'] = val

        if mechanism in [BorderMechanism.BOTTOM, BorderMechanism.GRID, BorderMechanism.INNER_GRID]:
            if start_row <= row_idx <= end_row and start_col <= col_idx <= end_col:
                if not (row_idx == end_row and mechanism == BorderMechanism.INNER_GRID):  # except last row
                    d['border_bottom'] = val

        if mechanism in [BorderMechanism.RIGHT, BorderMechanism.GRID, BorderMechanism.INNER_GRID]:
            if start_row <= row_idx <= end_row and start_col <= col_idx <= end_col:
                if not (col_idx == end_col and mechanism == BorderMechanism.INNER_GRID):
                    d['border_right'] = val

        if mechanism in [BorderMechanism.LEFT, BorderMechanism.GRID]:
            if start_row <= row_idx <= end_row and start_col <= col_idx <= end_col:
                d['border_left'] = val
            if start_row <= row_idx <= end_row and start_col - 1 <= col_idx <= end_col - 1:
                d['border_right'] = val

        return d