from core.reporting.enum import TableSection
from core.reporting.prettytable.utils import _normalize_idx_range


def _resolve_idx_range(params, cell_info):
    """ cell_info - a dictionary containing hdr row counts, df row counts and column counts """
    section                 = params.get('section', TableSection.ALL)
    hdr_row_count           = cell_info.get('hdr_row_count') or 0
    df_row_count            = cell_info['df_row_count']

    start_col, end_col      = params['start_col'], params['end_col']
    start_col, end_col, _   = slice(start_col, end_col).indices(len(cell_info['row']))

    start_row, end_row      = params['start_row'], params['end_row']
    start_row, end_row      = _normalize_idx_range(section, start_row, end_row, hdr_row_count, df_row_count)
    start_row, end_row, _   = slice(start_row, end_row).indices(hdr_row_count + df_row_count)

    return start_row, end_row, start_col, end_col


class PrettyTableOutputGenerator(object):

    def __init__(self, pt):
        self.pt = pt

    def _len_headers(self, cfg_df):
        no_of_hdrs = 0
        if self._is_show_header(cfg_df):
            no_of_hdrs += 1
        no_of_hdrs += len(self._get_extra_header_rows(cfg_df))
        return no_of_hdrs

    @staticmethod
    def _is_show_header(cfg_df):
        return cfg_df.get('show_headers', True)

    @staticmethod
    def _get_extra_header_rows(cfg_df):
        return cfg_df.get('extra_header_rows') or []

    @staticmethod
    def _get_col_order(df, cfg_df):
        columns   = list(df.columns)
        col_order = cfg_df.get('column_order')
        idx_name  = cfg_df.get('index_name', df.index.name) or ''
        inc_idx   = cfg_df.get('inc_idx', False)
        if col_order is None:
            col_order = (([idx_name] + columns) if inc_idx else columns)
        return col_order

    @staticmethod
    def _get_col_by_name( df, cfg_df, col_name):
        idx_name  = cfg_df.get('index_name', df.index.name) or ''
        return df.index if col_name == idx_name else df[col_name]

    def _resolve_idx_range(self, df, cfg_df, attrs, neg_idx=False):
        len_hdr            = self._len_headers(cfg_df)
        start_col, end_col = attrs['start_col'], attrs['end_col']
        start_row, end_row = attrs['start_row'], attrs['end_row']
        start_row, end_row = _normalize_idx_range(attrs['section'], start_row, end_row, len_hdr, len(df))
        if not neg_idx:
            start_row, end_row, _   = slice(start_row, end_row).indices(len_hdr + len(df))
        return start_row, end_row, start_col, end_col
