import cStringIO as StringIO
from functools import partial
from itertools import izip

import six
import xhtml2pdf.default
from reportlab.platypus.paraparser import tt2ps
from xhtml2pdf.util import memoized

from core.chart.table import format_value
from core.reporting.common.elems import AdaptablePimReportElem, RawParaRML
from core.reporting.enum import TableSection
from core.reporting.simple_email import HTMLTableRow, HTMLTableCell, ReportMessageElement


def _normalize_idx_range(section, start, end, hdr_count, body_count):
    if section == TableSection.BODY:
        if start >= 0:
            start += hdr_count
        if end >= 0:
            end += hdr_count
    elif section == TableSection.HDR:
        if start < 0:
            start -= body_count
        if end < 0:
            end -= body_count
    return start, end


def df_to_rml_rows(df, inc_idx=False, idx_name=None, col_order=None, formatter=None, attributor=[],
                   extra_header_rows=[], custom_headers={}, show_headers=True, mode='RML'):

    columns         = list(df.columns)
    if col_order is None:
        col_order = (([idx_name] + columns) if inc_idx else columns)
    headers         = col_order
    formatter       = formatter or dict()
    formatter       = [formatter.get(x) for x in headers]
    hdr_rows        = []
    data_rows       = []
    hdr_row_cnt     = 0
    data            = izip(*[(df.index if inc_idx and x == idx_name else df[x]) for x in col_order])
    data            = list(data)

    if show_headers:
        hdr_row_cnt = len(extra_header_rows) + 1
        i = 0
        for i, extra_hdr_row in enumerate(extra_header_rows):
            extra_hdr_row = [x if isinstance(x, (list, tuple)) else (x, 1) for x in extra_hdr_row]
            cells = []
            next_col_idx = 0    # the actual index of the header col. without the spanning
            for j, (h, col_span) in enumerate(extra_hdr_row):
                cell_info = {'row_idx': i, 'col_idx': j, 'row': extra_hdr_row, 'val': h, 'is_hdr': True,
                             'hdr_row_count': hdr_row_cnt, 'df_row_count': len(data), 'val_f': h,
                             'span_col_names': [headers[x] for x in xrange(next_col_idx, next_col_idx + col_span)]}
                attributes = _gen_attrs(attributor, cell_info)
                h = ReportMessageElement('para', h, **attributes.get('para', {}))
                cells.append(HTMLTableCell(h, **attributes.get('td', {})))
                map(cells.append, [HTMLTableCell(None) for _ in range(col_span - 1)])
                next_col_idx += col_span

            hdr_rows.append(HTMLTableRow(cells))
        if extra_header_rows:
            i += 1

        cells = []
        for j, h in enumerate(headers):
            h_elem, h_ren = _get_custom_hdr(h, custom_headers)
            cell_info = {'row_idx': i, 'col_idx': j, 'row': headers, 'val': h, 'is_hdr': True,
                         'hdr_row_count': hdr_row_cnt, 'df_row_count': len(data), 'col_name': h,
                         'val_f': h_ren}
            attributes = _gen_attrs(attributor, cell_info)
            h = ReportMessageElement('para', h_elem, **attributes.get('para', {}))
            cells.append(HTMLTableCell(h, **attributes.get('td', {})))
        hdr_rows.append(HTMLTableRow(cells))

    for i, r in enumerate(data):
        cells = []
        row_idx = len(hdr_rows) + i
        data_row_idx = i
        for j, v in enumerate(r):
            v_formatted = _format_value(v, formatter[j], r, j, data_row_idx, df, mode=mode)
            cell_info = {'row_idx': row_idx, 'col_idx': j, 'row': r, 'val': v, 'col_name': headers[j],
                         'hdr_row_count': hdr_row_cnt, 'df_row_count': len(data), 'val_f': v_formatted}
            attributes = _gen_attrs(attributor, cell_info)
            if isinstance(v_formatted, ReportMessageElement) and not isinstance(v_formatted, RawParaRML):
                c = v_formatted
            else:
                c = ReportMessageElement('para', v_formatted, **attributes.get('para', {}))
            cells.append(HTMLTableCell(c, **attributes.get('td', {})))
        data_rows.append(HTMLTableRow(cells))
    return hdr_rows + data_rows


def _gen_attrs(attributor, cell_info):
    attrs = {}
    x_list = attributor or []
    if x_list:
        x_list = x_list if isinstance(x_list, (list, tuple)) else [x_list]
    for x in x_list:
        if callable(x):
            x = x(cell_info)
        if x:
            attrs.update(x)
    return attrs


def _get_custom_hdr(h, custom_headers):
    h_elem = custom_headers.get(h, h)
    h_ren = h_elem
    if isinstance(h_elem, ReportMessageElement):
        buf = StringIO.StringIO()
        h_elem.render(buf, None, {})
        h_ren = buf.getvalue()
    return h_elem, h_ren


def _format_value(val, formatter, row, col_idx, row_idx, df, mode):
    new_formatter = formatter
    if callable(new_formatter):
        new_formatter = partial(formatter, row_idx=row_idx, df=df)
    return_val = format_value(val, new_formatter, row, col_idx)
    if isinstance(return_val, AdaptablePimReportElem):
        return return_val.as_report_element(mode)
    return return_val


def df_to_html_rows(df, inc_idx=False, idx_name=None, col_order=None, formatter=None, attributor=[],
                    extra_header_rows=[], custom_headers={}, show_headers=True, mode='HTML'):

    columns     = list(df.columns)
    if col_order is None:
        col_order = (([idx_name] + columns) if inc_idx else columns)
    headers     = col_order
    formatter   = formatter or dict()
    formatter   = [formatter.get(x) for x in headers]
    hdr_rows    = []
    data_rows   = []
    hdr_row_cnt = 0
    data        = izip(*[(df.index if inc_idx and x == idx_name else df[x]) for x in col_order])
    data        = list(data)

    if show_headers:
        hdr_row_cnt = len(extra_header_rows) + 1
        i = 0
        for i, extra_hdr_row in enumerate(extra_header_rows):
            extra_hdr_row = [x if isinstance(x, (list, tuple)) else (x, 1) for x in extra_hdr_row]
            cells = []
            for j, (h, col_span) in enumerate(extra_hdr_row):
                cell_info = {'row_idx': i, 'col_idx': j, 'row': extra_hdr_row, 'val': h, 'is_hdr': True,
                             'hdr_row_count': hdr_row_cnt, 'df_row_count': len(data)}
                cells.append(HTMLTableCell(h, colspan=col_span, **_gen_attrs(attributor, cell_info)))
            hdr_rows.append(HTMLTableRow(cells))
        if extra_header_rows:
            i += 1

        cells = []
        for j, h in enumerate(headers):
            h_elem, h_ren = _get_custom_hdr(h, custom_headers)
            cell_info = {'row_idx': i, 'col_idx': j, 'row': headers, 'val': h, 'is_hdr': True,
                         'hdr_row_count': hdr_row_cnt, 'df_row_count': len(data), 'col_name': h}
            cells.append(HTMLTableCell(h_elem, **_gen_attrs(attributor, cell_info)))
        hdr_rows.append(HTMLTableRow(cells))

    for i, r in enumerate(data):
        cells = []
        row_idx = len(hdr_rows) + i
        data_row_idx = i
        for j, v in enumerate(r):
            v_formatted = _format_value(v, formatter[j], r, j, data_row_idx, df, mode=mode)
            cell_info = {'row_idx': row_idx, 'col_idx': j, 'row': r, 'val': v, 'col_name': headers[j],
                         'hdr_row_count': hdr_row_cnt, 'df_row_count': len(data)}
            cells.append(HTMLTableCell(v_formatted, **_gen_attrs(attributor, cell_info)))
        data_rows.append(HTMLTableRow(cells))
    return hdr_rows + data_rows


@memoized
def html_to_bold_italic(font_weight, font_style):
    b = font_weight and font_weight.lower() in ("bold", "bolder", "500", "600", "700", "800", "900")
    i = font_style and font_style.lower() in ("italic", "oblique")
    return b, i


@memoized
def html_to_pdf_font_name(names, font_weight, font_style, default="helvetica"):
    """
    convert a CSS font-family value to a valid PDF font name
    """
    font_list = xhtml2pdf.default.DEFAULT_FONT
    fn = font_list.get(default, None)
    if type(names) is not list:
        if type(names) not in six.string_types:
            names = str(names)
        names = names.strip().split(",")
    for name in names:
        if type(name) not in six.string_types:
            name = str(name)
        font = font_list.get(name.strip().lower(), None)
        if font is not None:
            fn = font
            break
    b, i = html_to_bold_italic(font_weight, font_style)
    return tt2ps(fn, b, i)


def df_to_xlsx(df, ws, idx_start=(2,2), inc_idx=False, idx_name=None, col_order=None,
               cell_cb=None, extra_header_rows=[], custom_headers={}, show_headers=True):

    columns         = list(df.columns)
    if col_order is None:
        col_order = (([idx_name] + columns) if inc_idx else columns)
    headers         = col_order
    data            = izip(*[(df.index if inc_idx and x == idx_name else df[x]) for x in col_order])
    data            = list(data)
    x_start, y_start= idx_start     # excel start index
    x_idx, y_idx    = idx_start     # track current excel cell index
    cell_cb_fn      = lambda *args: cell_cb and cell_cb(*args)
    hdr_row_cnt     = 0

    if show_headers:
        hdr_row_cnt = len(extra_header_rows) + 1
        for i, extra_hdr_row in enumerate(extra_header_rows):
            y_idx = y_start
            extra_hdr_row = [x if isinstance(x, (list, tuple)) else (x, 1) for x in extra_hdr_row]
            for j, (h, col_span) in enumerate(extra_hdr_row):
                cell_info = {'row_idx'          : x_idx - x_start,
                             'col_idx'          : y_idx - y_start,
                             'row'              : [ic for c, cs in extra_hdr_row for ic in [c] + [''] * (cs - 1)],
                             'val'              : h,
                             'is_hdr'           : True,
                             'hdr_row_count'    : hdr_row_cnt,
                             'df_row_count'     : len(data)}
                c = ws.cell(column = y_idx, row = x_idx, value = h)
                cell_cb_fn(c, cell_info)
                if col_span > 1:
                    for z in range(cell_info['col_idx'] + 1, cell_info['col_idx'] + col_span):
                        cell_info.update({'col_idx': z, 'val': ''})
                        cell_cb_fn(ws.cell(column = y_start + z, row = x_idx), cell_info)
                y_idx += col_span
            x_idx += 1

        for j, h in enumerate(headers):
            cell_info = {'row_idx': x_idx - x_start, 'col_idx': j, 'row': headers, 'val': h, 'is_hdr': True,
                         'hdr_row_count': hdr_row_cnt, 'df_row_count': len(data), 'col_name': h}
            h_elem, h_ren = _get_custom_hdr(h, custom_headers)
            c = ws.cell(column = y_start + j, row = x_idx, value = h_ren)
            cell_cb_fn(c, cell_info)
        x_idx += 1

    for i, r in enumerate(data):
        for j, v in enumerate(r):
            cell_info = {'row_idx': x_idx - x_start, 'col_idx': j, 'row': r, 'val': v, 'col_name': headers[j],
                         'hdr_row_count': hdr_row_cnt, 'df_row_count': len(data)}
            c = ws.cell(column = y_start + j, row = x_idx, value = v)
            cell_cb_fn(c, cell_info)
        x_idx += 1
