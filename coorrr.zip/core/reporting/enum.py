
class BorderMechanism(object):
    GRID = 1
    INNER_GRID = 2
    BOX = 3
    TOP = 4
    RIGHT = 5
    BOTTOM = 6
    LEFT = 7

    @classmethod
    def get_rml_kind(cls, x):
        d = {cls.GRID: 'grid', cls.INNER_GRID: 'innergrid', cls.BOX: 'box',
             cls.TOP: 'lineabove', cls.RIGHT: 'lineafter', cls.BOTTOM: 'linebelow', cls.LEFT: 'linebefore'}
        return d.get(x, 'box')


class TableSection(object):
    ALL = 1
    HDR = 2
    BODY = 3