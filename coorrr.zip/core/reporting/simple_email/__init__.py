import cStringIO as StringIO
import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.mime.application import MIMEApplication
from core.common.util import extract_params
import cgi
import os
import collections
from core.common import util
from core.io import files
import functools
import six
import uuid
import time

__all__ = ['H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'XLTitle', 'LargeTitle', 'Title', 'Subtitle', 'SmallSubtitle',
           'XSSubtitle',
           'Image', 'Para', 'PageBreak', 'LayoutElement', 'TableLayout',
           'create_report_message', 'create_report_page', 'create_report_pdf', 'html_to_pdf']

BLANK = 0
SAME_AS_LEFT = 1
SAME_AS_ABOVE = 3


class BorderStyle(object):
    def __init__(self, width=None, color=None, line_style=None, radius=None, border_left=None, border_right=None,
                 border_top=None, border_bottom=None):
        self.width = width
        self.color = color
        self.line_style = line_style
        self.border_left = border_left
        self.border_right = border_right
        self.border_top = border_top
        self.border_bottom = border_bottom
        self.radius = radius

    def as_css_props(self, props=None):
        props = props or dict()

        self.__dump_props('border', props, self)
        self.__dump_props('border-left', props, self.border_left)
        self.__dump_props('border-right', props, self.border_right)
        self.__dump_props('border-bottom', props, self.border_bottom)
        self.__dump_props('border-top', props, self.border_top)

        return props

    def __dump_props(self, prefix, prop_dict, obj):
        if obj is not None:
            if isinstance(obj, basestring):
                prop_dict['prefix'] = obj
                return

            str_ = ''
            if isinstance(obj.width, basestring) and obj.line_style is None and obj.color is None:
                str_ = obj.width
            else:
                if obj.line_style is not None:
                    str_ += (' ' if str_ else '') + str(obj.line_style)

                if obj.color is not None:
                    str_ += (' ' if str_ else '') + str(obj.color)

                if obj.width is not None:
                    str_ += (' ' if str_ else '') + str(obj.width)

            if str_:
                prop_dict[prefix] = str_

            if obj.radius is not None:
                prop_dict[prefix + '-radius'] = obj.width


class Style(object):
    @util.explicit_param_checker
    def __init__(self, width=None, height=None, text_align=None, padding=None, margin=None, background=None, color=None,
                 font_weight=None, font_family=None, font_size=None, border=None, force_width=False, **kwargs):
        self.params = kwargs.pop('__explicit_params', dict())
        del self.params['__explicit_params']

        if 'force_width' in self.params:
            force_width = self.params.get('force_width')
            if force_width and 'width' in self.params:
                self.params['min_width'] = self.params['width']
                self.params['max_width'] = self.params['width']

    def as_css_props(self):
        prop_dict = dict()
        for k, v in self.params.iteritems():
            if k == 'force_width':
                continue

            if v is None:
                continue
            k = k.replace('_', '-')
            if isinstance(v, BorderStyle):
                v.as_css_props(prop_dict)
            elif isinstance(v, (list, tuple)):
                prop_dict[k] = ' '.join(str(x) for x in v)
            else:
                prop_dict[k] = v
        return prop_dict

    @staticmethod
    def as_css_string(css_prop_dict):

        return ';'.join(('%s: %s' % (k, v)) for k, v in css_prop_dict.iteritems())

    @staticmethod
    @util.explicit_param_checker
    def update_style(base_style, width=None, height=None, text_align=None, padding=None, margin=None, background=None,
                     color=None,
                     font_weight=None, font_family=None, font_size=None, border=None, force_width=False, **kwargs):
        if base_style is None:
            base_style = Style()

        style = Style()
        style.params = dict(base_style.params)

        params = kwargs.pop('__explicit_params', dict())
        del params['__explicit_params']

        style.params.update(params)

        force_width = style.params.get('force_width')
        if force_width and 'width' in style.params:
            style.params['min_width'] = style.params['width']
            style.params['max_width'] = style.params['width']
        return style

    def __add__(self, other):
        s = Style(**self.params)
        s.params.update(dict(other.params))
        return s

class ReportMessageElement(object):
    def __init__(self, tag, *sub_elements, **attributes):
        '''
        Creates new HTML element

        :param tag: HTML tag
        :param sub_elements: Child elements
        :param attributes: HTML Attributes
        :Keyword Arguments:
            * *css_class* -- CSS Class
            * *closing_tag* -- Emit Closing tag
        '''
        self.tag = tag
        self.css_class = attributes.pop('css_class', None)
        self.closing_tag = attributes.pop('closing_tag', True)
        self.children_only = attributes.pop('children_only', False)
        self.elements = sub_elements

        self.attributes = attributes or {}
        if self.css_class:
            self.attributes['class'] = self.css_class

    def render(self, buf, msg_root, temp_state):

        if self.children_only:
            self.render_children(buf, msg_root, temp_state)
            return

        buf.write("<")
        buf.write(self.tag)

        for name, val in self.attributes.iteritems():
            if val is not None:
                buf.write(" ")
                buf.write(name)
                buf.write('=')

                buf.write('"')
                if isinstance(val, Style):
                    buf.write(Style.as_css_string(val.as_css_props()))
                else:
                    buf.write(cgi.escape(str(val)))
                buf.write('"')
        if self.closing_tag:
            buf.write(">")
            self.render_children(buf, msg_root, temp_state)
            buf.write("</")
            buf.write(self.tag)
            buf.write(">")
        else:
            buf.write(" />")

    def render_children(self, buf, msg_root, temp_state):
        for e in self.elements:
            if e is None:
                continue
            if isinstance(e, ReportMessageElement):
                e.render(buf, msg_root, temp_state)
            else:
                buf.write(cgi.escape(e))

class RawHTML(ReportMessageElement):
    def __init__(self, html, **kwargs):
        super(RawHTML, self).__init__('span', **kwargs)
        self.html = html

    def render(self, buf, msg_root, temp_state):
        buf.write(self.html)


class UnicodeHex(ReportMessageElement):
    def __init__(self, unicode_val):
        super(UnicodeHex, self).__init__('span')
        self.unicode_val = unicode_val

    def render(self, buf, msg_root, temp_state):
        buf.write('&#x%04x;' % self.unicode_val)


class Span(ReportMessageElement):
    def __init__(self, *sub_elements, **attributes):
        super(Span, self).__init__('span', *sub_elements, **attributes)


class H1(ReportMessageElement):
    def __init__(self, *sub_elements, **attributes):
        super(H1, self).__init__('H1', *sub_elements, **attributes)


class H2(ReportMessageElement):
    def __init__(self, *sub_elements, **attributes):
        super(H2, self).__init__('H2', *sub_elements, **attributes)


class H3(ReportMessageElement):
    def __init__(self, *sub_elements, **attributes):
        super(H3, self).__init__('H3', *sub_elements, **attributes)


class H4(ReportMessageElement):
    def __init__(self, *sub_elements, **attributes):
        super(H4, self).__init__('H4', *sub_elements, **attributes)


class H5(ReportMessageElement):
    def __init__(self, *sub_elements, **attributes):
        super(H5, self).__init__('H5', *sub_elements, **attributes)


class H6(ReportMessageElement):
    def __init__(self, *sub_elements, **attributes):
        super(H6, self).__init__('H1', *sub_elements, **attributes)


class Para(ReportMessageElement):
    def __init__(self, *sub_elements, **attributes):
        super(Para, self).__init__('p', *sub_elements, **attributes)


class _Body(ReportMessageElement):
    def __init__(self, *sub_elements):
        super(_Body, self).__init__('body', *sub_elements)


class _Style(ReportMessageElement):
    def __init__(self, stylesheets):
        super(_Style, self).__init__('style')
        self.stylesheets = '\n'.join(stylesheets) if isinstance(stylesheets, (list, tuple)) else str(stylesheets)

    def render(self, buf, msg_root, temp_state):
        buf.write("<style>\n")
        buf.write(self.stylesheets)
        buf.write("\n</style>\n")


class _Head(ReportMessageElement):
    def __init__(self, *subelements):
        super(_Head, self).__init__('head', *subelements)


class _Meta(ReportMessageElement):
    def __init__(self, **attributes):
        super(_Meta, self).__init__('meta', closing_tag=False, **attributes)


class _Html(ReportMessageElement):
    def __init__(self, *sub_elements, **attributes):
        stylesheets = attributes.pop('stylesheets', [])
        if stylesheets:
            sub_elements = (_Style(stylesheets),) + sub_elements

        super(_Html, self).__init__('html', _Head(_Meta(**{'X-UA-Compatible': 'IE=11'})), *sub_elements)


XLTitle = H1
LargeTitle = H2
Title = H3
Subtitle = H4
SmallSubtitle = H5
XSSubtitle = H6


class Image(ReportMessageElement):
    def __init__(self, image_file_path, **attributes):
        self.file_path = image_file_path
        super(Image, self).__init__('img', closing_tag=False, **attributes)

    def render(self, buf, msg_root, temp_state):
        if 'src' not in self.attributes:
            if msg_root is not None:
                if 'img_cache' not in temp_state:
                    temp_state['img_cache'] = {}
                img_cache = temp_state['img_cache']

                if self.file_path not in img_cache:
                    cid = 'image%d_%s' % (len(img_cache), str(uuid.uuid4()).split('-')[-1])
                    img_cache[self.file_path] = cid

                    if hasattr(self.file_path, 'read'):
                        self.file_path.seek(0)
                        contents = self.file_path.read()
                    else:
                        with open(self.file_path, 'rb') as fp:
                            contents = fp.read()

                    msg_image = MIMEImage(contents)
                    msg_image.add_header('Content-ID', '<' + cid + '>')
                    msg_image.add_header('Content-Disposition', 'inline')
                    msg_root.attach(msg_image)
                else:
                    cid = img_cache[self.file_path]

                self.attributes['src'] = 'cid:' + cid
            else:
                self.attributes['src'] = ('file:///' if util.isWindows() else 'file://') \
                                         + os.path.abspath(self.file_path).replace('\\', '/')

        super(Image, self).render(buf, msg_root, temp_state)


class _CoreChart(Image):
    def __init__(self, chart_func, chart_args, chart_kwargs, file_name_param_name):
        file_path = os.tempnam() + ".png"
        super(_CoreChart, self).__init__(file_path)

        chart_kwargs[file_name_param_name] = file_path
        self.chart_args = chart_args
        self.chart_kwargs = chart_kwargs
        self.chart_func = chart_func

    def get_png_size(self, path):
        import struct
        with open(path, "r+b") as input:
            data = input.read(25)
            w, h = struct.unpack(">LL", data[16:24])
            width = int(w)
            height = int(h)
            return width, height

    def render(self, buf, msg_root, temp_state):

        if 'px_width' in self.chart_kwargs and 'px_height' in self.chart_kwargs and msg_root is None:
            scale_factor = 3.0
            kwargs = dict(self.chart_kwargs)

            kwargs['px_height'] = kwargs['px_height'] * scale_factor
            kwargs['px_width'] = kwargs['px_width'] * scale_factor
            kwargs['dpi'] = kwargs.get('dpi', 100.0) * scale_factor

            fig = self.chart_func(*self.chart_args, **kwargs)
            w, h = self.get_png_size(self.file_path)
            w /= scale_factor
            h /= scale_factor
        else:
            fig = self.chart_func(*self.chart_args, **self.chart_kwargs)

            w, h = self.get_png_size(self.file_path)

        w = int(w)
        h = int(h)

        self.attributes['width'] = '%dpx' % w
        self.attributes['height'] = '%dpx' % h

        super(_CoreChart, self).render(buf, msg_root, temp_state)


def __del__(self):
    try:
        import os
        os.unlink(self.file_path)
    except:
        pass


class _LayoutRow(ReportMessageElement):
    def __init__(self, *cells, **attributes):
        super(_LayoutRow, self).__init__('tr', *cells, **attributes)


class _CenteredDiv(ReportMessageElement):
    def __init__(self, *content, **attributes):
        align = attributes.pop('align', 'center')
        margin = '0 auto' if align == 'center' else ('0 auto 0 0' if align == 'left' else '0 0 0 auto')
        margin = attributes.pop('margin', margin) or margin
        style = attributes.pop('style', Style())
        attributes['style'] = Style.update_style(style, display='table', margin=margin)
        super(_CenteredDiv, self).__init__('div', *content, **attributes)


class _Div(ReportMessageElement):
    def __init__(self, content, **attributes):
        super(_Div, self).__init__('div', content, **attributes)


class _LayoutCell(ReportMessageElement):
    def __init__(self, content, **attributes):
        super(_LayoutCell, self).__init__('td', _CenteredDiv(
            *(content if isinstance(content, collections.Sequence) else [content]),
            align=attributes.pop('align', 'center'),
            margin=attributes.pop('margin', None), style=attributes.pop('container_style', None)),
             **attributes)


class LayoutElement(object):
    def __init__(self, row, col, content, rowspan=None, colspan=None, **attributes):
        self.row = row
        self.rowspan = rowspan or 1
        self.col = col
        self.colspan = colspan or 1
        self.attributes = attributes
        self.content = content
        self.align = attributes.pop('align', 'center')
        self.margin = attributes.pop('margin', None)
        self.container_style = attributes.pop('container_style', None)


class TableLayout(ReportMessageElement):
    def __init__(self, *elements, **attributes):
        self.table_elements = elements
        min_row = min(x.row for x in elements)
        max_row = max((x.row + x.rowspan - 1) for x in elements)

        row_cnt = max_row - min_row + 1

        min_col = min(x.col for x in elements)
        max_col = max((x.col + x.colspan - 1) for x in elements)

        col_cnt = max_col - min_col + 1

        data = [[LayoutElement(0, 0, '')] * col_cnt for x in xrange(row_cnt)]

        for el in elements:
            k = 0
            while k < el.rowspan:
                l = 0
                while l < el.colspan:
                    data[el.row + k - min_row][el.col + l - min_col] = el if (k, l) == (0, 0) else None
                    l += 1
                k += 1

        # use col_widths if available
        col_widths = attributes.pop('col_widths', [])
        col_widths += [col_widths and col_widths[-1] or None] * (col_cnt - len(col_widths))
        col_widths = [str(_) for _ in col_widths]

        def _get_attrs(x):
            x_attrs = x.attributes
            try:    # try adding col width or just leave it
                if col_widths and x.col <= len(col_widths):
                    s = x_attrs.get('style', Style())
                    if isinstance(s, Style):
                        s += Style(width=col_widths[x.col - 1])
                        x_attrs['style'] = s
            except:
                pass
            return x_attrs


        table_class = attributes.pop('css_class', '')
        if table_class:
            table_class = 'pp-layout-table' + table_class
        else:
            table_class = 'pp-layout-table'

        cell_class = 'pp-layout-table-td'
        data = [_LayoutRow(
            *[_LayoutCell(x.content, colspan=x.colspan, rowspan=x.rowspan, css_class=cell_class, align=x.align,
                          margin=x.margin, container_style=x.container_style, **_get_attrs(x))
              for x in r if x is not None])
                for r in data]
        attributes['css_class'] = table_class
        super(TableLayout, self).__init__('table', *data, **attributes)


class RMLTableLayout(ReportMessageElement):

    def __init__(self, *elements, **attributes):
        rme      = ReportMessageElement
        min_row  = min(x.row for x in elements)
        max_row  = max((x.row + x.rowspan - 1) for x in elements)
        row_cnt  = max_row - min_row + 1
        elements = sorted(elements, key=lambda x: (x.col, x.row))
        data     = [[] for x in xrange(row_cnt)]
        style_elements = attributes.pop('style_elements', [])
        col_widths = attributes.pop('col_widths', [])
        for el in elements:
            if el.rowspan > 1 or el.colspan > 1:
                start_row, start_col = el.row - 1, len(data[el.row - 1])
                end_row, end_col = start_row + el.rowspan - 1, start_col + el.colspan - 1
                style_elements.append(rme('blockSpan', start='%s,%s' % (start_col, start_row),
                                          stop='%s,%s' % (end_col, end_row)))
            new_grid = [[None] * el.colspan for _ in range(el.rowspan)]
            new_grid[0][0] = el
            for i, x in enumerate(new_grid):
                data[el.row - 1 + i].extend(x)

        tbl_elems = []
        for r in data:
            cells = []
            for le in r:
                cell_contents, cell_attribs = [], {}
                if le:
                    cell_attribs = le.attributes
                    para_attribs = cell_attribs.pop('para', {})
                    if le.content:
                        cell_contents = [le.content]
                        if isinstance(le.content, six.string_types):
                            cell_contents = [rme('para', le.content, **para_attribs)]
                cells.append(rme('td', *cell_contents, **cell_attribs))
            col_cnt = len(cells)
            tbl_elems.append(rme('tr', *cells))

        col_widths += [col_widths and col_widths[-1] or None] * (col_cnt - len(col_widths))
        col_widths = [str(x) for x in col_widths]
        style_id = 's%s' % str(uuid.uuid4()).split('-')[-1]  # unique enough
        style_elements = [rme('blockTableStyle', *style_elements, id=style_id)]
        super(RMLTableLayout, self).__init__('blockTable', *(style_elements + tbl_elems),
                                             colWidths=','.join(col_widths), **attributes)


class PageBreak(ReportMessageElement):
    def __init__(self, is_visible=True):
        args = dict(closing_tag=False, css_class='pp-page-break')
        if not is_visible:
            args['style'] = Style(visibility='hidden')

        super(PageBreak, self).__init__('hr', **args)


class HorizontalLine(ReportMessageElement):
    def __init__(self,style=None):
        args = dict(closing_tag=False)
        if style is not None:
            args['style'] = style

        super(HorizontalLine, self).__init__('hr', **args)


class LineBreak(ReportMessageElement):
    def __init__(self):
        args = dict(closing_tag=False)

        super(LineBreak, self).__init__('br', **args)


class _THead(ReportMessageElement):
    def __init__(self, rows, **attributes):
        super(_THead, self).__init__('thead', *rows, **attributes)


class _TBody(ReportMessageElement):
    def __init__(self, rows, **attributes):
        super(_TBody, self).__init__('tbody', *rows, **attributes)


class HTMLTableCell(ReportMessageElement):
    def __init__(self, *subelements, **attributes):
        super(HTMLTableCell, self).__init__('td', *subelements, **attributes)


class HTMLTableHeader(ReportMessageElement):
    def __init__(self, *subelements, **attributes):
        super(HTMLTableHeader, self).__init__('th', *subelements, **attributes)


class HTMLTableRow(ReportMessageElement):
    def __init__(self, cells, **attributes):
        super(HTMLTableRow, self).__init__('tr', *cells, **attributes)


class HTMLTable(ReportMessageElement):
    def __init__(self, header=None, rows=None, **attributes):
        elements = []
        if header is not None:
            header = [header] if not isinstance(header, list) else header
            header = _THead(header)
            elements.append(header)
        body = _TBody(rows or [])
        elements.append(body)

        super(HTMLTable, self).__init__('table', *elements, **attributes)


def create_report_page(file_name, *message_elements, **kwargs):
    """
    Create report

    Keyword arguments:
    stylesheets -- stylesheets to add to a message
    """

    with open(file_name, "w+") as buf:
        stylesheets = kwargs.pop('stylesheets', [])
        state = {}
        html = _Html(_Body(*message_elements), stylesheets=stylesheets)
        html.render(buf, None, state)


def get_phantomjs_driver(service_log_path=None):
    import sys, getpass
    from selenium.webdriver import PhantomJS

    phjs_executable = 'phantomjs.exe' if util.isWindows() else 'phantomjs'
    phjs_path = os.path.join(os.path.dirname(sys.executable), phjs_executable)
    try:
        if not service_log_path and os.path.isdir('/usr/local/osmosix'):
            service_log_path = '/home/%s/ghostdriver.log' % getpass.getuser()
    except:
        pass
    return PhantomJS(executable_path=phjs_path, service_args=['--load-images=true'], service_log_path=service_log_path)


def html_to_pdf(pdf_file, html_file, paper_format='Letter', orientation='portrait', service_log_path=None):
    import os.path
    html_file = os.path.abspath(html_file).replace("\\", "/")
    driver = get_phantomjs_driver(service_log_path)
    try:
        driver.get(('file:///' if util.isWindows() else 'file://') + html_file)

        def execute(script, args):
            driver.execute('executePhantomScript', {'script': script, 'args': args})

        driver.command_executor._commands['executePhantomScript'] = ('POST', '/session/$sessionId/phantom/execute')

        page_format = '''this.paperSize = {format: "%s", orientation: "%s" };''' % (paper_format, orientation)
        execute(page_format, [])

        # render current page
        render = '''this.render("%s")''' % pdf_file.replace('\\', '/')

        time.sleep(2)
        execute(render, [])
    finally:
        driver.quit()


def html_to_png(png_file, html_file, window_size=(1024, 768), wait_math_jax=False):
    driver = get_phantomjs_driver()
    try:
        driver.get(('file:///' if util.isWindows() else 'file://') + html_file)
        driver.set_window_size(*window_size)

        attempts = 0
        while driver.execute_script('return document.readyState;') != 'complete' and attempts < 1000:
            time.sleep(0.5)
            attempts += 1

        if wait_math_jax:
            try:
                b = """MathJax.Hub.Register.StartupHook("Begin Typeset",function () {
                            $(document.body).append('<div id="helloDiv">helloDivText</div>');
                    });"""
                driver.execute_script(b)

                attempts = 0
                while driver.execute_script("return $('#helloDiv').text();") != 'helloDivText' and attempts < 100:
                    time.sleep(0.5)
                    attempts += 1
                driver.execute_script("$('#helloDiv').remove();")
            except:
                pass    # don't care

        driver.save_screenshot(png_file)
    finally:
        driver.quit()


def create_report_pdf(file_name, *message_elements, **kwargs):
    html_file = os.tempnam() + '.html'
    create_report_page(html_file, *message_elements, **kwargs)

    html_to_pdf(file_name, html_file, paper_format=kwargs.pop('paper_format', 'Letter'),
                orientation=kwargs.pop('orientation', 'portrait'))

    os.unlink(html_file)


def create_report_message(*message_elements, **kwargs):
    """
    Create report

    Keyword arguments:
    stylesheets -- stylesheets to add to a message
    """

    stylesheets = kwargs.pop('stylesheets', [])
    buf = StringIO.StringIO()
    state = {}
    msg_root = MIMEMultipart('related')
    msg_alt = MIMEMultipart('alternative')
    msg_root.preamble = 'This is a multi-part message in MIME format.'
    msg_root.attach(msg_alt)

    html = _Html(_Body(*message_elements), stylesheets=stylesheets)
    html.render(buf, msg_root, state)
    msg_alt.attach(MIMEText(buf.getvalue(), 'html'))

    attachments = kwargs.pop('attachments', [])

    for a in attachments:
        if isinstance(a, tuple):
            a, n = a
        else:
            a, n = a, a
        if os.path.isfile(a):
            data = files.readflat(a, 'r+b')
            att = MIMEApplication(data, Name=n)
            att['Content-Disposition'] = 'attachment; filename="%s"' % n
            msg_root.attach(att)

    return msg_root
