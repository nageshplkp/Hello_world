import os
import six

from openpyxl import Workbook, load_workbook
from openpyxl.utils import coordinate_to_tuple

from core.reporting.common.defaults import DefaultsConfig
from core.reporting.common.xl_abstract import XlExportable
from core.reporting.enum import BorderMechanism
from core.reporting.xl.utils import xl_color, xl_v_align, xl_apply_border, xl_apply_fg, \
    xl_apply_bg, xl_apply_font, xl_apply_align


class PimReportXlDefaults(object):
    """
    Global default values for PimReportXl
    """
    V_ALIGN = 'center'


class PimReportXlConfig(DefaultsConfig, PimReportXlDefaults):
    """
    Represents the default settings that can be applied on PimReportXl. The objects can be added together as well::

        cfg1 = PimReportXlConfig(V_ALIGN=6)
        cfg2 = PimReportXlConfig(HDR_FG='YELLOW')
        PimReportXl(cfg = cfg1 + cfg2)
    """
    pass


class PimReportXl(object):
    """
    Quickly design an Excel report in a pythonic fashion. Easily embed components such as PrettyTable,
    EasyLine, matplotlib figures etc in your report.

    In order to simplify the interface, this class keep tracks of the current cell (or call it the current position
    or a cursor) so that you can call functions such as merge and text without specifying which cell you are referring
    to. The "move" and "move_to" functions will allow you to move the current position to a different cell
    """

    def __init__(self, load_file=None, cfg=None):
        """
        Create a new instance of PimReportXl. Optionally pass an existing workbook so you can add new stuff to it

        :param load_file: Optional full path of the file to be loaded or an instance of "openpyxl.Workbook"
        """
        self._cfg = cfg or PimReportXlConfig()
        if isinstance(load_file, Workbook):
            self._c_wb = load_file
        elif load_file and os.path.exists(load_file):
            self._c_wb = load_workbook(filename=load_file)
        else:
            self._c_wb = Workbook()
        self._c_ws = self._c_wb.active
        self._c_cell = self._cell(1, 1)

    def _cell(self, row=None, column=None, ws=None):
        alignment_attrs = {}
        ws = ws or self._c_ws
        c = ws.cell(row=row, column=column)
        if not c.alignment.vertical:
            alignment_attrs['vertical'] = xl_v_align(self._cfg.V_ALIGN)
        if alignment_attrs:
            c.alignment = c.alignment.copy(**alignment_attrs)
        return c

    def gcws(self):
        """
        Returns the current worksheet object

        :return: Returns the current worksheet object

        """
        return self._c_ws

    def scws(self, sheet_name, start_row=None, start_col=None):
        """
        Sets the current worksheet

        :param sheet_name: the name of the worksheet
        """
        self._c_ws = self._c_wb[sheet_name]
        self._c_cell = self._cell(start_row or 1, start_col or 1)
        return self

    def gcc(self):
        """
        Returns the current cell object

        :return: Returns the current cell object

        """
        return self._c_cell

    def gcc_idx(self):
        """
        Returns the index (1 based) of the current cell

        :return: Returns a tuuple with the index (1 based) of the current cell --> (row, col)

        """
        c = self.gcc()
        return c.row, c.col_idx

    def gccol(self):
        """
        Returns the current column's index

        :return: Returns the current column's index

        """
        return self.gcc().col_idx

    def gcrow(self):
        """
        Returns the current row's index

        :return: Returns the current row's index

        """
        return self.gcc().row

    def _parse_pos(self, pos):
        if pos is None:
            return self.gcc_idx()
        if isinstance(pos, six.string_types):
            row, col = coordinate_to_tuple(pos)
        else:
            pos = [pos] if not isinstance(pos, (list, tuple)) else list(pos)
            if len(pos) <= 1:
                pos.append(self.gccol())
            row, col = pos[0], pos[1]
        return row, col

    def move(self, row_distance=0, col_distance=0):
        """
        Sets the current cell to the cell that is (row_distance, col_distance) away from the previous current cell.

        :param row_distance: The number of rows to move forward / backward
        :param col_distance: The number of columns to move forward / backward
        :return:
        """
        row, col = self.gcc_idx()
        row += row_distance
        col += col_distance
        row = row >= 1 and row or 1
        col = col >= 1 and col or 1
        self._c_cell = self._cell(row, col)
        return self

    def move_to(self, pos):
        """
        Sets the current cell to the given row and column. If either of it is None, the current cell's index
        will be used

        :param pos: The destination cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                    indexes. Row and column indexes start with 1.
        :return:
        """
        row, col = self._parse_pos(pos)
        self._c_cell = self._cell(row=row or self.gcrow(), column=col or self.gccol())
        return self

    def right(self, steps=1):
        """
        Move "steps" number of cells to the right to make that cell the current cell

        :param steps: The number of cells to move to the right
        """
        return self.move(0, steps)

    def left(self, steps=1):
        return self.move(0, steps * -1)

    def up(self, steps=1):
        return self.move(steps * -1, 0)

    def down(self, steps=1):
        return self.move(steps, 0)

    def merge(self, no_of_rows=1, no_of_cols=1, start_pos=None):
        """
        Merge cells. Specify the number of rows and cols to merge.

        :param no_of_rows: Number of row cells to merge
        :param no_of_cols: Number of col cells to merge
        :param start_pos: The destination cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                          indexes. Row and column indexes start with 1.
        :return:
        """
        start_row, start_col = self._parse_pos(start_pos)
        self.gcws().merge_cells(start_row=start_row, end_row=start_row+no_of_rows-1,
                                start_column=start_col, end_column=start_col+no_of_cols-1)
        return self

    def unmerge(self, no_of_rows=None, no_of_cols=None, start_pos=None):
        """
        Un-merge cells. Specify the number of rows and cols to un-merge. Fails if you try to un-merge cells
        that aren't merged in the first place.

        :param no_of_rows: Number of row cells to un-merge
        :param no_of_cols: Number of col cells to un-merge
        :param start_pos: The destination cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                          indexes. Row and column indexes start with 1.
        :return:
        """
        start_row, start_col = self._parse_pos(start_pos)
        self.gcws().unmerge_cells(start_row=start_row, end_row=start_row+no_of_rows-1,
                                  start_column=start_col, end_column=start_col+no_of_cols-1)
        return self

    def freeze(self, pos=None):
        """
        Freeze column or row headers

        :param pos: The position to freeze. Some examples below
                    'A2' - Freezes Row 1
                    'B1' - Freezes Column A
                    'C1' - Freezes Columns A and B
                    'C2' - Freezes Row 1 and columns A and B
                    'A1' or None - No frozen panes
                    You could also send in a tuple (row_index, column_index)
        """
        start_row, start_col = self._parse_pos(pos)
        self.gcws().freeze_panes = self.gcws().cell(row=start_row, column=start_col)
        return self

    def sheet_name(self, new_name=None, old_name=None, tab_color=None):
        """
        Change name of the sheets. Excel limits the names to be less than 31 characters wide

        :param new_name: New sheet name
        :param old_name: old sheet's name. optional. If not provided, will use the current sheet
        :param tab_color: Optional color for the tab
        """
        ws = old_name and self._c_wb.get_sheet_by_name(old_name) or self.gcws()
        ws.title = new_name
        if tab_color:
            ws.sheet_properties.tabColor = xl_color(tab_color)
        return self

    def remove_sheet(self, sheet_name=None):
        """
        Removes a given sheet or the current sheet.

        :param sheet_name: Optional. Name of the sheet to remove. Default is the current work sheet
        """
        if len(self._c_wb.get_sheet_names()) <= 1:
            raise Exception("Can't remove the only worksheet")
        ws = sheet_name and self._c_wb.get_sheet_by_name(sheet_name) or self.gcws()
        self._c_wb.remove_sheet(ws)
        return self.scws(self._c_wb.get_sheet_names()[-1])

    def add_sheet(self, sheet_name=None, insert_at=None, tab_color=None):
        """
        Add a new sheet

        :param sheet_name: Optional title of the new sheet
        :param insert_at: Optional position at which the sheet will be inserted
        :param tab_color: Optional color for the tab
        """
        ws = self._c_wb.create_sheet(sheet_name, insert_at)
        if tab_color:
            ws.sheet_properties.tabColor = xl_color(tab_color)
        return self.scws(ws.title)

    def inc(self, obj):
        if isinstance(obj, XlExportable):
            obj.to_xlsx(self._c_wb, sheet=self.gcws(), start_row=self.gcrow(), start_col=self.gccol(), save=False)
        else:
            raise Exception("Not implemented. Please email pypimcohelp for support")
        return self

    def set(self, val, pos=None):
        row, col = self._parse_pos(pos)
        c = self._cell(row, col)
        c.value = val
        return self

    def border(self, color=None, mechanism=BorderMechanism.BOX, start=None, end=None):
        """
        Sets the border of the specified region

        :param color: A hex value
        :param mechanism: See BorderMechanism
        :param start: The start cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                      indexes. Row and column indexes start with 1.
        :param end: The end cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                    indexes. Row and column indexes start with 1.
        """
        start_row, start_col    = self._parse_pos(start)
        end_row, end_col        = self._parse_pos(end)
        params = dict(start_row=start_row, start_col=start_col, end_row=end_row, end_col=end_col,
                      border_style='thin', color=color, mechanism=mechanism, cell_getter=self._cell)
        xl_apply_border(self.gcws(), params)
        return self

    def bg(self, color=None, start=None, end=None):
        """
        Sets the background color of the specified region

        :param color:  A hex value. It could be a list as well. If more than one color is specified, the colors will
                       by cycled by rows. For ex: for [red, blue, green], the first row will be red, second row will be
                       blue, and the third row will be green and the fourth row will be red and so on
        :param start: The start cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                      indexes. Row and column indexes start with 1.
        :param end: The end cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                    indexes. Row and column indexes start with 1.
        """
        start_row, start_col    = self._parse_pos(start)
        end_row, end_col        = self._parse_pos(end)
        colors                  = color if isinstance(list, tuple) else [color]
        params = dict(start_row=start_row, start_col=start_col, end_row=end_row, end_col=end_col,
                      colors=colors, cell_getter=self._cell)
        xl_apply_bg(self.gcws(), params)
        return self

    def fg(self, color=None, start=None, end=None):
        """
        Sets the background color of the specified region

        :param color:  A hex value.
        :param start: The start cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                      indexes. Row and column indexes start with 1.
        :param end: The end cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                    indexes. Row and column indexes start with 1.
        """
        start_row, start_col    = self._parse_pos(start)
        end_row, end_col        = self._parse_pos(end)
        params = dict(start_row=start_row, start_col=start_col, end_row=end_row, end_col=end_col,
                      color=color, cell_getter=self._cell)
        xl_apply_fg(self.gcws(), params)
        return self

    def font(self, family=None, font_size=None, bold=None, italic=None, start=None, end=None):
        """
        Sets the font for the specified region

        :param family: font family
        :param font_size: font size in pixels or points
        :param bold: True or False
        :param italic: True or False
        :param start: The start cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                      indexes. Row and column indexes start with 1.
        :param end: The end cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                    indexes. Row and column indexes start with 1.
        """
        start_row, start_col    = self._parse_pos(start)
        end_row, end_col        = self._parse_pos(end)
        params = dict(start_row=start_row, start_col=start_col, end_row=end_row, end_col=end_col,
                      font_family=family, font_size=font_size, bold=bold, italic=italic, cell_getter=self._cell)
        xl_apply_font(self.gcws(), params)
        return self

    def align(self, align=None, start=None, end=None):
        """
        Sets the horizontal alignment for the text in the specified region

        :param align:  'right', 'center', 'centerContinuous', 'distributed', 'general', 'left', 'justify', 'fill'
        :param start: The start cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                      indexes. Row and column indexes start with 1.
        :param end: The end cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                    indexes. Row and column indexes start with 1.
        """
        start_row, start_col    = self._parse_pos(start)
        end_row, end_col        = self._parse_pos(end)
        params = dict(start_row=start_row, start_col=start_col, end_row=end_row, end_col=end_col,
                      h_align=align, cell_getter=self._cell)
        xl_apply_align(self.gcws(), params)
        return self

    def valign(self, align=None, start=None, end=None):
        """
        Sets the vertical alignment for the text in the specified region

        :param align:  'top', 'justify', 'distributed', 'center', 'bottom'
        :param start: The start cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                      indexes. Row and column indexes start with 1.
        :param end: The end cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                    indexes. Row and column indexes start with 1.
        """
        start_row, start_col    = self._parse_pos(start)
        end_row, end_col        = self._parse_pos(end)
        params = dict(start_row=start_row, start_col=start_col, end_row=end_row, end_col=end_col,
                      v_align=align, cell_getter=self._cell)
        xl_apply_align(self.gcws(), params)
        return self

    def txt_wrap(self, wrap=None, start=None, end=None):
        """
        Sets the text wrap for the text in the specified region

        :param wrap:  True or False
        :param start: The start cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                      indexes. Row and column indexes start with 1.
        :param end: The end cell address. Can be a cell name "A2", "C10" etc. Or can be a tuple for (row, col)
                    indexes. Row and column indexes start with 1.
        """
        start_row, start_col    = self._parse_pos(start)
        end_row, end_col        = self._parse_pos(end)
        params = dict(start_row=start_row, start_col=start_col, end_row=end_row, end_col=end_col,
                      wrap_text=wrap, cell_getter=self._cell)
        xl_apply_align(self.gcws(), params)
        return self

    def grid(self, elements, size=None, x_co=None, y_co=None):
        if not size:
            raise Exception('Please specify grid size')
        rows, cols = size
        if not isinstance(elements[0], (list, tuple)):  # convert to 2 d list
            elements = [elements[i:i+cols] for i in range(0, len(elements), cols)]
        if not (x_co and len(x_co) == rows):
            raise Exception('Please specify x co-ordinates for the grid')
        if not (y_co and len(y_co) == cols):
            raise Exception('Please specify y co-ordinates for the grid')
        x_co = [self._parse_pos(_)[0] for _ in x_co]
        y_co = [self._parse_pos(_)[1] for _ in y_co]
        for i, row_elements in enumerate(elements):
            for j, e in enumerate(row_elements):
                if not isinstance(e, XlExportable):
                    raise Exception('Unsupported element')
                e.to_xlsx(self._c_wb, sheet=self.gcws(), start_row=x_co[i], start_col=y_co[j], save=False)
        return self

    def save(self, filename):
        self._c_wb.save(filename)
