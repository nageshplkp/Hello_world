import traceback

__all__ = [
    'DispatchPath',
    'DispatchKWArgsCallError',
    'DispatchException',
    'DispatchPathInvalidArgsError',
    'DispatchProxy'
]


class DispatchKWArgsCallError(Exception):
    def __str__(self):
        return "%s: DispatchProxy doesn't support calls with keyword args" % (self.__class__.__name__,)


class DispatchPathInvalidArgsError(Exception):
    def __init__(self, action, expected, got):
        super(DispatchPathInvalidArgsError, self).__init__(
            '%s: %s action expected %d args but got %d' % (self.__class__.__name__, action, expected, got))


class DispatchCallNotPrecededByGet(Exception):
    def __init__(self):
        super(DispatchCallNotPrecededByGet, self).__init__(
            '%s: Calls must be parented to GET paths' % (self.__class__.__name__,))


class DispatchException(object):
    def __init__(self, type_, value, tb):
        self.type = str(type_)
        self.value = str(value)
        if isinstance(tb, (str, unicode)):
            self.tb = tb
        else:
            try:
                self.tb = '\n'.join(traceback.format_tb(tb))
            except:
                self.tb = str(tb)

    def __str__(self):
        return "%s: %s\n%s" % (self.type, self.value, self.tb)


class DispatchPath(object):
    DISPATCH_GET = 0
    DISPATCH_CALL = 2
    DISPATCH_GETITEM = 3

    __slots__ = ['parent_dispatch', 'action', 'args']

    def __init__(self, parent_dispatch, action, *args, **kwargs):

        assert (parent_dispatch is None) or isinstance(parent_dispatch, DispatchPath)
        self.parent_dispatch = parent_dispatch
        self.action = action
        self.args = args

        if action == DispatchPath.DISPATCH_GET:
            if len(args) != 1:
                raise DispatchPathInvalidArgsError(action, 1, len(args))
        elif action == DispatchPath.DISPATCH_GETITEM:
            if len(args) != 1:
                raise DispatchPathInvalidArgsError(action, 1, len(args))
        elif action == DispatchPath.DISPATCH_CALL:
            if not kwargs.get('firstArgIsName'):
                if self.parent_dispatch is None or self.parent_dispatch.action != DispatchPath.DISPATCH_GET:
                    raise DispatchCallNotPrecededByGet()

                self.args = self.parent_dispatch.args[:1] + self.args
                self.parent_dispatch = self.parent_dispatch.parent_dispatch
            else:
                if not self.args:
                    raise DispatchCallNotPrecededByGet()

    def apply(self, real_obj):

        if self.parent_dispatch:
            target = self.parent_dispatch.apply(real_obj)
        else:
            target = real_obj

        if self.action == DispatchPath.DISPATCH_GET:
            return getattr(target, self.args[0])
        elif self.action == DispatchPath.DISPATCH_CALL:
            return getattr(target, self.args[0])(*self.args[1:])
        elif self.action == DispatchPath.DISPATCH_GETITEM:
            return target[self.args[0]]


class DispatchProxy(object):
    __slots__ = ['zmq_context', 'object_name', 'dispatch_path', '_delayed_eval']

    def __init__(self, zmq_context, object_name, dispatch_path=None):
        assert zmq_context is not None
        assert object_name is not None

        self.zmq_context = zmq_context
        self.object_name = object_name
        self.dispatch_path = dispatch_path
        self._delayed_eval = False

    def eval(self):
        return self.zmq_context.eval(self.object_name, self.dispatch_path)

    def __eval_internal(self, action, *args):
        proxy = DispatchProxy(self.zmq_context, self.object_name, DispatchPath(self.dispatch_path, action, *args))
        proxy._delayed_eval = self._delayed_eval
        if self._delayed_eval:
            return proxy
        return proxy.eval()

    def delayed_eval(self):
        return evalContextManager(self)

    def __call__(self, *args, **kwargs):
        if kwargs:
            raise DispatchKWArgsCallError()

        return self.__eval_internal(DispatchPath.DISPATCH_CALL, *args)

    def __getattr__(self, item):
        return self.__eval_internal(DispatchPath.DISPATCH_GET, item)

    def __getitem__(self, item):
        return self.__eval_internal(DispatchPath.DISPATCH_GETITEM, item)

    def __setattr__(self, key, value):
        if key in DispatchProxy.__slots__:
            return object.__setattr__(self, key, value)
        self.zmq_context.set_member(self.object_name, self.dispatch_path, key, value)

    def __setitem__(self, key, value):
        self.zmq_context.set_item(self.object_name, self.dispatch_path, key, value)


class evalContextManager(object):
    __slots__ = ['proxy', '_old_val']

    def __init__(self, proxy):
        self.proxy = proxy

    def __enter__(self):
        self._old_val = self.proxy.delayed_eval
        self.proxy._delayed_eval = True

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.proxy._delayed_eval = self._old_val
