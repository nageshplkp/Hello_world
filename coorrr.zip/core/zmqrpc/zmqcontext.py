import zmq
import cStringIO as StringIO
import logging
import sys

from .serialize import serialize_to_bytes, deserialize_bytes, deserialize, serialize, is_serializable_object
from .dispatch import DispatchException, DispatchPath, DispatchProxy
from struct import pack, unpack, unpack_from
import contextlib

CMD_UNREGISTER_TYPE = 12
CMD_REGISTER_TYPE = 11
CMD_PING_ACK_TYPE = 10
CMD_PING_TYPE = 9
CMD_EVAL = 8
CMD_SET_MEMBER = 7
CMD_SET_ITEM = 6
CMD_SHUTDOWN = 5
CMD_REPLY = 4
CMD_GET_OBJECT = 3


class InvalidCommandError(Exception):
    def __init__(self, cmd_id):
        super(InvalidCommandError, self).__init__()
        self.cmd_id = cmd_id

    def __str__(self):
        return "Invalid command id: %d" % (self.cmd_id)


class RequestReplyOutOfOrderError(Exception):
    def __init__(self):
        super(RequestReplyOutOfOrderError, self).__init__('%s: Out of order reply' % (self.__class__.__name__,))


class MissingSenderIdError(Exception):
    def __init__(self):
        super(MissingSenderIdError, self).__init__('%s: Missing sender id information' % (self.__class__.__name__,))


class ShutdownException(Exception):
    pass


class ZmqObjectNonexistantError(Exception):
    def __init__(self, object_name):
        super(ZmqObjectNonexistantError, self).__init__("Zmq object does not exist: %s" % (object_name,))


class ZmqInvocationError(Exception):
    def __init__(self, dispatch_exception):
        assert isinstance(dispatch_exception, DispatchException)
        super(ZmqInvocationError, self).__init__('%s: %s\n%s', dispatch_exception.type, dispatch_exception.value,
                                                 dispatch_exception.tb)


class ZmqObjectAlreadyRegistered(Exception):
    def __init__(self, object_name):
        super(ZmqObjectAlreadyRegistered, self).__init__("Zmq object is already registered: %s" % (object_name,))


class InvalidDispatchPathError(Exception):
    def __init__(self):
        super(InvalidDispatchPathError, self).__init__(self.__class__.__name__)


class ZmqContext(object):
    def __init__(self, name, remote_broker, zmq_context_factory=None):

        assert remote_broker is not None

        self.remote_broker = remote_broker
        self.name = name
        self.logger = logging.getLogger('ZmqContext [%s]' % (self.name,))

        self.__socket = None
        self.__context = zmq_context_factory() if zmq_context_factory else zmq.Context()
        self.__object_registry = {}
        self.__req_id = 0

    def __enter__(self):
        self.__context.__enter__()

        self.__socket = self.__context.socket(zmq.DEALER)
        self.__socket.setsockopt(zmq.IDENTITY, self.name)
        self.__socket.connect(self.remote_broker)

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.__socket:
            self.__socket.__exit__(exc_type, exc_val, exc_tb)
        self.__context.__exit__(exc_type, exc_val, exc_tb)

    def register_object(self, name, object_):
        if name not in self.__object_registry:
            self.__execute_command(CMD_REGISTER_TYPE, serialize_to_bytes(name))
            self.__object_registry[name] = object_
        else:
            raise ZmqObjectAlreadyRegistered(name)

    def deregister_object(self, name):
        if name in self.__object_registry:
            self.__execute_command(CMD_UNREGISTER_TYPE, serialize_to_bytes(name))
            del self.__object_registry[name]
        else:
            raise ZmqObjectNonexistantError(name)

    def get_object(self, name):
        if name in self.__object_registry:
            return DispatchProxy(self, name)

        return self.__execute_command(CMD_GET_OBJECT, serialize_to_bytes(name))

    def eval(self, object_name, dispatch_path):

        if object_name in self.__object_registry:
            if not dispatch_path:
                return self.__object_registry[object_name]
            return dispatch_path.apply(self.__object_registry[object_name])
        else:
            with contextlib.closing(StringIO.StringIO()) as buf:
                serialize(object_name, buf)
                serialize(dispatch_path, buf)
                return self.__execute_command(CMD_EVAL, buf.getvalue())

    def set_member(self, object_name, dispatch_path, member_name, value):
        if object_name in self.__object_registry:
            if dispatch_path:
                root_obj = dispatch_path.apply(self.__object_registry[object_name])
            else:
                root_obj = self.__object_registry[object_name]
            setattr(root_obj, member_name, value)
        else:
            with contextlib.closing(StringIO.StringIO()) as buf:
                serialize(object_name, buf)
                serialize(dispatch_path, buf)
                serialize(member_name, buf)
                serialize(value, buf)
                return self.__execute_command(CMD_SET_MEMBER, buf.getvalue())

    def set_item(self, object_name, dispatch_path, item_index, value):
        if object_name in self.__object_registry:
            if dispatch_path:
                root_obj = dispatch_path.apply(self.__object_registry[object_name])
            else:
                root_obj = self.__object_registry[object_name]
            root_obj[item_index] = value
        else:
            with contextlib.closing(StringIO.StringIO()) as buf:
                serialize(object_name, buf)
                serialize(dispatch_path, buf)
                serialize(item_index, buf)
                serialize(value, buf)
                return self.__execute_command(CMD_SET_ITEM, buf.getvalue())

    def run_message_loop(self, nTimes=-1):
        iteration_count = 0
        while nTimes == -1 or iteration_count < nTimes:
            if self.__socket.poll(5000, zmq.POLLIN):
                parts = self.__socket.recv_multipart()
                try:
                    if parts[0]:
                        sender_id = parts[0]
                        parts = parts[2:]
                    else:
                        parts = parts[1:]

                    cmd_id, req_id = unpack_from("<bL", parts[0])
                    if cmd_id == CMD_REPLY:
                        return req_id, deserialize_bytes(parts[1], self)

                    if not sender_id:
                        raise MissingSenderIdError()

                    handler = self.__get_command_handler(cmd_id)
                    result = handler(parts[1])
                    self.__socket.send_multipart([
                        sender_id,
                        bytes(),
                        pack("<bL", CMD_REPLY, req_id),
                        serialize_to_bytes(result)
                    ])
                except ShutdownException:
                    raise
                except:
                    self.logger.warning("Invalid message received: \n%s" % ('\n'.join(parts)))
            iteration_count += 1

    def __execute_command(self, cmd_id, cmd_data):
        req_id = self.__req_id
        self.__req_id += 1

        self.__socket.send_multipart([
            bytes(),
            pack("<bL", cmd_id, req_id),
            cmd_data if isinstance(cmd_data, bytes) else serialize_to_bytes(cmd_data)
        ])

        last_req_id, reply = self.run_message_loop()

        if last_req_id != req_id:
            raise RequestReplyOutOfOrderError()

        if isinstance(reply, DispatchException):
            raise ZmqInvocationError(reply)
        return reply

    def __cmd_eval(self, command_bytes):
        try:
            with contextlib.closing(StringIO.StringIO(command_bytes)) as buf:
                object_name = deserialize(buf)
                if object_name not in self.__object_registry:
                    raise ZmqObjectNonexistantError(object_name)

                dispatch_path = deserialize(buf)

                if not isinstance(dispatch_path, DispatchPath):
                    raise InvalidDispatchPathError()

                if dispatch_path:
                    result = dispatch_path.apply(self.__object_registry[object_name])
                else:
                    result = self.__object_registry[object_name]

                if not is_serializable_object(result):
                    return DispatchProxy(self, object_name, dispatch_path)
                return result
        except ShutdownException:
            raise
        except:
            return DispatchException(*sys.exc_info())

    def __cmd_ping(self, command_bytes):
        pass  # same as returning None which is acceptable and expected reply

    def __cmd_set_item(self, command_bytes):
        try:
            with contextlib.closing(StringIO.StringIO(command_bytes)) as buf:
                object_name = deserialize(buf)
                if object_name not in self.__object_registry:
                    raise ZmqObjectNonexistantError(object_name)

                dispatch_path, item_index, value = deserialize(buf), deserialize(buf), deserialize(buf)

                if dispatch_path:
                    object_target = dispatch_path.apply(self.__object_registry[object_name])
                else:
                    object_target = self.__object_registry[object_name]

                object_target[item_index] = value
        except ShutdownException:
            raise
        except:
            return DispatchException(*sys.exc_info())

    def __cmd_set_member(self, command_bytes):
        try:
            with contextlib.closing(StringIO.StringIO(command_bytes)) as buf:
                object_name = deserialize(buf)
                if object_name not in self.__object_registry:
                    raise ZmqObjectNonexistantError(object_name)

                dispatch_path, prop_name, value = deserialize(buf), deserialize(buf), deserialize(buf)

                if dispatch_path:
                    object_target = dispatch_path.apply(self.__object_registry[object_name])
                else:
                    object_target = self.__object_registry[object_name]

                setattr(object_target, prop_name, value)
        except ShutdownException:
            raise
        except:
            return DispatchException(*sys.exc_info())

    def __get_command_handler(self, cmd_id):

        try:
            if cmd_id == CMD_EVAL:
                return self.__cmd_eval
            elif cmd_id == CMD_PING_TYPE:
                return self.__cmd_ping
            elif cmd_id == CMD_SET_ITEM:
                return self.__cmd_set_item
            elif cmd_id == CMD_SET_MEMBER:
                return self.__cmd_set_member
            elif cmd_id == CMD_SHUTDOWN:
                raise ShutdownException()
            else:
                raise InvalidCommandError(cmd_id)
        except ShutdownException:
            raise
        except:
            return DispatchException(*sys.exc_info())
