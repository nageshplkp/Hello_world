import traceback
from struct import pack, unpack
from .dispatch import DispatchProxy, DispatchPath, DispatchException
import contextlib
import cStringIO as StringIO

DISPATCH_PATH_TYPE = 13
FALSE_TYPE = 10
TRUE_TYPE = 9
DISPATCH_TYPE = 8
EXC_TYPE = 7
DICT_TYPE = 6
LIST_TYPE = 5
STRING_TYPE = 4
FLOAT_TYPE = 2
INT_TYPE = 1
NONE_TYPE = 0


class InvalidTypeDesignatorError(Exception):
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return "Invalid type designator: %d" % self.value


class UnserializableObjectError(Exception):
    def __init__(self, object_):
        self.object_ = object_

    def __str__(self):
        return "Invalid object for serialization: %s" % (self.object_,)


def is_serializable_object(data):
    if data is None:
        return True
    elif isinstance(data, int):
        return True
    elif isinstance(data, float):
        return True
    elif isinstance(data, bool):
        return True
    elif isinstance(data, (str, unicode)):
        return True
    elif isinstance(data, (list, tuple)):
        return True
    elif isinstance(data, dict):
        return True
    elif isinstance(data, DispatchException):
        return True
    elif isinstance(data, DispatchProxy):
        return True
    elif isinstance(data, DispatchPath):
        return True

    return False


def serialize(data, buffer_):
    if data is None:
        buffer_.write(pack("b", NONE_TYPE))
    elif isinstance(data, bool):
        if data:
            buffer_.write(pack("b", TRUE_TYPE))
        else:
            buffer_.write(pack("b", FALSE_TYPE))
    elif isinstance(data, int):
        buffer_.write(pack("<bl", INT_TYPE, data))
    elif isinstance(data, float):
        buffer_.write(pack("<bd", FLOAT_TYPE, data))
    elif isinstance(data, (str, unicode)):
        data = data.encode('utf-8')
        buffer_.write(pack("<bl", STRING_TYPE, len(data)))
        buffer_.write(data)
    elif isinstance(data, (list, tuple)):
        buffer_.write(pack("<bl", LIST_TYPE, len(data)))
        map(lambda x: serialize(x, buffer_), data)
    elif isinstance(data, dict):
        buffer_.write(pack("<bl", DICT_TYPE, len(data)))
        for x, y in data.iteritems():
            serialize(x, buffer_)
            serialize(y, buffer_)
    elif isinstance(data, DispatchException):
        buffer_.write(pack("<b", EXC_TYPE))
        serialize(data.type, buffer_)
        serialize(data.value, buffer_)
        serialize(data.tb, buffer_)
    elif isinstance(data, DispatchPath):
        buffer_.write(pack("<b", DISPATCH_PATH_TYPE))
        serialize(data.parent_dispatch, buffer_)
        serialize(data.action, buffer_)
        serialize(data.args, buffer_)
    elif isinstance(data, DispatchProxy):
        buffer_.write(pack("<b", DISPATCH_TYPE))
        serialize(data.object_name, buffer_)
        serialize(data.dispatch_path, buffer_)
    else:
        raise UnserializableObjectError(data)


def deserialize(buffer_, zmq_context=None):
    type_designator = unpack("b", buffer_.read(1))[0]
    if type_designator == NONE_TYPE:
        return None
    elif type_designator == INT_TYPE:
        return unpack("<l", buffer_.read(4))[0]
    elif type_designator == FLOAT_TYPE:
        return unpack("<d", buffer_.read(8))[0]
    elif type_designator == TRUE_TYPE:
        return True
    elif type_designator == FALSE_TYPE:
        return False
    elif type_designator == STRING_TYPE:
        len_ = unpack("<l", buffer_.read(4))[0]
        return buffer_.read(len_).decode('utf-8')
    elif type_designator == LIST_TYPE:
        len_ = unpack("<l", buffer_.read(4))[0]
        return tuple(deserialize(buffer_, zmq_context) for x in xrange(len_))
    elif type_designator == DICT_TYPE:
        len_ = unpack("<l", buffer_.read(4))[0]
        return dict((deserialize(buffer_, zmq_context), deserialize(buffer_, zmq_context)) for x in xrange(len_))
    elif type_designator == EXC_TYPE:
        return DispatchException(deserialize(buffer_, zmq_context), deserialize(buffer_, zmq_context),
                                 deserialize(buffer_, zmq_context))
    elif type_designator == DISPATCH_PATH_TYPE:
        return DispatchPath(deserialize(buffer_), deserialize(buffer_), *deserialize(buffer_), firstArgIsName=True)
    elif type_designator == DISPATCH_TYPE:
        return DispatchProxy(zmq_context, deserialize(buffer_, zmq_context), deserialize(buffer_, zmq_context))

    raise InvalidTypeDesignatorError(type_designator)


def deserialize_bytes(bytes_, zmq_context=None):
    with contextlib.closing(StringIO.StringIO(bytes_)) as buf:
        return deserialize(buf, zmq_context)


def serialize_to_bytes(data):
    with contextlib.closing(StringIO.StringIO()) as buf:
        serialize(data, buf)
        return buf.getvalue()


def serialize_many_to_bytes(*data):
    with contextlib.closing(StringIO.StringIO()) as buf:
        for d in data:
            serialize(d, buf)
        return buf.getvalue()


def many_deserialize_bytes(bytes_, count, zmq_context=None):
    with contextlib.closing(StringIO.StringIO(bytes_)) as buf:
        return tuple([deserialize(buf, zmq_context) for x in xrange(count)])
