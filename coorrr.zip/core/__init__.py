import sys
import os, logging
import logging.handlers
import getpass
import time
from core.common import util
from core.io import files
from core.config import config_api
from core.log import log_config
import six


def _init_pimlib():
    if 'PIMLIB_SYBASE_OVERRIDE' in os.environ and os.environ.get('PIMLIB_SYBASE_OVERRIDE'):
        os.environ['PIMLIB_DB_SERVER'] = os.environ['PIMLIB_SYBASE_OVERRIDE']
        os.environ['DSQUERY'] = os.environ['PIMLIB_SYBASE_OVERRIDE']
    else:
        os.environ['PIMLIB_DB_SERVER'] = str(config_api.get('PIMLIB_DB_SERVER'))
        os.environ['DSQUERY'] = str(config_api.get('PIMLIB_DB_SERVER'))

__UMD_EXCLUSION_MODULES = ['pyodbc']

def _spyder_fix():
    import six.moves.builtins as builtins

    if hasattr(builtins, 'runfile') and builtins.runfile.__module__ == 'sitecustomize':
        # we are running in spyder, god help us all
        umd_exclude = [x.strip() for x in os.environ.get('UMD_NAMELIST', '').split(',') if x]
        umd_exclude += __UMD_EXCLUSION_MODULES
        umd_exclude = set(umd_exclude)
        os.environ['UMD_NAMELIST'] = str(','.join(umd_exclude))

        import sitecustomize
        if sitecustomize.__umr__ is not None:
            sitecustomize.__umr__.namelist += [x for x in __UMD_EXCLUSION_MODULES if x not in sitecustomize.__umr__.namelist]

def init():
    _spyder_fix()
    log.log_config.init_logging()
    config_api.load()
    _init_pimlib()

init()
