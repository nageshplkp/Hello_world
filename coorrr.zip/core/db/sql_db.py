import getpass
import logging
import time
from core.common import util
from core.db import sql_db_impl
from core.db import sql_db_conn


class SqlDb(object):
    """
    Use Db class if client requires more control over connections, cursor
    """

    def __init__(self, server, vendor, user='', password='', options=None, session_config={}, log=True, useDsn=False):
        """
        Creates a db connection
        
        :param server:  connection string
        :type server: str
        :param vendor:  oracle | sybase
        :type vendor: str
        :param user: Username for the db connection; if left blank, use kerberos
        :type user: str
        :param password: Password to use for the db connection
        :type password: str
        :param options: None, or a dict with additional options. Values must be strings. Options are driver specific.
        :type options: dict[str,object]
        :param session_config: Session configuration dictionary. Mostly used for hive
        :type session_config: dict[str,object]
        :param log: If true, each statement will be logged
        :type log: bool
        :param useDsn: For oracle, will use server as DSN name rathen than server name
        :type useDsn: bool
        """
        self.server = server
        self.vendor = 'oracle' if vendor == 'default' else vendor
        self.user = user
        self.password = password
        self.session_config = session_config
        self.options = options or {}
        self.options = dict((k, v) for k, v in self.options.iteritems() if v is not None)
        self.useDsn = useDsn
        user = self.user if self.user else getpass.getuser()
        if log:
            logging.info('db connecting to %s, user=%s' % (server, user))

        sql_db_conn._connect(self)

    def query(self, sql, params={}, columns=None, fetchAll=True, bindarraysize=10000, log=True, oracle_unicode=False,
              input_sizes=None, param_transformer=None):
        """
        Runs SQL and returns a result set. Do not use this for DML or DDL statements.
        
        :param sql:      sql string
        :type sql: str
        :param params:   query params as dict.
        :type params: list|dict
        :param columns:  if array is passed in, will return the list of columns
        :type columns: list
        :param fetchAll: if false, return the cursor, up to client to close closer
                         ** careful not to leak the cursor if not fetchall
        :type fetchAll: bool
        :param bindarraysize: ORACLE only, bindarraysize
        :type bindarraysize: dict
        :param log: If true, statement will be logged.
        :type log: bool
        :param input_sizes: For vendors that support it, input sizes for bind vars.
        :type input_sizes: dict
        :param param_transformer: An optional lambda used to transform statement parameters into vendor-specific objects,
            i.e. str->cx_Oracle.CLOB
        :type param_transformer: func
        :param oracle_unicode: Handle strings as unicode (oracle only)
        :type oracle_unicode: bool
        :return: Result set
        :rtype: list[list]
        """

        return sql_db_impl._query(self, sql, params, columns, fetchAll, bindarraysize, log, oracle_unicode,
              input_sizes, param_transformer)


    def query_stream(self, sql, params={}, bindarraysize=10000, log=True, oracle_unicode=False,
                     input_sizes=None, param_transformer=None):
        """
        Runs SQL and returns a generator for the result set. Do not use with DML or DDL statements.
        
        :param sql:      sql string
        :type sql: str
        :param params:   query params as dict.
        :type params: list|dict
        :param bindarraysize: ORACLE only, bindarraysize
        :type bindarraysize: dict
        :param log: If true, statement will be logged.
        :type log: bool
        :param input_sizes: For vendors that support it, input sizes for bind vars.
        :type input_sizes: dict
        :param param_transformer: An optional lambda used to transform statement parameters into vendor-specific objects,
            i.e. str->cx_Oracle.CLOB
        :type param_transformer: func
        :param oracle_unicode: Handle strings as unicode (oracle only)
        :type oracle_unicode: bool
        :return: Result set
        :rtype: list[list]
        """

        return sql_db_impl._query_stream(self, sql, params, bindarraysize, log, oracle_unicode,
                     input_sizes, param_transformer)

    def query_as_df(self, sql, params=None, log=True, input_sizes=None, param_transformer=None, coerce_float=False):
        """
        Runs SQL and returns a result set as pandas.DataFrame . Do not use this for DML or DDL statements.

        :param sql:      sql string
        :type sql: str
        :param params:   query params as dict.
        :type params: list|dict
        :param log: If true, statement will be logged.
        :type log: bool
        :param input_sizes: Ignored
        :param param_transformer: Ignored
        :return: Pandas Dataframe
        :rtype: DataFrame
        """

        return sql_db_impl._query_as_df(self, sql, params, log, input_sizes, param_transformer, coerce_float=coerce_float)

    def insert(self, dataframe, table_name, columns=None, pk_source='row', pk_columns=None, nanAndInfAsNone=False):
        """
        Inserts dataframe into the given table.

        :param dataframe: Dataframe to save
        :param table_name: Table to write
        :param columns: List of columns to write. Default is all columns
        :param pk_source: 'index' or 'row' - where to grab the primary key values for upsert/insert. 'index' means
               that primary key is coming from dataframe index, 'row' means that it's coming from actual row values
        :param pk_columns: names of primary key columns. Required for 'insert' only if source is 'index'
        :param mode: 'upsert' or 'insert'
        :return:
        """
        return sql_db_impl._insert(self, dataframe, table_name, columns, pk_source, pk_columns, nanAndInfAsNone=nanAndInfAsNone)


    def update(self, dataframe, table_name, pk_columns, columns=None, pk_source='row', nanAndInfAsNone=False):
        """
        Updates rows in the given table with the values from the dataframe.
        
        :param dataframe: Dataframe to save
        :param table_name: Table to write
        :param columns: List of columns to write. Default is all columns
        :param pk_source: 'index' or 'row' - where to grab the primary key values for update. 'index' means
               that primary key is coming from dataframe index, 'row' means that it's coming from actual row values
        :param pk_columns: names of primary key columns. Required.
        :param mode: 'upsert' or 'insert'
        :return:
        """

        return sql_db_impl._update(self, dataframe, table_name, pk_columns, columns, pk_source, nanAndInfAsNone=nanAndInfAsNone)


    def delete(self, dataframe, table_name, pk_columns=None, pk_source='row'):
        """
        Deletes rows contained in the dataframe from the given table. 
        
        :param dataframe: Dataframe to save
        :param table_name: Table to write
        :param columns: List of columns to write. Default is all columns
        :param pk_source: 'index' or 'row' - where to grab the primary key values for update. 'index' means
               that primary key is coming from dataframe index, 'row' means that it's coming from actual row values
        :param pk_columns: names of primary key columns. Required.
        :param mode: 'upsert' or 'insert'
        :return:
        """

        return sql_db_impl._delete(self, dataframe, table_name, pk_columns, pk_source)


    def upsert(self, dataframe, table_name, pk_columns, columns=None, pk_source='row', nanAndInfAsNone=False):
        """
        Inserts or updates rows contained in the dataframe into the given table.
        
        :param dataframe: Dataframe to save
        :param table_name: Table to write
        :param columns: List of columns to write. Default is all columns
        :param pk_source: 'index' or 'row' - where to grab the primary key values for update. 'index' means
               that primary key is coming from dataframe index, 'row' means that it's coming from actual row values
        :param pk_columns: names of primary key columns. Required.
        :param mode: 'upsert' or 'insert'
        :return:
        """

        return  sql_db_impl._upsert(self, dataframe, table_name, pk_columns, columns, pk_source, nanAndInfAsNone=nanAndInfAsNone)


    def _insert_df(self, df, table_name):
        return sql_db_impl._insert_df(self, df, table_name)


    def table_columns(self, table_name):
        """
        Returns list containing column names of a given table
        
        :param table_name: Name of the table
        :type table_name: str
        :return: List of column names
        :rtype: list[str]
        """

        return sql_db_impl._table_columns(self, table_name)

    def schema(self, schema, table):
        """
        Gets the schema of the given table
        
        :param schema: Schema/owner of the table
        :param schema: str
        :param table: Table name
        :param table: str
        :return: Table description in the same format as DBAPI 2.0 cursor.description
        """

        return sql_db_impl._schema(self, schema, table)


    def execute(self, sql, params=[], commit=True, log=True):
        """
        Executes a DDL or DML statement and returns number of rows affected.
        
        :param sql: SQL statement to execute
        :type sql: str
        :param params: Statement params
        :type params: list|dict
        :param commit: If true, commit will be called on the connection
        :type commit: bool
        :return: Number of rows affected
        :rtype: int
        """

        return sql_db_impl._execute(self, sql, params, commit, log=log)


    def executemany(self, statement, list_data=[], commit=True, bindarraysize=10000, log=True, oracle_unicode=False,
                input_sizes=None):
        """
        Runs the same statement over the list of param dicts or tuples efficiently
        
        :param statement: Statement to execute for each element of list_data 
        :param list_data: List of lists or list of dicts, supplying params to the statement
        :param commit: If true, commit will be called afterwards
        :param bindarraysize: For db engines which support it, bindarraysize
        :param log: If true, statmenet sql will be logged.
        :param oracle_unicode: If true, will turn on unicode processing for oracle
        :param input_sizes: For engines which support it, input sizes.
        :return: 
        """

        return sql_db_impl._executemany(self, statement, list_data, commit, bindarraysize, log, oracle_unicode, input_sizes)


    def call_proc(self, procname, params=[], commit=True):
        """
        Calls a stored procedure
        
        :param procname: Name of the stored procedure 
        :type procname: str
        :param params: Params to pass to the procedure
        :type params: list|dict
        :param commit: If true, commit will be called.
        :type commit: bool
        """

        return sql_db_impl._call_proc(self, procname, params, commit)


    def cursor(self, retryCount=1):
        '''
        Gets the DBAPI2.0 cursor
        :param retryCount: Times to retry if connection throws an exception 
        :return: Cursor
        '''
        try:
            return self._conn.cursor()
        except Exception, ex:
            if retryCount <= 3:  # going to try again in case the connection went down
                logging.error('connection lost, sleeping and trying again')
                sql_db_conn._connect(self)
                retryCount += 1
                time.sleep(30)
                return self.cursor(retryCount)
            msg = 'DB Connnection or cursor problem %s' % util.exceptionAsStr(ex)
            raise Exception(msg)


    def _log(self, sql, params):
        user = self.user if self.user else getpass.getuser()

        logging.info('{"user":"%s", "server":"%s", "sql":"%s", "params"="%s"}' %
                     (user, self.server, sql, params))


    def _closeCur(self, cur):
        try:
            if cur:
                cur.close()
        except Exception, ex:
            pass


    def close(self):
        """
        Closes the connection
        """
        try:
            if self._conn:
                self._conn.close()
        except Exception, ex:
            pass

    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        self.close()

    def __repr__(self):
        return 'server:%s  vendor:%s' % (self.server, self.vendor)


def single_value(rows):
    """
    Take a result set from a statement which is supposed to return just one value and convert it to a single value

    :param rows: Result set from query
    :type rows: list[list]
    :return: Single value
    :rtype: object
    """
    if rows:
        return rows[0][0]

    return None


def rows_of_dicts(rows, cols):
    """
    Transforms a result from query into list of dicts using the provided column order

    :param rows: Result set from query
    :type rows: list[list]
    :param cols: Column names in the same order as they appear in result set
    :type cols: list[str]
    :return: List of dictionaries representing the result set
    :rtype: list[dict]
    """

    def rowToDict(r):
        return dict((c, r[i]) for i, c in enumerate(cols))

    return map(rowToDict, rows)


def connect_sybase(server, user=None, password=None, database=None, auto_commit=None, bulkcopy=None, locale=None,
                   is_iq=False, **kwargs):
    """
    Returns SqlDb object connected to give sybase server
    
    :param server: ASE or IQ server to connect to
    :type server: str
    :param user: 
    :type user: str
    :param password:
    :type password: str
    :param database: Database to select
    :type database: str
    :param auto_commit: Auto-commit flag value
    :param auto_commit: bool
    :param bulkcopy: Flag specifying bulk-copy mode
    :type bulkcopy: bool
    :param locale: Locale/charset to use
    :type locale: str
    :param is_iq: True if the target server is IQ, false if ASE
    :type is_iq: bool
    :param kwargs: 
    :return: SqlDb connected to the server
    :rtype: SqlDb
    """
    options = {}
    if util.isWindows():
        options['autocommit'] = auto_commit
        options['EnableBulkLoad'] = bulkcopy
        options['charset'] = locale
    else:
        options['auto_commit'] = auto_commit
        options['bulkcopy'] = bulkcopy
        options['locale'] = locale
    options['database'] = database

    kwargs = dict((k, v) for k, v in kwargs.iteritems() if v is not None)
    options = dict((k, v) for k, v in options.iteritems() if v is not None)
    kwargs.update(options)

    return SqlDb(server, 'sybiq' if is_iq else 'sybase', user, password, kwargs)
