from core.io import files
import os
import os.path
import re

space_rx = re.compile('\s+')


def read_tns_file_as_dict():
    '''
    Reads tnsnames.ora located in os.environ['TNS_ADMIN'] and returns entries as dict
    :return: Dict containing list of TNS identifiers and their connection strings
    :rtype: dict[str,str]
    '''
    if 'TNS_ADMIN' not in os.environ:
        raise Exception('Must set TNS_ADMIN')
    data = files.readflat(os.path.join(os.environ['TNS_ADMIN'], 'tnsnames.ora')) or ''
    return parse_tnsnames(data)


def parse_tnsnames(tnsnames):
    '''
    Parses a string in tnsnames.ora format and returns entries as dict
    :param tnsnames: String in tnsnames.ora format
    :type tnsnames:str
    :return: Dict containing list of TNS identifiers and their connection strings
    :rtype: dict[str,str]
    '''
    tnsnames = space_rx.sub(' ', tnsnames)
    last_r_paren = None
    last_equals = None
    result = {}
    while True:
        id_start = (last_r_paren + 1) if last_r_paren else 0
        last_equals = tnsnames.find('=', id_start)

        if last_equals < 0:
            return result

        oraname = tnsnames[id_start:last_equals].strip()
        lparen = 0
        rparen = 0

        last_r_paren = None
        for i in xrange(last_equals + 1, len(tnsnames)):
            c = tnsnames[i]
            if c == '(':
                lparen += 1
            elif c == ')':
                rparen += 1
                if lparen == rparen:
                    last_r_paren = i
                    break
        if not last_r_paren:
            break
        connect_data = tnsnames[last_equals + 1:last_r_paren + 1].strip()
        result[oraname] = connect_data
    return result