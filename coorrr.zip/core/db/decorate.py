import os, datetime, sys, logging, traceback, time, functools, getpass
from pprint import pformat

CONN_MAP = {
    'default.default': 'ORARPTPIM_CA',
    'default.conn': 'oracle',
    'oracle.prod': ('ORAPRDPIM', 'oracle'),
    'oracle.prodwrite': ('ORAPRDPIM', 'oracle'),
    'oracle.rpt': ('ORARPTPIM_CA', 'oracle'),
    'oracle.hist': ('ORAPRDHST', 'oracle'),
    'oracle.trn': ('ORAPRDTRN', 'oracle'),
    'oracle.bda': ('ORABDATST', 'oracle'),
    'oracle.beta': ('ORABTAPIM', 'oracle'),
    'oracle.dev': ('ORADEVPIM', 'oracle'),
    'sybase.prod': ('SYBPRDPIM', 'sybase'),
    'iq.prod': ('SYBPRDPMIQ', 'iq'),
    'impala_bda.prod': ('bda14node04.pimco.imswest.sscims.com:21050', 'impala'),
    'hive_bda.prod': ('bda14node04.pimco.imswest.sscims.com:10000', 'hive'),
    'impala_mapr.prod': ('prodpmbd2.pimco.imswest.sscims.com:21050', 'impala'),
    'impala_bda.beta': ('bda65node04.core.pimcocloud.net:21050', 'impala'),
    'hive_bda.beta': ('bda65node04.core.pimcocloud.net:10000', 'hive'),
}

def db_map():
    import pandas as pd

    data = []
    for k, v in CONN_MAP.iteritems():
        if k ==  'default.conn' or k == 'default.vendor':
            continue

        server = v
        if not isinstance(v, basestring):
            server = v[0]
        s = k.split('.')
        d = dict(
            conn=s[0],
            env=s[1],
            server=server
        )

        data.append(d)

    return pd.DataFrame.from_dict(data).sort_values(['conn', 'env'])


## Deprecated for now..
def query_wrap(f):
    def func_wrap(*args, **kwargs):
        return f(*args, **kwargs)

    return func_wrap
