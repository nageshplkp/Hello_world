from decorate import CONN_MAP
from sql_db import rows_of_dicts, single_value
from core.db.conn_pool import connect
import pandas as pd


def insert(dataframe, table_name, conn='oracle', env='prodwrite', columns=None, pk_source='row', pk_columns=None, nanAndInfAsNone=False):
    """
    Inserts rows from the dataframe into the table.

    :param dataframe: Dataframe with rows to insert
    :type dataframe: pd.DataFrame
    :param table_name: Table to update
    :type table_name: str
    :param conn: Name of the connection (e.g. oracle, sybase, impala_bda) 
    :type conn: str
    :param env: Connection environment (prod, prodwrite, beta, etc)
    :type env: str
    :param pk_columns: List of primary key columns which are used to construct the update statement
    :type pk_columns: list[str]
    :param columns: Columns to insert. All dataframe columns by default
    :type columns: list[str]
    :param pk_source: Source of primary key: row or index
    :type pk_source: str
    :return: Nothing
    """
    _db = connect(conn, env)
    if _db.vendor != 'oracle':
        raise Exception('Insert only supported for oracle')
    return _db.insert(dataframe, table_name, columns=columns, pk_source=pk_source, pk_columns=pk_columns, nanAndInfAsNone=nanAndInfAsNone)


def update(dataframe, table_name, pk_columns, conn='oracle', env='prodwrite', columns=None, pk_source='row', nanAndInfAsNone=False):
    """
    Updates table with rows from the dataframe. Only existing data will be updated. New rows will not be inserted.

    :param dataframe: Dataframe with rows to update
    :type dataframe: pd.DataFrame
    :param table_name: Table to update
    :type table_name: str
    :param conn: Name of the connection (e.g. oracle, sybase, impala_bda) 
    :type conn: str
    :param env: Connection environment (prod, prodwrite, beta, etc)
    :type env: str
    :param pk_columns: List of primary key columns which are used to construct the update statement
    :type pk_columns: list[str]
    :param columns: Columns to update. All dataframe columns by default
    :type columns: list[str]
    :param pk_source: Source of primary key: row or index
    :type pk_source: str
    :return: Nothing
    """
    _db = connect(conn, env)
    if _db.vendor != 'oracle':
        raise Exception('Update only supported for oracle')
    return _db.update(dataframe, table_name, pk_columns, columns=columns, pk_source=pk_source, nanAndInfAsNone=nanAndInfAsNone)


def upsert(dataframe, table_name, pk_columns, conn='oracle', env='prodwrite', columns=None, pk_source='row', nanAndInfAsNone=False):
    """
    Inserts rows from the dataframe if they aren't present in the table, and updates rows with data from the data frame
    if they are present in the table.

    :param dataframe: Dataframe with rows to update/insert
    :type dataframe: pd.DataFrame
    :param table_name: Table to upsert to
    :type table_name: str
    :param conn: Name of the connection (e.g. oracle, sybase, impala_bda) 
    :type conn: str
    :param env: Connection environment (prod, prodwrite, beta, etc)
    :type env: str
    :param pk_columns: List of primary key columns which are used to construct the update statement
    :type pk_columns: list[str]
    :param columns: Columns to insert/update. All dataframe columns by default
    :type columns: list[str]
    :param pk_source: Source of primary key: row or index
    :type pk_source: str
    :return: Nothing
    """
    _db = connect(conn, env)
    if _db.vendor != 'oracle':
        raise Exception('Upsert only supported for oracle')
    return _db.upsert(dataframe, table_name, pk_columns, columns=columns, pk_source=pk_source, nanAndInfAsNone=nanAndInfAsNone)


def delete(dataframe, table_name, conn='oracle', env='prodwrite', pk_columns=None, pk_source='row'):
    """
    Deletes rows in the dataframe from the specified table

    :param dataframe: Dataframe with rows to delete
    :type dataframe: pd.DataFrame
    :param table_name: Table to delete from
    :type table_name: str
    :param conn: Name of the connection (e.g. oracle, sybase, impala_bda) 
    :type conn: str
    :param env: Connection environment (prod, prodwrite, beta, etc)
    :type env: str
    :param pk_columns: List of primary key columns which are used to construct the delete statement
    :type pk_columns: list[str]
    :param pk_source: Source of primary key: row or index
    :type pk_source: str
    :return: Nothing
    """
    _db = connect(conn, env)
    if _db.vendor != 'oracle':
        raise Exception('Delete only supported for oracle')
    return _db.delete(dataframe, table_name, pk_columns=pk_columns, pk_source=pk_source)

def delete_by_clause(table_name, clause, params={}, conn='oracle', env='prodwrite'):
    _db = connect(conn, env)
    sql = "delete %s where %s " % (table_name, clause)
    return _db.execute(sql, params)




