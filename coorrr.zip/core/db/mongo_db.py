import getpass

from six.moves import urllib
from pymongo import MongoClient

from core.config import config_api


def mongo_client(database='rdf'):
    mongo_server = config_api.get('MONGO_HOST')

    return MongoDb(database, mongo_server)


class MongoDb(object):

    def __init__(self, database, server, user=None, password=None, write_concern=1, auth_db=None):
        self.user = user or getpass.getuser()
        self.server = server
        self.database = database
        self.auth_db = database if auth_db is None else auth_db

        qname = 'PIMCO.IMSWEST.SSCIMS.COM'
        if (qname not in self.server) and (qname.find('.') == -1):
            self.server = '%s.%s' % (self.server, qname)

        connStr = 'mongodb://%s:%s@%s/%s' % (self.user, urllib.parse.quote(password) if password is not None else '',
                                             self.server, self.auth_db)
        if not password:  # if not password, assume kerberos
            if qname not in self.user:
                self.user =  self.user + '%40'+ qname
            connStr = 'mongodb://%s@%s/?authMechanism=GSSAPI' % (self.user, self.server)

        #print connStr
        self.mongo = MongoClient(connStr, w=write_concern)
        self.db = self.mongo[self.database]

    def db_collection(self, collectionName):
        if collectionName not in self.db.collection_names():
            self.db.create_collection(collectionName)

        return self.db[collectionName]

    def delete(self, collectionName, filter):
        #self.mongo.write_concern = {'w':1}
        collection = self.db_collection(collectionName)
        collection.remove(filter)

    def drop_collection(self, collectionName):
        collection = self.db_collection(collectionName)
        collection.drop()

    def save(self, collectionName, data):
        '''
        use only if "_id" field is available or want to always insert
        '''
        #self.mongo.write_concern = {'w':1}
        collection = self.db_collection(collectionName)

        if isinstance(data, list):
            for d in data:
                collection.save(d)
        else:
            collection.save(data)

    def upsert(self, collectionName, data, pk):
        assert pk

        collection = self.db_collection(collectionName)
        if isinstance(data, list):
            bulk = collection.initialize_unordered_bulk_op()
            for d in data:
                keyVal = d.get(pk)
                assert keyVal
                bulk.find({'%s' % pk : keyVal}).upsert().replace_one(d)
            return bulk.execute()
        else:
            keyVal = data.get(pk)
            assert keyVal
            return collection.update({'%s' % pk : keyVal}, data, upsert=True)  # changed to upsert

    def updateOnly(self, collectionName, filter, data):
        '''
        :param collectionName:
        :param filter:   filter to find the documents to update
        :param data: dict of key, val in document to update
        :return:
        '''
        assert filter and data
        collection = self.db_collection(collectionName)
        collection.update(filter, {'$set':data})

    def insert(self, collectionName, data):
        collection = self.db_collection(collectionName)

        if isinstance(data, list):
            bulk = collection.initialize_unordered_bulk_op()
            for d in data:
                if not d.get('_id'):
                    bulk.insert(d)
            return bulk.execute()
        else:
            if not data.get('_id'):
                collection.insert(data)

    def query(self, collectionName, filter={}, fields=None, lazy=False, sort=[], limit=0):
        collection = self.db_collection(collectionName)

        cur = collection.find(filter, fields)
        if sort:
            cur = cur.sort(sort)

        if limit > 0:
            cur = cur.limit(limit)

        if lazy:
            return cur

        return [c for c in cur]

    def query_one(self, collectionName, filter):
        collection = self.db_collection(collectionName)
        return collection.find_one(filter)

    def create_index(self, collectionName, cols, unique=True):
        collection = self.db_collection(collectionName)
        collection.create_index(cols, unique=unique)

    def close(self):
        """
        Closes the connection
        """
        try:
            if self.mongo:
                self.mongo.close()
        except Exception, ex:
            pass

    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        self.close()
