from core.db import sql_db
from core.config import config_api
import copy


def db_to_hive_type(db_type, scale, precision, use_integers=False):
    """
    Converts oracle/sybase/iq data type to hive type name
    """

    db_type = db_type.lower()
    if db_type == 'number' or db_type == 'numeric':
        if use_integers:
            if scale is not None and scale != 0:
                return 'decimal'
            if precision > 10:
                return 'bigint'
            return 'int'

        else:
            return 'decimal'

    if 'char' in db_type or 'clob' in db_type:
        return 'string'

    if 'integer' == db_type or 'int' in db_type:
        return 'int'

    if 'time' in db_type or 'date' in db_type:
        return 'timestamp'

    if 'bit' in db_type:
        return 'int'

    return db_type


class Schema(object):
    """
    Database schema representation
    """
    def __init__(self, table, vendor='oracle'):
        """
        Constructs database table schema representation

        :param table:
        :param vendor: oracle, bda
        """

        self.table = table
        self.vendor = vendor
        self.columns = []

        if '.' not in self.table:
            raise Exception('table name requires db schema and table.  ex: pm_own.pma_a_v')

        if self.vendor.lower().strip() not in ['oracle', 'bda', 'mapr', 'sybase','iq', 'iq_mtg']:
            raise Exception('unsupported vendor db = %s' % self.vendor)

        self.load()

    def load(self):
        """
        Loads schema data from the backing database table

        :return:
        """
        pass

    def column_names(self):
        """
        Returns array of column names
        :return:  array of col
        :rtype: list[str]
        """
        return [c.name for c in self.columns]

    def columns_as_dict(self):
        """
        Returns a dict of columns, indexed by name

        :return: Dict of columns
        :rtype: dict[str, Column]
        """
        return dict([(c.name, c) for c in self.columns])

    def diff(self, schema, cols_to_exclude=[]):
        """
        general use will be to compare current oracle schema to hive schema
        :param schema: schema to compare to. generally hive schema
        :param col_to_exclude: option columns to exclude from compare
        :return: tupe of (missing, diff)  diff is a dict, key is oracle column and value is hive column
        """

        cols_to_compare = schema.columns_as_dict()
        missing = []
        diffs = []
        for c in self.columns:
            if c.name in cols_to_exclude:
                continue

            c2 = cols_to_compare.get(c.name)
            if not c2:
                missing.append(c)
            elif not c.is_same(c2):
                diffs[c] = c2

        return missing, diffs

    def full_diff(self, target_schema):
        """
        Diff target schema against this schema, and return new, missing, and changed cols in target schema as a tuple

        :param target_schema: Target hive schema
        :type target_schema: Schema
        :return: Tuple of (new, missing, modified) where new is a list of new items in target_schema,
        missing is a list of missing items in target schema, and modified is a list of tuples (name, this_field, target_field)
        representing modifications
        :rtype: tuple[list]
        """

        net_new = []
        net_missing = []
        net_change = []

        my_cols = self.columns_as_dict()
        their_cols = target_schema.columns_as_dict()

        my_names = set(x.lower() for x in my_cols.iterkeys())
        their_names = set(x.lower() for x in their_cols.iterkeys())

        net_new = [their_cols[x] for x in their_names.difference(my_names)]
        net_missing = [my_cols[x] for x in my_names.difference(their_names) if not x.startswith('deleted_')]
        net_changed = []
        common_names = my_names.intersection(their_names)
        for c in common_names:
            if not their_cols[c].is_same(my_cols[c]):
                net_changed.append((c, my_cols[c], their_cols[c]))

        return net_new, net_missing, net_changed

    def __str__(self):
        from pprint import pformat
        return pformat({
            'table': self.table,
            'columns':self.column_names()
        })


def resolve_env_and_server(use_hist=False, appenv=None, vendor='oracle', use_rpt=False, bigdata_cluster='', oracle_db='' ):
    """
    :param use_hist:  adds _hist to db look up
    :param appenv:    dev|beta|prod|bda|mapr
    :param vendor:    oracle|iq|iq_mtg|sybase
    :param use_rpt:   use rpt2 db.  use rpt for prod for now
    :param bigdata_cluster:  bda|mapr
    :param oracle_db:  blank is oraprdpim.  others attrib,  which will map to oraprdattr
    :return:
    """

    key = '{VENDOR}'
    env = None
    if use_rpt:
        key = '%s_%s' %(key, 'rpt2')
        env = 'rpt'
    elif use_hist:
        key = '%s_%s' % (key, 'hist')
        env = 'hist'
    elif oracle_db:
        key = '%s_%s' % (key, oracle_db.lower())

    if bigdata_cluster:
        key = '%s_%s' % (key, bigdata_cluster.lower())
        env = bigdata_cluster

    env = (appenv or config_api.get('appenv')) if not env else env

    if 'oracle' in vendor:
        key = '{VENDOR}_rpt' if key == '{VENDOR}' else key
        key = key.format(VENDOR='oracle')
    elif 'iq' in vendor:
        key = key.format(VENDOR='sybaseiq')
    elif 'iq_mtg' in vendor:
        key = key.format(VENDOR='sybaseiq')
        key = 'sybaseiq_mtg' if env != 'hist' else key
    elif 'sybase' in vendor:
        key = key.format(VENDOR='sybase')

    server = config_api.get(key)
    return env, server


class OracleSchema(Schema):
    """
    Class representing oracle table schema
    """
    def __init__(self, table, use_hist=False, user=None, passwd=None, appenv=None, initial_load=True, vendor='oracle',
                 server='', oracle_db=''):
        """
        Create soracle table schema representation

        :param table: Name of the table
        :type table: str
        :param use_hist: Use historical database
        :type use_hist: bool
        :param user: Username used to connect to db (optional for kerberos)
        :type user: str
        :param passwd: Password used to connect to db (optional for kerberos)
        :type passwd: str
        :param initial_load: If true, grab schema data from oracle. Empty schema if false
        :type initial_load: bool
        """

        if not server:
            env, server = resolve_env_and_server(use_hist, appenv, vendor, oracle_db=oracle_db)
        else:
            env = 'hist' if use_hist else (appenv or config_api.get('appenv'))

        self.env = env
        self.server = server
        self.user = user
        self.passwd = passwd
        self.__initial_load = initial_load
        self.columns = []

        Schema.__init__(self, table, vendor)

    def load(self):
        """
        Loads schema data from the underlying oracle table
        """

        if not self.__initial_load:
            return

        owner, table = self.table.split('.')
        sql = ORACLE_SCHEMA_SQL % (owner.upper(), table.upper())

        cols = self._query_cols(sql)
        cols_dict = dict([(c.name, c) for c in cols])
        col_names_ordered = [c[0].lower() for c in self._query_schema()]

        for c in col_names_ordered:
            self.columns.append(cols_dict.get(c))

    def get_cols(self, include_partition_cols=True):

        """
        get the list of columns

        :param include_partition_cols:  ignore as oracle re-uses parition key as part of col.
                this is diff to hive where parition key is seperate from table
        :return: List of columns
        :rtype: list[Column]
        """
        return self.columns

    def convert_to_hive_cols(self, use_integer=False):
        """
        Converts oracle columns to hive columns performing necessary data type adjustments

        :return: List of hive columns
        :rtype: list[Column]
        """
        cols = []
        for c in self.columns:
            new_col = copy.deepcopy(c)
            new_col.type = db_to_hive_type(new_col.type, new_col.scale, new_col.precision, use_integer)
            new_col.is_null = False

            if new_col.type != 'decimal' and new_col.type != 'numeric':
                new_col.scale = None
                new_col.precision = None
                new_col.size = None
            cols.append(new_col)

        return cols

    def as_hive_cols(self):
        """
        Converts oracle columns to hive columns and returns their string definitions for use with CREATE TABLE

        :return: List of hive column definitions
        :rtype: list[str]
        """
        cols = self.convert_to_hive_cols()
        cols = ["%s %s" % (c.name, c.type_str()) for c in cols]
        return cols

    def _query_cols(self, sql):
        """
        Runs a query to grab column info from oracle and converts result to list of columns

        :param sql: SQL which grabs column info from oracle
        :return: list of columns
        :rtype: list[Column]
        """
        with sql_db.SqlDb(self.server, vendor='oracle', user=self.user, password=self.passwd, log=False) as db:
            rows = db.query(sql, log=False)
        return [Column(r[0].lower(),  r[4], r[5], r[3], r[2], r[1]) for r in rows]

    def _query_schema(self):
        """
        Returns table schema as seen by the database cursor

        :return:
        """
        owner, table = self.table.split('.')
        with sql_db.SqlDb(self.server, vendor='oracle', user=self.user, password=self.passwd, log=False) as db:
            return db.schema(owner, table)

    def partitions(self):
        """
        Returns dataframe containing list of oracle partitions

        :return: Dataframe
        :rtype: pandas.DataFrame
        """
        owner, table = self.table.split('.')
        sql = """
            select table_name, partition_name, num_rows
            FROM all_tab_partitions 
            WHERE table_owner = '%s'
            AND table_name =  '%s'
        """ %  (owner.upper(), table.upper())

        with sql_db.SqlDb(self.server, vendor='oracle', user=self.user, password=self.passwd) as db:
            return db.query_as_df(sql, log=False)

class SybaseSchema(OracleSchema):

    def __init__(self, table, use_hist=False, user=None, passwd=None, appenv=None, initial_load=True, vendor='sybase'):
        """
        Create sybase schema  ( default is Sybase IQ )

        :param table: Name of the table
        :type table: str
        :param use_hist: Use historical database
        :type use_hist: bool
        :param user: Username used to connect to db (optional for kerberos)
        :type user: str
        :param passwd: Password used to connect to db (optional for kerberos)
        :type passwd: str
        :param initial_load: If true, grab sch/_querema data from oracle. Empty schema if false
        :type initial_load: bool
        """
        self.__initial_load = initial_load
        OracleSchema.__init__(self, table, use_hist, user, passwd, appenv, initial_load, vendor=vendor)

    def load(self):
        """
        Loads schema data from the underlying oracle table
        """

        if not self.__initial_load:
            return

        owner, table = self.table.split('..')  # Sybase is ".." that for schema
        sql = SYBASE_SCHEAMA_SQL % (owner.lower(), table.lower())

        OracleSchema.columns = []
        cols = self._query_cols(sql)
        cols_dict = dict([(c.name, c) for c in cols])
        col_names_ordered = [c[0].lower() for c in self._query_schema()]

        for c in col_names_ordered:
            self.columns.append(cols_dict.get(c))

    def _query_cols(self, sql):
        """
        Runs a query to grab column info from oracle and converts result to list of columns

        :param sql: SQL which grabs column info from oracle
        :return: list of columns
        :rtype: list[Column]
        """

        with sql_db.SqlDb(self.server, vendor=self.vendor, user=self.user, password=self.passwd, log=False) as db:
            rows = db.query(sql, log=False)
        return [Column(r[0].lower().rstrip(), r[4].rstrip(), r[5], r[3], r[2], r[1]) for r in rows]

    def _query_schema(self):
        """
        Returns table schema as seen by the database cursor

        :return:
        """
        owner, table = self.table.split('..')
        with sql_db.SqlDb(self.server, vendor=self.vendor, user=self.user, password=self.passwd) as db:
            return db.schema(owner, table)


    def partitions(self):
        import pandas as pd
        return pd.DataFrame()

class SybaseIQSchema(SybaseSchema):

    def __init__(self, table, use_hist=False, user=None, passwd=None, appenv=None, initial_load=True, vendor='iq'):
        """
        Create sybase schema  ( default is Sybase IQ )

        :param table: Name of the table
        :type table: str
        :param use_hist: Use historical database
        :type use_hist: bool
        :param user: Username used to connect to db (optional for kerberos)
        :type user: str
        :param passwd: Password used to connect to db (optional for kerberos)
        :type passwd: str
        :param initial_load: If true, grab schema data from oracle. Empty schema if false
        :type initial_load: bool
        """

        SybaseSchema.__init__(self, table, use_hist, user, passwd, appenv, initial_load, vendor=vendor)


class Column(object):
    """
    Database table column schema representation
    """
    def __init__(self, name, type, is_null=False, size=None, scale=None, precision=None):
        """
        Creates column schema representation

        :param name: Name of the column
        :param type: Type of the column
        :type type: str
        :param is_null: Nullability of the column
        :type is_null: bool
        :param size: Size of the column (for char/varchar/etc)
        :type size: int
        :param scale: Scale of the column (for decimals)
        :type scale: int
        :param precision: Precision of the column (for decimals)
        :type precision: int
        """
        self.name = name
        self.type = type
        self.is_null = is_null

        if type.lower() in ('number', 'decimal', 'numeric'):
            size = None
            if precision is None:
                precision = 38
            if scale is None:
                scale = 18
        elif type.lower() in ('float', 'double'):
            size = None
            scale = None
            precision = None

        else:
            scale = None
            precision = None

        self.scale = scale
        self.size = size
        self.precision = precision

    def is_same(self, hive_col):
        """
        Compares two columns and returns if they are same. For decimals, columns will be same if hive_col can fit at least
        same scale/precision numbers.

        :param hive_col: Hive columns
        :return: True if columns are same
        :rtype: bool
        """
        hive_type = db_to_hive_type(self.type, self.scale, self.precision)
        other_hive_type = db_to_hive_type(hive_col.type, hive_col.scale, hive_col.precision)

        if hive_col.type == hive_type:
            if hive_type == 'decimal':
                # hleft, hright = hive_col.precision - hive_col.scale, hive_col.scale
                # left, right = self.precision - self.scale, self.scale
                #
                # return hleft >= left and hright >= right
                if self.precision != hive_col.precision:
                    return False

                #if (self.scale and hive_col.scale) and (self.scale == 0 or hive_col.scale == 0):
                #    if self.scale != hive_col.scale:
                #        return False
            return True
        else:
            ### are the data types change and this causes issue in current implementation
            ### TODO FIX ME!
            return False

    def type_str(self):
        return '%s%s' % (self.type, (('(%s)' % self.size)
                                     if self.size
                                     else ('(%s,%s)' % (self.precision, self.scale)
                                           if self.precision is not None and self.scale is not None
                                           else '')))

    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return self.name == other.name
        return False

    def equals(self, other):
        if not isinstance(other, Column):
            return False

        return self.name == other.name and self.type_str() == other.type_str()

    def __hash__(self):
        return hash(self.name)

    def __repr__(self):
        return '%s %s' % (self.name, self.type_str())

    def __str__(self):
        return self.__repr__()

    def to_dict(self):
        """
        Converts this object to dict

        :return: Dict containing fields of this object
        :rtype: dict
        """
        return dict(name=self.name, type=self.type, size=self.size, scale=self.scale, precision=self.precision,
                    is_null=self.is_null)

    def clone(self):
        """
        Clones a column
        :return: Cloned copy
        :rtype: Column
        """
        return Column.from_dict(self.to_dict())

    @staticmethod
    def from_dict(d):
        """
        Populates this object from a dict

        :param d:
        :return: Column object
        :rtype: Column
        """
        return Column(**d)

ORACLE_SCHEMA_SQL = """
SELECT
    column_name,
    data_precision,
    data_scale,
    data_length,
    data_type,
    nullable "Null"
FROM all_tab_columns
WHERE owner = '%s'
AND table_name = '%s'
order by column_name desc
"""

SYBASE_SCHEAMA_SQL = """
select 
    a.column_name,
    a.width as data_precision,
    a.scale as data_scale,
    a.width as data_length,
    c.domain_name as data_type,
    a.nulls as "Nulls"
from systabcol a
join systab b ON a.table_id = b.table_id
join sysdomain c ON a.domain_id = c.domain_id
where b.object_id IN (
    select id
    from sysobjects
    where type = 'U'
    and user_name(sysobjects.uid) = '%s'
    and name = '%s'
  )
order by a.column_name desc
"""








