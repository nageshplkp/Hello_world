from decorate import CONN_MAP
from sql_db import rows_of_dicts, single_value
from core.db.conn_pool import connect
from core.db import conn_pool
from core.db import sql_update
import pandas as pd
from core.common.decorate import Deprecated


def db_dict():
    """    
    :return: dataframe with env and conn combination and database server it's mapped to for  sql_query module 
    """
    from decorate import db_map as db_list
    return db_list()

def query(sql, params=None, conn='default', env='default', include_cols=None, log=True, input_sizes=None,
          param_transformer=None):
    """
    Runs sql against the database and returns the result as a list of lists
    
    :param sql: SQL query to run
    :type sql: str
    :param params: A list of bind var values if using positional binding. A dict of bind var values if using named binding.
    :type params: list | dict
    :param conn: Name of the connection (e.g. oracle, sybase, impala_bda) 
    :type conn: str
    :param env: Connection environment (prod, prodwrite, beta, etc)
    :type env: str
    :param log: Log query text
    :type log: bool
    :param input_sizes:  Input sizes for bind vars. List for positionals, dict for named bind vars.
    :type input_sizes: list | dict
    :param param_transformer: A lambda taking a cursor and a list|dict of bind vars and returning a transformed list|dict. 
     Useful when string bind values need to be transformed to LOBs
    :type param_transformer: function
    :param include_cols: Include column names as the first row of result
    :type include_cols: bool
    :return: Result as list of lists
    :rtype: list[list]
    """
    if not sql:
        return

    _db = connect(conn, env)
    cols = [] if include_cols else None
    rows = _db.query(sql, params, cols, log=log, input_sizes=input_sizes, param_transformer=param_transformer)

    return ([cols] + rows) if include_cols else rows


def query_as_dicts(sql, params=None, conn='default', env='default', log=True, input_sizes=None, param_transformer=None):
    """
    Runs sql against the database and returns the result as a list of dicts
    
    :param sql: SQL query to run
    :type sql: str
    :param params: A list of bind var values if using positional binding. A dict of bind var values if using named binding.
    :type params: list | dict
    :param conn: Name of the connection (e.g. oracle, sybase, impala_bda) 
    :type conn: str
    :param env: Connection environment (prod, prodwrite, beta, etc)
    :type env: str
    :param log: Log query text
    :type log: bool
    :param input_sizes:  Input sizes for bind vars. List for positionals, dict for named bind vars.
    :type input_sizes: list | dict
    :param param_transformer: A lambda taking a cursor and a list|dict of bind vars and returning a transformed list|dict. 
     Useful when string bind values need to be transformed to LOBs
    :type param_transformer: function
    :return: Result as list of dicts
    :rtype: list[dict]
    """
    if not sql:
        return

    _db = connect(conn, env)
    cols = []
    rows = _db.query(sql, params, columns=cols, log=log, input_sizes=input_sizes, param_transformer=param_transformer)

    return rows_of_dicts(rows, cols)


def query_as_dataframe(sql, params=None, conn='default', env='default', log=True, input_sizes=None,
                       param_transformer=None):
    """
    Runs sql against the database and returns the result as a dataframe
    
    :param sql: SQL query to run
    :type sql: str
    :param params: A list of bind var values if using positional binding. A dict of bind var values if using named binding.
    :type params: list | dict
    :param conn: Name of the connection (e.g. oracle, sybase, impala_bda) 
    :type conn: str
    :param env: Connection environment (prod, prodwrite, beta, etc)
    :type env: str
    :param log: Log query text
    :type log: bool
    :param input_sizes:  Input sizes for bind vars. List for positionals, dict for named bind vars.
    :type input_sizes: list | dict
    :param param_transformer: A lambda taking a cursor and a list|dict of bind vars and returning a transformed list|dict. 
     Useful when string bind values need to be transformed to LOBs
    :type param_transformer: function
    :return: Result as dataframe
    :rtype: pd.DataFrame
    """
    _db = connect(conn, env)
    return _db.query_as_df(sql, params, log=log, input_sizes=input_sizes, param_transformer=param_transformer)


def query_single_value(sql, params=None, conn='default', env='default', log=True, input_sizes=None,
                       param_transformer=None):
    """
    Runs sql against the database and returns the first item of the first row
    
    :param sql: SQL query to run
    :type sql: str
    :param params: A list of bind var values if using positional binding. A dict of bind var values if using named binding.
    :type params: list | dict
    :param conn: Name of the connection (e.g. oracle, sybase, impala_bda) 
    :type conn: str
    :param env: Connection environment (prod, prodwrite, beta, etc)
    :type env: str
    :param log: Log query text
    :type log: bool
    :param input_sizes:  Input sizes for bind vars. List for positionals, dict for named bind vars.
    :type input_sizes: list | dict
    :param param_transformer: A lambda taking a cursor and a list|dict of bind vars and returning a transformed list|dict. 
     Useful when string bind values need to be transformed to LOBs
    :type param_transformer: function
    :return: First item of the first row
    """
    return single_value(query(sql, params, conn, env, include_cols=False, log=log, input_sizes=input_sizes,
                              param_transformer=param_transformer))


def set_default_env(conn='oracle', env='prod'):
    """
    Set what conn=default env=default connections map to

    :param conn: Default connection name
    :param env: Default environment
    :return: Nothing
    """
    dbname = CONN_MAP[conn + '.' + env]
    CONN_MAP['default.default'] = dbname
    CONN_MAP['default.vendor'] = conn


def close(conn='default', env='default'):
    """
    force clean up connection pool 
    """
    conn_pool.close(conn, env)


def execute(sql, params=None, conn='default', env='default', commit=True):
    """
    Execute SQL that doesn't return results and return number of rows affected

    :param sql: SQL query to run
    :type sql: str
    :param params: List or dict of bind params. List for positionals, dict for named params
    :type params: list|dict
    :param conn: Name of the connection (e.g. oracle, sybase, impala_bda) 
    :type conn: str
    :param env: Connection environment (prod, prodwrite, beta, etc)
    :type env: str
    :param commit: If true, perform commit if execution is successful.
    :type commit: bool
    :return: 
    """
    _db = connect(conn, env)
    return _db.execute(sql, params, commit=commit)


@Deprecated("Deprecated method, use sql_update.insert()")
def insert(dataframe, table_name, conn='default', env='default', columns=None, pk_source='row', pk_columns=None):
    """
    @DEPRECATED,  use sql_update.insert()
    """
    return sql_update.insert(dataframe, table_name, conn, env, columns, pk_source, pk_columns)

@Deprecated("Deprecated method, use sql_update.update()")
def update(dataframe, table_name, pk_columns, conn='default', env='default', columns=None, pk_source='row'):
    """
    @DEPRECATEED, use sql_update.update()    
    """
    return sql_update.update(dataframe, table_name, pk_columns, conn, env, columns, pk_source)

@Deprecated("Deprecated method, use sql_update.upsert()")
def upsert(dataframe, table_name, pk_columns, conn='default', env='default', columns=None, pk_source='row'):
    """
    @DEPRECATED use sql_update.upsert()
    """
    return sql_update.upsert(dataframe, table_name, pk_columns, conn, env, columns, pk_source)

@Deprecated("Deprecated method, use sql_update.delete()")
def delete(dataframe, table_name, conn='default', env='default', pk_columns=None, pk_source='row'):
    """
    @DEPRECATED, use sql_update.delete()
    """
    return sql_update.delete(dataframe, table_name, conn, env, pk_columns, pk_source)


