from core.common import util
import datetime

__iq_configured = False

def configure_sybase_iq():
    """
    Configures sybase iq library paths
    """
    global __iq_configured
    if __iq_configured:
        return

    import os.path
    if util.isWindows():
        os_path = os.environ['PATH'].split(';') or []
        found_dbcapi = False
        for op in os_path:
            if os.path.isfile(os.path.join(op, 'dbcapi.dll')):
                found_dbcapi = True

        if not found_dbcapi:
            os_path.insert(0, r'W:\pm\vendor\sybase\win64\client_15\IQ-15_4\Bin64')
        os.environ['PATH'] = ';'.join(os_path)
    __iq_configured = True


def _connect(sql_db):
    try:
        _connect_(sql_db)
    except Exception, ex:
        import logging
        from pprint import pformat
        d = dict(
            server=sql_db.server,
            vendor=sql_db.vendor,
            user=sql_db.user            
        )
        logging.error('Connection error, details:\n%s' % pformat(d))
        raise ex

def _connect_(sql_db):
    if 'oracle' in sql_db.vendor.lower():
        if util.isWindows():
            import os, os.path
            env_oracle_home = os.environ.get('PYPIMLIB_ORACLE_HOME', r"W:\pm\vendor\oracle\win64\client_11.2.0")
            os.environ['ORACLE_HOME'] = env_oracle_home
            if env_oracle_home not in (os.environ['PATH'] or '').split(os.pathsep):
                os.environ['PATH'] = os.path.join(env_oracle_home) + os.pathsep + os.environ.get('PATH')
            if os.path.isfile(r'C:\oracle\product\11.2.0\client_32\Network\Admin\tnsnames.ora'):
                os.environ['TNS_ADMIN'] = r'C:\oracle\product\11.2.0\client_32\Network\Admin'
        import cx_Oracle
        # print '%s  %s  %s' %(sql_db.user, sql_db.password, sql_db.server)
        user = '' if not sql_db.user else sql_db.user
        password = '' if not sql_db.password else sql_db.password
        if sql_db.useDsn:
            sql_db._conn = cx_Oracle.Connection(user, password, dsn=sql_db.server)
        else:
            sql_db._conn = cx_Oracle.Connection(user, password, sql_db.server, **sql_db.options)
    elif 'sybase' in sql_db.vendor.lower() or 'iq' in sql_db.vendor.lower():
        if util.isWindows():
            import pyodbc
            import os
            os.environ['SYBASE'] = os.environ.get('PYPIMLIB_SYBASE_HOME', r'W:\pm\vendor\sybase\win64\client_15')

            if 'iq' in sql_db.vendor.lower():
                configure_sybase_iq()
                driver = '{Sybase IQ}'
            else:
                driver = '{Adaptive Server Enterprise}'
            dsn = 'DRIVER=%s;DSN=sybase;UID=%s;PWD=%s;SRVR=%s' % (
                driver, sql_db.user, sql_db.password, sql_db.server)

            kwargs = {}
            options = sql_db.options.copy()
            options.pop('datetime', None)   # only for linux driver
            kwargs['ansi'] = sql_db.options.pop('ansi', None)
            kwargs['attrs_before'] = options.pop('attrs_before', None)
            kwargs['autocommit'] = options.pop('autocommit', 1)
            kwargs['encoding'] = options.pop('encoding', None)
            kwargs['readonly'] = options.pop('readonly', None)
            kwargs['timeout'] = options.pop('timeout', None)

            kwargs = dict((x, y) for x, y in kwargs.iteritems() if y is not None)

            options = ';'.join(('%s=%s' % i for i in options.iteritems()))
            if options:
                dsn = dsn + ';' + options
            sql_db._conn = pyodbc.connect(dsn, **kwargs)
        else:
            import Sybase
            options = _normalize_linux_sybase_options(sql_db.options.copy())
            sql_db._conn = Sybase.connect(sql_db.server, sql_db.user, sql_db.password, **options)
    elif 'impala' in sql_db.vendor.lower():
        from impala.dbapi import connect
        h, p = sql_db.server.split(':')
        user = util.username() if not sql_db.user else sql_db.user
        sql_db._conn = connect(host=h, port=int(p), user=user)

    elif 'hive' in sql_db.vendor.lower():
        import pyhs2
        h, p = sql_db.server.split(':')
        user = util.username() if not sql_db.user else sql_db.user

        sql_db._conn = pyhs2.connect(host=h,
                                   port=p,
                                   authMechanism="PLAIN",
                                   user=user,
                                   configuration=sql_db.session_config)

    elif 'mssql' in sql_db.vendor.lower():
        import pytds
        import re

        m = re.match(r'mssql://(?P<server>[^/:]+)(?:\:(?P<port>\d+))?(?:/(?P<database>.+))?', sql_db.server)
        if not m:
            raise Exception('Invalid connection string: %s' % sql_db.server)

        args = m.groupdict()
        tds_args = {}
        tds_args['dsn'] = args['server']
        if args['port'] > 1:
            tds_args['port'] = int(args['port'])
        if args['database']:
            tds_args['database'] = args['database']

        sql_db._conn = pytds.connect(user=sql_db.user, password=sql_db.password, **tds_args)
    else:
        raise Exception('Unsupported DB vendor %s  server=%s' % (sql_db.vendor, sql_db.server))


def _normalize_linux_sybase_options(options):
    import Sybase

    _SybaseDateTimeAsPython = {
        Sybase.CS_DATETIME_TYPE: lambda val: val is not None and datetime.datetime(
            val.year, val.month + 1, val.day, val.hour, val.minute, val.second, val.msecond * 1000) or val,
        Sybase.CS_DATETIME4_TYPE: lambda val: val is not None and datetime.datetime(
            val.year, val.month + 1, val.day, val.hour, val.minute, val.second, val.msecond * 1000) or val }

    options['auto_commit'] = options.pop('autocommit', 1)

    # by default sybase driver returns sybasect.DateTimeType for datetime
    # this can be modified by sending in an option {'datetime': 'python'}
    if 'datetime' in options:   # we should probably default this behavior
        if options['datetime'] in ('python', 'auto'):
            options.pop('datetime')
            options['outputmap'] = _SybaseDateTimeAsPython
    return options
