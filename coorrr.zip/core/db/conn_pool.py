import datetime
from core.db.decorate import CONN_MAP
from .sql_db import SqlDb
import logging
import itertools


class PooledConnection(SqlDb):
    '''
    Class representing pooled sql db connection. 
    Do not create instances of this class. 
    '''
    def __init__(self, pool, *args, **kwargs):
        super(PooledConnection, self).__init__(*args, **kwargs)
        self.pool = pool

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close(pool_closing=False)

    def close(self, pool_closing=False):
        '''
        Returns connection to the pool, or if pool is closing, closes the connection
        
        :param pool_closing: True if the owner pool is closing, false otherwise. Never set this to True in code.
        :return: 
        '''
        if pool_closing:
            super(PooledConnection, self).close()
        else:
            self.pool._return_connection(self)

    def __del__(self):
        self.close(pool_closing=False)


class SqlDbPool(object):

    def __init__(self, server='default', vendor='default', env='default',
                 user='', password='', options=None, session_config={}, log=True, useDsn=False,
                 max_size=3, min_size=1, test_on_obtain='', name=''):
        """
        Creates a pool of SqlDb objects. The object implements a context manager and will close all underlying connections
        if required. If not using with the context manager, please call the close method. The pool will attempt to destroy 
        underlying connections if the reference to it is destroyed.
        :param server: Server to connect to, or 'default'
        :param vendor: Server's vendor, or 'default'
        :param env: Environment from which to lookup server name if server='default', or 'default'
        :param user: Username used to connect
        :param password: Password used to connect
        :param options: Connection options (for some vendors)
        :param session_config: Session config (for some vendors)
        :param log: If true, will log every statement
        :param useDsn: For some vendors, treat server as DSN (like odbc dsn)
        :param max_size: Max pool size
        :param min_size: Min pool size
        :param test_on_obtain: Test on obtain SQL statement. If empty string, a default one will be generated for the vendor.
        If None, test_on_obtain will not be performed.
        :param name: Pool name, empty string by default.
        """

        self.__max_size = max_size
        self.__min_size = min_size

        if max_size < 1:
            raise Exception('Max size must be greater than 1')
        if not (0 < min_size <= max_size):
            raise Exception('Min size falls outside of (0, max_size)')

        if (server is None or server == 'default'):
            server, vendor = _server_conn_from_conn_env(vendor, env)

        self.__conn_args = dict(server=server, vendor=vendor, user=user, password=password, options=options,
                                session_config=session_config, log=log, useDsn=useDsn)

        if test_on_obtain == '':
            if vendor == 'oracle':
                test_on_obtain = 'SELECT 1 from dual'
            else:
                test_on_obtain = 'SELECT 1'

        self.test_on_obtain = test_on_obtain

        self.__connections = []
        self.__obtained_connections = []
        self.name  = name or []
        self.logger = logging.getLogger('SqlDbPool[%s][%s]' % (vendor, self.name))

        self.__resize_pool()

    @property
    def connection_args(self):
        """
        Args used to create underlying SqlDb
        
        :return: Dict that can be passed as kwargs to SqlDb constructor
        :rtype: dict
        """
        return dict(self.__conn_args)

    @property
    def min_size(self):
        """
        Min pool size
        
        :rtype: int
        """
        return self.__min_size

    @property
    def max_size(self):
        """
        Max pool size
        
        :rtype: int
        """
        return self.__max_size

    @property
    def available_connections(self):
        """
        Number of available connections in the pool
        
        :rtype: int
        """
        return len(self.__connections)

    @property
    def active_connections(self):
        """
        Number of in-use connections in the pool
        
        :rtype: int 
        """
        return len(self.__obtained_connections)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self):
        """
        Closes the pool and all the underlying connections
        """
        for conn in itertools.chain(self.__connections, self.__obtained_connections):
            try:
                conn.close(pool_closing=True)
            except Exception, ex:
                self.logger.warn('Error closing connection: %s', str(ex))

        self.__connections = []
        self.__obtained_connections = []

    def __del__(self):
        self.close()

    def __resize_pool(self):
        while len(self.__obtained_connections) + len(self.__connections) < self.min_size:
            self.__connections.append(PooledConnection(self, **self.__conn_args))

        while len(self.__obtained_connections) + len(self.__connections) > self.max_size \
            and len(self.__connections) > 0:
            try:
                self.__connections[-1].close(pool_closing=True)
            except Exception, ex:
                self.logger.warn('Error closing connection: %s', str(ex))

            self.__connections.remove(self.__connections[-1])

    def get_connection(self):
        """
        Obtains a connection from the pool
        
        :return: SqlDb object
        :rtype: SqlDb
        """
        conn = None
        while len(self.__connections) > 0:
            conn = self.__connections[0]
            if self.test_on_obtain:
                try:
                    conn.query(self.test_on_obtain, log=False)
                except Exception, ex:
                    self.logger.warn('Connection seems to be expired: %s', str(ex))
                    self.__connections.remove(conn)
                    conn = None
                    continue
            self.__connections.remove(conn)
            break

        if conn is None:
            conn = PooledConnection(self, **self.__conn_args)
        self.__obtained_connections.append(conn)
        return conn

    def _return_connection(self, conn):
        """
        Returns the connection back to the pool. 
        Please never call this method directly. To return the connection to the pool, call close method on the obtained
        connection.
        
        :param conn: 
        :return: 
        """
        if conn not in self.__obtained_connections:
            return

        if len(self.__obtained_connections) + len(self.__connections) > self.max_size:
            conn.close(pool_closing=True)
        else:
            self.__connections.append(conn)

        self.__obtained_connections.remove(conn)


class SharedConnectionPool(SqlDbPool):

    def __init__(self,server='default', vendor='default', env='default',
                 user='', password='', options=None, session_config={}, log=True, useDsn=False,
                 test_on_obtain='', name=''):
        """
        Creates a pool which only has one connection and that returns that single connection for every connection request.
        
        :param server: Server to connect to, or 'default'
        :param vendor: Server's vendor, or 'default'
        :param env: Environment from which to lookup server name if server='default', or 'default'
        :param user: Username used to connect
        :param password: Password used to connect
        :param options: Connection options (for some vendors)
        :param session_config: Session config (for some vendors)
        :param log: If true, will log every statement
        :param useDsn: For some vendors, treat server as DSN (like odbc dsn)
        :param test_on_obtain: Test on obtain SQL statement. If empty string, a default one will be generated for the vendor.
        If None, test_on_obtain will not be performed.
        :param name: Pool name, empty string by default. 
        """
        super(SharedConnectionPool, self).__init__(server=server,
                                                   vendor=vendor,
                                                   env=env,
                                                   user=user,
                                                   password=password,
                                                   options=options,
                                                   session_config=session_config,
                                                   log=log,
                                                   useDsn=useDsn,
                                                   min_size=1,
                                                   max_size=1,
                                                   test_on_obtain=test_on_obtain,
                                                   name=name)
        self.__connection = None

    def get_connection(self):
        """
        Gets the sql db connection
        
        :return: SqlDb
        :rtype: SqlDb
        """
        if self.__connection == None:
            self.__connection = super(SharedConnectionPool, self).get_connection()
        else:
            if self.test_on_obtain:
                try:
                    self.__connection.query(self.test_on_obtain, log=False)
                except:
                    super(SharedConnectionPool, self)._return_connection(self.__connection)
                    self.__connection = None
                    self.__connection = super(SharedConnectionPool, self).get_connection()
        return self.__connection

    def _return_connection(self, conn):
        pass


class SharedConnectionPoolManager(object):
    def __init__(self):
        """
        Holds multiple SharedConnection pools
        """
        self.__pool_cache = {}

    def get_pool(self, server='default', vendor='default', env='default',
                 user='', password='', options=None, session_config={}, log=True, useDsn=False,
                 test_on_obtain='', name=''):
        """
        Gets or creates a connection pool using specified paramteters. Pools are considered to be same 
        if server, vendor, and name are same.
        
        :param server: Server to connect to, or 'default'
        :param vendor: Server's vendor, or 'default'
        :param env: Environment from which to lookup server name if server='default', or 'default'
        :param user: Username used to connect
        :param password: Password used to connect
        :param options: Connection options (for some vendors)
        :param session_config: Session config (for some vendors)
        :param log: If true, will log every statement
        :param useDsn: For some vendors, treat server as DSN (like odbc dsn)
        :param test_on_obtain: Test on obtain SQL statement. If empty string, a default one will be generated for the vendor.
        If None, test_on_obtain will not be performed.
        :param name: Pool name, empty string by default. 
        :rtype: SharedConnectionPool
        """
        name = name or 'default'
        if (server is None or server == 'default'):
            server, vendor = _server_conn_from_conn_env(vendor, env)

        uuid = '%s.%s.%s' % (server, vendor, name)
        if uuid not in self.__pool_cache:
            self.__pool_cache[uuid] = SharedConnectionPool(server=server, vendor=vendor, env=env,
                                                           user=user, password=password, options=options,
                                                           session_config=session_config, log=log,
                                                           useDsn=useDsn, test_on_obtain=test_on_obtain,
                                                           name=name)

        return self.__pool_cache[uuid]

_DEFAULT_POOL_MANAGER = SharedConnectionPoolManager()


def connect(conn='default', env='default'):
    """
    Gets default connection for (conn,env)
    
    :param conn: 
    :param env: 
    :return: SqlDb
    :rtype: SqlDb
    """
    return _DEFAULT_POOL_MANAGER.get_pool(vendor=conn, env=env).get_connection()

def close(conn='default', env='default'):
    _DEFAULT_POOL_MANAGER.get_pool(vendor=conn, env=env).close()

def _server_conn_from_conn_env(conn, env):
    server = CONN_MAP.get('%s.%s' % (conn, env))
    if not server and conn == 'default':
        server = CONN_MAP.get('%s.%s' % (CONN_MAP.get('default.vendor'), env))
    if isinstance(server, tuple):
        server, conn = server
    server_resolved = bool(server)
    if not server_resolved:
        server = conn
    if conn == 'default' or not server_resolved:
        conn = CONN_MAP.get('default.vendor')

    if 'hive' in conn:
        conn = 'hive'
    elif 'impala' in conn:
        conn = 'impala'
    return server, conn