import collections
import datetime
import itertools
import logging
import pandas as pd
from core.common import util
from core.common.util import transform_np2py
from functools import partial

"""
Implementation of sql_db.SqlDb class.
Check sql_db.SqlDb class for param definitions
"""

def _query(sql_db, sql, params={}, columns=None, fetchAll=True, bindarraysize=10000, log=True, oracle_unicode=False,
          input_sizes=None, param_transformer=None):
    try:
        params = params or {}
        cur = sql_db.cursor()
        params = __setup_cursor(sql_db, cur, params, bindarraysize, input_sizes, param_transformer)
        __setup_connection(sql_db, oracle_unicode)
        if params:
            cur.execute(sql, params)
        else:
            cur.execute(sql)

        if columns is not None:
            if hasattr(cur, 'description'):
                map(lambda x: columns.append(x[0]), cur.description)
            else:
                map(lambda x: columns.append(x.get('columnName')), cur.getSchema())

        if log:
            sql_db._log(sql, params)

        if fetchAll:
            return cur.fetchall()

        return cur
    except Exception, e:
        msg = 'db query error %s, %s\n%s' % (sql, params, util.exceptionAsStr(e))
        raise Exception(msg)
    finally:
        if fetchAll:
            sql_db._closeCur(cur)

def _query_as_df(sql_db, sql, params=None, log=True, input_sizes=None, param_transformer=None, coerce_float=False):
    read_sql_args = dict(con=sql_db._conn)
    if params is not None:
        read_sql_args['params'] = params

    if 'impala' in sql_db.vendor:
        from impala.util import as_pandas
        cur = sql_db.query(sql, params=params,fetchAll=False, log=log)
        df = as_pandas(cur)
        if coerce_float:
            df = pd.DataFrame.from_records(df, coerce_float=True)

        sql_db._closeCur(cur)
        return df
    elif 'hive' in sql_db.vendor:
        cur = sql_db.query(sql, params=params,fetchAll=False, log=log)
        rows = cur.fetchall()
        cols = [s['columnName'] for s in cur.getSchema()]
        df = pd.DataFrame(data=rows, columns=cols)
        sql_db._closeCur(cur)
        return df
    elif 'oracle' in sql_db.vendor:
        import cx_Oracle
        cur = sql_db.query(sql, params=params, fetchAll=False, log=log)
        columnNames = [desc[0] for desc in cur.description]
        columnTypes = [desc[1] for desc in cur.description]
        hasClobs = [idx for idx,col in enumerate(columnTypes) if col == cx_Oracle.CLOB]
        if hasClobs:
            rows = [[col.read() if isinstance(col, cx_Oracle.LOB) else col for col in row ]
                        for row in _query_stream(sql_db, sql, params=params, input_sizes=input_sizes, param_transformer=param_transformer, cur=cur)]
        else:
            rows = cur.fetchall()
            sql_db._closeCur(cur)
        return pd.DataFrame(data=rows, columns=columnNames)
    else:
        if log:
            sql_db._log(sql, params)
        return pd.read_sql_query(sql, params=params, con=sql_db._conn)

def _query_stream(sql_db, sql, params={}, bindarraysize=10000, log=True, oracle_unicode=False,
                     input_sizes=None, param_transformer=None, cur=None):
    try:
        params = params or {}
        if not cur:
            cur = sql_db.cursor()
        params = __setup_cursor(sql_db, cur, params, bindarraysize, input_sizes, param_transformer)
        __setup_connection(sql_db, oracle_unicode)
        if params:
            cur.execute(sql, params)
        else:
            cur.execute(sql)

        if log:
            sql_db._log(sql, params)

        cur.arraysize = 256
        for row in cur:
            yield row

    except Exception, e:
        msg = 'db query error %s, %s\n%s' % (sql, params, util.exceptionAsStr(e))
        raise Exception(msg)
    finally:
        sql_db._closeCur(cur)


def _insert(sql_db, dataframe, table_name, columns=None, pk_source='row', pk_columns=None, nanAndInfAsNone=False):
    if len(dataframe) == 0:
        return

    if not pk_columns and pk_source is 'index':
        raise Exception('pk_columns must not be empty if primary key source is index')

    last_chg_user = util.username()
    last_chg_date = datetime.datetime.now()

    if columns is None:
        columns = [x for x in dataframe.columns]

    d = [ ((x[0], x[1]) if isinstance(x, collections.Sequence) and not isinstance(x, basestring) else (x, str(x)))
            for x in columns]
    col_dict = collections.OrderedDict(d)

    col_series = collections.OrderedDict(
        (x, itertools.imap(partial(transform_np2py, nanAndInfAsNone=nanAndInfAsNone), dataframe[x])) for x in dataframe.columns if
        x in col_dict.keys())
    col_series = itertools.izip(*[col_series[x] for x in col_series.keys()])

    statement = 'INSERT INTO %s (%s) VALUES(%s)' % (
        table_name,
        ', '.join((pk_columns if pk_source == 'index' else []) + [col_dict[x] for x in col_dict.keys()]
                  + ['LAST_CHG_USER', 'LAST_CHG_DATE']),
        ', '.join(':%d' % i
                  for i in range(1, len(col_dict) + (len(pk_columns) if pk_source == 'index' else 0) + 3))
    )

    cur = sql_db.cursor()

    if pk_source == 'index':
        data = itertools.imap(
            lambda x, y: partial(transform_np2py, nanAndInfAsNone=nanAndInfAsNone)(__transform_index(x, len(pk_columns))) + y
                         + (last_chg_user, last_chg_date),
            dataframe.index, col_series)
    else:
        data = itertools.imap(lambda y: y + (last_chg_user, last_chg_date), col_series)

    try:
        data = list(data)
        values = []
        #oracle doesnt like pandas cdecimal.  little hack to convert
        import cdecimal, decimal
        def convert_dec(x):
            if isinstance(x, cdecimal.Decimal):
                return decimal.Decimal(str(x))
            return x

        for row in data:
            new_row = map(convert_dec, row)
            values.append(new_row)

        cur.prepare(statement)
        cur.executemany(None, values)
        sql_db._conn.commit()
    except:
        sql_db._conn.rollback()
        raise
    finally:
        sql_db._closeCur(cur)

def _insert_df(sql_db, df, table_name):
    columns = [x for x in df.columns]
    bindings = [':%d' % i for i in range(1, len(columns) + 1)]

    statement = 'INSERT INTO %s (%s) VALUES(%s)' % (
        table_name,
        ', '.join(columns),
        ', '.join(bindings)
    )

    data = df.values.tolist()
    cur = sql_db.cursor()
    try:
        cur.prepare(statement)
        cur.executemany(None, df.values.tolist())
        sql_db._conn.commit()
    finally:
        cur.close()


def _update(sql_db, dataframe, table_name, pk_columns, columns=None, pk_source='row', nanAndInfAsNone=False):
    if len(dataframe) == 0:
        return

    if not pk_columns:
        raise Exception('pk_columns must not be empty')

    last_chg_user = util.username()
    last_chg_date = datetime.datetime.now()

    if columns is None:
        columns = [x for x in dataframe.columns]

    col_dict = collections.OrderedDict(
        [
            ((x[0], x[1]) if isinstance(x, collections.Sequence) and not isinstance(x, basestring) else (
                x, str(x)))
            for x in columns
        ])

    col_series = collections.OrderedDict(
        (x, itertools.imap(transform_np2py, dataframe[x])) for x in dataframe.columns if x in col_dict.keys())

    if pk_source == 'row':
        df_pk = [kk for kk in col_dict.iterkeys() if col_dict[kk] in pk_columns]
        key_series = dict(
            (col_dict[k], col_series[k]) for k in df_pk)
        for k in df_pk:
            del col_series[k]
            del col_dict[k]

        for k in pk_columns:
            if k not in key_series:
                if k not in dataframe.columns:
                    raise Exception(
                        "Column for primary key %s is not found in the dataframe and no mapping is provided" % k)
                else:
                    key_series[k] = itertools.imap(partial(transform_np2py, nanAndInfAsNone=nanAndInfAsNone), dataframe[k])
        key_series = itertools.izip(*[key_series[k] for k in pk_columns])
    elif pk_source == "index":
        key_series = map(lambda x: partial(transform_np2py, nanAndInfAsNone=nanAndInfAsNone)(__transform_index(x, len(pk_columns))),
                         dataframe.index)
    else:
        raise Exception('Unknown pk_source: %s', pk_source)

    statement = 'UPDATE %s SET LAST_CHG_USER=:1, LAST_CHG_DATE=:2, %s WHERE %s' % (
        table_name,
        ', '.join('%s = :%d' % (col_dict[c], i + 3) for i, c in enumerate(col_dict.keys())),
        ' AND '.join('%s = :%d' % (c, i + 3 + len(col_dict)) for i, c in enumerate(pk_columns))
    )

    cur = sql_db.cursor()

    data = itertools.imap(lambda x, y: (last_chg_user, last_chg_date) + x + y,
                          itertools.izip(*[col_series[c] for c in col_series.keys()]),
                          key_series)

    try:
        data = list(data)
        cur.prepare(statement)
        cur.executemany(None, list(data))
        sql_db._conn.commit()
    except:
        sql_db._conn.rollback()
        raise
    finally:
        sql_db._closeCur(cur)


def _delete(sql_db, dataframe, table_name, pk_columns=None, pk_source='row'):
    if len(dataframe) == 0:
        return

    if not pk_columns:
        pk_columns = list(dataframe.columns)

    last_chg_user = util.username()
    last_chg_date = datetime.datetime.now()

    if pk_source == 'row':
        df_pk = [kk for kk in dataframe.columns if str(kk) in pk_columns]
        key_series = dict(
            (str(k), itertools.imap(transform_np2py, dataframe[k])) for k in df_pk)

        if len(key_series) != len(pk_columns):
            for k in pk_columns:
                if k not in key_series:
                    raise Exception(
                        "Column %s for primary key is not found in the dataframe and no mapping is provided" % k)

        key_series = itertools.izip(*[key_series[k] for k in pk_columns])
    elif pk_source == "index":
        key_series = itertools.imap(
            lambda x: map(transform_np2py, __transform_index(x, len(pk_columns))),
            dataframe.index)
    else:
        raise Exception('Unknown pk_source: %s', pk_source)

    statement = 'DELETE FROM %s WHERE %s' % (
        table_name,
        ' AND '.join('%s = :%d' % (c, i + 1) for i, c in enumerate(pk_columns))
    )

    cur = sql_db.cursor()
    data = key_series

    try:
        data = list(data)
        cur.prepare(statement)

        cur.executemany(None, list(data))
        sql_db._conn.commit()
    except:
        sql_db._conn.rollback()
        raise
    finally:
        sql_db._closeCur(cur)


def _upsert(sql_db, dataframe, table_name, pk_columns, columns=None, pk_source='row', nanAndInfAsNone=False):

    if len(dataframe) == 0:
        return

    if not pk_columns:
        raise Exception('pk_columns must not be empty')

    last_chg_user = util.username()
    last_chg_date = datetime.datetime.now()

    if columns is None:
        columns = [x for x in dataframe.columns]

    col_dict = collections.OrderedDict(
        [
            ((x[0], x[1]) if isinstance(x, collections.Sequence) and not isinstance(x, basestring) else (
                x, str(x)))
            for x in columns
        ])

    col_series = collections.OrderedDict(
        (x, itertools.imap(partial(transform_np2py, nanAndInfAsNone=nanAndInfAsNone), dataframe[x])) for x in dataframe.columns if x in col_dict.keys())

    if pk_source == 'row':
        df_pk = [kk for kk in col_dict.iterkeys() if col_dict[kk] in pk_columns]
        key_series = dict(
            (col_dict[k], col_series[k]) for k in df_pk)
        for k in df_pk:
            del col_series[k]
            del col_dict[k]

        for k in pk_columns:
            if k not in key_series:
                if k not in dataframe.columns:
                    raise Exception(
                        "Column for primary key %s is not found in the dataframe and no mapping is provided" % k)
                else:
                    key_series[k] = itertools.imap(partial(transform_np2py, nanAndInfAsNone=nanAndInfAsNone), dataframe[k])
        key_series = itertools.izip(*[key_series[k] for k in pk_columns])
    elif pk_source == "index":
        key_series = map(
            lambda x: partial(transform_np2py, nanAndInfAsNone=nanAndInfAsNone)(__transform_index(x, len(pk_columns))),
            dataframe.index)
    else:
        raise Exception('Unknown pk_source: %s', pk_source)

    statement = '''MERGE INTO {table_name} t1
            USING (
                SELECT :1 LAST_CHG_USER, :2 LAST_CHG_DATE, {column_list} FROM dual
            ) t2 ON ({condition})
            WHEN MATCHED THEN UPDATE SET t1.LAST_CHG_USER = t2.LAST_CHG_USER , t1.LAST_CHG_DATE = t2.LAST_CHG_DATE,
                                         {update}
            WHEN NOT MATCHED THEN INSERT (LAST_CHG_USER, LAST_CHG_DATE, {column_list_ins})
                                  VALUES (t2.LAST_CHG_USER, t2.LAST_CHG_DATE, {values})
            '''.format(table_name=table_name,
                       column_list=', '.join(':%s %s' % (num + 3, col)
                                             for num, col
                                             in enumerate(itertools.chain(pk_columns,
                                                                          [col_dict[c] for c in col_dict.keys()]))),
                       condition=' AND '.join('t1.%s = t2.%s' % (x, x) for x in pk_columns),
                       update=', '.join('t1.%s = t2.%s' % (c, c) for c in col_dict.values()),
                       values=', '.join('t2.%s' % c for c in itertools.chain(pk_columns, col_dict.values())),
                       column_list_ins=', '.join(itertools.chain(pk_columns,
                                                                 [col_dict[c] for c in col_dict.keys()]))
                       )

    cur = sql_db.cursor()

    data = itertools.imap(lambda x, y: (last_chg_user, last_chg_date) + x + y, key_series,
                          itertools.izip(*[col_series[k] for k in col_series.keys()]))

    try:
        data = list(data)
        cur.prepare(statement)

        cur.executemany(None, list(data))
        sql_db._conn.commit()
    except:
        sql_db._conn.rollback()
        raise
    finally:
        sql_db._closeCur(cur)

def _execute(sql_db, sql, params=[], commit=True, log=True):
    cursor = sql_db.cursor()
    try:

        if 'hive' in sql_db.vendor.lower() or 'impala' in sql_db.vendor.lower():
            res = cursor.execute(sql)
            return None
        else:
            cursor.execute(sql, params)
            row_count = cursor.rowcount
            if commit:
                sql_db._conn.commit()
            return row_count
    except Exception, ex:
        if log:
            logging.error('exception execute() sql=\n%s' % sql)
        raise ex
    finally:
        sql_db._closeCur(cursor)

def _executemany(sql_db, statement, list_data=[], commit=True, bindarraysize=10000, log=True, oracle_unicode=False,
                input_sizes=None):

    try:
        list_data = list(list_data) if not isinstance(list_data, list) else list_data
        cur = sql_db.cursor()
        if sql_db.vendor == 'oracle':
            cur.bindarraysize = bindarraysize
        if input_sizes is not None:
            if isinstance(input_sizes, (tuple, list)):
                cur.setinputsizes(*input_sizes)
            else:
                cur.setinputsizes(**input_sizes)
                __setup_connection(sql_db, oracle_unicode)

        cur.prepare(statement)
        cur.executemany(None, list_data)

        if log:
            sql_db._log(statement, {})

        rc = cur.rowcount
        if commit:
            sql_db._conn.commit()
        return rc
    except Exception, e:
        msg = 'db execute error %s\n%s' % (statement, util.exceptionAsStr(e))
        raise Exception(msg)
    finally:
        sql_db._closeCur(cur)


def _call_proc(sql_db, procname, params=[], commit=True):
    cursor = sql_db.cursor()
    try:
        cursor.callproc(procname, parameters=params)
        if commit:
            sql_db._conn.commit()
    finally:
        sql_db._closeCur(cursor)

def _schema(sql_db, schema, table):
    if 'oracle' not in sql_db.vendor.lower() and \
        'sybase' not in sql_db.vendor.lower() and \
        'iq' not in sql_db.vendor.lower(): \
        raise Exception('%s vendor not supported yet' % sql_db.vendor)
        
    cur = sql_db.cursor()
    if 'sybase' in sql_db.vendor.lower() or 'iq' in sql_db.vendor.lower():
        sql = "select top 1 * from %s..%s " % (schema, table)
    else:
        sql = "select * from %s.%s where 1=0" % (schema, table)

    try:
        cur.execute(sql)
        columns = []
        if hasattr(cur, 'description'):
            map(lambda x: columns.append(x), cur.description)
        else:
            map(lambda x: columns.append(x), cur.getSchema())
        return columns
    except Exception, ex:
        logging.error('error running sql %s' % sql)
        raise ex
    finally:
        try:
            cur.close()
        except Exception, ex:
            pass


def _table_columns(sql_db, table_name):
    """
    Returns list containing column names of a given table

    :param table_name: Name of the table
    :type table_name: str
    :return: List of column names
    :rtype: list[str]
    """

    if 'oracle' in sql_db.vendor.lower():
        sql = """
                select distinct column_name from all_tab_columns where table_name = '%s'
            """ % table_name.upper()

        cols = _query(sql_db, sql, log=False)
        return [(c[0].upper() if c else c) for c in cols]
    else:
        raise NotImplementedError()


def __transform_index(val, length):
    if isinstance(val, collections.Sequence):
        r = val
    else:
        r = (val,)

    if len(r) != length:
        raise Exception("Index length doesn't match primary key length")
    return r


def __oracle_unicode(cursor, name, defaultType, size, precision, scale):
    import cx_Oracle
    if defaultType in (cx_Oracle.STRING, cx_Oracle.FIXED_CHAR):
        return cursor.var(unicode, size, cursor.arraysize)

def __setup_connection(sql_db, oracle_unicode):
    if oracle_unicode:
        sql_db._conn.outputtypehandler = __oracle_unicode

def __setup_cursor(sql_db, cur, params, bindarraysize, input_sizes, param_transformer):
    if 'oracle' in sql_db.vendor:
        cur.bindarraysize = bindarraysize
        cur.arraysize = 2000
    if input_sizes is not None:
        if isinstance(input_sizes, (tuple, list)):
            cur.setinputsizes(*input_sizes)
        else:
            cur.setinputsizes(**input_sizes)
    if param_transformer is not None:
        params = param_transformer(cur, params)
    return params
