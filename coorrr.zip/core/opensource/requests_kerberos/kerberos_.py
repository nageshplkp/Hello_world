try:
    import kerberos
except ImportError:
    try:
        import winkerberos as kerberos
    except ImportError:
        import core.opensource.kerberos_sspi as kerberos
import logging
import re
import socket

from requests.auth import AuthBase
from requests.compat import urlparse
from requests.cookies import cookiejar_from_dict
from requests.models import Response
from requests.structures import CaseInsensitiveDict

from .exceptions import MutualAuthenticationError

log = logging.getLogger(__name__)


# Different types of mutual authentication:
#  with mutual_authentication set to REQUIRED, all responses will be
#   authenticated with the exception of errors. Errors will have their contents
#   and headers stripped. If a non-error response cannot be authenticated, a
#   MutualAuthenticationError exception will be raised.
# with mutual_authentication set to OPTIONAL, mutual authentication will be
#   attempted if supported, and if supported and failed, a
#   MutualAuthenticationError exception will be raised. Responses which do not
#   support mutual authentication will be returned directly to the user.
# with mutual_authentication set to DISABLED, mutual authentication will not be
#   attempted, even if supported.
REQUIRED = 1
OPTIONAL = 2
DISABLED = 3

class SanitizedResponse(Response):
    """The :class:`Response <Response>` object, which contains a server's
    response to an HTTP request.

    This differs from `requests.models.Response` in that it's headers and
    content have been sanitized. This is only used for HTTP Error messages
    which do not support mutual authentication when mutual authentication is
    required."""

    def __init__(self, response):
        super(SanitizedResponse, self).__init__()
        self.status_code = response.status_code
        self.encoding = response.encoding
        self.raw = response.raw
        self.reason = response.reason
        self.url = response.url
        self.request = response.request
        self.connection = response.connection
        self._content_consumed = True

        self._content = ""
        self.cookies = cookiejar_from_dict({})
        self.headers = CaseInsensitiveDict()
        self.headers['content-length'] = '0'
        for header in ('date', 'server'):
            if header in response.headers:
                self.headers[header] = response.headers[header]


def _negotiate_value(response):
    """Extracts the gssapi authentication token from the appropriate header"""
    if hasattr(_negotiate_value, 'regex'):
        regex = _negotiate_value.regex
    else:
        # There's no need to re-compile this EVERY time it is called. Compile
        # it once and you won't have the performance hit of the compilation.
        regex = re.compile('(?:.*,)*\s*Negotiate\s*([^,]*),?', re.I)
        _negotiate_value.regex = regex

    authreq = response.headers.get('www-authenticate', None)

    if authreq:
        match_obj = regex.search(authreq)
        if match_obj:
            #print authreq
            #print '111111111111111111111111111111111'
            return match_obj.group(1)

    return None


class HTTPKerberosAuth(AuthBase):
    """Attaches HTTP GSSAPI/Kerberos Authentication to the given Request
    object."""
    def __init__(
            self, mutual_authentication=REQUIRED,
            service="HTTP", delegate=False):
        self.context = {}
        self.mutual_authentication = mutual_authentication
        self.delegate = delegate
        self.pos = None
        self.service = service

    def get_spn(self, url, skip_port):
        urlparts = urlparse(url)
        host = urlparts.hostname
        port = urlparts.port

        fqdn, _, __ = (socket.gethostbyname_ex(host) or ('', [], []))
        if fqdn:
            host = fqdn

        #if skip_port or port is None or port == 80:
        if skip_port or port is None or port == 80:
            principal_name = "{0}@{1}".format(self.service, host)
        else:
            principal_name = "{0}@{1}:{2}".format(self.service, host, port)
#            print principal_name # this line is a must. there's something wrong with python that unless u print here,
                                 # the next line is gonna generate segfault
        return principal_name

    def generate_token(self, response, skip_port):
        """
        Generates the GSSAPI authentication token with kerberos.

        If any GSSAPI step fails, return None.

        """
        # Flags used by kerberos module.
        gssflags = kerberos.GSS_C_SEQUENCE_FLAG

        if self.mutual_authentication != DISABLED:
            gssflags |= kerberos.GSS_C_MUTUAL_FLAG
        if self.delegate:
            gssflags |= kerberos.GSS_C_DELEG_FLAG

        principal_name = ""

        try:
            principal_name = self.get_spn(response.url, skip_port)
            # print(principal_name) # this line is a must. there's something wrong with python that unless u print here,
                             # the next line is gonna generate segfault
                             # if u comment this line, please make sure tests.core.rest.client still works on betapmapp1.
            result, context_ = kerberos.authGSSClientInit(principal_name, gssflags=gssflags)
            self.context[principal_name] = context_
            #log.debug('************************************** %s' % "{0}".format(principal_name))
            #log.debug(response.text)

        except kerberos.GSSError as error:
            log.error("generate_request_header(): authGSSClientInit() failed:")
            log.exception(error)
            return None, principal_name

        if result < 1:
            log.error("generate_request_header(): authGSSClientInit() failed: "
                      "{0}".format(result))
            return None, principal_name

        try:
            result = kerberos.authGSSClientStep(self.context[principal_name],
                                                _negotiate_value(response))
        except kerberos.GSSError as error:
            log.exception(
                    "generate_request_header(): authGSSClientStep() failed:")
            log.exception(error)
            return 2, principal_name # we actually get an exception when trying to authenticate with a port where no port is needed
                                     # do not remove it

        return result, principal_name

    def generate_request_header(self, response):
        """
        Generates the GSSAPI authentication token with kerberos.

        If any GSSAPI step fails, return None.

        """
        res, principal_name = self.generate_token(response, False)
        # If its not a Kerberos Token, have another go without the port.
        # Active Directory drops down to NTLM is the SPN doesnt exist!
        if res == 2:
            res, principal_name = self.generate_token(response, True)

        try:
            gss_response = kerberos.authGSSClientResponse(self.context[principal_name])
        except kerberos.GSSError as error:
            log.exception(
                "generate_request_header(): authGSSClientResponse() failed:")
            log.exception(error)
            return None

        return "Negotiate {0}".format(gss_response)

    def authenticate_user(self, response, **kwargs):
        """Handles user authentication with gssapi/kerberos"""

        auth_header = self.generate_request_header(response)
        if auth_header is None:
            # GSS Failure, return existing response
            return response

        #log.debug("authenticate_user(): Authorization header: {0}".format(auth_header))
        response.request.headers['Authorization'] = auth_header

        # Consume the content so we can reuse the connection for the next
        # request.
        response.content
        response.raw.release_conn()

        _r = response.connection.send(response.request, **kwargs)
        _r.history.append(response)

        #log.debug("authenticate_user(): returning {0}".format(_r))
        return _r

    def handle_401(self, response, **kwargs):
        """Handles 401's, attempts to use gssapi/kerberos authentication"""

        #log.debug("handle_401(): Handling: 401")
        if _negotiate_value(response) is not None:
            _r = self.authenticate_user(response, **kwargs)
            #log.debug("handle_401(): returning {0}".format(_r))
            return _r
        else:
            #log.debug("handle_401(): Kerberos is not supported")
            #log.debug("handle_401(): returning {0}".format(response))
            return response

    def handle_other(self, response):
        """Handles all responses with the exception of 401s.

        This is necessary so that we can authenticate responses if requested"""

        #log.debug("handle_other(): Handling: %d" % response.status_code)

        if 200 <= response.status_code < 300:
            return response

        if self.mutual_authentication in (REQUIRED, OPTIONAL):

            is_http_error = response.status_code >= 400

            if _negotiate_value(response) is not None:
                #log.debug("handle_other(): Authenticating the server")
                if self.mutual_authentication == REQUIRED and not self.authenticate_server(response):
                    # Mutual authentication failure when mutual auth is wanted,
                    # raise an exception so the user doesn't use an untrusted
                    # response.
                    log.error("handle_other(): Mutual authentication failed")
                    raise MutualAuthenticationError("Unable to authenticate "
                                                    "{0}".format(response))

                # Authentication successful
                #log.debug("handle_other(): returning {0}".format(response))
                return response

            elif is_http_error or self.mutual_authentication == OPTIONAL:
                if not response.ok:
                    log.error("handle_other(): Mutual authentication unavailable "
                              "on {0} response".format(response.status_code))

                if self.mutual_authentication == REQUIRED:
                    return SanitizedResponse(response)
                else:
                    return response
            else:
                # Unable to attempt mutual authentication when mutual auth is
                # required, raise an exception so the user doesnt use an
                # untrusted response.
                log.error("handle_other(): Mutual authentication failed")
                raise MutualAuthenticationError("Unable to authenticate "
                                                "{0}".format(response))
        else:
            #log.debug("handle_other(): returning {0}".format(response))
            return response

    def authenticate_server(self, response):
        """
        Uses GSSAPI to authenticate the server.

        Returns True on success, False on failure.
        """

        #log.debug("authenticate_server(): Authenticate header: {0}".format(_negotiate_value(response)))

        principal_name = self.get_spn(response.url, False)

        try:
            result = kerberos.authGSSClientStep(self.context[principal_name],
                                                _negotiate_value(response))
        except kerberos.GSSError:
            log.exception("authenticate_server(): authGSSClientStep() failed:")
            return False

        if result < 1:
            log.error("authenticate_server(): authGSSClientStep() failed: "
                      "{0}".format(result))
            return False

        #log.debug("authenticate_server(): returning {0}".format(response))
        return True

    def handle_response(self, response, **kwargs):
        """Takes the given response and tries kerberos-auth, as needed."""

        num_401s = kwargs.pop('num_401s', 0)

        if self.pos is not None:
            # Rewind the file position indicator of the body to where
            # it was to resend the request.
            response.request.body.seek(self.pos)

        if response.status_code == 401 and num_401s < 2:
            # 401 Unauthorized. Handle it, and if it still comes back as 401,
            # that means authentication failed.
            _r = self.handle_401(response, **kwargs)
            #log.debug("handle_response(): returning %s", _r)
            #log.debug("handle_response() has seen %d 401 responses", num_401s)
            num_401s += 1
            return self.handle_response(_r, num_401s=num_401s, **kwargs)
        elif response.status_code == 401 and num_401s >= 2:
            # Still receiving 401 responses after attempting to handle them.
            # Authentication has failed. Return the 401 response.
            #log.debug("handle_response(): returning 401 %s", response)
            return response
        else:
            _r = self.handle_other(response)
            #log.debug("handle_response(): returning %s", _r)
            return _r

    def deregister(self, response):
        """Deregisters the response handler"""
        response.request.deregister_hook('response', self.handle_response)

    def __call__(self, request):
        request.register_hook('response', self.handle_response)
        try:
            self.pos = request.body.tell()
        except AttributeError:
            # In the case of HTTPKerberosAuth being reused and the body
            # of the previous request was a file-like object, pos has
            # the file position of the previous body. Ensure it's set to
            # None.
            self.pos = None
        return request
