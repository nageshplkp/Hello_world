# -*- coding: utf-8 -*-
""" CMP Example - Helpful Utiliies
 *
 * Copyright 2017 Bloomberg Finance L.P.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:  The above
 * copyright notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
"""
import csv
import re
import time

def get_timestamps(unix_time=time.time()):
    return {
        'unix_time': unix_time,
        'date_time': time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(unix_time)),
        'date': time.strftime('%Y%m%d', time.localtime(unix_time))
    }

def get_granularity(dealfile):
    if check_if_repline(dealfile):
        return 'REPLINE_LEVEL'

    return 'LOAN_LEVEL'

def check_if_repline(dealfile):
    if dealfile.get('default_cashflow_use_reported', None):
        return True

    return False

def write_csv(row, name='temp.csv', mode='ab'):
    name = time.strftime('%Y%m%d-%H%M%S.csv', time.localtime(time.time()))

    with open(name, mode) as f:
        writer = csv.writer(f, dialect='excel')
        writer.writerow(row)

    return name

def convert_dealname(deal):
    issuer, series = re.split(r'_|\s', deal)
    res = re.match(r'(19|20)(\d\d-\w+)', series)
    series = res.group(2) if res else series

    return '_'.join((issuer, series))