# -*- coding: utf-8 -*-
""" CMP Example - Getting Reference Data through DAPI
 *
 * Copyright 2017 Bloomberg Finance L.P.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:  The above
 * copyright notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
"""

""" NOTE: ReferenceDataRequest is not part of the CMP service.
    It uses the refdata service, which is part of the DAPI suite.
    For more information about DAPI, please visit DAPI <GO> on Terminal
"""

import json

class Refdata(object):

    request_info = {
            'request': 'ReferenceDataRequest',
            'service': 'refdata',
            'base_request': 'ReferenceDataRequest'
        }

    def get_request(self, request, inputs):
        request.getElement('securities').appendValue(inputs['security'] + ' ' + inputs.get('yellow', 'Mtge'))

        for i in inputs['fields']:
            request.getElement('fields').appendValue(i)

        return request

    def process_response(self, response):
        results = {}

        for i in (response.getElement('securityData').getValueAsElement().
            getElement('fieldData').elements()):

            results[str(i.name())] = i.getValue()

        return results