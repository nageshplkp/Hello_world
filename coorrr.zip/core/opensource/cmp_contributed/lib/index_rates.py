# -*- coding: utf-8 -*-
""" CMP Example - Getting Index Rates
 *
 * Copyright 2017 Bloomberg Finance L.P.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:  The above
 * copyright notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
"""
import json

class IndexRates(object):
    request_info = {
            'request': 'getForwardIndexRates',
            'service': 'cmp'
        }

    def get_request(self, request, inputs):
        request.getElement('getForwardIndexRates').setElement('asof', inputs['date_time'])

        for r in inputs['req_rates']['indices']['list']:
            e = request.getElement('getForwardIndexRates').getElement('rates').appendElement()
            e.setElement('name', str(r))
            e.setElement('startdate', inputs['req_rates']['bonds'][inputs['bond']]['rate_start_date'])
            e.setElement('length', inputs['req_rates']['max_wam'] if inputs['req_rates']['max_wam'] else 480)
            e.setElement('frequency', 'MONTHLY')

        return request

    def process_response(self, response):
        return self.__convert_index_rates_to_json(response.getElement('forwardIndexRatesResponse'))

    def __convert_index_rates_to_json(self, rates_response):
        rates = {
            'asof': rates_response.getElement('asof').getValueAsString(),
            'index': {}
        }

        for i in rates_response.getElement('index').values():
            rates['index'][i.getElement('name').getValueAsString()] = {
                'start_date': i.getElement('vector').getElement('start_date').getValue(),
                'frequency': i.getElement('vector').getElement('frequency').getValueAsString(),
                'values': list(i.getElement('vector').getElement('values').values()),
                'dates': list(i.getElement('vector').getElement('dates').values()),
                'anchor': i.getElement('vector').getElement('anchor').getValueAsString()
            }

        return json.dumps(rates)
