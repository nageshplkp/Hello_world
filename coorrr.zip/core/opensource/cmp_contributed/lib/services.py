# -*- coding: utf-8 -*-
""" CMP Example - Setting up the Requests
 *
 * Copyright 2017 Bloomberg Finance L.P.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:  The above
 * copyright notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
"""
import os

import bapi
from activation import Activation
from analytics import Analytics
from cashflows import Cashflows
from curves import Curves
from dealfile import Dealfile
from index_rates import IndexRates
from refdata import Refdata
from required_rates import RequiredRates

class Services(object):
    _REQUESTS = {}

    imports = [Activation, Analytics, Cashflows, Curves, Dealfile, IndexRates, Refdata, RequiredRates]

    for i in imports:
        _REQUESTS[i.request_info['request']] = {
            'service': i.request_info['service'],
            'module': i(),
            'base_request': i.request_info.get('base_request', 'request')
        }

    services = {}

    def __init__(self, uuid=None):
        for i in list(set([ self._REQUESTS[x]['service'] for x in self._REQUESTS ])):
            self.services[i] = bapi.BlpApiService(i)

    def make_request(self, name, inputs):
        request = self._REQUESTS[name]['module'].get_request(self.services[self._REQUESTS[name]['service']].
            get_base_request(self._REQUESTS[name]['base_request']), inputs)
        response = self.services[self._REQUESTS[name]['service']].get_response(request)

        return self._REQUESTS[name]['module'].process_response(response)