# -*- coding: utf-8 -*-
""" CMP Example - Getting Benchmark Curves
 *
 * Copyright 2017 Bloomberg Finance L.P.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:  The above
 * copyright notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
"""
import json

class Curves(object):
    request_info = {
            'request': 'getAllCurves',
            'service': 'cmp'
        }

    def get_request(self, request, inputs):
        request.getElement('getAllCurves').setElement('settledate', inputs['date'])

        return request

    def process_response(self,response):
        return self.__convert_curves_to_json(response.getElement('curveResponseJson'))

    def __convert_curves_to_json(self, curve_response):
        # This is an Element, not JSON
        curves = {
            'vectors': {}
        }

        curves_map = json.loads(curve_response.getElement('json').getValueAsString())

        for i in curves_map:
            for j in curves_map[i]:
                pos = curves_map[i][j]['position']
                vec_type = curves_map[i][j]['type']
                curves['vectors'].setdefault(i, {}).setdefault(j, {})
                curves['vectors'][i][j] = [ x for x in curve_response.getElement('vectors')
                    .getValueAsElement(pos).getElement(vec_type).values() ]

        return json.dumps(curves)
