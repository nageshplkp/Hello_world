# -*- coding: utf-8 -*-
""" CMP Example - Getting Cashflows
 *
 * Copyright 2017 Bloomberg Finance L.P.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:  The above
 * copyright notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
"""
import json

import lib.utils

class Cashflows(object):
    request_info = {
        'request': 'cashFlowsAggregate',
        'service': 'cmp'
    }

    def get_request(self, request, inputs):
        request.getElement('cashFlowsAggregate').setElement('security_id', inputs['dealfile']['revision'])

        scenario = request.getElement('cashFlowsAggregate').getElement('scenario')

        if inputs['assumptions']['scenario_assumptions']['type'] == 'canned_deal_flow':
            self.__set_canned_deal_assumptions(scenario, inputs['dealfile'], inputs['assumptions']['scenario_assumptions'], inputs['rates'])
        elif inputs['assumptions']['scenario_assumptions']['type'] == 'dynamic_deal_flow':
            self.__set_dynamic_deal_assumptions(scenario, inputs['dealfile'], inputs['assumptions']['scenario_assumptions'], inputs['rates'])

        if inputs['assumptions'].get('collateral_assumptions'):
            if inputs['assumptions']['collateral_assumptions']['type'] == 'canned_collateral_flow':
                self.__set_canned_collateral_assumptions(scenario, inputs['assumptions']['collateral_assumptions'])
            elif inputs['assumptions']['collateral_assumptions']['type'] == 'dynamic_collateral_flow':
                self.__set_dynamic_collateral_assumptions(scenario, inputs['assumptions']['collateral_assumptions'])
            elif inputs['assumptions']['collateral_assumptions']['type'] == 'contributed_collateral_flow':
                self.__set_contributed_collateral_assumptions(scenario, inputs['assumptions']['collateral_assumptions'])

        reports = request.getElement('cashFlowsAggregate').getElement('reports').appendElement()
        reports.setElement('no_history', False)
        reports.getElement('filter').getElement('bonds').appendValue(inputs['bond'])
        reports.getElement('filter').getElement('collateral_groups').appendValue('*')

        collat_fields = ['balance', 'interest', 'gross_accrued_interest', 'net_accrued_interest',
            'gross_interest', 'sched', 'performing_balance', 'unsched', 'deferred_interest',
            'loss', 'recovery', 'defaults', 'subsequent_recovery']

        collat_properties = reports.getElement('properties').appendElement()
        collat_properties.setElement('name', 'collateral')
        for i in collat_fields:
            collat_properties.getElement('fields').appendElement().setElement('attribute', i)

        bond_fields = ['dates', 'actual_payment_dates', 'balance', 'cashflow', 'coupon', 'credit_support',
            'implied_loss_amount', 'interest', 'interest_accrual_end_dates', 'interest_accrual_start_dates',
            'loss', 'nominal_payment_dates', 'principal', 'sched', 'shortfall', 'unsched']

        bond_properties = reports.getElement('properties').appendElement()
        bond_properties.setElement('name', 'bond')
        for i in bond_fields:
            bond_properties.getElement('fields').appendElement().setElement('attribute', i)

        return request

    def process_response(self, response):
        return self.__convert_cashflows_to_json(response.getElement('cashFlowsResponse'))

    def __convert_cashflows_to_json(self, cashflows_response):
        cashflows = {
            'vectors': {}
        }

        cashflows_map = json.loads(cashflows_response.getElement('json').getValueAsString())

        for i in ('Collat', 'Bond'):
            for j in cashflows_map['vector_index'][i].keys():
                for k in cashflows_map['vector_index'][i][j]:
                    pos = cashflows_map['vector_index'][i][j][k]['pos']
                    vec_type = cashflows_map['vector_index'][i][j][k]['type']
                    cashflows['vectors'].setdefault(i, {}).setdefault(j, {}).setdefault(k, {})
                    cashflows['vectors'][i][j][k] = [ x if vec_type != 'values_date' else str(x) for x in cashflows_response.getElement('vectors')
                        .getValueAsElement(pos).getElement(vec_type).values() ]

        return json.dumps(cashflows)

    def __set_canned_deal_assumptions(self, scenario_element, dealfile, assumptions, rates):
        flow = scenario_element.getElement('canned_deal_flow')
        flow.setElement('name', assumptions['name'])
        flow.setElement('timestamp', assumptions['timestamp'])

        if rates:
            self.__add_rates_to_cashflow(rates, flow.getElement('index'))

    def __set_dynamic_deal_assumptions(self, scenario_element, dealfile, assumptions, rates):
        flow = scenario_element.getElement('dynamic_deal_flow')
        flow.getElement('call').setElement('call_bool', assumptions['call'])
        flow.setElement('respect_delinquency', assumptions['respect_delinquency'])
        flow.setElement('run_replines', lib.utils.check_if_repline(dealfile))

        if rates:
            self.__add_rates_to_cashflow(rates, flow.getElement('index'))

    def __add_rates_to_cashflow(self, rates, index_element):
        rates = json.loads(rates)['index']

        for i in rates.keys():
            index = index_element.appendElement()
            index.setElement('name', i)
            index.getElement('vector').setElement('start_date', rates[i]['start_date'])
            index.getElement('vector').setElement('frequency', rates[i]['frequency'])
            index.getElement('vector').setElement('anchor', rates[i]['anchor'])
            [ index.getElement('vector').getElement('values').appendValue(x) for x in rates[i]['values'] ]
            [ index.getElement('vector').getElement('dates').appendValue(x) for x in rates[i]['dates'] ]

    def __set_prepayment(self, collateral_assump, prepay_assumptions):
        collateral_assump.getElement('prepayment').setElement('type', prepay_assumptions['type'])

        for i in prepay_assumptions['rate']:
            collateral_assump.getElement('prepayment').getElement('rate').getElement('values').appendValue(i)

    def __set_default(self, collateral_assump, default_assumptions):
        collateral_assump.getElement('default').setElement('type', default_assumptions['type'])

        for i in default_assumptions['rate']:
            collateral_assump.getElement('default').getElement('rate').getElement('values').appendValue(i)

    def __set_severity(self, collateral_assump, severity_assumptions):
        if severity_assumptions.get('type'):
            collateral_assump.getElement('default').setElement('loss_severity_type', severity_assumptions['type'])

        for i in severity_assumptions['rate']:
            collateral_assump.getElement('default').getElement('loss_severity').getElement('values').appendValue(i)

    def __set_delinquency(self, collateral_assump, delinquency_assumptions):
        if delinquency_assumptions.get('type'):
            collateral_assump.getElement('delinquencies').setElement('type', delinquency_assumptions['type'])

        for i in delinquency_assumptions['rate']:
            collateral_assump.getElement('delinquencies').getElement('rate').getElement('values').appendValue(i)

    def __set_condition(self, collateral_assump, condition_assumptions):
        collateral_assump.setElement('condition', condition_assumptions)

    def __set_dynamic_collateral_assumptions(self, scenario_element, assumptions):
        for i in assumptions.get('assumptions', [{'prepayment': {'type': 'VPR', 'rate': [0]}}]):
            collateral_assump = scenario_element.getElement('dynamic_deal_flow').getElement('collateral_assumptions').getElement('dynamic_collateral_flow').appendElement()

            if i.get('prepayment'):
                self.__set_prepayment(collateral_assump, i['prepayment'])

            if i.get('default'):
                self.__set_default(collateral_assump, i['default'])

            if i.get('severity'):
                self.__set_severity(collateral_assump, i['severity'])

            if i.get('delinquency'):
                self.__set_delinquency(collateral_assump, i['delinquency'])

            if i.get('condition'):
                self.__set_condition(collateral_assump, i['condition'])

    def __set_canned_collateral_assumptions(self, scenario_element, assumptions):
        collateral_assump = scenario_element.getElement('dynamic_deal_flow').getElement('collateral_assumptions').getElement('canned_collateral_flow')
        collateral_assump.setElement('name', assumptions['name'])
        collateral_assump.setElement('timestamp', assumptions['timestamp'])

    def __set_contributed_collateral_assumptions(self, scenario_element, assumptions):
        contributed_collat_fields = ['balance', 'defaults', 'deferred_interest',
            'gross_accrued_interest', 'gross_interest', 'interest', 'loss', 'net_accrued_interest',
            'performing_balance', 'recovery', 'sched', 'subsequent_recovery', 'unsched']

        collateral_assump = scenario_element.getElement('dynamic_deal_flow').getElement('collateral_assumptions').getElement('contributed_collateral_flow')
        collateral_assump.setElement('anchor_month', assumptions['anchor_month'])

        for period in range(len(assumptions['contributed_collateral'].itervalues().next()['dates'])):
            period_flow = collateral_assump.getElement('contributed_collateral').appendElement()

            for group in assumptions['contributed_collateral'].keys():
                group_flow = period_flow.getElement('collateral_groups').appendElement()
                group_flow.setElement('name', group)

                for i in contributed_collat_fields:
                    group_flow.setElement(i, assumptions['contributed_collateral'][group][i][period])