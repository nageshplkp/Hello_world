# -*- coding: utf-8 -*-
""" CMP Example - Getting Mortgage Analytics
 *
 * Copyright 2017 Bloomberg Finance L.P.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:  The above
 * copyright notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
"""
import json

class Analytics(object):
    request_info = {
        'request': 'mtgeAnalyticsRequest',
        'service': 'cmp'
    }

    def get_request(self, request, inputs):
        request.getElement('mtgeAnalyticsRequest').setElement('settle_date', inputs['settle_date'])
        request.getElement('mtgeAnalyticsRequest').getElement('day_count').setElement('day_count', inputs['dealfile']['bonds'][inputs['bond']]['interest_accrual_methods'][-1]['day_count'])
        request.getElement('mtgeAnalyticsRequest').getElement('day_count').setElement('day_count_overriden', inputs['dealfile']['bonds'][inputs['bond']]['interest_accrual_methods'][-1]['day_count'])
        request.getElement('mtgeAnalyticsRequest').getElement('calendar').getElement('calendar_list').appendValue(inputs['dealfile']['bonds'][inputs['bond']]['interest_accrual_methods'][-1]['holidays'][0])

        self.__add_bond_flows_to_analytics(inputs['bond'], inputs['cashflows'], request.getElement('mtgeAnalyticsRequest').getElement('cashflows'),
            request.getElement('mtgeAnalyticsRequest').getElement('dates_info').getElement('cashflow_dates'))

        self.__add_curves_to_analytics(inputs['curves'], inputs['curve_date'], request.getElement('mtgeAnalyticsRequest').getElement('curves'))

        bond_rates = inputs['req_rates']['indices']['map'][inputs['bond']]

        if bond_rates:
            self.__add_rates_to_analytics(inputs['rates'], bond_rates, request.getElement('mtgeAnalyticsRequest').getElement('index'))

        calc_scenario = request.getElement('mtgeAnalyticsRequest').getElement('calc_scenarios').appendElement()

        if 'spread' in inputs['assumptions']['input']['type']:
            calc_scenario.getElement('spread').setElement('spread_type', inputs['assumptions']['input']['type'])
            calc_scenario.getElement('spread').setElement('spread_value', inputs['assumptions']['input']['value'])
        else:
            calc_scenario.setElement(inputs['assumptions']['input']['type'], inputs['assumptions']['input']['value'])

        for i in inputs['assumptions']['outputs']:
            calc_scenario.getElement('request_fields').appendValue(i)

        return request

    def process_response(self, response):
        return self.__convert_analytics_to_json(response.getElement('mtgeAnalyticsResponse'))

    def __convert_analytics_to_json(self, analytics_response):
        analytics = {}

        for i in analytics_response.getElement('calc_results').values():
            for j in i.getElement('calc_result').values():
                field_type = j.getElement('field_type').getValueAsString()
                analytics[j.getElement('field_name').getValueAsString()] = j.getElement(field_type).getValue()

        return analytics

    def __add_bond_flows_to_analytics(self, bond, cashflows, cashflow_element, dates_element):
        bond_cashflow_fields = {
            'bond': ['balance', 'principal', 'interest', 'coupon', 'loss', 'shortfall', 'credit_support'],
            'date': ['actual_payment_dates', 'nominal_payment_dates', 'interest_accrual_start_dates',
            'interest_accrual_end_dates']
        }

        for i in bond_cashflow_fields['bond']:
            for j in cashflows[i]:
                cashflow_element.getElement(i).appendValue(j)

        for i in bond_cashflow_fields['date']:
            for j in cashflows[i]:
                dates_element.getElement(i).appendValue(j)

    def __add_curves_to_analytics(self, curves, curve_date, curves_element):
        vectors = json.loads(curves)['vectors']

        curves_element.setElement('curve_date', curve_date)

        for i in vectors:
            c = curves_element.getElement('curve_values').appendElement()
            c.setElement('curve_type', i)

            for j in vectors[i]:
                for k in vectors[i][j]:
                    c.getElement(j).appendValue(k)

    def __add_rates_to_analytics(self, rates, bond_rates, rates_element):
        bond_rate = json.loads(rates)['index'][bond_rates[0]]

        rates_element.setElement('index_name', bond_rates[0])
        rates_element.setElement('start_date', bond_rate['start_date'])
        rates_element.setElement('decimal', True)

        for i in bond_rate['values']:
            rates_element.getElement('index').appendValue(i)