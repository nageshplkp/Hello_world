# CMP - Contributing Collateral Cashflow Example

A typical `cashflowAggregate` request first generates collateral flows from an asset pool or replines.  These flows are then fed into deal waterfall engine which determines bond payments.  CMP offers the ability to bypass the collateral amortizer and feed imported collateral flows directly to the deal waterfall engine.  For example, if more granularity is needed that broad pool level assumptions (CPR, CDR, Severity) cannot handle, you can generate the flows externally and contribute them to CMP.  CMP will then return the resulting bond cashflows/analytics.

See the CMP Reference API documentation on CMP <GO> on Terminal for more information.

## Running this example in Python 2.7:
```
> python .\get_collateral_flows.py 3137G0DW6
```

This program will generate a JSON formatted text file called `3137G0DW6_collateral_flows.json` which contains the collateral cashflows 'as-modeled' by Bloomberg.  You can pass these cashflows as-is, modified or fully re-created (taking care to ensure that periods line up to the original flows).

```
> .\get_contributed_analytics.py 3137G0DW6
```

This program will import the `3137G0DW6_collateral_flows.json` file and use containing flows as collateral flows (fully overriding what Bloomberg's amortization engine produces).  Resulting bond analytics will be printed to the screen.

You can use any mortgage security as long as the deal is modeled for cashflows by Bloomberg.

## License
```
"""
 *
 * Copyright 2017 Bloomberg Finance L.P.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:  The above
 * copyright notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
"""
```