# -*- coding: utf-8 -*-
""" CMP Example - Get Contributed Collateral Analytics
 *
 * Copyright 2017 Bloomberg Finance L.P.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:  The above
 * copyright notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
"""
import json
import sys

import lib.services
import lib.utils

def main(security_id):
    service = lib.services.Services()

    timestamps = lib.utils.get_timestamps()

    security = service.make_request('ReferenceDataRequest', {
        'security': security_id,
        'fields': ['MTG_DEAL_NAME', 'MTG_CMO_CLASS']
        }
    )

    dealname = security['MTG_DEAL_NAME']
    bond = security['MTG_CMO_CLASS']

    service.make_request('activateDealRequest', {'dealname': dealname})

    dealfile = service.make_request('dealRequest', {
        'dealname': dealname,
        'unix_timestamp': timestamps['unix_time']
        }
    )

    req_rates = service.make_request('requiredIndexRatesRequest', {'dealfile': dealfile})

    index_rates = service.make_request('getForwardIndexRates', {
        'req_rates': req_rates,
        'date_time': timestamps['date_time'],
        'bond': bond
        }
    )

    with open(security_id + '_collateral_flows.json', 'r') as f:
        collat_flows = json.load(f)

    cashflow_assumptions = {
        'scenario_assumptions': {
            'type': 'dynamic_deal_flow',
            'call': False,
            'respect_delinquency': True
        },
        'collateral_assumptions': {
            'type': 'contributed_collateral_flow',
            'contributed_collateral': collat_flows,
            'anchor_month': 201701
        }
    }

    cashflow_inputs = {
        'dealfile': dealfile,
        'rates': index_rates,
        'bond': bond,
        'assumptions': cashflow_assumptions
    }

    cashflows = service.make_request('cashFlowsAggregate', cashflow_inputs)

    curves = service.make_request('getAllCurves', {'date': timestamps['date']})

    analytics_inputs = {
        'dealfile': dealfile,
        'req_rates': req_rates,
        'rates': index_rates,
        'curves': curves,
        'curve_date': timestamps['date'],
        'cashflows': json.loads(cashflows)['vectors']['Bond'][bond],
        'bond': bond,
        'settle_date': timestamps['date'],
        'assumptions': {
            'input': {
                'type': 'price',
                'value': 100.0
            },
            'outputs': ['price', 'yield', 'dm', 'wal', 'mod_dur', 'n_spread']
        }
    }

    print service.make_request('mtgeAnalyticsRequest', analytics_inputs)

if len(sys.argv) < 2:
    print 'Usage:', sys.argv[0], '<security>'
    sys.exit(1)

main(sys.argv[1])