"""PyDoctor, an API documentation generator for Python libraries."""

from __future__ import print_function

version_info = (16, 2, 1, '', 0)
