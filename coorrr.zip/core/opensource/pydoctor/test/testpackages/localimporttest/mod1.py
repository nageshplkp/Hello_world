from mod2 import B

class C(B):
    """This is not a docstring."""
    pass
