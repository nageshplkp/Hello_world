from zope.interface import implements

from interfaceallgames.interface import IAnInterface

class Implementation:
    implements(IAnInterface)
