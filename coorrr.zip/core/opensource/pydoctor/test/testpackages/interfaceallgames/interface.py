from zope.interface import Interface

class IAnInterface(Interface):
    pass
