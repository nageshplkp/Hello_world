from interfaceallgames._implementation import Implementation
__all__ = ["Implementation"]
