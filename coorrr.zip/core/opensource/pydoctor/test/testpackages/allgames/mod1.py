
__all__ = ['InSourceAll']

class InSourceAll:
    pass

class NotInSourceAll:
    pass
