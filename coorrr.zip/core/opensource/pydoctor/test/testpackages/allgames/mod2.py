__all__ = ['InSourceAll', 'NotInSourceAll']

from allgames.mod1 import InSourceAll, NotInSourceAll
