def functionInInit(self):
    "why do people put code here?"
