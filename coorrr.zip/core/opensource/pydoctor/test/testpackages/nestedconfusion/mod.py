class C:
    pass
class nestedconfusion:
    class A(C):
        pass
