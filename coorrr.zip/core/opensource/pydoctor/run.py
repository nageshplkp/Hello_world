#!/usr/bin/env python
import os
import sys

d = os.path.dirname(os.path.dirname(__file__))

if os.path.isdir(os.path.join(d, 'pydoctor')):
   sys.path.insert(0, d)

from driver import main

sys.exit(main(sys.argv[1:]))
