# Backwards compat shim.
from __future__ import print_function

from pydoctor.templatewriter.writer import TemplateWriter
TemplateWriter = TemplateWriter
