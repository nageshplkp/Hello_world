__author__ = 'rghosh'
CONN_MAP =  {
        'prod' : 'http://timeseries:61000/timeseries/v1',
        'beta' : 'http://timeseriesbeta:61000/timeseries/v1',
        'dev' : 'http://timeseriesdev:61000/timeseries/v1',
        'local': 'http://localhost:61000/timeseries/v1',
    }

END_POINT_MAP = {
    "metadata_only" : ['seriesMetaData', 'time series descriptors' ], # Metadata queries return values under time series descriptors
    "data" : [ 'series', 'time series'],
    "dicitonarydesc" : ['dictionaryNames','dictionary descriptors'],
    "dictionary" : ['dictionary','@REPLACE@']
}

AUTH_CONN_MAP =  {
        'prod' : 'http://ptp-prod/timeseries/v1',
        'beta' : 'http://ptp-beta/timeseries/v1',
        'dev' : 'http://ptp-dev/timeseries/v1'
    }
