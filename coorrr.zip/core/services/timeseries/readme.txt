The time series service interface exposes provides simple to use query based api.
For details on the project go to http://pimcoportal/newport/technology/coreservices/tss/Pages/tech-home.aspx

Service End Points:
    http://timeseriesservices

Python Package Dependencies
    https://pypi.python.org/pypi/isodate
    To install use: pip install isodate