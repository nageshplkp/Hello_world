__author__ = 'rghosh'

from core.rest.utils import popcorn_jcsv_to_dataframe
from core.services.timeseries.decorate import END_POINT_MAP
from core.services.timeseries.ts_proxy import TsProxy

import logging
from collections import OrderedDict


def __ts_execute_service(service_end_point, return_field_name, params, throw_on_error=False, debug=False, env="prod",
                         is_matrix=False):
        if params is None:
            params = dict()
        params["_Accept"] = "application/json;fmt=csv" # always add csv encoding for the data.
        t = TsProxy(base_url=env, throw_on_error=throw_on_error, debug=debug)
        jsonmap = t.raw_get(service_end_point, params)
        return popcorn_jcsv_to_dataframe(jsonmap[return_field_name], throw_on_error=throw_on_error, debug=debug,
                                             is_matrix=is_matrix)

def ts_dictionary(name=None, env="prod", throw_on_error=False, debug=False):
    """
    Retrieve a dictionary from the time series database. When name is not specified method
    returns the list of all available dictionaries.
    :param name: The name of the dictionary 
    :param env:  The environment to query.
    :param throw_on_error: True if an exception should be thrown on error.
    :debug              True|False - enable enhanced debugging options. 
    :return:
    """
    try:
        params = dict()
        if name == None:
            (service_end_point, return_field_name) = END_POINT_MAP.get("dicitonarydesc")
        else:
            (service_end_point, return_field_name) = END_POINT_MAP.get("dictionary")
            return_field_name = name
            params["name"]=name
        return __ts_execute_service(service_end_point,  return_field_name, params, throw_on_error, debug=debug, env=env)
    except Exception, e:
        if throw_on_error:
            raise e
        logging.exception(e)
    return None

def ts_search(tickers=None, fields=None, mnemonic=None, search_key=None, tags=None, env="prod", throw_on_error=False, debug=False):
    """
    See query.
    :param tickers:
    :param fields:
    :param mnemonic:
    :param search_key:
    :param tags:
    :param env:
    :debug              True|False - enable enhanced debugging options. 
    :return:
    """

    return ts_query(tickers, fields, mnemonic=None, search_key=search_key, tags = tags, metadataonly=True, use_default_series=False, env=env, throw_on_error=throw_on_error, debug=debug)

def ts_query(tickers=None, fields=None, start_date=None, end_date=None, mnemonic=None, search_key=None,
             tags=None, metadataonly=False,  env="prod", use_default_series=True, throw_on_error=False, debug=False,
             external_params = None):
    """  Query the time series service for data. Nomenclature
    :rtype : pandas data set
    :param tickers:     list or comma separated list of ticker registered in the time series database
    :param fields:      list or comma separated list of fields registered in the time series database
    :param start_date:  start date yyyy-mm-dd
    :param end_date:    end date yyyy-mm-dd
    :param mnemonic:    source mnemonic
    :param search_key:  pimco specific search key. Example: ABS.USD.FANNY.4Y.OAS
    :param tags:        collection of tags as tuples
    :param metadataonly: when true return only the descriptive information related this request.
    :param env          the environment to connect to. by default "prod"
    :param external_params: a dictionary containing parameters to be passed to external series
    :use_default_series trigger default series selection logic. error out if for a given criteria two or more series are matched.
    :throw_on_error     when False propagate exception upstream, otherwise silently ignore.
    :debug              True|False - enable enhanced debugging options. 
    :return:            pandas data set. when a single ticker and field are selected the headers are the name of the fields.
                        when multiple tickers, single field are specified the headers are tickers, and when the multiple
                        tickers and multiple fields are specified the headers are using the format2 of [ticker field].
    """

    try:

        params = OrderedDict()
        if use_default_series:
            # Error out if multiple matches found
            params['is_default_series'] = 'true'
        # Enable parameters constraints
        # Consistent set of parameters requried.
        params['enable_parameter_constraints'] = 'true'

        if metadataonly:
            (service_end_point, return_field_name) = END_POINT_MAP.get("metadata_only")
        else:
            (service_end_point, return_field_name) = END_POINT_MAP.get("data")



        if tickers:
            if isinstance(tickers, list):
                tickers = ','.join(tickers)
            params["id"] = tickers

        if fields:
            if isinstance(fields, list):
                fields = ','.join(fields)
            params["fields"] = fields

        if start_date:
            params["start_date"] = start_date

        if end_date:
            params["end_date"] = end_date

        if mnemonic:
            params["mnemonic"] =  mnemonic

        if search_key:
            params["search_key"] =  search_key

        if tags:
            if isinstance(tags, tuple):
                tags = [tags]
            if isinstance(tags, list):
                tagstring = None
                for tag in tags:
                    if tagstring:
                        tagstring = '%s,%s=%s' % (tagstring, tag[0], tag[1])
                    else:
                        tagstring = '%s=%s' % tag
                params["tags"] = tagstring
            else:
                if debug:
                    logging.warn("tags must be specified as tuples! Aborting.")
                if throw_on_error:
                    raise ValueError("tags must be specified as tuples! Aborting.")
                return None
        if external_params:
            if isinstance(external_params, dict):
                sb=[]
                for k,v in external_params.iteritems():
                    sb.append(k + "=" + v)
                params["external_params"] = ','.join(sb)
        return __ts_execute_service(service_end_point, return_field_name, params, throw_on_error, debug=debug, env=env)
    except Exception, e:
        if debug:
            logging.exception(e)
        if throw_on_error:
            raise e
    return None


def ts_query_multi_spec(spec_list, start_date=None, end_date=None, env="prod",  throw_on_error=False,
                    debug=False, is_strict_match=False):
    """
    Queries the timeseries service confirming to the
    `Multiseries Matrix Specification <https://pimcowiki:8443/display/TimeSrvc/Multiseries+Matrix+Specification>`_

    :param spec_list: List of specs. Each spec is a list containing [NAME, FIELD, SEARCH1, SEARCH2,...]
                      There are a few rules. Each spec list should contain at least two elements.
                      The first two elements are NAME and FIELD. They are mandatory. It can be None or an empty string
                      The following example provides three specs. The second one doesn't specify name and field::

                          [
                            ["USSW2", "RATE", "SOURCE=MDS", "SOURCE_MARKET=CURNCY"],
                            ["", "", "SOURCE_PRICING_SOURCE=ICPL", "SOURCE_MARKET=GOVT"],
                            ["CT2", "YIELD", "FREQUENCY=MONTHLY", "SOURCE_EXCHANGE=US"],
                          ]

    :param start_date: start date yyyy-mm-dd
    :param end_date: end date yyyy-mm-dd
    :param env: the environment to connect to. by default "prod"
    :param throw_on_error: when False propagate exception upstream, otherwise silently ignore.
    :param debug: True|False - enable enhanced debugging options.
    :param is_strict_match: See the matrix spec URL above
    :return: pandas data set
    """
    try:
        this_fn_name = ts_query_multi_spec
        params = OrderedDict()
        params['enable_parameter_constraints'] = 'true'

        service_end_point, return_field_name = END_POINT_MAP.get("data")

        if not spec_list:
            raise Exception('%s: Input "spec_list" cannot be empty', this_fn_name)
        elif (not isinstance(spec_list, (list, tuple))) or \
                [_ for _ in spec_list if not isinstance(_, (tuple, list)) or len(_) < 2]:
            raise Exception('%s: Input should be a list/tuple of lists/tuples. Minimum length on each list should be 2')

        def make_matrix(my_spec_list):
            max_len = max(len(_) for _ in my_spec_list)
            my_spec_list = [my_spec + [''] * (max_len - len(my_spec)) for my_spec in my_spec_list]
            return zip(*my_spec_list) # transpose

        data_matrix = make_matrix(spec_list)
        data_step_1 = [','.join(map(lambda x: '"%s"' % x if x is not None else '""', row)) for row in data_matrix]
        data_step_2 = '[%s]' % ','.join(['[%s]' % row for row in data_step_1])
        params['matrix'] = data_step_2

        if start_date:
            params["start_date"] = start_date

        if end_date:
            params["end_date"] = end_date

        if is_strict_match:
            params['is_strict_match'] = is_strict_match

        return __ts_execute_service(service_end_point, return_field_name, params, throw_on_error, debug=debug,
                                    env=env, is_matrix=True)

    except Exception as ex:
        if debug:
            logging.exception(ex)
        if throw_on_error:
            raise
    return None

