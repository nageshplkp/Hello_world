from core.services.timeseries.classes.com.pimco.dataservices.timeseries import \
    SeriesSource, SeriesMetadata, SeriesDescriptor, SeriesTag, Series, \
    DataManifest, Data
from dateutil import parser

def create_series_source_from_dict(
        template = None,
        attributes_dict = None
        ):
    local_dict = dict();
    if template is not None:
        if isinstance(template, SeriesSource) :
            for k, v in template.iteritems():
                local_dict[k] = v
        else:
            raise ValueError("template is of wrong type")

    if attributes_dict is not None:
        if isinstance(attributes_dict, dict):
            for k, v in attributes_dict.iteritems():
                local_dict[k] = v
        else:
            raise ValueError("attribute_dict is of wrong type")
    return SeriesSource(local_dict)

def create_series_metadata_from_dict(
        template = None,
        attributes_dict = None
        ):
    local_dict = dict();
    if template is not None:
        if isinstance(template, SeriesMetadata) :
            for k, v in template.iteritems():
                local_dict[k] = v
        else:
            raise ValueError("template is of wrong type")

    if attributes_dict is not None:
        if isinstance(attributes_dict, dict):
            for k, v in attributes_dict.iteritems():
                local_dict[k] = v
        else:
            raise ValueError("attribute_dict is of wrong type")
    return SeriesMetadata(local_dict)

def create_series_tags_from_dict(
        template = None,
        attributes_dict = None
        ):
    local_dict = dict();
    if template is not None:
        if isinstance(template, list) :
            for tag in template:
                if isinstance(tag, SeriesTag):
                    local_dict[tag.name] = tag.value
                else:
                    raise ValueError("template is of wrong type")
        else:
            raise ValueError("template is of wrong type")

    if attributes_dict is not None:
        if isinstance(attributes_dict, dict):
            for k, v in attributes_dict.iteritems():
                local_dict[k] = v
        else:
            raise ValueError("attribute_dict is of wrong type")
    list_tags  = [];
    for(k,v) in local_dict.iteritems():
        tag = SeriesTag()
        tag.name = k
        tag.value = v
        list_tags.append(tag)
    return list_tags

def create_data_manifest_from_dict(
        template = None,
        attributes_dict = None
        ):
    local_dict = dict();
    if template is not None:
        if isinstance(template, DataManifest) :
            for k, v in template.iteritems():
                local_dict[k] = v
        else:
            raise ValueError("template is of wrong type")

    if attributes_dict is not None:
        if isinstance(attributes_dict, dict):
            for k, v in attributes_dict.iteritems():
                local_dict[k] = v
        else:
            raise ValueError("attribute_dict is of wrong type")
    return DataManifest(local_dict)

def is_integer(value) :
    try:
        int(value)
        return True
    except:
        return False

def create_data_from_dict(
        template = None,
        attributes_dict = None,
        data_type = 'NUMERIC'
        ):
    if data_type is None:
        data_type = 'NUMERIC'
    local_dict = dict();
    if template is not None:
        if isinstance(template, Data) :
            for k, v in template.iteritems():
                local_dict[k] = v
        else:
            raise ValueError("template is of wrong type")

    new_dates = None
    new_numeric_values = None
    new_string_values = None
    data_list = []
    if attributes_dict is not None:
        if isinstance(attributes_dict, dict):
            for k, v in attributes_dict.iteritems():
                if k == 'dates':
                    if isinstance(v,list):
                        new_dates = v
                    else:
                        raise ValueError(k + " is of wrong type")
                elif k == 'numeric_values':
                    if isinstance(v, list):
                        new_numeric_values = v
                    else:
                        raise ValueError(k + " is of wrong type")
                elif k == 'string_values':
                    if isinstance(v, list):
                        new_string_values = v
                    else:
                        raise ValueError(k + " is of wrong type")
                elif is_integer(k):
                    index = int(k)
                    tokens = v.split('|')
                    if len(tokens) != 2:
                        raise ValueError(v + " is of wrong format: expected=<date>|<value>")
                    date = parser.parse(tokens[0])
                    numeric_value = None
                    string_value = None
                    if data_type == 'STRING':
                        string_value = tokens[1]
                    elif data_type == 'NUMERIC':
                        numeric_value = float(tokens[1])
                    else:
                        raise ValueError("unsupported data_type=" + data_type)
                    data_list.append((index, date, numeric_value, string_value))
                else:
                    local_dict[k] = v
        else:
            raise ValueError("attribute_dict is of wrong type")

    if len(data_list) > 0 :
        dates = []
        numeric_values = []
        string_values = []
        data_list.sort(key = lambda data_tuple: data_tuple[0])
        for data_tuple in data_list:
            dates.append(data_tuple[1])
            if data_tuple[2] is not None:
                numeric_values.append(data_tuple[2])
            if data_tuple[3] is not None:
                string_values.append(data_tuple[3])
        local_dict['dates'] = dates
        local_dict['numeric_values'] = numeric_values
        local_dict['string_values'] = string_values
    else:
        if not new_dates is None:
            local_dict['dates'] = new_dates
        if not new_numeric_values is None:
            local_dict['numeric_values'] = new_numeric_values
        if not new_string_values is None:
            local_dict['string_values'] = new_string_values

    return Data(local_dict)


LENGTH_SOURCE_DOT = len('source.')
LENGTH_METADATA_DOT = len('metadata.')
LENGTH_TAGS_DOT = len('tags.')

def create_series_descriptor_from_dict(
        template = None,
        attributes_dict = None
        ):
    local_dict = dict();
    if template is not None:
        if isinstance(template, SeriesDescriptor) :
            for k, v in template.iteritems():
                local_dict[k] = v
        else:
            raise ValueError("template is of wrong type")

    existing_source = local_dict['source'] if local_dict.has_key('source') else None
    existing_metadata = local_dict['metadata'] if local_dict.has_key('metadata') else None
    existing_tags = local_dict['tags'] if local_dict.has_key('tags') else None
    source_dict = dict()
    metadata_dict = dict()
    tags_dict=dict()
    new_source = None
    new_metadata = None
    new_tags = None
    if attributes_dict is not None:
        if isinstance(attributes_dict, dict):
            for k, v in attributes_dict.iteritems():
                if k == 'source':
                    if not isinstance(v, SeriesSource):
                        raise ValueError(k + " is of wrong type")
                    else:
                        new_source = v
                elif k == 'metadata':
                    if not isinstance(v, SeriesMetadata):
                        raise ValueError(k + " is of wrong type")
                    else:
                        new_metadata = v
                elif k == 'tags':
                    if not isinstance(v, list):
                        raise ValueError(k + " is of wrong type")
                    else:
                        if (len(v)) > 0:
                            #check the first item
                            first = v[0]
                            if not isinstance(first, SeriesTag):
                                raise ValueError(k + " is list of wrong type")
                        new_tags = v
                elif k.startswith('source.'):
                    k1 = k[LENGTH_SOURCE_DOT:]
                    source_dict[k1] = v
                elif k.startswith('metadata.'):
                    k1 = k[LENGTH_METADATA_DOT:]
                    metadata_dict[k1] = v
                elif k.startswith('tags.'):
                    k1 = k[LENGTH_TAGS_DOT:]
                    tags_dict[k1] = v
                else:
                    local_dict[k] = v
        else:
            raise ValueError("attribute_dict is of wrong type")
    #check for source
    if not new_source is None:
        local_dict['source'] = new_source
    elif len(source_dict) > 0 :
        ss = create_series_source_from_dict(existing_source, source_dict)
        local_dict['source'] = ss
    else:
        local_dict['source'] = existing_source

    #check for metadata
    if not new_metadata is None:
        local_dict['metadata'] = new_metadata
    elif len(metadata_dict) > 0 :
        ss = create_series_metadata_from_dict(existing_metadata, metadata_dict)
        local_dict['metadata'] = ss
    else:
        local_dict['metadata'] = existing_metadata

    #check for tags
    if not new_tags is None:
        local_dict['tags'] = new_tags
    elif len(tags_dict) > 0 :
        ss = create_series_tags_from_dict(existing_tags, tags_dict)
        local_dict['tags'] = ss
    else:
        local_dict['tags'] = existing_tags

    return SeriesDescriptor(local_dict)

LENGTH_DESCRIPTOR_DOT = len('descriptor.')
LENGTH_DATA_MANIFEST_DOT = len('data_manifest.')
LENGTH_DATA_DOT = len('data.')

def create_series_from_dict(
        template = None,
        attributes_dict = None
        ):
    local_dict = dict();
    if template is not None:
        if isinstance(template, Series) :
            for k, v in template.iteritems():
                local_dict[k] = v
        else:
            raise ValueError("template is of wrong type")

    existing_descriptor = local_dict['descriptor'] if local_dict.has_key('descriptor') else None
    existing_data_manifest = local_dict['data_manifest'] if local_dict.has_key('data_manifest') else None
    existing_data = local_dict['data'] if local_dict.has_key('data') else None
    descriptor_dict = dict()
    data_manifest_dict = dict()
    data_dict = dict()
    new_descriptor = None
    new_data_manifest = None
    new_data = None
    if attributes_dict is not None:
        if isinstance(attributes_dict, dict):
            for k, v in attributes_dict.iteritems():
                if k == 'descriptor':
                    if not isinstance(v, SeriesDescriptor):
                        raise ValueError(k + " is of wrong type")
                    else:
                        new_descriptor = v
                elif k == 'data_manifest':
                    if not isinstance(v, DataManifest):
                        raise ValueError(k + " is of wrong type")
                    else:
                        new_data_manifest = v
                elif k == 'data':
                    if not isinstance(v, Data):
                        raise ValueError(k + " is of wrong type")
                    else:
                        new_data = v
                elif k.startswith('descriptor.'):
                    k1 = k[LENGTH_DESCRIPTOR_DOT:]
                    descriptor_dict[k1] = v
                elif k.startswith('data_manifest.'):
                    k1 = k[LENGTH_DATA_MANIFEST_DOT:]
                    data_manifest_dict[k1] = v
                elif k.startswith('data.'):
                    k1 = k[LENGTH_DATA_DOT:]
                    data_dict[k1] = v
                else:
                    local_dict[k] = v
        else:
            raise ValueError("attribute_dict is of wrong type")
    #check for descriptor
    if not new_descriptor is None:
        local_dict['descriptor'] = new_descriptor
    elif len(descriptor_dict) > 0 :
        ss = create_series_descriptor_from_dict(existing_descriptor, descriptor_dict)
        local_dict['descriptor'] = ss
    else:
        local_dict['descriptor'] = existing_descriptor

    #check for data_manifest
    if not new_data_manifest is None:
        local_dict['data_manifest'] = new_data_manifest
    elif len(data_manifest_dict) > 0 :
        ss = create_data_manifest_from_dict(existing_data_manifest, data_manifest_dict)
        local_dict['data_manifest'] = ss
    else:
        local_dict['data_manifest'] = existing_data_manifest

    #check for data
    if not new_data is None:
        local_dict['data'] = new_data
    elif len(data_dict) > 0 :
        data_type = None
        if('descriptor' in local_dict):
            sd = local_dict['descriptor']
            if not sd is None :
                data_type = sd.data_type
        ss = create_data_from_dict(existing_data, data_dict)
        local_dict['data'] = ss
    else:
        local_dict['data'] = existing_data

    return Series(local_dict)



def create_series_source(
        template = None,
        base_ccy = None,
        broker = None,
        broker_source = None,
        country_code = None,
        created_by = None,
        created_timestamp = None,
        datafeed = None,
        delivery_time = None,
        exchange = None,
        id = None,
        market = None,
        mnemonic = None,
        series_metadata_id = None,
        source = None,
        source_transformation = None,
        ticker = None,
        unit = None,
        updated_by = None,
        updated_timestamp = None) :
    ss= create_series_source_from_dict(template=template)
    if base_ccy is not None:
        ss.base_ccy = base_ccy
    if broker is not None:
        ss.broker = broker
    if broker_source is not None:
        ss.broker_source = broker_source
    if country_code is not None:
        ss.country_code = country_code
    if created_by is not None:
        ss.created_by = created_by
    if created_timestamp is not None:
        ss.created_timestamp = created_timestamp
    if datafeed is not None:
        ss.datafeed = datafeed
    if delivery_time is not None:
        ss.delivery_time = delivery_time
    if exchange is not None:
        ss.exchange = exchange
    if id is not None:
        ss.id = id
    if market is not None:
        ss.market = market
    if mnemonic is not None:
        ss.mnemonic =  mnemonic
    if series_metadata_id is not None:
        ss.series_metadata_id = series_metadata_id
    if source is not None:
        ss.source = source
    if source_transformation is not None:
        ss.source_transformation = source_transformation
    if ticker is not None:
        ss.ticker = ticker
    if unit is not None:
        ss.unit = unit
    if updated_by is not None:
        ss.updated_by = updated_by
    if updated_timestamp is not None:
        ss.updated_timestamp = updated_timestamp

    return ss

def create_series_metadata(
        template = None,
        created_by = None,
        created_timestamp = None,
        description = None,
        id = None,
        owner = None,
        steward = None,
        tech_group = None,
        updated_by=None,
        updated_timestamp = None) :
    smd= create_series_metadata_from_dict(template)
    if created_by is not None:
        smd.created_by = created_by
    if created_timestamp is not None:
        smd.created_timestamp = created_timestamp
    if description is not None:
        smd.description = description
    if owner is not None:
        smd.owner = owner
    if steward is not None:
        smd.steward = steward
    if tech_group is not None:
        smd.tech_group = tech_group
    if updated_by is not None:
        smd.updated_by = updated_by
    if updated_timestamp is not None:
        smd.updated_timestamp = updated_timestamp

    return smd
