import getpass
import json
import logging
from urllib import urlencode
from urlparse import urlparse

from core.rest import client
from core.services.timeseries.classes.com.pimco.dataservices import timeseries as _ts
from core.services.timeseries.classes.schema_classes import _json_converter
from core.services.timeseries.decorate import CONN_MAP

assert isinstance(CONN_MAP, object)


class TsProxy:
    def __init__(self, base_url='dev', throw_on_error=True, debug=False):
        """
        Initialize a TsProxy instance.
        :param base_url: The base url (e.g. http://timeseriesdev:61000/timeseries/v1) to connect to
        One can also pass a environment name (e.g. dev) that is mapped internally to an url.
        :param throw_on_error: True|False if an exception should be thrown on error.
        :param debug           True|False - enable enhanced debugging options. 
        :return: Initialized instance
        """
        lower_case_base_url = base_url.lower()
        if lower_case_base_url.startswith('http://') or lower_case_base_url.startswith('https://'):
            assert isinstance(lower_case_base_url, object)
            self.base_url = lower_case_base_url
        else:
            if(CONN_MAP.has_key(lower_case_base_url)):
                self.base_url = CONN_MAP.get(lower_case_base_url).lower()
            else:
               raise ValueError('parameter must be a valid http/https url or a environment name in '+ ','.join(CONN_MAP.keys()))
        url = urlparse(self.base_url)
        if(url.netloc.startswith("ptp-")):
            self.use_kerberos = True
            self.headers = None
        else:
            self.use_kerberos = False
            self.headers = {'X-Remote-User': getpass.getuser()}
        self.throw_on_error = throw_on_error
        self.debug = debug

    def raw_get(self, url_suffix, params = None):
        """

        :rtype: json
        """
        url = self._parse_url_suffix(url_suffix, params=params)
        try:
            return client.get(url, use_kerberos=self.use_kerberos, headers=self.headers)
        except Exception as e:
            logging.exception(e)
            if self.throw_on_error:
                raise

        return None

    def roles(self, user=None):
        """
        :param user: If provided, use it as the username to provide roles for, otherwise use 
        the current user
        :return: A list of roles for the user
        """
        return self.raw_get(url_suffix='roles', params = None if (user is None) else {"user": user})

    def search_desc(self, filter = None, fields = None):
        params = dict()
        if filter is not None:
            params = filter.copy()
        if fields is not None:
            params['meta_data_field'] = ','.join(fields)
        params['_accept'] = 'application/json;fmt=csvs'
        return self.raw_get(url_suffix='seriesMetaData', params=params)

    def _parse_url_suffix(self, url_suffix, params=None):
        url = self.base_url
        if url_suffix is not None:
            url_suffix = url_suffix.strip()
            while url_suffix.startswith('/'):
                url_suffix = url_suffix[1:]
                url_suffix = url_suffix.strip()
            if len(url_suffix) > 0:
                url = url + '/' + url_suffix

        if params is not None:
            url = url + '?' + urlencode(params)
        return url

    def post_obj(self, url_suffix, obj):
        """
        Posts obj (an instance of a Python class) to the given TSS rest endpoint url.
        For example, if you want to post an approval object, you should create an instance of
        core.services.timeseries.classes.com.pimco.dataservices.timeseries.Approval and pass it to this
        method and it will return back an instance of UpdateResponse.

        :param url_suffix: suffix such as /approval or /series etc
        :param obj: The request object. Could be a list of request objects as well
        :return: Returns the response as a python object
        """
        url = self._parse_url_suffix(url_suffix)
        return parse_resp(
            client.post(url, obj, request_serializer=client.JSON_SERIALIZER_DW_ENC,
                        use_kerberos=self.use_kerberos, headers=self.headers)
        )


def parse_resp(resp, return_as=_ts.UpdateResponse):
    """
    Parses the JSON response from the TSS REST service into Python objects

    :param resp: The response received from the timeseries REST API
    :param return_as: Optional. Default is an instance of UpdateResponse class, assuming all the TSS service endpoints
                      return UpdateResponse. Pass a different class if the endpoint returns something else.
    :return: An instance of a generated python class
    """
    return _json_converter.from_json_object(resp, readers_schema=return_as.RECORD_SCHEMA)
