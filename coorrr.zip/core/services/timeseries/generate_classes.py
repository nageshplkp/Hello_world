import argparse
import json
import os
import shutil
import tempfile
import urllib
import zipfile

import six

from core.common.util import topo_sort_flatten
from tech.apps.avrogen.__main__ import write_schema


def parse_args():
    parser = argparse.ArgumentParser('Cloud Notebook Executor')
    parser.add_argument('-o', '--output-dir', type=str, help='Classes will be generated here', default='')
    return parser.parse_args()


def main():
    classes_dir = parse_args().output_dir
    if not classes_dir:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        classes_dir = os.path.join(script_dir, 'classes')
    if not os.path.exists(classes_dir):
        os.mkdir(classes_dir)

    url_schema_zip = 'http://prodart:1977/artifactory/repo/' \
                     'com/pimco/dataservices/timeseries-schema/3.9.7/timeseries-schema-3.9.7-avsc.zip'

    temp_d = tempfile.mkdtemp()

    # download
    print('Downloading', url_schema_zip)
    path_schema_zip = os.path.join(temp_d, 'schema.zip')
    urllib.urlretrieve (url_schema_zip, path_schema_zip)

    # extract
    z = zipfile.ZipFile(path_schema_zip, 'r')
    z.extractall(temp_d)
    z.close()

    path_schema_dir = os.path.join(temp_d, 'com/pimco/dataservices/timeseries')
    full_schema_file = os.path.join(temp_d, 'full_schema.avsc')

    # read individual schema files
    all_schemas_txt = []
    for schema_file in os.listdir(path_schema_dir):
        with open(os.path.join(path_schema_dir, schema_file)) as f:
            all_schemas_txt.append(f.read())

    # combine them into one and eliminate duplicates
    # ideally speaking, we shouldn't be doing this. The server doesn't provide a ".avpr" file
    # at this time. When available, we should use that.
    combined_json = json.loads('[' + ',\n'.join(all_schemas_txt) + ']')
    combined_json = remove_duplicates_in_schema(combined_json)
    with open(full_schema_file, 'w') as f:
        f.write(json.dumps(combined_json))

    # generate the classes
    write_schema(full_schema_file, classes_dir, argparse.Namespace(logical_types=False))
    print('Classes generated at ', classes_dir)

    print('cleaning up temporary files', temp_d)
    shutil.rmtree(temp_d, ignore_errors=True)


def remove_duplicates_in_schema(combined_json):
    # we have to replace duplicate definitions of schema elements.
    # for example, Series is defined at the root level and is also defined under UpdateRequest
    # replace the one under UpdateRequest
    # create a dependency graph so that schemas are merged with the correct order.
    my_types = set()
    result = []
    my_children = {}
    current_top_schema_name = None

    def deep_copy(value):
        if isinstance(value, dict) and 'type' in value:     # if this element represents a type in avro
            n, t = value.get('name'), value.get('type')
            if isinstance(t, six.string_types) and (n, t) in my_types:
                my_children[current_top_schema_name].add(n)  # create a dependency graph
                return n
        if isinstance(value, dict):
            return dict((_k, deep_copy(_v)) for _k, _v in six.iteritems(value))
        elif isinstance(value, (list, tuple)):
            return [deep_copy(_v) for _v in value]
        return value

    for i in combined_json:
        my_types.add((i['name'], i['type']))
        my_children[i['name']] = set()

    for i in combined_json:
        new_dict = {}
        current_top_schema_name = i['name']
        for k, v in six.iteritems(i):
            new_dict[k] = deep_copy(v)
        result.append(new_dict)

    ordered_names = topo_sort_flatten(my_children)
    end_result = list(ordered_names)
    for r in result:
        end_result[ordered_names.index(r['name'])] = r
    return end_result


if __name__ == "__main__":
    main()
