import json
import os.path
import decimal
import datetime
import six
import core.io.pimavro
from avrogen.dict_wrapper import DictWrapper
from avrogen import avrojson
from avro import schema as avro_schema
if six.PY3:    from avro.schema import SchemaFromJSONData as make_avsc_object
    
else:
    from avro.schema import make_avsc_object
    


def __read_file(file_name):
    with open(file_name, "r") as f:
        return f.read()

def __get_names_and_schema(file_name):
    names = avro_schema.Names()
    schema = make_avsc_object(json.loads(__read_file(file_name)), names)
    return names, schema

__NAMES, SCHEMA = __get_names_and_schema(os.path.join(os.path.dirname(__file__), "schema.avsc"))
__SCHEMAS = {}
def get_schema_type(fullname):
    return __SCHEMAS.get(fullname)
__SCHEMAS = dict((n.fullname.lstrip("."), n) for n in six.itervalues(__NAMES.names))


class SchemaClasses(object):
    
    
    pass
    class com(object):
        class pimco(object):
            class dataservices(object):
                class timeseries(object):
                    
                    class ApprovalClass(DictWrapper):
                        
                        """
                        * Approval record
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.Approval")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.ApprovalClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.series_natural_key = str()
                                self.etl_job_code = str()
                                self.approval_status_code = SchemaClasses.com.pimco.dataservices.timeseries.ApprovalStatusCodeClass.PENDING
                                self.created_date = SchemaClasses.com.pimco.dataservices.timeseries.ApprovalClass.RECORD_SCHEMA.fields[3].default
                                self.created_by = SchemaClasses.com.pimco.dataservices.timeseries.ApprovalClass.RECORD_SCHEMA.fields[4].default
                                self.last_chg_date = SchemaClasses.com.pimco.dataservices.timeseries.ApprovalClass.RECORD_SCHEMA.fields[5].default
                                self.last_chg_by = SchemaClasses.com.pimco.dataservices.timeseries.ApprovalClass.RECORD_SCHEMA.fields[6].default
                        
                        
                        @property
                        def series_natural_key(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('series_natural_key')
                        
                        @series_natural_key.setter
                        def series_natural_key(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['series_natural_key'] = value
                        
                        
                        @property
                        def etl_job_code(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('etl_job_code')
                        
                        @etl_job_code.setter
                        def etl_job_code(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['etl_job_code'] = value
                        
                        
                        @property
                        def approval_status_code(self):
                            """
                            :rtype: SchemaClasses.com.pimco.dataservices.timeseries.ApprovalStatusCodeClass
                            """
                            return self._inner_dict.get('approval_status_code')
                        
                        @approval_status_code.setter
                        def approval_status_code(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.dataservices.timeseries.ApprovalStatusCodeClass value:
                            #"""
                            self._inner_dict['approval_status_code'] = value
                        
                        
                        @property
                        def created_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_date')
                        
                        @created_date.setter
                        def created_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_date'] = value
                        
                        
                        @property
                        def created_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_by')
                        
                        @created_by.setter
                        def created_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_by'] = value
                        
                        
                        @property
                        def last_chg_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('last_chg_date')
                        
                        @last_chg_date.setter
                        def last_chg_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['last_chg_date'] = value
                        
                        
                        @property
                        def last_chg_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('last_chg_by')
                        
                        @last_chg_by.setter
                        def last_chg_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['last_chg_by'] = value
                        
                        
                    class ApprovalStatusClass(DictWrapper):
                        
                        """
                        * Approval status
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.ApprovalStatus")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.ApprovalStatusClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.approval_status_code = str()
                                self.approval_status_name = str()
                                self.created_date = SchemaClasses.com.pimco.dataservices.timeseries.ApprovalStatusClass.RECORD_SCHEMA.fields[2].default
                                self.created_by = SchemaClasses.com.pimco.dataservices.timeseries.ApprovalStatusClass.RECORD_SCHEMA.fields[3].default
                                self.last_chg_date = SchemaClasses.com.pimco.dataservices.timeseries.ApprovalStatusClass.RECORD_SCHEMA.fields[4].default
                                self.last_chg_by = SchemaClasses.com.pimco.dataservices.timeseries.ApprovalStatusClass.RECORD_SCHEMA.fields[5].default
                        
                        
                        @property
                        def approval_status_code(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('approval_status_code')
                        
                        @approval_status_code.setter
                        def approval_status_code(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['approval_status_code'] = value
                        
                        
                        @property
                        def approval_status_name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('approval_status_name')
                        
                        @approval_status_name.setter
                        def approval_status_name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['approval_status_name'] = value
                        
                        
                        @property
                        def created_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_date')
                        
                        @created_date.setter
                        def created_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_date'] = value
                        
                        
                        @property
                        def created_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_by')
                        
                        @created_by.setter
                        def created_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_by'] = value
                        
                        
                        @property
                        def last_chg_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('last_chg_date')
                        
                        @last_chg_date.setter
                        def last_chg_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['last_chg_date'] = value
                        
                        
                        @property
                        def last_chg_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('last_chg_by')
                        
                        @last_chg_by.setter
                        def last_chg_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['last_chg_by'] = value
                        
                        
                    class ApprovalStatusCodeClass(object):
                        
                        """
                        Not approved
                        """
                        
                        PENDING = "PENDING"
                        APPROVED = "APPROVED"
                        REJECTED = "REJECTED"
                        
                    class BlobClass(DictWrapper):
                        
                        """
                        Binary objects
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.Blob")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.BlobClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.data = str()
                                self.content_type = str()
                        
                        
                        @property
                        def data(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('data')
                        
                        @data.setter
                        def data(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['data'] = value
                        
                        
                        @property
                        def content_type(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('content_type')
                        
                        @content_type.setter
                        def content_type(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['content_type'] = value
                        
                        
                    class BlobDatumClass(DictWrapper):
                        
                        """
                        String data
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.BlobDatum")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.BlobDatumClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.value = SchemaClasses.com.pimco.dataservices.timeseries.BlobClass()
                        
                        
                        @property
                        def date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('date')
                        
                        @date.setter
                        def date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['date'] = value
                        
                        
                        @property
                        def value(self):
                            """
                            :rtype: SchemaClasses.com.pimco.dataservices.timeseries.BlobClass
                            """
                            return self._inner_dict.get('value')
                        
                        @value.setter
                        def value(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.dataservices.timeseries.BlobClass value:
                            #"""
                            self._inner_dict['value'] = value
                        
                        
                        @property
                        def arrival_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('arrival_date')
                        
                        @arrival_date.setter
                        def arrival_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['arrival_date'] = value
                        
                        
                    class DataClass(DictWrapper):
                        
                        """
                        data encapsulate the data for this series
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.Data")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.DataClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.dates = None
                                self.numeric_values = None
                                self.string_values = None
                                self.blob_values = None
                                self.updated = None
                                self.active = None
                        
                        
                        @property
                        def dates(self):
                            """
                            :rtype: list[str]
                            """
                            return self._inner_dict.get('dates')
                        
                        @dates.setter
                        def dates(self, value):
                            #"""
                            #:param list[str] value:
                            #"""
                            self._inner_dict['dates'] = value
                        
                        
                        @property
                        def numeric_values(self):
                            """
                            :rtype: list[float]
                            """
                            return self._inner_dict.get('numeric_values')
                        
                        @numeric_values.setter
                        def numeric_values(self, value):
                            #"""
                            #:param list[float] value:
                            #"""
                            self._inner_dict['numeric_values'] = value
                        
                        
                        @property
                        def string_values(self):
                            """
                            :rtype: list[str]
                            """
                            return self._inner_dict.get('string_values')
                        
                        @string_values.setter
                        def string_values(self, value):
                            #"""
                            #:param list[str] value:
                            #"""
                            self._inner_dict['string_values'] = value
                        
                        
                        @property
                        def blob_values(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.BlobClass]
                            """
                            return self._inner_dict.get('blob_values')
                        
                        @blob_values.setter
                        def blob_values(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.BlobClass] value:
                            #"""
                            self._inner_dict['blob_values'] = value
                        
                        
                        @property
                        def updated(self):
                            """
                            :rtype: list[bool]
                            """
                            return self._inner_dict.get('updated')
                        
                        @updated.setter
                        def updated(self, value):
                            #"""
                            #:param list[bool] value:
                            #"""
                            self._inner_dict['updated'] = value
                        
                        
                        @property
                        def active(self):
                            """
                            :rtype: list[bool]
                            """
                            return self._inner_dict.get('active')
                        
                        @active.setter
                        def active(self, value):
                            #"""
                            #:param list[bool] value:
                            #"""
                            self._inner_dict['active'] = value
                        
                        
                    class Data2DClass(DictWrapper):
                        
                        """
                        data2D record
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.Data2D")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.Data2DClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.idHeaders = None
                                self.coreIdHeaders = None
                                self.dataHeaders = None
                                self.rows = None
                        
                        
                        @property
                        def idHeaders(self):
                            """
                            :rtype: list[str]
                            """
                            return self._inner_dict.get('idHeaders')
                        
                        @idHeaders.setter
                        def idHeaders(self, value):
                            #"""
                            #:param list[str] value:
                            #"""
                            self._inner_dict['idHeaders'] = value
                        
                        
                        @property
                        def coreIdHeaders(self):
                            """
                            :rtype: dict[str, str]
                            """
                            return self._inner_dict.get('coreIdHeaders')
                        
                        @coreIdHeaders.setter
                        def coreIdHeaders(self, value):
                            #"""
                            #:param dict[str, str] value:
                            #"""
                            self._inner_dict['coreIdHeaders'] = value
                        
                        
                        @property
                        def dataHeaders(self):
                            """
                            :rtype: list[str]
                            """
                            return self._inner_dict.get('dataHeaders')
                        
                        @dataHeaders.setter
                        def dataHeaders(self, value):
                            #"""
                            #:param list[str] value:
                            #"""
                            self._inner_dict['dataHeaders'] = value
                        
                        
                        @property
                        def rows(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.RowClass]
                            """
                            return self._inner_dict.get('rows')
                        
                        @rows.setter
                        def rows(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.RowClass] value:
                            #"""
                            self._inner_dict['rows'] = value
                        
                        
                    class DataCellClass(DictWrapper):
                        
                        """
                        one single cell containing data
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.DataCell")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.DataCellClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.value = None
                        
                        
                        @property
                        def value(self):
                            """
                            :rtype: str | bool | int | long | float
                            """
                            return self._inner_dict.get('value')
                        
                        @value.setter
                        def value(self, value):
                            #"""
                            #:param str | bool | int | long | float value:
                            #"""
                            self._inner_dict['value'] = value
                        
                        
                    class DataManifestClass(DictWrapper):
                        
                        """
                        data manifest describes specific data update
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.DataManifest")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.DataManifestClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.arrival_date = None
                                self.supplier = None
                                self.validator = None
                                self.is_validated = None
                                self.source_uri = None
                                self.updated_by = SchemaClasses.com.pimco.dataservices.timeseries.DataManifestClass.RECORD_SCHEMA.fields[5].default
                                self.updated_timestamp = SchemaClasses.com.pimco.dataservices.timeseries.DataManifestClass.RECORD_SCHEMA.fields[6].default
                        
                        
                        @property
                        def arrival_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('arrival_date')
                        
                        @arrival_date.setter
                        def arrival_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['arrival_date'] = value
                        
                        
                        @property
                        def supplier(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('supplier')
                        
                        @supplier.setter
                        def supplier(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['supplier'] = value
                        
                        
                        @property
                        def validator(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('validator')
                        
                        @validator.setter
                        def validator(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['validator'] = value
                        
                        
                        @property
                        def is_validated(self):
                            """
                            :rtype: bool
                            """
                            return self._inner_dict.get('is_validated')
                        
                        @is_validated.setter
                        def is_validated(self, value):
                            #"""
                            #:param bool value:
                            #"""
                            self._inner_dict['is_validated'] = value
                        
                        
                        @property
                        def source_uri(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('source_uri')
                        
                        @source_uri.setter
                        def source_uri(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['source_uri'] = value
                        
                        
                        @property
                        def updated_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('updated_by')
                        
                        @updated_by.setter
                        def updated_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['updated_by'] = value
                        
                        
                        @property
                        def updated_timestamp(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('updated_timestamp')
                        
                        @updated_timestamp.setter
                        def updated_timestamp(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['updated_timestamp'] = value
                        
                        
                    class DataRequestClass(DictWrapper):
                        
                        """
                        always performed with a single transaction
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.DataRequest")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.DataRequestClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.is_over_write = bool()
                                self.data_manifest = SchemaClasses.com.pimco.dataservices.timeseries.DataManifestClass()
                                self.id_list = None
                                self.name_list = None
                                self.natural_key_list = None
                                self.data_list = list()
                        
                        
                        @property
                        def is_over_write(self):
                            """
                            :rtype: bool
                            """
                            return self._inner_dict.get('is_over_write')
                        
                        @is_over_write.setter
                        def is_over_write(self, value):
                            #"""
                            #:param bool value:
                            #"""
                            self._inner_dict['is_over_write'] = value
                        
                        
                        @property
                        def data_manifest(self):
                            """
                            :rtype: SchemaClasses.com.pimco.dataservices.timeseries.DataManifestClass
                            """
                            return self._inner_dict.get('data_manifest')
                        
                        @data_manifest.setter
                        def data_manifest(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.dataservices.timeseries.DataManifestClass value:
                            #"""
                            self._inner_dict['data_manifest'] = value
                        
                        
                        @property
                        def id_list(self):
                            """
                            :rtype: list[int]
                            """
                            return self._inner_dict.get('id_list')
                        
                        @id_list.setter
                        def id_list(self, value):
                            #"""
                            #:param list[int] value:
                            #"""
                            self._inner_dict['id_list'] = value
                        
                        
                        @property
                        def name_list(self):
                            """
                            :rtype: list[str]
                            """
                            return self._inner_dict.get('name_list')
                        
                        @name_list.setter
                        def name_list(self, value):
                            #"""
                            #:param list[str] value:
                            #"""
                            self._inner_dict['name_list'] = value
                        
                        
                        @property
                        def natural_key_list(self):
                            """
                            :rtype: list[str]
                            """
                            return self._inner_dict.get('natural_key_list')
                        
                        @natural_key_list.setter
                        def natural_key_list(self, value):
                            #"""
                            #:param list[str] value:
                            #"""
                            self._inner_dict['natural_key_list'] = value
                        
                        
                        @property
                        def data_list(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.DataClass]
                            """
                            return self._inner_dict.get('data_list')
                        
                        @data_list.setter
                        def data_list(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.DataClass] value:
                            #"""
                            self._inner_dict['data_list'] = value
                        
                        
                    class DictionaryClass(DictWrapper):
                        
                        """
                        dictionary payload
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.Dictionary")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.DictionaryClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.id = SchemaClasses.com.pimco.dataservices.timeseries.DictionaryClass.RECORD_SCHEMA.fields[0].default
                                self.name = SchemaClasses.com.pimco.dataservices.timeseries.DictionaryClass.RECORD_SCHEMA.fields[1].default
                                self.description = SchemaClasses.com.pimco.dataservices.timeseries.DictionaryClass.RECORD_SCHEMA.fields[2].default
                                self.blob = SchemaClasses.com.pimco.dataservices.timeseries.BlobClass(_json_converter.from_json_object(SchemaClasses.com.pimco.dataservices.timeseries.DictionaryClass.RECORD_SCHEMA.fields[3].default, writers_schema=SchemaClasses.com.pimco.dataservices.timeseries.DictionaryClass.RECORD_SCHEMA.fields[3].type))
                                self.created_by = SchemaClasses.com.pimco.dataservices.timeseries.DictionaryClass.RECORD_SCHEMA.fields[4].default
                                self.updated_by = SchemaClasses.com.pimco.dataservices.timeseries.DictionaryClass.RECORD_SCHEMA.fields[5].default
                                self.created_timestamp = SchemaClasses.com.pimco.dataservices.timeseries.DictionaryClass.RECORD_SCHEMA.fields[6].default
                                self.updated_timestamp = SchemaClasses.com.pimco.dataservices.timeseries.DictionaryClass.RECORD_SCHEMA.fields[7].default
                        
                        
                        @property
                        def id(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('id')
                        
                        @id.setter
                        def id(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['id'] = value
                        
                        
                        @property
                        def name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('name')
                        
                        @name.setter
                        def name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['name'] = value
                        
                        
                        @property
                        def description(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('description')
                        
                        @description.setter
                        def description(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['description'] = value
                        
                        
                        @property
                        def blob(self):
                            """
                            :rtype: SchemaClasses.com.pimco.dataservices.timeseries.BlobClass
                            """
                            return self._inner_dict.get('blob')
                        
                        @blob.setter
                        def blob(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.dataservices.timeseries.BlobClass value:
                            #"""
                            self._inner_dict['blob'] = value
                        
                        
                        @property
                        def created_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_by')
                        
                        @created_by.setter
                        def created_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_by'] = value
                        
                        
                        @property
                        def updated_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('updated_by')
                        
                        @updated_by.setter
                        def updated_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['updated_by'] = value
                        
                        
                        @property
                        def created_timestamp(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_timestamp')
                        
                        @created_timestamp.setter
                        def created_timestamp(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_timestamp'] = value
                        
                        
                        @property
                        def updated_timestamp(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('updated_timestamp')
                        
                        @updated_timestamp.setter
                        def updated_timestamp(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['updated_timestamp'] = value
                        
                        
                    class ETLJobClass(DictWrapper):
                        
                        """
                        * ETL Job
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.ETLJob")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.ETLJobClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.etl_job_code = str()
                                self.etl_job_name = str()
                                self.created_date = SchemaClasses.com.pimco.dataservices.timeseries.ETLJobClass.RECORD_SCHEMA.fields[2].default
                                self.created_by = SchemaClasses.com.pimco.dataservices.timeseries.ETLJobClass.RECORD_SCHEMA.fields[3].default
                                self.last_chg_date = SchemaClasses.com.pimco.dataservices.timeseries.ETLJobClass.RECORD_SCHEMA.fields[4].default
                                self.last_chg_by = SchemaClasses.com.pimco.dataservices.timeseries.ETLJobClass.RECORD_SCHEMA.fields[5].default
                        
                        
                        @property
                        def etl_job_code(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('etl_job_code')
                        
                        @etl_job_code.setter
                        def etl_job_code(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['etl_job_code'] = value
                        
                        
                        @property
                        def etl_job_name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('etl_job_name')
                        
                        @etl_job_name.setter
                        def etl_job_name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['etl_job_name'] = value
                        
                        
                        @property
                        def created_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_date')
                        
                        @created_date.setter
                        def created_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_date'] = value
                        
                        
                        @property
                        def created_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_by')
                        
                        @created_by.setter
                        def created_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_by'] = value
                        
                        
                        @property
                        def last_chg_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('last_chg_date')
                        
                        @last_chg_date.setter
                        def last_chg_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['last_chg_date'] = value
                        
                        
                        @property
                        def last_chg_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('last_chg_by')
                        
                        @last_chg_by.setter
                        def last_chg_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['last_chg_by'] = value
                        
                        
                    class FieldEntryClass(DictWrapper):
                        
                        """
                        * Field List record
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.FieldEntry")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.FieldEntryClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.name = str()
                                self.type = str()
                                self.series = str()
                                self.doc = None
                                self.frequency = SchemaClasses.com.pimco.dataservices.timeseries.FieldEntryClass.RECORD_SCHEMA.fields[4].default
                        
                        
                        @property
                        def name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('name')
                        
                        @name.setter
                        def name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['name'] = value
                        
                        
                        @property
                        def type(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('type')
                        
                        @type.setter
                        def type(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['type'] = value
                        
                        
                        @property
                        def series(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('series')
                        
                        @series.setter
                        def series(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['series'] = value
                        
                        
                        @property
                        def doc(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('doc')
                        
                        @doc.setter
                        def doc(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['doc'] = value
                        
                        
                        @property
                        def frequency(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('frequency')
                        
                        @frequency.setter
                        def frequency(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['frequency'] = value
                        
                        
                    class IdCellClass(DictWrapper):
                        
                        """
                        one single cell making up the identifier
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.IdCell")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.IdCellClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.value = None
                        
                        
                        @property
                        def value(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('value')
                        
                        @value.setter
                        def value(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['value'] = value
                        
                        
                    class LookupClass(DictWrapper):
                        
                        """
                        * Lookup
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.Lookup")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.LookupClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.id = int()
                                self.lookup_set = str()
                                self.name = str()
                                self.description = SchemaClasses.com.pimco.dataservices.timeseries.LookupClass.RECORD_SCHEMA.fields[3].default
                                self.created_by = SchemaClasses.com.pimco.dataservices.timeseries.LookupClass.RECORD_SCHEMA.fields[4].default
                                self.last_chg_by = SchemaClasses.com.pimco.dataservices.timeseries.LookupClass.RECORD_SCHEMA.fields[5].default
                                self.created_date = SchemaClasses.com.pimco.dataservices.timeseries.LookupClass.RECORD_SCHEMA.fields[6].default
                                self.last_chg_date = SchemaClasses.com.pimco.dataservices.timeseries.LookupClass.RECORD_SCHEMA.fields[7].default
                        
                        
                        @property
                        def id(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('id')
                        
                        @id.setter
                        def id(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['id'] = value
                        
                        
                        @property
                        def lookup_set(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('lookup_set')
                        
                        @lookup_set.setter
                        def lookup_set(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['lookup_set'] = value
                        
                        
                        @property
                        def name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('name')
                        
                        @name.setter
                        def name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['name'] = value
                        
                        
                        @property
                        def description(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('description')
                        
                        @description.setter
                        def description(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['description'] = value
                        
                        
                        @property
                        def created_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_by')
                        
                        @created_by.setter
                        def created_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_by'] = value
                        
                        
                        @property
                        def last_chg_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('last_chg_by')
                        
                        @last_chg_by.setter
                        def last_chg_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['last_chg_by'] = value
                        
                        
                        @property
                        def created_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_date')
                        
                        @created_date.setter
                        def created_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_date'] = value
                        
                        
                        @property
                        def last_chg_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('last_chg_date')
                        
                        @last_chg_date.setter
                        def last_chg_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['last_chg_date'] = value
                        
                        
                    class LookupSetClass(DictWrapper):
                        
                        """
                        * Lookup set
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.LookupSet")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.LookupSetClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.set = None
                        
                        
                        @property
                        def set(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.LookupClass]
                            """
                            return self._inner_dict.get('set')
                        
                        @set.setter
                        def set(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.LookupClass] value:
                            #"""
                            self._inner_dict['set'] = value
                        
                        
                    class NumericDatumClass(DictWrapper):
                        
                        """
                        Numerical data
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.NumericDatum")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.NumericDatumClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.value = float()
                                self.active = SchemaClasses.com.pimco.dataservices.timeseries.NumericDatumClass.RECORD_SCHEMA.fields[3].default
                        
                        
                        @property
                        def date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('date')
                        
                        @date.setter
                        def date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['date'] = value
                        
                        
                        @property
                        def value(self):
                            """
                            :rtype: float
                            """
                            return self._inner_dict.get('value')
                        
                        @value.setter
                        def value(self, value):
                            #"""
                            #:param float value:
                            #"""
                            self._inner_dict['value'] = value
                        
                        
                        @property
                        def arrival_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('arrival_date')
                        
                        @arrival_date.setter
                        def arrival_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['arrival_date'] = value
                        
                        
                        @property
                        def active(self):
                            """
                            :rtype: bool
                            """
                            return self._inner_dict.get('active')
                        
                        @active.setter
                        def active(self, value):
                            #"""
                            #:param bool value:
                            #"""
                            self._inner_dict['active'] = value
                        
                        
                    class RequestParamClass(DictWrapper):
                        
                        """
                        * Usage Tracking - REST request parameter
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.RequestParam")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.RequestParamClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.name = None
                                self.value = None
                        
                        
                        @property
                        def name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('name')
                        
                        @name.setter
                        def name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['name'] = value
                        
                        
                        @property
                        def value(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('value')
                        
                        @value.setter
                        def value(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['value'] = value
                        
                        
                    class RowClass(DictWrapper):
                        
                        """
                        one single row containing identifier cells and data cells
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.Row")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.RowClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.idRow = None
                                self.dataRow = list()
                        
                        
                        @property
                        def idRow(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.IdCellClass]
                            """
                            return self._inner_dict.get('idRow')
                        
                        @idRow.setter
                        def idRow(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.IdCellClass] value:
                            #"""
                            self._inner_dict['idRow'] = value
                        
                        
                        @property
                        def dataRow(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.DataCellClass]
                            """
                            return self._inner_dict.get('dataRow')
                        
                        @dataRow.setter
                        def dataRow(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.DataCellClass] value:
                            #"""
                            self._inner_dict['dataRow'] = value
                        
                        
                    class SeriesClass(DictWrapper):
                        
                        """
                        Main object describing series
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.Series")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.SeriesClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.descriptor = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass(_json_converter.from_json_object(SchemaClasses.com.pimco.dataservices.timeseries.SeriesClass.RECORD_SCHEMA.fields[0].default, writers_schema=SchemaClasses.com.pimco.dataservices.timeseries.SeriesClass.RECORD_SCHEMA.fields[0].type))
                                self.start_date = SchemaClasses.com.pimco.dataservices.timeseries.SeriesClass.RECORD_SCHEMA.fields[1].default
                                self.end_date = SchemaClasses.com.pimco.dataservices.timeseries.SeriesClass.RECORD_SCHEMA.fields[2].default
                                self.data = SchemaClasses.com.pimco.dataservices.timeseries.DataClass(_json_converter.from_json_object(SchemaClasses.com.pimco.dataservices.timeseries.SeriesClass.RECORD_SCHEMA.fields[3].default, writers_schema=SchemaClasses.com.pimco.dataservices.timeseries.SeriesClass.RECORD_SCHEMA.fields[3].type))
                                self.data_manifest = SchemaClasses.com.pimco.dataservices.timeseries.DataManifestClass(_json_converter.from_json_object(SchemaClasses.com.pimco.dataservices.timeseries.SeriesClass.RECORD_SCHEMA.fields[4].default, writers_schema=SchemaClasses.com.pimco.dataservices.timeseries.SeriesClass.RECORD_SCHEMA.fields[4].type))
                                self.version = SchemaClasses.com.pimco.dataservices.timeseries.SeriesClass.RECORD_SCHEMA.fields[5].default
                        
                        
                        @property
                        def descriptor(self):
                            """
                            :rtype: SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass
                            """
                            return self._inner_dict.get('descriptor')
                        
                        @descriptor.setter
                        def descriptor(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass value:
                            #"""
                            self._inner_dict['descriptor'] = value
                        
                        
                        @property
                        def start_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('start_date')
                        
                        @start_date.setter
                        def start_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['start_date'] = value
                        
                        
                        @property
                        def end_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('end_date')
                        
                        @end_date.setter
                        def end_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['end_date'] = value
                        
                        
                        @property
                        def data(self):
                            """
                            :rtype: SchemaClasses.com.pimco.dataservices.timeseries.DataClass
                            """
                            return self._inner_dict.get('data')
                        
                        @data.setter
                        def data(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.dataservices.timeseries.DataClass value:
                            #"""
                            self._inner_dict['data'] = value
                        
                        
                        @property
                        def data_manifest(self):
                            """
                            :rtype: SchemaClasses.com.pimco.dataservices.timeseries.DataManifestClass
                            """
                            return self._inner_dict.get('data_manifest')
                        
                        @data_manifest.setter
                        def data_manifest(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.dataservices.timeseries.DataManifestClass value:
                            #"""
                            self._inner_dict['data_manifest'] = value
                        
                        
                        @property
                        def version(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('version')
                        
                        @version.setter
                        def version(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['version'] = value
                        
                        
                    class SeriesDatumClass(DictWrapper):
                        
                        """
                        single series contains a natural key and a list of data Datum records
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.SeriesDatum")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.SeriesDatumClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.natural_key = str()
                                self.numeric_data_list = None
                                self.string_data_list = None
                                self.blob_data_list = None
                        
                        
                        @property
                        def natural_key(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('natural_key')
                        
                        @natural_key.setter
                        def natural_key(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['natural_key'] = value
                        
                        
                        @property
                        def numeric_data_list(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.NumericDatumClass]
                            """
                            return self._inner_dict.get('numeric_data_list')
                        
                        @numeric_data_list.setter
                        def numeric_data_list(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.NumericDatumClass] value:
                            #"""
                            self._inner_dict['numeric_data_list'] = value
                        
                        
                        @property
                        def string_data_list(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.StringDatumClass]
                            """
                            return self._inner_dict.get('string_data_list')
                        
                        @string_data_list.setter
                        def string_data_list(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.StringDatumClass] value:
                            #"""
                            self._inner_dict['string_data_list'] = value
                        
                        
                        @property
                        def blob_data_list(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.BlobDatumClass]
                            """
                            return self._inner_dict.get('blob_data_list')
                        
                        @blob_data_list.setter
                        def blob_data_list(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.BlobDatumClass] value:
                            #"""
                            self._inner_dict['blob_data_list'] = value
                        
                        
                    class SeriesDescriptorClass(DictWrapper):
                        
                        """
                        root object for meta data describing any series
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.SeriesDescriptor")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.id = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[0].default
                                self.type = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[1].default
                                self.data_type = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[2].default
                                self.frequency = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[3].default
                                self.unit = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[4].default
                                self.transformation = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[5].default
                                self.source = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass(_json_converter.from_json_object(SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[6].default, writers_schema=SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[6].type))
                                self.data_context = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[7].default
                                self.search_key = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[8].default
                                self.search_tags = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[9].default
                                self.name = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[10].default
                                self.description = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[11].default
                                self.long_description = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[12].default
                                self.field_name = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[13].default
                                self.data_state = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[14].default
                                self.created_by = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[15].default
                                self.updated_by = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[16].default
                                self.created_timestamp = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[17].default
                                self.updated_timestamp = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[18].default
                                self.metadata = SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass(_json_converter.from_json_object(SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[19].default, writers_schema=SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[19].type))
                                self.tags = None
                                self.is_default_series = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass.RECORD_SCHEMA.fields[21].default
                        
                        
                        @property
                        def id(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('id')
                        
                        @id.setter
                        def id(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['id'] = value
                        
                        
                        @property
                        def type(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('type')
                        
                        @type.setter
                        def type(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['type'] = value
                        
                        
                        @property
                        def data_type(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('data_type')
                        
                        @data_type.setter
                        def data_type(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['data_type'] = value
                        
                        
                        @property
                        def frequency(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('frequency')
                        
                        @frequency.setter
                        def frequency(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['frequency'] = value
                        
                        
                        @property
                        def unit(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('unit')
                        
                        @unit.setter
                        def unit(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['unit'] = value
                        
                        
                        @property
                        def transformation(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('transformation')
                        
                        @transformation.setter
                        def transformation(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['transformation'] = value
                        
                        
                        @property
                        def source(self):
                            """
                            :rtype: SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass
                            """
                            return self._inner_dict.get('source')
                        
                        @source.setter
                        def source(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass value:
                            #"""
                            self._inner_dict['source'] = value
                        
                        
                        @property
                        def data_context(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('data_context')
                        
                        @data_context.setter
                        def data_context(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['data_context'] = value
                        
                        
                        @property
                        def search_key(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('search_key')
                        
                        @search_key.setter
                        def search_key(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['search_key'] = value
                        
                        
                        @property
                        def search_tags(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('search_tags')
                        
                        @search_tags.setter
                        def search_tags(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['search_tags'] = value
                        
                        
                        @property
                        def name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('name')
                        
                        @name.setter
                        def name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['name'] = value
                        
                        
                        @property
                        def description(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('description')
                        
                        @description.setter
                        def description(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['description'] = value
                        
                        
                        @property
                        def long_description(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('long_description')
                        
                        @long_description.setter
                        def long_description(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['long_description'] = value
                        
                        
                        @property
                        def field_name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('field_name')
                        
                        @field_name.setter
                        def field_name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['field_name'] = value
                        
                        
                        @property
                        def data_state(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('data_state')
                        
                        @data_state.setter
                        def data_state(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['data_state'] = value
                        
                        
                        @property
                        def created_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_by')
                        
                        @created_by.setter
                        def created_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_by'] = value
                        
                        
                        @property
                        def updated_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('updated_by')
                        
                        @updated_by.setter
                        def updated_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['updated_by'] = value
                        
                        
                        @property
                        def created_timestamp(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_timestamp')
                        
                        @created_timestamp.setter
                        def created_timestamp(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_timestamp'] = value
                        
                        
                        @property
                        def updated_timestamp(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('updated_timestamp')
                        
                        @updated_timestamp.setter
                        def updated_timestamp(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['updated_timestamp'] = value
                        
                        
                        @property
                        def metadata(self):
                            """
                            :rtype: SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass
                            """
                            return self._inner_dict.get('metadata')
                        
                        @metadata.setter
                        def metadata(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass value:
                            #"""
                            self._inner_dict['metadata'] = value
                        
                        
                        @property
                        def tags(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.SeriesTagClass]
                            """
                            return self._inner_dict.get('tags')
                        
                        @tags.setter
                        def tags(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.SeriesTagClass] value:
                            #"""
                            self._inner_dict['tags'] = value
                        
                        
                        @property
                        def is_default_series(self):
                            """
                            :rtype: bool
                            """
                            return self._inner_dict.get('is_default_series')
                        
                        @is_default_series.setter
                        def is_default_series(self, value):
                            #"""
                            #:param bool value:
                            #"""
                            self._inner_dict['is_default_series'] = value
                        
                        
                    class SeriesDescriptorLiteClass(DictWrapper):
                        
                        """
                        A record which returns a light-weight descriptor
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.SeriesDescriptorLite")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorLiteClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.name = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorLiteClass.RECORD_SCHEMA.fields[0].default
                                self.data_context = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorLiteClass.RECORD_SCHEMA.fields[1].default
                                self.source = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorLiteClass.RECORD_SCHEMA.fields[2].default
                                self.source_pricing_source = SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorLiteClass.RECORD_SCHEMA.fields[3].default
                        
                        
                        @property
                        def name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('name')
                        
                        @name.setter
                        def name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['name'] = value
                        
                        
                        @property
                        def data_context(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('data_context')
                        
                        @data_context.setter
                        def data_context(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['data_context'] = value
                        
                        
                        @property
                        def source(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('source')
                        
                        @source.setter
                        def source(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['source'] = value
                        
                        
                        @property
                        def source_pricing_source(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('source_pricing_source')
                        
                        @source_pricing_source.setter
                        def source_pricing_source(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['source_pricing_source'] = value
                        
                        
                    class SeriesHierarchyClass(DictWrapper):
                        
                        """
                        series hierarchy model
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.SeriesHierarchy")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.SeriesHierarchyClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.id = SchemaClasses.com.pimco.dataservices.timeseries.SeriesHierarchyClass.RECORD_SCHEMA.fields[0].default
                                self.name = SchemaClasses.com.pimco.dataservices.timeseries.SeriesHierarchyClass.RECORD_SCHEMA.fields[1].default
                                self.description = SchemaClasses.com.pimco.dataservices.timeseries.SeriesHierarchyClass.RECORD_SCHEMA.fields[2].default
                                self.parent_id = SchemaClasses.com.pimco.dataservices.timeseries.SeriesHierarchyClass.RECORD_SCHEMA.fields[3].default
                                self.created_by = SchemaClasses.com.pimco.dataservices.timeseries.SeriesHierarchyClass.RECORD_SCHEMA.fields[4].default
                                self.updated_by = SchemaClasses.com.pimco.dataservices.timeseries.SeriesHierarchyClass.RECORD_SCHEMA.fields[5].default
                                self.created_timestamp = SchemaClasses.com.pimco.dataservices.timeseries.SeriesHierarchyClass.RECORD_SCHEMA.fields[6].default
                                self.updated_timestamp = SchemaClasses.com.pimco.dataservices.timeseries.SeriesHierarchyClass.RECORD_SCHEMA.fields[7].default
                        
                        
                        @property
                        def id(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('id')
                        
                        @id.setter
                        def id(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['id'] = value
                        
                        
                        @property
                        def name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('name')
                        
                        @name.setter
                        def name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['name'] = value
                        
                        
                        @property
                        def description(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('description')
                        
                        @description.setter
                        def description(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['description'] = value
                        
                        
                        @property
                        def parent_id(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('parent_id')
                        
                        @parent_id.setter
                        def parent_id(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['parent_id'] = value
                        
                        
                        @property
                        def created_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_by')
                        
                        @created_by.setter
                        def created_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_by'] = value
                        
                        
                        @property
                        def updated_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('updated_by')
                        
                        @updated_by.setter
                        def updated_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['updated_by'] = value
                        
                        
                        @property
                        def created_timestamp(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_timestamp')
                        
                        @created_timestamp.setter
                        def created_timestamp(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_timestamp'] = value
                        
                        
                        @property
                        def updated_timestamp(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('updated_timestamp')
                        
                        @updated_timestamp.setter
                        def updated_timestamp(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['updated_timestamp'] = value
                        
                        
                    class SeriesIndexChangeClass(DictWrapper):
                        
                        """
                        A record sent internally between engines to notify each other of changes
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.SeriesIndexChange")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.SeriesIndexChangeClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.host = str()
                                self.entityType = str()
                                self.entityName = SchemaClasses.com.pimco.dataservices.timeseries.SeriesIndexChangeClass.RECORD_SCHEMA.fields[2].default
                                self.operationType = SchemaClasses.com.pimco.dataservices.timeseries.SeriesIndexChangeClass.RECORD_SCHEMA.fields[3].default
                                self.seriesIndex = SchemaClasses.com.pimco.dataservices.timeseries.SeriesIndexChangeClass.RECORD_SCHEMA.fields[4].default
                                self.changeId = SchemaClasses.com.pimco.dataservices.timeseries.SeriesIndexChangeClass.RECORD_SCHEMA.fields[5].default
                        
                        
                        @property
                        def host(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('host')
                        
                        @host.setter
                        def host(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['host'] = value
                        
                        
                        @property
                        def entityType(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('entityType')
                        
                        @entityType.setter
                        def entityType(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['entityType'] = value
                        
                        
                        @property
                        def entityName(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('entityName')
                        
                        @entityName.setter
                        def entityName(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['entityName'] = value
                        
                        
                        @property
                        def operationType(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('operationType')
                        
                        @operationType.setter
                        def operationType(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['operationType'] = value
                        
                        
                        @property
                        def seriesIndex(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('seriesIndex')
                        
                        @seriesIndex.setter
                        def seriesIndex(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['seriesIndex'] = value
                        
                        
                        @property
                        def changeId(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('changeId')
                        
                        @changeId.setter
                        def changeId(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['changeId'] = value
                        
                        
                    class SeriesMetadataClass(DictWrapper):
                        
                        """
                        series meta data define ownership and other info
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.SeriesMetadata")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.id = SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass.RECORD_SCHEMA.fields[0].default
                                self.description = SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass.RECORD_SCHEMA.fields[1].default
                                self.owner = SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass.RECORD_SCHEMA.fields[2].default
                                self.steward = SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass.RECORD_SCHEMA.fields[3].default
                                self.tech_group = SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass.RECORD_SCHEMA.fields[4].default
                                self.created_by = SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass.RECORD_SCHEMA.fields[5].default
                                self.updated_by = SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass.RECORD_SCHEMA.fields[6].default
                                self.created_timestamp = SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass.RECORD_SCHEMA.fields[7].default
                                self.updated_timestamp = SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass.RECORD_SCHEMA.fields[8].default
                        
                        
                        @property
                        def id(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('id')
                        
                        @id.setter
                        def id(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['id'] = value
                        
                        
                        @property
                        def description(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('description')
                        
                        @description.setter
                        def description(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['description'] = value
                        
                        
                        @property
                        def owner(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('owner')
                        
                        @owner.setter
                        def owner(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['owner'] = value
                        
                        
                        @property
                        def steward(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('steward')
                        
                        @steward.setter
                        def steward(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['steward'] = value
                        
                        
                        @property
                        def tech_group(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('tech_group')
                        
                        @tech_group.setter
                        def tech_group(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['tech_group'] = value
                        
                        
                        @property
                        def created_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_by')
                        
                        @created_by.setter
                        def created_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_by'] = value
                        
                        
                        @property
                        def updated_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('updated_by')
                        
                        @updated_by.setter
                        def updated_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['updated_by'] = value
                        
                        
                        @property
                        def created_timestamp(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_timestamp')
                        
                        @created_timestamp.setter
                        def created_timestamp(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_timestamp'] = value
                        
                        
                        @property
                        def updated_timestamp(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('updated_timestamp')
                        
                        @updated_timestamp.setter
                        def updated_timestamp(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['updated_timestamp'] = value
                        
                        
                    class SeriesRequestInfoClass(DictWrapper):
                        
                        """
                        * Usage Tracking - REST request
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.SeriesRequestInfo")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.SeriesRequestInfoClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.url = None
                                self.params = None
                                self.id_list = None
                                self.message = None
                        
                        
                        @property
                        def url(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('url')
                        
                        @url.setter
                        def url(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['url'] = value
                        
                        
                        @property
                        def params(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.RequestParamClass]
                            """
                            return self._inner_dict.get('params')
                        
                        @params.setter
                        def params(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.RequestParamClass] value:
                            #"""
                            self._inner_dict['params'] = value
                        
                        
                        @property
                        def id_list(self):
                            """
                            :rtype: list[int]
                            """
                            return self._inner_dict.get('id_list')
                        
                        @id_list.setter
                        def id_list(self, value):
                            #"""
                            #:param list[int] value:
                            #"""
                            self._inner_dict['id_list'] = value
                        
                        
                        @property
                        def message(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('message')
                        
                        @message.setter
                        def message(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['message'] = value
                        
                        
                    class SeriesSetClass(DictWrapper):
                        
                        """
                        series sets
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.SeriesSet")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.id = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetClass.RECORD_SCHEMA.fields[0].default
                                self.name = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetClass.RECORD_SCHEMA.fields[1].default
                                self.description = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetClass.RECORD_SCHEMA.fields[2].default
                                self.hierarchy_id = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetClass.RECORD_SCHEMA.fields[3].default
                                self.created_by = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetClass.RECORD_SCHEMA.fields[4].default
                                self.updated_by = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetClass.RECORD_SCHEMA.fields[5].default
                                self.created_timestamp = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetClass.RECORD_SCHEMA.fields[6].default
                                self.updated_timestamp = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetClass.RECORD_SCHEMA.fields[7].default
                                self.tags = None
                        
                        
                        @property
                        def id(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('id')
                        
                        @id.setter
                        def id(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['id'] = value
                        
                        
                        @property
                        def name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('name')
                        
                        @name.setter
                        def name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['name'] = value
                        
                        
                        @property
                        def description(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('description')
                        
                        @description.setter
                        def description(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['description'] = value
                        
                        
                        @property
                        def hierarchy_id(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('hierarchy_id')
                        
                        @hierarchy_id.setter
                        def hierarchy_id(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['hierarchy_id'] = value
                        
                        
                        @property
                        def created_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_by')
                        
                        @created_by.setter
                        def created_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_by'] = value
                        
                        
                        @property
                        def updated_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('updated_by')
                        
                        @updated_by.setter
                        def updated_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['updated_by'] = value
                        
                        
                        @property
                        def created_timestamp(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_timestamp')
                        
                        @created_timestamp.setter
                        def created_timestamp(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_timestamp'] = value
                        
                        
                        @property
                        def updated_timestamp(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('updated_timestamp')
                        
                        @updated_timestamp.setter
                        def updated_timestamp(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['updated_timestamp'] = value
                        
                        
                        @property
                        def tags(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetTagClass]
                            """
                            return self._inner_dict.get('tags')
                        
                        @tags.setter
                        def tags(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetTagClass] value:
                            #"""
                            self._inner_dict['tags'] = value
                        
                        
                    class SeriesSetTagClass(DictWrapper):
                        
                        """
                        set of series tags
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.SeriesSetTag")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetTagClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.id = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetTagClass.RECORD_SCHEMA.fields[0].default
                                self.name = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetTagClass.RECORD_SCHEMA.fields[1].default
                                self.tag_order = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetTagClass.RECORD_SCHEMA.fields[2].default
                        
                        
                        @property
                        def id(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('id')
                        
                        @id.setter
                        def id(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['id'] = value
                        
                        
                        @property
                        def name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('name')
                        
                        @name.setter
                        def name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['name'] = value
                        
                        
                        @property
                        def tag_order(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('tag_order')
                        
                        @tag_order.setter
                        def tag_order(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['tag_order'] = value
                        
                        
                    class SeriesSourceClass(DictWrapper):
                        
                        """
                        define source properties
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.SeriesSource")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.id = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[0].default
                                self.source = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[1].default
                                self.ticker = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[2].default
                                self.mnemonic = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[3].default
                                self.market = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[4].default
                                self.broker = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[5].default
                                self.base_ccy = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[6].default
                                self.series_metadata_id = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[7].default
                                self.datafeed = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[8].default
                                self.unit = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[9].default
                                self.broker_source = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[10].default
                                self.exchange = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[11].default
                                self.delivery_time = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[12].default
                                self.source_transformation = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[13].default
                                self.created_by = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[14].default
                                self.updated_by = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[15].default
                                self.created_timestamp = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[16].default
                                self.updated_timestamp = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[17].default
                                self.country_code = SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass.RECORD_SCHEMA.fields[18].default
                        
                        
                        @property
                        def id(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('id')
                        
                        @id.setter
                        def id(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['id'] = value
                        
                        
                        @property
                        def source(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('source')
                        
                        @source.setter
                        def source(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['source'] = value
                        
                        
                        @property
                        def ticker(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('ticker')
                        
                        @ticker.setter
                        def ticker(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['ticker'] = value
                        
                        
                        @property
                        def mnemonic(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('mnemonic')
                        
                        @mnemonic.setter
                        def mnemonic(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['mnemonic'] = value
                        
                        
                        @property
                        def market(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('market')
                        
                        @market.setter
                        def market(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['market'] = value
                        
                        
                        @property
                        def broker(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('broker')
                        
                        @broker.setter
                        def broker(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['broker'] = value
                        
                        
                        @property
                        def base_ccy(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('base_ccy')
                        
                        @base_ccy.setter
                        def base_ccy(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['base_ccy'] = value
                        
                        
                        @property
                        def series_metadata_id(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('series_metadata_id')
                        
                        @series_metadata_id.setter
                        def series_metadata_id(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['series_metadata_id'] = value
                        
                        
                        @property
                        def datafeed(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('datafeed')
                        
                        @datafeed.setter
                        def datafeed(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['datafeed'] = value
                        
                        
                        @property
                        def unit(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('unit')
                        
                        @unit.setter
                        def unit(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['unit'] = value
                        
                        
                        @property
                        def broker_source(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('broker_source')
                        
                        @broker_source.setter
                        def broker_source(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['broker_source'] = value
                        
                        
                        @property
                        def exchange(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('exchange')
                        
                        @exchange.setter
                        def exchange(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['exchange'] = value
                        
                        
                        @property
                        def delivery_time(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('delivery_time')
                        
                        @delivery_time.setter
                        def delivery_time(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['delivery_time'] = value
                        
                        
                        @property
                        def source_transformation(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('source_transformation')
                        
                        @source_transformation.setter
                        def source_transformation(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['source_transformation'] = value
                        
                        
                        @property
                        def created_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_by')
                        
                        @created_by.setter
                        def created_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_by'] = value
                        
                        
                        @property
                        def updated_by(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('updated_by')
                        
                        @updated_by.setter
                        def updated_by(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['updated_by'] = value
                        
                        
                        @property
                        def created_timestamp(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('created_timestamp')
                        
                        @created_timestamp.setter
                        def created_timestamp(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['created_timestamp'] = value
                        
                        
                        @property
                        def updated_timestamp(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('updated_timestamp')
                        
                        @updated_timestamp.setter
                        def updated_timestamp(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['updated_timestamp'] = value
                        
                        
                        @property
                        def country_code(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('country_code')
                        
                        @country_code.setter
                        def country_code(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['country_code'] = value
                        
                        
                    class SeriesTagClass(DictWrapper):
                        
                        """
                        a simple tag has a value and a name
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.SeriesTag")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.SeriesTagClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.name = None
                                self.value = None
                        
                        
                        @property
                        def name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('name')
                        
                        @name.setter
                        def name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['name'] = value
                        
                        
                        @property
                        def value(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('value')
                        
                        @value.setter
                        def value(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['value'] = value
                        
                        
                    class SeriesUpdateRequestClass(DictWrapper):
                        
                        """
                        series update request.
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.SeriesUpdateRequest")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.SeriesUpdateRequestClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.manifest = SchemaClasses.com.pimco.dataservices.timeseries.DataManifestClass(_json_converter.from_json_object(SchemaClasses.com.pimco.dataservices.timeseries.SeriesUpdateRequestClass.RECORD_SCHEMA.fields[0].default, writers_schema=SchemaClasses.com.pimco.dataservices.timeseries.SeriesUpdateRequestClass.RECORD_SCHEMA.fields[0].type))
                                self.series_list = list()
                        
                        
                        @property
                        def manifest(self):
                            """
                            :rtype: SchemaClasses.com.pimco.dataservices.timeseries.DataManifestClass
                            """
                            return self._inner_dict.get('manifest')
                        
                        @manifest.setter
                        def manifest(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.dataservices.timeseries.DataManifestClass value:
                            #"""
                            self._inner_dict['manifest'] = value
                        
                        
                        @property
                        def series_list(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.SeriesDatumClass]
                            """
                            return self._inner_dict.get('series_list')
                        
                        @series_list.setter
                        def series_list(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.SeriesDatumClass] value:
                            #"""
                            self._inner_dict['series_list'] = value
                        
                        
                    class StringDatumClass(DictWrapper):
                        
                        """
                        String data
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.StringDatum")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.StringDatumClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.value = str()
                                self.active = SchemaClasses.com.pimco.dataservices.timeseries.StringDatumClass.RECORD_SCHEMA.fields[3].default
                        
                        
                        @property
                        def date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('date')
                        
                        @date.setter
                        def date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['date'] = value
                        
                        
                        @property
                        def value(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('value')
                        
                        @value.setter
                        def value(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['value'] = value
                        
                        
                        @property
                        def arrival_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('arrival_date')
                        
                        @arrival_date.setter
                        def arrival_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['arrival_date'] = value
                        
                        
                        @property
                        def active(self):
                            """
                            :rtype: bool
                            """
                            return self._inner_dict.get('active')
                        
                        @active.setter
                        def active(self, value):
                            #"""
                            #:param bool value:
                            #"""
                            self._inner_dict['active'] = value
                        
                        
                    class UpdateCodeClass(object):
                        
                        """
                        no series found
                        """
                        
                        SUCCESS = "SUCCESS"
                        PARTIAL_SUCCESS = "PARTIAL_SUCCESS"
                        FAILURE = "FAILURE"
                        NONE = "NONE"
                        NOT_FOUND = "NOT_FOUND"
                        
                    class UpdateRequestClass(DictWrapper):
                        
                        """
                        update request for multiple series
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.UpdateRequest")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.UpdateRequestClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.is_over_write = bool()
                                self.is_atomic = bool()
                                self.series_list = None
                        
                        
                        @property
                        def is_over_write(self):
                            """
                            :rtype: bool
                            """
                            return self._inner_dict.get('is_over_write')
                        
                        @is_over_write.setter
                        def is_over_write(self, value):
                            #"""
                            #:param bool value:
                            #"""
                            self._inner_dict['is_over_write'] = value
                        
                        
                        @property
                        def is_atomic(self):
                            """
                            :rtype: bool
                            """
                            return self._inner_dict.get('is_atomic')
                        
                        @is_atomic.setter
                        def is_atomic(self, value):
                            #"""
                            #:param bool value:
                            #"""
                            self._inner_dict['is_atomic'] = value
                        
                        
                        @property
                        def series_list(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.SeriesClass]
                            """
                            return self._inner_dict.get('series_list')
                        
                        @series_list.setter
                        def series_list(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.SeriesClass] value:
                            #"""
                            self._inner_dict['series_list'] = value
                        
                        
                    class UpdateResponseClass(DictWrapper):
                        
                        """
                        update response wrapper
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.UpdateResponse")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.UpdateResponseClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.update_code = SchemaClasses.com.pimco.dataservices.timeseries.UpdateCodeClass.SUCCESS
                                self.update_details = list()
                        
                        
                        @property
                        def update_code(self):
                            """
                            :rtype: SchemaClasses.com.pimco.dataservices.timeseries.UpdateCodeClass
                            """
                            return self._inner_dict.get('update_code')
                        
                        @update_code.setter
                        def update_code(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.dataservices.timeseries.UpdateCodeClass value:
                            #"""
                            self._inner_dict['update_code'] = value
                        
                        
                        @property
                        def update_details(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.dataservices.timeseries.UpdateStatusClass]
                            """
                            return self._inner_dict.get('update_details')
                        
                        @update_details.setter
                        def update_details(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.dataservices.timeseries.UpdateStatusClass] value:
                            #"""
                            self._inner_dict['update_details'] = value
                        
                        
                    class UpdateStatusClass(DictWrapper):
                        
                        """
                        update status meta data
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.dataservices.timeseries.UpdateStatus")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.dataservices.timeseries.UpdateStatusClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.request_id = str()
                                self.target_type = SchemaClasses.com.pimco.dataservices.timeseries.UpdateTargetTypeClass.SERIES
                                self.target_id = int()
                                self.update_code = SchemaClasses.com.pimco.dataservices.timeseries.UpdateCodeClass.SUCCESS
                                self.message = None
                        
                        
                        @property
                        def request_id(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('request_id')
                        
                        @request_id.setter
                        def request_id(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['request_id'] = value
                        
                        
                        @property
                        def target_type(self):
                            """
                            :rtype: SchemaClasses.com.pimco.dataservices.timeseries.UpdateTargetTypeClass
                            """
                            return self._inner_dict.get('target_type')
                        
                        @target_type.setter
                        def target_type(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.dataservices.timeseries.UpdateTargetTypeClass value:
                            #"""
                            self._inner_dict['target_type'] = value
                        
                        
                        @property
                        def target_id(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('target_id')
                        
                        @target_id.setter
                        def target_id(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['target_id'] = value
                        
                        
                        @property
                        def update_code(self):
                            """
                            :rtype: SchemaClasses.com.pimco.dataservices.timeseries.UpdateCodeClass
                            """
                            return self._inner_dict.get('update_code')
                        
                        @update_code.setter
                        def update_code(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.dataservices.timeseries.UpdateCodeClass value:
                            #"""
                            self._inner_dict['update_code'] = value
                        
                        
                        @property
                        def message(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('message')
                        
                        @message.setter
                        def message(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['message'] = value
                        
                        
                    class UpdateTargetTypeClass(object):
                        
                        """
                        ETL Job update
                        """
                        
                        SERIES = "SERIES"
                        SERIES_SET = "SERIES_SET"
                        SERIES_DICTIONARY = "SERIES_DICTIONARY"
                        SERIES_CONSTRUCTOR = "SERIES_CONSTRUCTOR"
                        SERIES_SET_HIERARCHY = "SERIES_SET_HIERARCHY"
                        APPROVAL = "APPROVAL"
                        APPROVAL_STATUS = "APPROVAL_STATUS"
                        ETL_JOB = "ETL_JOB"
                        
                    pass
                    
__SCHEMA_TYPES = {
'com.pimco.dataservices.timeseries.Approval': SchemaClasses.com.pimco.dataservices.timeseries.ApprovalClass,
    'com.pimco.dataservices.timeseries.ApprovalStatus': SchemaClasses.com.pimco.dataservices.timeseries.ApprovalStatusClass,
    'com.pimco.dataservices.timeseries.ApprovalStatusCode': SchemaClasses.com.pimco.dataservices.timeseries.ApprovalStatusCodeClass,
    'com.pimco.dataservices.timeseries.Blob': SchemaClasses.com.pimco.dataservices.timeseries.BlobClass,
    'com.pimco.dataservices.timeseries.BlobDatum': SchemaClasses.com.pimco.dataservices.timeseries.BlobDatumClass,
    'com.pimco.dataservices.timeseries.Data': SchemaClasses.com.pimco.dataservices.timeseries.DataClass,
    'com.pimco.dataservices.timeseries.Data2D': SchemaClasses.com.pimco.dataservices.timeseries.Data2DClass,
    'com.pimco.dataservices.timeseries.DataCell': SchemaClasses.com.pimco.dataservices.timeseries.DataCellClass,
    'com.pimco.dataservices.timeseries.DataManifest': SchemaClasses.com.pimco.dataservices.timeseries.DataManifestClass,
    'com.pimco.dataservices.timeseries.DataRequest': SchemaClasses.com.pimco.dataservices.timeseries.DataRequestClass,
    'com.pimco.dataservices.timeseries.Dictionary': SchemaClasses.com.pimco.dataservices.timeseries.DictionaryClass,
    'com.pimco.dataservices.timeseries.ETLJob': SchemaClasses.com.pimco.dataservices.timeseries.ETLJobClass,
    'com.pimco.dataservices.timeseries.FieldEntry': SchemaClasses.com.pimco.dataservices.timeseries.FieldEntryClass,
    'com.pimco.dataservices.timeseries.IdCell': SchemaClasses.com.pimco.dataservices.timeseries.IdCellClass,
    'com.pimco.dataservices.timeseries.Lookup': SchemaClasses.com.pimco.dataservices.timeseries.LookupClass,
    'com.pimco.dataservices.timeseries.LookupSet': SchemaClasses.com.pimco.dataservices.timeseries.LookupSetClass,
    'com.pimco.dataservices.timeseries.NumericDatum': SchemaClasses.com.pimco.dataservices.timeseries.NumericDatumClass,
    'com.pimco.dataservices.timeseries.RequestParam': SchemaClasses.com.pimco.dataservices.timeseries.RequestParamClass,
    'com.pimco.dataservices.timeseries.Row': SchemaClasses.com.pimco.dataservices.timeseries.RowClass,
    'com.pimco.dataservices.timeseries.Series': SchemaClasses.com.pimco.dataservices.timeseries.SeriesClass,
    'com.pimco.dataservices.timeseries.SeriesDatum': SchemaClasses.com.pimco.dataservices.timeseries.SeriesDatumClass,
    'com.pimco.dataservices.timeseries.SeriesDescriptor': SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass,
    'com.pimco.dataservices.timeseries.SeriesDescriptorLite': SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorLiteClass,
    'com.pimco.dataservices.timeseries.SeriesHierarchy': SchemaClasses.com.pimco.dataservices.timeseries.SeriesHierarchyClass,
    'com.pimco.dataservices.timeseries.SeriesIndexChange': SchemaClasses.com.pimco.dataservices.timeseries.SeriesIndexChangeClass,
    'com.pimco.dataservices.timeseries.SeriesMetadata': SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass,
    'com.pimco.dataservices.timeseries.SeriesRequestInfo': SchemaClasses.com.pimco.dataservices.timeseries.SeriesRequestInfoClass,
    'com.pimco.dataservices.timeseries.SeriesSet': SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetClass,
    'com.pimco.dataservices.timeseries.SeriesSetTag': SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetTagClass,
    'com.pimco.dataservices.timeseries.SeriesSource': SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass,
    'com.pimco.dataservices.timeseries.SeriesTag': SchemaClasses.com.pimco.dataservices.timeseries.SeriesTagClass,
    'com.pimco.dataservices.timeseries.SeriesUpdateRequest': SchemaClasses.com.pimco.dataservices.timeseries.SeriesUpdateRequestClass,
    'com.pimco.dataservices.timeseries.StringDatum': SchemaClasses.com.pimco.dataservices.timeseries.StringDatumClass,
    'com.pimco.dataservices.timeseries.UpdateCode': SchemaClasses.com.pimco.dataservices.timeseries.UpdateCodeClass,
    'com.pimco.dataservices.timeseries.UpdateRequest': SchemaClasses.com.pimco.dataservices.timeseries.UpdateRequestClass,
    'com.pimco.dataservices.timeseries.UpdateResponse': SchemaClasses.com.pimco.dataservices.timeseries.UpdateResponseClass,
    'com.pimco.dataservices.timeseries.UpdateStatus': SchemaClasses.com.pimco.dataservices.timeseries.UpdateStatusClass,
    'com.pimco.dataservices.timeseries.UpdateTargetType': SchemaClasses.com.pimco.dataservices.timeseries.UpdateTargetTypeClass,
    
}
_json_converter = avrojson.AvroJsonConverter(use_logical_types=False, schema_types=__SCHEMA_TYPES)

