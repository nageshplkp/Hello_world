

from .schema_classes import SchemaClasses, SCHEMA as my_schema, get_schema_type
from avro.io import DatumReader


class SpecificDatumReader(DatumReader):
    SCHEMA_TYPES = {
        "com.pimco.dataservices.timeseries.Approval": SchemaClasses.com.pimco.dataservices.timeseries.ApprovalClass,
        "com.pimco.dataservices.timeseries.ApprovalStatus": SchemaClasses.com.pimco.dataservices.timeseries.ApprovalStatusClass,
        "com.pimco.dataservices.timeseries.ApprovalStatusCode": SchemaClasses.com.pimco.dataservices.timeseries.ApprovalStatusCodeClass,
        "com.pimco.dataservices.timeseries.Blob": SchemaClasses.com.pimco.dataservices.timeseries.BlobClass,
        "com.pimco.dataservices.timeseries.BlobDatum": SchemaClasses.com.pimco.dataservices.timeseries.BlobDatumClass,
        "com.pimco.dataservices.timeseries.Data": SchemaClasses.com.pimco.dataservices.timeseries.DataClass,
        "com.pimco.dataservices.timeseries.Data2D": SchemaClasses.com.pimco.dataservices.timeseries.Data2DClass,
        "com.pimco.dataservices.timeseries.DataCell": SchemaClasses.com.pimco.dataservices.timeseries.DataCellClass,
        "com.pimco.dataservices.timeseries.DataManifest": SchemaClasses.com.pimco.dataservices.timeseries.DataManifestClass,
        "com.pimco.dataservices.timeseries.DataRequest": SchemaClasses.com.pimco.dataservices.timeseries.DataRequestClass,
        "com.pimco.dataservices.timeseries.Dictionary": SchemaClasses.com.pimco.dataservices.timeseries.DictionaryClass,
        "com.pimco.dataservices.timeseries.ETLJob": SchemaClasses.com.pimco.dataservices.timeseries.ETLJobClass,
        "com.pimco.dataservices.timeseries.FieldEntry": SchemaClasses.com.pimco.dataservices.timeseries.FieldEntryClass,
        "com.pimco.dataservices.timeseries.IdCell": SchemaClasses.com.pimco.dataservices.timeseries.IdCellClass,
        "com.pimco.dataservices.timeseries.Lookup": SchemaClasses.com.pimco.dataservices.timeseries.LookupClass,
        "com.pimco.dataservices.timeseries.LookupSet": SchemaClasses.com.pimco.dataservices.timeseries.LookupSetClass,
        "com.pimco.dataservices.timeseries.NumericDatum": SchemaClasses.com.pimco.dataservices.timeseries.NumericDatumClass,
        "com.pimco.dataservices.timeseries.RequestParam": SchemaClasses.com.pimco.dataservices.timeseries.RequestParamClass,
        "com.pimco.dataservices.timeseries.Row": SchemaClasses.com.pimco.dataservices.timeseries.RowClass,
        "com.pimco.dataservices.timeseries.Series": SchemaClasses.com.pimco.dataservices.timeseries.SeriesClass,
        "com.pimco.dataservices.timeseries.SeriesDatum": SchemaClasses.com.pimco.dataservices.timeseries.SeriesDatumClass,
        "com.pimco.dataservices.timeseries.SeriesDescriptor": SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorClass,
        "com.pimco.dataservices.timeseries.SeriesDescriptorLite": SchemaClasses.com.pimco.dataservices.timeseries.SeriesDescriptorLiteClass,
        "com.pimco.dataservices.timeseries.SeriesHierarchy": SchemaClasses.com.pimco.dataservices.timeseries.SeriesHierarchyClass,
        "com.pimco.dataservices.timeseries.SeriesIndexChange": SchemaClasses.com.pimco.dataservices.timeseries.SeriesIndexChangeClass,
        "com.pimco.dataservices.timeseries.SeriesMetadata": SchemaClasses.com.pimco.dataservices.timeseries.SeriesMetadataClass,
        "com.pimco.dataservices.timeseries.SeriesRequestInfo": SchemaClasses.com.pimco.dataservices.timeseries.SeriesRequestInfoClass,
        "com.pimco.dataservices.timeseries.SeriesSet": SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetClass,
        "com.pimco.dataservices.timeseries.SeriesSetTag": SchemaClasses.com.pimco.dataservices.timeseries.SeriesSetTagClass,
        "com.pimco.dataservices.timeseries.SeriesSource": SchemaClasses.com.pimco.dataservices.timeseries.SeriesSourceClass,
        "com.pimco.dataservices.timeseries.SeriesTag": SchemaClasses.com.pimco.dataservices.timeseries.SeriesTagClass,
        "com.pimco.dataservices.timeseries.SeriesUpdateRequest": SchemaClasses.com.pimco.dataservices.timeseries.SeriesUpdateRequestClass,
        "com.pimco.dataservices.timeseries.StringDatum": SchemaClasses.com.pimco.dataservices.timeseries.StringDatumClass,
        "com.pimco.dataservices.timeseries.UpdateCode": SchemaClasses.com.pimco.dataservices.timeseries.UpdateCodeClass,
        "com.pimco.dataservices.timeseries.UpdateRequest": SchemaClasses.com.pimco.dataservices.timeseries.UpdateRequestClass,
        "com.pimco.dataservices.timeseries.UpdateResponse": SchemaClasses.com.pimco.dataservices.timeseries.UpdateResponseClass,
        "com.pimco.dataservices.timeseries.UpdateStatus": SchemaClasses.com.pimco.dataservices.timeseries.UpdateStatusClass,
        "com.pimco.dataservices.timeseries.UpdateTargetType": SchemaClasses.com.pimco.dataservices.timeseries.UpdateTargetTypeClass,
    }
    def __init__(self, readers_schema=None, **kwargs):
        writers_schema = kwargs.pop("writers_schema", readers_schema)
        writers_schema = kwargs.pop("writer_schema", writers_schema)
        super(SpecificDatumReader, self).__init__(writers_schema, readers_schema, **kwargs)
    def read_record(self, writers_schema, readers_schema, decoder):
        
        result = super(SpecificDatumReader, self).read_record(writers_schema, readers_schema, decoder)
        
        if readers_schema.fullname in SpecificDatumReader.SCHEMA_TYPES:
            result = SpecificDatumReader.SCHEMA_TYPES[readers_schema.fullname](result)
        
        return result