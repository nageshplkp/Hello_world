from datetime import datetime

import cx_Oracle
import pandas as pd
import logging

# Temporary here.
# Should be using core.db.sql however there are some initialization restrictions
# that cause a connection to be created on the fly during init.
# This is not a desired behavior. Followup with James S.
class Oracle:

    def __init__(self, u, p, c):
        self.conn = cx_Oracle.Connection(u, p, c)
        self.blockSize = 10000

    def executeQuery(self, s):
        try:
            curs = self.conn.cursor()
            curs.bindarraysize = self.blockSize
            curs.execute(s)
            d = curs.fetchall()
            curs.close()
        except:
            logging.error('bad query %s', s)
            d = []
        return d

    def executeBindQuery(self,s, b):
        try:
            curs = self.conn.cursor()
            curs.bindarraysize = self.blockSize
            curs.prepare(s)
            curs.execute(s, b)
            d = curs.fetchall()
            curs.close()
        except:
            logging.error('bad query %s',s)
            d = []

        return d

    def executeSingleInsert(self, s):
        c = self.conn.cursor()
        c.execute(s)
        self.conn.commit()
        c.close()

    def executeValueInsert(self, s, d, i):

        c = self.conn.cursor()
        c.bindarraysize = len(d)
        c.setinputsizes(i)
        c.executemany(s, d)
        self.conn.commit()
        c.close()

    def closeConnection(self):
        self.conn.close()

# Temporary Class that allows for the direct query of
# PIMCO Live's database using BBG Tickers and Mnemonics
#TODO: To be replaced with core.services.timeseries.Query at appropriate time.
class TimeSeries:
    def __init__( self , server, user, password ):
        self.oraconn = Oracle(user, password, server )
        self.columns = ( 'asof_date' , 'ticker' , 'mnemonic_value' )

    def close(self):
        self.oraconn.closeConnection();

    def query(self, ticker, yellow=None, mnemonic=None, start_date=None, end_date=None, options=None, error_on_dupes=True, debug=False):
        '''
        :param ticker: list of tickers
        :param yellow:
        :param mnemonic:
        :param start_date:
        :param end_date:
        :param options: forward_curve_quote_format=points - select points format for ticker.
        :return:
        '''
        if not ticker:
            raise Exception( "Empty Tickers " )

        if not mnemonic:
            mnemonic = 'PX_LAST' # always default to PX_LAST if not supplied.

        pl_mnemonic = None
        if mnemonic == 'PX_LAST':
            pl_mnemonic = 'Price'

        #if no mnemonic or yellow_key is given , check if there are dupes and print a warning
        if yellow:
            check_bbg_query = ''' select bbg_ticker, bbg_yellow, count(*) mnemonic_count
                from pm_own.PL_BENCHMARK_BBG_KEY_VW bd
            '''
        else: # no yellow specified look for dupes at the ticker level
            check_bbg_query = ''' select bbg_ticker, count(*) mnemonic_count
                from pm_own.PL_BENCHMARK_BBG_KEY_VW bd
            '''



        query = '''select bs.asof_date, bd.bbg_ticker, bs.mnemonic_value
            from PM_OWN.PL_BENCHMARK_BBG_KEY_VW bd
            join PM_OWN.pl_ticker_lookup tl on tl.ticker = bd.pim_ticker
            join PM_OWN.pl_mnemonic_lookup ml on ml.mnemonic = bd.pim_mnemonic
            join PM_OWN.pl_benchmark_securities bs on bs.ticker_id=tl.ticker_id and bs.mnemonic_id=ml.mnemonic_id
        '''
        bindvars = { }
        
        if isinstance( ticker , list ):
            query += " where bd.bbg_ticker in ( %s ) " % ( ",".join( [  "'%s'" % ( each ) for each in ticker  ]) )
            check_bbg_query += " where bd.bbg_ticker in ( %s ) " % ( ",".join( [  "'%s'" % ( each ) for each in ticker  ]) )
        else:
            bindvars = { 'ticker' : ticker }
            query += '''where bd.bbg_ticker = :ticker '''
            check_bbg_query += '''where bd.bbg_ticker = :ticker '''

        check_bbg_query += " and not bd.pim_ticker like '%@%' and data_context = 'EOD' and bbg_priority = 1" # remove any PL specific tickers.
        query += " and not bd.pim_ticker like '%@%' and data_context = 'EOD' and bbg_priority = 1" # remove any PL specific tickers.

        if yellow:
            query += " and  bd.bbg_yellow = :yellow "
            check_bbg_query += ''' and bd.bbg_yellow = :yellow '''
            bindvars['yellow'] = yellow


        if mnemonic:
            bindvars['mnemonic'] = mnemonic
            query += ' and bd.bbg_mnemonic = :mnemonic '
            check_bbg_query += ''' and bd.bbg_mnemonic = :mnemonic '''
            if pl_mnemonic:
                query += ''' and not bd.pim_mnemonic ='NAV' '''
                check_bbg_query += ''' and not bd.pim_mnemonic ='NAV' '''

        if options:
            if options == "forward_curve_quote_format=points":
                query += ''' and bd.pim_mnemonic like '%Points' '''
                check_bbg_query += ''' and bd.pim_mnemonic like '%Points' '''
            else:
                print "Warning: Options %s not supported. " % ( options )




        error = False

        # Check for dupes in definition
        if yellow:
            check_bbg_query += ''' group by bbg_ticker, bbg_yellow, pim_ticker having count(*) > 1 '''
        else:
            check_bbg_query += ''' group by bbg_ticker, pim_ticker having count(*) > 1 '''

        dupemnemonics =  self.oraconn.executeBindQuery( check_bbg_query , bindvars)
        tickers_with_dupes = dict()
        for dupes in dupemnemonics:
            error = True
            bindvars_det = {}
            check_bbg_query_details = '''select bbg_ticker, bbg_yellow, bbg_mnemonic
            from pm_own.PL_BENCHMARK_BBG_KEY_VW bd where bbg_ticker = :ticker and bbg_mnemonic = :mnemonic and data_context = 'EOD' and bbg_priority = 1
             '''
            dticker = dupes[0]
            bindvars_det['ticker'] = dticker
            bindvars_det['mnemonic'] = mnemonic
            if yellow:
                check_bbg_query_details += ''' and bbg_yellow = :yellow '''
                bindvars_det['yellow'] = dupes[1]
                print "Warning: Duplicated records for BBG ticker:%s, BBG Yellow Key: %s, number of mnemonics found: %d " % ( dupes )
            else:
                print "Warning: Duplicated records for BBG ticker:%s, number of mnemonics found: %d " % ( dupes )

            detailmnemonics =  self.oraconn.executeBindQuery( check_bbg_query_details , bindvars_det)

            for detailm in detailmnemonics:
                print "Available BBG Ticker: %s, Yellow: %s, Mnemonic: %s" % ( detailm )
            print ""
            tickers_with_dupes[dticker]=detailmnemonics



        if error and not error_on_dupes:
            # trun off errors due to duplicates
            error = False
                            
        if start_date:
            query += "  and bs.asof_date >= :asof_date "
            bindvars['asof_date'] = datetime.strptime(start_date , '%Y-%m-%d')

        if end_date:
            query += "  and bs.asof_date <= :asof_date_end "
            bindvars['asof_date_end'] = datetime.strptime(end_date , '%Y-%m-%d')

        query += '''order by tl.ticker , bs.asof_date'''
        
        data = [ dict(zip( self.columns , row )) for row in self.oraconn.executeBindQuery( query , bindvars) ]
        if debug:
            print query
        if data and not error:
            df = pd.DataFrame( data )
            if not error_on_dupes:

                # remove any duplicates
                for dticker in tickers_with_dupes:
                    dupedata = tickers_with_dupes[dticker];
                    items_to_remove = dupedata[1:None]
                    for item in items_to_remove:
                        dyellow = item[1];
                        dmnemonic = item[2];

                        print "WARNING: Dropping duplicate data for ticker: %s, yellow: %s, mnemonic: %s" % ( dticker , dyellow, dmnemonic)
                        drop_data_idx = (df['ticker'] == dticker)
                        keep_data_idx = [ not x for x in drop_data_idx ]
                        df = df[keep_data_idx]
            # dupdf = df[df.duplicated(['asof_date','ticker'],keep=False)]
            # if len(dupdf)>0:
            #    print dupdf
            return df.pivot( index ='asof_date', columns='ticker', values='mnemonic_value')


