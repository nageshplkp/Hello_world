from core.config import config_api
from core.db.sql_db import SqlDb
from core.db.conn_pool import connect
from .shared import ALL_DATA_FIELDS
import datetime
import collections


ALL_DATA_FIELDS_1Y = ['%s_1Y' % x for x in ALL_DATA_FIELDS]

HR_MIS_TO_MONTHS = {1: 0, 2: 1, 3: 2, 4: 3, 5: 12, 6: 13, 7: 14, 8: 15}

__all__ = [
    'get_merged_data_location', 'get_db_name', 'ALL_DATA_FIELDS', 'ALL_DATA_FIELDS_1Y',
    'orig_hr_date', 'hrdate_range', 'get_monthly_data', 'get_merged_data', 'get_merged_data_yoy',
    'get_merged_data_yoy_pivot', 'get_available_dates'
]


def get_monthly_data_location():
    return "maprfs:///pimco/ds/econ/cps_monthly_%s" % config_api._env()


def get_merged_data_location(is_daly=False):
    return "maprfs:///pimco/ds/econ/cps_merged_%s%s" % (config_api._env(), '_daly' if is_daly else '')


def get_db_name():
    return 'econ_%s' % config_api._env()


def __get_db():
    return connect('impala_mapr', 'prod')


def orig_hr_date(hrdate, hrmis):
    hr_year = int(hrdate // 100)
    hr_month = int(hrdate % 100)

    if hrmis < 0:
        sub_months = -HR_MIS_TO_MONTHS.get(-hrmis, 0)
    else:
        sub_months = HR_MIS_TO_MONTHS.get(hrmis, 0)

    hr_month -= sub_months

    while hr_month < 1:
        hr_year -= 1
        hr_month += 12

    while hr_month > 12:
        hr_year += 1
        hr_month -= 12

    return hr_year * 100 + hr_month


def hrdate_range(start, end, step):
    yr_start = start // 100
    mo_start = start % 100

    while start < end:
        yield start
        mo_start += step

        while mo_start > 12:
            mo_start -= 12
            yr_start += 1

        while mo_start < 1:
            mo_start += 12
            yr_start -= 1

        start = yr_start * 100 + mo_start


def get_monthly_data(dates, fields, computed_cols=None, addl_cond=None, order_by=None):
    dates = [dates] if not isinstance(dates, collections.Sequence) else dates
    fields = [fields] if not isinstance(fields, collections.Sequence) else fields

    dates = set([(d.strftime('%Y%m') if isinstance(d, datetime.date) else str(d)) for d in dates])

    fields = ["HRHHID", 'HRHHID2', 'PULINENO', 'HRYEAR4', 'HRMONTH', 'HRMIS', 'HRDATE'] + [x for x in fields if
                                                                                           x in ALL_DATA_FIELDS]

    fields = set(fields)

    addl_cond, computed_cols, order_by = __prepare_query_parts(addl_cond, computed_cols, order_by)

    sql = '''
    SELECT %s %s FROM %s.cps_monthly WHERE  HRDATE in (%s) %s %s
    ''' % (', '.join(fields), computed_cols, get_db_name(), ', '.join(dates), addl_cond, order_by)

    with __get_db() as db:
        return db.query_as_df(sql, log=False)


def __prepare_query_parts(addl_cond, computed_cols, order_by):
    if addl_cond:
        addl_cond = 'AND (%s)' % addl_cond
    else:
        addl_cond = ''
    if computed_cols:
        if not isinstance(computed_cols, collections.Sequence):
            computed_cols = [computed_cols]
        computed_cols = ', %s' % ', '.join(computed_cols)
    else:
        computed_cols = ''
    if order_by:
        if not isinstance(order_by, collections.Sequence):
            order_by = [order_by]
        order_by = 'ORDER BY %s ' % ', '.join(order_by)
    else:
        order_by = ''
    return addl_cond, computed_cols, order_by


def get_merged_data(dates, fields, computed_cols=None, addl_cond=None, order_by=None):
    dates = [dates] if not isinstance(dates, collections.Sequence) else dates
    fields = [fields] if not isinstance(fields, collections.Sequence) else fields

    dates = set([(d.strftime('%Y%m') if isinstance(d, datetime.date) else str(d)) for d in dates])

    fields = ['PIM_HH_ID', 'PIM_HH_PP_ID', 'HRYEAR4', 'HRMONTH', 'HRMIS', 'HRDATE', 'ORIG_HRDATE'] + [x for x in fields
                                                                                                      if
                                                                                                      x in ALL_DATA_FIELDS]
    fields = set(fields)

    addl_cond, computed_cols, order_by = __prepare_query_parts(addl_cond, computed_cols, order_by)

    sql = '''
    SELECT %s %s FROM %s.cps_merged WHERE  HRDATE in (%s) %s %s
    ''' % (', '.join(fields), computed_cols, get_db_name(), ', '.join(dates), addl_cond, order_by)

    with __get_db() as db:
        return db.query_as_df(sql, log=False)


def get_merged_data_yoy(dates, fields, computed_cols=None, addl_cond=None, order_by=None):
    dates = [dates] if not isinstance(dates, collections.Sequence) else dates
    fields = [fields] if not isinstance(fields, collections.Sequence) else fields

    dates = set([(d.strftime('%Y%m') if isinstance(d, datetime.date) else str(d)) for d in dates])
    dates = [int(d) for d in dates]
    fields = ['PIM_HH_ID', 'PIM_HH_PP_ID', 'HRYEAR4', 'HRMONTH', 'HRMIS', 'HRDATE', 'ORIG_HRDATE'] + [x for x in fields
                                                                                                      if
                                                                                                      x in ALL_DATA_FIELDS]
    fields = set(fields)

    addl_cond, computed_cols, order_by = __prepare_query_parts(addl_cond, computed_cols, order_by)

    date_cond = []
    for date in dates:
        date_cond += [(i, orig_hr_date(date, i)) for i in xrange(1, 5)] + [
            (i + 4, orig_hr_date(date, i)) for i in xrange(1, 5)]

    date_cond = ['(HRMIS = %s and ORIG_HRDATE = %s)' % (x, y) for x, y in date_cond]

    sql = '''
    SELECT %s %s FROM %s.cps_merged WHERE  (%s) %s %s
    ''' % (', '.join(fields), computed_cols, get_db_name(), ' OR '.join(date_cond), addl_cond, order_by)

    with __get_db() as db:
        return db.query_as_df(sql, log=True)


def get_merged_data_yoy_pivot(dates, fields, computed_cols=None, addl_cond=None, order_by=None):
    dates = [dates] if not isinstance(dates, collections.Sequence) else dates
    fields = [fields] if not isinstance(fields, collections.Sequence) else fields

    dates = set([(d.strftime('%Y%m') if isinstance(d, datetime.date) else str(d)) for d in dates])
    dates = [int(d) for d in dates]
    fields = ['PIM_HH_ID', 'PIM_HH_PP_ID', 'HRYEAR4', 'HRMONTH', 'HRMIS', 'HRDATE', 'ORIG_HRDATE',
              'HRDATE_1Y', 'HRYEAR4_1Y', 'HRMONTH_1Y', 'HRMIS_1Y'] \
             + [x for x in fields if x in ALL_DATA_FIELDS] \
             + ['%s_1Y' % x for x in fields if x in ALL_DATA_FIELDS]

    fields = set(fields)

    addl_cond, computed_cols, order_by = __prepare_query_parts(addl_cond, computed_cols, order_by)

    date_cond = []
    for date in dates:
        date_cond += [(i, orig_hr_date(date, i)) for i in xrange(1, 5)]

    date_cond = ['(t1.HRMIS = %s and t1.ORIG_HRDATE = %s)' % (x, y) for x, y in date_cond]

    t1_cols = ['t1.%s' % x for x in ALL_DATA_FIELDS]
    t2_cols = ['t2.%s %s_1Y' % (x, x) for x in ALL_DATA_FIELDS]

    sql = '''
    SELECT {fields} {computed_cols}
    FROM (
      SELECT  t1.ORIG_HRDATE, t1.PIM_HH_ID,  t1.PIM_HH_PP_ID, t1.HRDATE, t2.HRDATE as HRDATE_1Y,  {t1_cols}, {t2_cols}
      FROM
        {db}.cps_merged t1
         inner join {db}.cps_merged t2 on t1.PIM_HH_PP_ID = t2.PIM_HH_PP_ID and t2.HRMIS = t1.HRMIS + 4
      WHERE
        ({dates})
    ) m
    WHERE 1=1 {addl_conds}
    {order_by}
    '''.format(fields=', '.join(fields), t1_cols=', '.join(t1_cols), t2_cols=', '.join(t2_cols), db=get_db_name(),
               dates=' OR '.join(date_cond), addl_conds=addl_cond, computed_cols=computed_cols,
               order_by=order_by)

    with __get_db() as db:
        return db.query_as_df(sql, log=False)


def get_available_dates():
    with __get_db() as db:
        sql = 'SELECT DISTINCT hrdate from %s.cps_monthly order by HRDATE' % get_db_name()
        return [x[0] for x in db.query(sql)]


def _recover_monthly_partitions():
    with __get_db() as db:
        sql = 'ALTER TABLE %s.cps_monthly RECOVER PARTITIONS' % get_db_name()
        db.execute(sql)
        sql = 'COMPUTE STATS %s.cps_monthly' % get_db_name()
        db.execute(sql)


def _recover_merged_partitions():
    with __get_db() as db:
        sql = 'ALTER TABLE %s.cps_merged RECOVER PARTITIONS' % get_db_name()
        db.execute(sql)
        sql = 'COMPUTE STATS %s.cps_merged' % get_db_name()
        db.execute(sql)
