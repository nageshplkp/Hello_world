from pyspark.sql import SparkSession
from pyspark.sql import functions as spf
from pyspark.sql import types as spt
from . import get_monthly_data_location, get_merged_data_location, orig_hr_date

import math
import logging


def get_monthly_data_df():
    spark = SparkSession.builder.getOrCreate()
    logging.info("Reading parquet from %s", get_monthly_data_location())
    return spark.read.parquet(get_monthly_data_location())


def get_monthly_data_for_merging(df=None):
    orig_hr_date_udf = spf.udf(orig_hr_date, spt.IntegerType())

    if df is None:
        df = get_monthly_data_df()

    df = df.withColumn('orig_hrdate', orig_hr_date_udf(spf.col('hrdate'), spf.col('HRMIS')))
    part_count = df.select('orig_hrdate').distinct().count()
    df = df.repartition(part_count, 'orig_hrdate')
    df = df.sortWithinPartitions('orig_hrdate', 'hrdate', 'HRMIS', 'HRHHID', 'HRHHID2', 'GESTFIPS', 'PULINENO')
    df = df.withColumn('PIM_HH_ID', spf.lit(long(1)))
    df = df.withColumn('PIM_HH_PP_ID', spf.lit(long(1)))

    logging.info('Defined new id columns')
    return df


def __merger_mapper(rows):
    import core
    import logging

    current_ohr_date = 0

    current_hh_num = 0
    current_pp_num = 0

    hh_dict = dict()
    pp_dict = dict()

    i = 0
    logging.info("Starting the map")
    print "Checking for logging conf..."
    for r in rows:

        if r['orig_hrdate'] != current_ohr_date:
            current_ohr_date = r['orig_hrdate']
            logging.info('Processing new OHR date: %s', current_ohr_date)
            hh_dict = dict()
            pp_dict = dict()

            current_hh_num = current_ohr_date * 10000000
            current_pp_num = current_hh_num * 100
            i = 0

        hh_key = (r['HRHHID'], r['HRHHID2'], r['GESTFIPS'])
        pp_key = (r['HRHHID'], r['HRHHID2'], r['GESTFIPS'], r['PULINENO'], r['PESEX'])

        if not hh_key in hh_dict:
            hh_dict[hh_key] = current_hh_num
            current_hh_num += 1

        if not pp_key in pp_dict:
            pp_dict[pp_key] = current_pp_num
            current_pp_num += 1

        r = r.asDict()
        r['PIM_HH_PP_ID'] = pp_dict[pp_key]
        r['PIM_HH_ID'] = hh_dict[hh_key]

        yield r
        i += 1

        if i % 20000 == 0:
            logging.info('Wrote %d rows for %s', i, current_ohr_date)

    hh_dict = dict()
    pp_dict = dict()


def __merger_mapper_daly(rows):
    import core
    import logging

    current_ohr_date = 0

    current_hh_num = 0
    current_pp_num = 0

    hh_dict = dict()
    pp_dict = dict()

    i = 0
    logging.info("Starting the map")
    print "Checking for logging conf..."
    for r in rows:

        if r['orig_hrdate'] != current_ohr_date:
            current_ohr_date = r['orig_hrdate']
            logging.info('Processing new OHR date: %s', current_ohr_date)
            hh_dict = dict()
            pp_dict = dict()

            current_hh_num = current_ohr_date * 10000000
            current_pp_num = current_hh_num * 100
            i = 0

        hh_key = (r['HRHHID'], r['HRHHID2'])  #, r['GESTFIPS'])
        #pp_key = (r['HRHHID'], r['HRHHID2'], r['GESTFIPS'], r['PULINENO'], r['PESEX'])

        if not hh_key in hh_dict:
            hh_dict[hh_key] = current_hh_num
            current_hh_num += 1

        pp_exists = False
        for i in range(-1, 4):
            pp_key = (r['HRHHID'], r['HRHHID2'], r['PTDTRACE'], r['PULINENO'], r['PRTAGE'] + i)
            if pp_key in pp_dict:
                pp_exists = True
                break

        if not pp_exists:
            pp_dict[pp_key] = current_pp_num
            current_pp_num += 1

        r = r.asDict()
        r['PIM_HH_PP_ID'] = pp_dict[pp_key]
        r['PIM_HH_ID'] = hh_dict[hh_key]

        yield r
        i += 1

        if i % 20000 == 0:
            logging.info('Wrote %d rows for %s', i, current_ohr_date)

    hh_dict = dict()
    pp_dict = dict()


def merge_monthly(df=None, is_daly=False):
    spark = SparkSession.builder.getOrCreate()
    if df is None:
        df = get_monthly_data_for_merging()

    logging.info('Merging monthly files')
    merged_rdd = df.rdd.mapPartitions(__merger_mapper_daly if is_daly else __merger_mapper)
    merged_df = spark.createDataFrame(merged_rdd, df.schema)

    return merged_df


def save_merged_data(location=None, df=None, daly_df=None, only_daly=False):
    if df is None:
        df = merge_monthly()
    if daly_df is None:
        daly_df = merge_monthly(is_daly=True)

    if location is None:
        location = get_merged_data_location()
        location_daly = get_merged_data_location(True)
    else:
        location_daly = location + '_daly'

    if not only_daly:
        df.write.parquet(location, mode='overwrite', partitionBy=['orig_hrdate'], compression='snappy')
    daly_df.write.parquet(location_daly, mode='overwrite', partitionBy=['orig_hrdate'], compression='snappy')
