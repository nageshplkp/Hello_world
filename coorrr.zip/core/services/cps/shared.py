from core.config import config_api
from avro.schema import RecordSchema, Field, Names

NBER_ROOT_URL = 'http://www.nber.org/cps-basic/'

ALL_DATA_FIELDS = ["HRHHID", "HRHHID2", "PULINENO", "HRYEAR4", "HRMONTH", "HRMIS", "PESEX", "PRTAGE", "PTDTRACE",
                   "PTWK", "PXLAYAVL", "PXRACE1", "PELAYLK", "PXIO2ICD", "PRDISC", "PELKFTO", "PXMNTVTY", "PUIODP1",
                   "PUIODP2", "PUIODP3", "HUBUSL4", "HUBUSL2", "HUBUSL3", "HUBUSL1", "PEMOMTYP", "PENLFACT", "PELKLL1O",
                   "PEDWLKO", "PREMPHRS", "PEIO1ICD", "HWHHWGT", "PRINUSYR", "HEPHONEO", "PWVETWGT", "PRAGNA",
                   "PUHROT1", "PEDADTYP", "PEMJOT", "PEDWLKWK", "PXNATVTY", "PXABSRSN", "PXAGE", "PEERNUOT", "PRJOBSEA",
                   "PXNLFACT", "PECOHAB", "GTMETSTA", "PXDWWNTO", "PXNLFRET", "PXDWWK", "PRMARSTA", "PEDWWK",
                   "PXAFEVER", "PUJHCK4", "PUJHCK5", "PXJHWKO", "PUJHCK1", "PUJHCK2", "PUJHCK3", "PELKLL2O", "PUERN2",
                   "PXDWRSN", "PEDISPHY", "PEIO2OCD", "PEJHWANT", "PENLFJH", "PEJHWKO", "PRDTIND2", "PRDTIND1", "PUDIS",
                   "PRCOWPG", "PEDISREM", "PRUNEDUR", "PUDWCK5", "PUDWCK4", "PUDWCK3", "PUDWCK2", "PUDWCK1", "PRABSREA",
                   "PREMP", "PESPOUSE", "GTCO", "PXERNPER", "PXERNH1O", "HRINTSTA", "PEHRAVL", "PULKPS4", "PULKPS5",
                   "PULKPS6", "PEDW4WK", "PULAY", "PULKPS1", "PULKPS2", "PULKPS3", "PRHRUSL", "PELKAVL", "PEDISEYE",
                   "PUBUSCK4", "PUBUSCK1", "PUBUSCK3", "PUBUSCK2", "PXLKFTO", "PELNDAD", "PXDISOUT", "PEIO2ICD",
                   "PXERNH2", "PRPERTYP", "PRERNWA", "PEMJNUM", "PRCITFLG", "PEMNTVTY", "PRFAMNUM", "PXIO2OCD",
                   "HUPRSCNT", "PUWK", "PRDISFLG", "PRIMIND1", "HETELAVL", "PEMLR", "HUINTTYP", "PRIMIND2", "PXAFWHN1",
                   "PXHRWANT", "PXMJNUM", "PEHRWANT", "PEIO1OCD", "PRCIVLF", "PXDWLKO", "PRDTOCC1", "PRDTOCC2",
                   "PXIO1COW", "PUHRCK4", "PUHRCK5", "PUHRCK6", "PUHRCK7", "PUHRCK1", "PUHRCK2", "PUHRCK3", "PEHRUSL2",
                   "PEHRUSL1", "PERET1", "PULK", "PESCHLVL", "PXJHWANT", "PRMJOCC1", "PRMJOCC2", "HUBUS", "PEIO1COW",
                   "GESTFIPS", "PXRRP", "PXSPOUSE", "PXFNTVTY", "PRNAGWS", "PXERNLAB", "PEHRUSLT", "PEDIPGED", "PTOT",
                   "PXHRAVL", "PRUNTYPE", "PRMJIND2", "PRMJIND1", "PRCOW1", "HRLONGLK", "PXJHRSN", "PRFTLF", "HURESPLI",
                   "PXCOHAB", "PEDWWNTO", "PXLKAVL", "PXIO2COW", "PRIOELG", "PEABSPDO", "PXLKLL1O", "PEERNLAB",
                   "PXDISPHY", "PRERNHLY", "PRERELG", "GTCBSA", "PENATVTY", "PXLAYLK", "PEHGCOMP", "PXNLFJH", "PEDWAVL",
                   "PERRP", "PUERNH1C", "PXERNCOV", "PEDWAVR", "PXHRACTT", "PEERN", "PEDWRSN", "PEABSRSN", "PXLKM1",
                   "PEHSPNON", "PRWERNAL", "PULKAVR", "PXDWAVL", "HETELHHD", "PXMOMTYP", "PXDW4WK", "PRMJOCGR",
                   "PEHRRSN1", "PEHRRSN2", "PEHRRSN3", "PXERN", "PXLKLWO", "PEMARITL", "PXHRACT2", "PXHRACT1",
                   "PELKDUR", "PUNLFCK2", "PUNLFCK1", "PXPARENT", "PEAFNOW", "PEIO2COW", "PRDASIAN", "PXLKDUR",
                   "PUBUS1", "PUHROT2", "PEERNHRO", "PXMARITL", "PXABSPDO", "PULAY6M", "PULAYCK1", "PULAYCK3",
                   "PULAYCK2", "PEHRFTPT", "PXLKLL2O", "PRCITSHP", "PXDISDRS", "PEJHRSN", "PRDTCOW1", "PEDISEAR",
                   "PRDTCOW2", "HXTELHHD", "PXDWLKWK", "PRPTREA", "PRNMCHLD", "PXLNDAD", "PULAYAVR", "PEPARENT",
                   "PEERNH2", "PXMLR", "PXEDUCA", "HUFINAL", "PTHR", "PXCYC", "PURETOT", "PEERNH1O", "PXDIPGED",
                   "PUHROFF2", "PUHROFF1", "PENLFRET", "PEDISDRS", "PXIO1ICD", "PRFAMREL", "PXINUSYR", "PXHRUSL2",
                   "PXHRUSL1", "PUIOCK2", "PUIOCK3", "PUIOCK1", "HUTYPB", "HUTYPC", "PXLAYDUR", "PXHRUSLT", "PREXPLF",
                   "PUDIS2", "PUDIS1", "HXFAMINC", "PEAFWHN4", "PEAFWHN3", "PEAFWHN2", "PEAFWHN1", "PEEDUCA",
                   "PXIO1OCD", "GTCBSAST", "GTCBSASZ", "GEREG", "PULKM6", "PULKM5", "PULKM4", "PULKM3", "PULKM2",
                   "PUCHINHH", "PESCHFT", "PUSLFPRX", "PRCOW2", "PEFNTVTY", "PXSCHENR", "PUABSOT", "GTINDVPC", "QSTNUM",
                   "PULAYDT", "PEERNPER", "PRPTHRS", "PWLGWGT", "HEHOUSUT", "OCCURNUM", "PXDISEAR", "PXLAYFTO",
                   "PWSSWGT", "PEERNRT", "PUIO2MFG", "PEERNHRY", "PELKLWO", "PUHRCK12", "PEERNCOV", "PXHRFTPT",
                   "PWORWGT", "HXTELAVL", "PXERNUOT", "HUSPNISH", "PELKM1", "PELAYDUR", "PRTFAGE", "HRHTYPE", "PWFMWGT",
                   "PRWNTJOB", "PEHRACT1", "PXHGCOMP", "HUTYPEA", "PRNAGPWS", "PXERNWKP", "HXHOUSUT", "PELNMOM",
                   "PEDISOUT", "PELAYFTO", "PRHERNAL", "PXSCHFT", "PEHRACTT", "PXERNRT", "PRFAMTYP", "HRNUMHOU",
                   "PEERNWKP", "PECYC", "PXERNHRY", "PXDISEYE", "PXDISREM", "HETENURE", "PXDWAVR", "GTCSA", "PXERNHRO",
                   "PREMPNOT", "HWHHWTLN", "PRDTHSP", "PESCHENR", "PUIO1MFG", "PEHRACT2", "PXLNMOM", "PULKDK1",
                   "PULKDK2", "PULKDK3", "PULKDK4", "PULKDK5", "PULKDK6", "HXTENURE", "PRNLFSCH", "PWCMPWGT",
                   "HEFAMINC", "PXRET1", "PXDADTYP", "PELAYAVL", "PRCHLD", "PXHRRSN1", "PXHRRSN3", "PXHRRSN2",
                   "PRWKSTAT", "PRWKSCH", "PXMJOT", "PXHSPNON", "PXSEX", "PUBUS2OT", "PRSJMJ", "HXPHONEO", "PEAFEVER",
                   "PXAFNOW", "PUJHDP1O", "PXSCHLVL"]

__CURRENT_CONFIG = None


def get_avro_schema():
    int_type = [{'type': 'long'}, {'type': 'null'}]
    schema = RecordSchema('CPS', 'com.pimco.pypimco.core.services.cps',
                          [{'default': None, 'name': f, 'type': int_type} for f in ALL_DATA_FIELDS], names=Names())
    return schema


def get_config_db():
    uname = config_api.get('MONGO_RDF')
    passwd = config_api.get('MONGO_RDF_PASSWD')
    from core.db import mongo_db
    db = mongo_db.MongoDb('rdf', config_api.get('MONGO_HOST'), user=uname, password=passwd)

    if 'cps_config' not in db.db.collection_names():
        import json, os.path, logging

        db.db.create_collection('cps_config')
        coll = db.db_collection('cps_config')

        with open(os.path.join(os.path.dirname(__file__), 'default_config.json'), "r") as f:
            data = json.load(f)
            coll.insert_many(data)

            logging.info('Populated cps_config with default data')

    return db


def get_config():
    global __CURRENT_CONFIG

    if __CURRENT_CONFIG is None:
        db = get_config_db()
        configs = list(db.db_collection("cps_config").find({'Kind': 'Global'}))
        __CURRENT_CONFIG = configs[0]
    return __CURRENT_CONFIG


def get_data_definitions():
    db = get_config_db()

    dds = db.db_collection('cps_config').find({'Kind': 'DataDictionary'})

    return [__parse_field_dictionary(dd) for dd in sorted(list(dds), cmp=lambda x, y: cmp(x['Name'], y['Name']))]


def get_data_definition_fixups():
    db = get_config_db()
    dds = db.db_collection('cps_config').find({'Kind': 'DictionaryFixups'})

    return list(dds)


def apply_fixups(data_defs, fixups):
    for dd in data_defs:
        for fx in fixups:
            if not (fx['AppliesFrom'] <= dd['Name'] <= fx['AppliesTo']):
                continue
            for k, v in fx['Renames'].iteritems():
                if k in dd['Fields']:
                    f = dd['Fields'][k]
                    f['name'] = v
                    dd['Fields'][v] = f
                    del dd['Fields'][k]


def __parse_field_dictionary(data_definition):
    data_definition['Fields'] = dict((x['name'], x) for x in data_definition['Fields'])
    return data_definition


def _restore_default_config():
    db = get_config_db()
    db.db_collection('cps_config')
