from core.rest import client as rest_client
from core.services.cps import shared
from core.common.parallel import spark_map
from core.common.util import last, ireadlines
from avro.datafile import DataFileWriter
from avro.io import DatumWriter

import re
import os, os.path
import logging
import traceback
import datetime
import functools
import collections

PARQUET_MULTITOOL_LOCATION = "/appl/coreservice/hadoop/hadoop-multitool-1.0.0.jar"


def download_data_files(start_date=None, end_date=None, exclude_dates=None, download_location=None, overwrite=False, parse=False,
                        update_store=False, store_location=None, delete_avro=False, map_func=spark_map):
    logging.info("Downloading files: download location=%s store_location=%s", download_location, store_location)
    return_data = rest_client.get(shared.NBER_ROOT_URL, use_kerberos=False, parse_content_as='text')

    if download_location is None:
        download_location = os.getcwd()

    exclude_dates = exclude_dates or set()
    rx = re.compile(r'((jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)(\d\d)pub\.zip)', re.IGNORECASE)
    files = rx.findall(return_data)
    files = [(datetime.datetime.strptime('%s-%s-01' % (f[2], f[1]), '%y-%b-%d'), f[0]) for f in files]

    files = [(d, f) for d, f in files
             if ((start_date is None or d >= start_date) and (end_date is None or d <= end_date))
             and (overwrite or not os.path.exists(os.path.join(download_location, f))) and d not in exclude_dates
             ]

    result = map_func(functools.partial(download_item, download_location, parse, update_store, store_location, delete_avro), files)
    return result


def run_update_store(avro_name, store_location, date):
    import subprocess
    file_name = os.path.basename(avro_name).replace('.avro', '.parquet')
    avro_name = "file://" + os.path.abspath(avro_name)
    year = date.strftime('%Y')
    month = date.strftime('%m')
    subprocess.check_call(['hadoop', 'jar', PARQUET_MULTITOOL_LOCATION, 'convert', '-s', avro_name,
                           '-d', store_location.format(year=year, month=month, filename=file_name),
                           '-i', 'avro', '-o', 'parquet'])


def download_item(download_location, parse_file, update_store, store_location, delete_avro, item):
    d, f = item
    try:

        logging.info("Downloading file %s", f)
        data = rest_client.get(shared.NBER_ROOT_URL + '/' + f, use_kerberos=False, parse_content_as='binary')
        with open(os.path.join(download_location, f), "w+b") as out:
            out.write(data.read())
        iter_result = d, os.path.join(download_location, f), True
        logging.info("Downloaded file %s", iter_result[1])

        if parse_file:
            avro_name = convert_to_avro(iter_result[1], iter_result[0], download_location)
            os.unlink(iter_result[1])
            iter_result = d, avro_name, True

            if update_store:
                run_update_store(avro_name, store_location, iter_result[0])
                if delete_avro:
                    logging.info('Deleting %s', avro_name)
                    os.unlink(avro_name)
    except:
        logging.error("Failed to download file: %s", item[1])
        logging.error(traceback.format_exc())
        iter_result = d, os.path.join(download_location, f), False
    return iter_result


__DATA_DEFINITIONS = None


def __get_line_slice(start, end, line):
    return long(line[start:end])


def get_line_parsers(dd):
    parsers = []
    for i, f in enumerate(shared.ALL_DATA_FIELDS):
        if f in dd['Fields']:
            fd = dd['Fields'][f]
            start = fd['start'] - 1
            end = fd['end']

            parsers.append((f, functools.partial(__get_line_slice, start, end)))
        else:
            parsers.append((f, lambda line: None))
    return parsers


def get_line_data(line, parsers, linenumber):
    rs = dict()
    for name, parser in parsers:
        try:
            rs[name] = parser(line)
        except:
            logging.warn("Error parsing value on line %d for %s", linenumber, name)
            rs[name] = None
    return rs


def convert_to_avro(datafile, date, output_location):
    import zipfile
    import os.path

    global __DATA_DEFINITIONS
    if __DATA_DEFINITIONS is None:
        __DATA_DEFINITIONS = shared.get_data_definitions()
        shared.apply_fixups(__DATA_DEFINITIONS, shared.get_data_definition_fixups())

    date_str = date.strftime('%Y-%m')
    dd = last(__DATA_DEFINITIONS, lambda x: x['Name'] <= date_str)
    parsers = get_line_parsers(dd)
    if dd is None:
        raise Exception("Could not find data dictionary for %s" % date_str)

    if not dd.get("Approved", True):
        raise Exception("The data dictionary for the file has not yet been approved.")

    basename = os.path.basename(datafile)
    basename = basename.replace('.zip', '')
    avro_name = date.strftime('%Y-%m') + '.avro'

    with zipfile.ZipFile(datafile) as zf:

        success = False
        for ext in ['.dat', '.cps', '.txt']:
            try:
                try_name = basename + ext
                f = zf.open(try_name)
                basename = try_name
                success = True
            except:
                pass
        if not success:
            raise Exception('Could not find content in the zip file for %s' % basename)

        try:
            with DataFileWriter(open(os.path.join(output_location, avro_name), 'w+b'), DatumWriter(),
                                shared.get_avro_schema(), codec='deflate') as avrow:
                logging.info('Writing %s', avro_name)
                for i, line in enumerate(ireadlines(f, True)):
                    data = get_line_data(line, parsers, i + 1)
                    avrow.append(data)

                    if (i + 1) % 1000 == 0:
                        logging.info('Wrote %d lines', i + 1)
        finally:
            f.close()
    return os.path.join(output_location, avro_name)


def str2date(s):
    try:
        return datetime.datetime.strptime("%s-01" % s, "%Y-%m-%d")
    except:
        return datetime.datetime.strptime("%s-01" % s, "%Y%m-%d")

def run_online(args):
    import os.path

    results = download_data_files(args.start_date, args.end_date, set(args.exclude or []), args.location, args.overwrite, args.update_store,
                                  args.update_store, args.store_location, args.delete_avro)

    paths = []
    for dt, path, success in results:
        if not success:
            logging.error("Failed to download %s" % os.path.basename(path))
        paths.append(path)

    return paths


def run_parse(args):
    file_date = args.date
    file_name = args.file
    download_location = args.location
    avro_name = convert_to_avro(file_name, file_date, download_location)

    if args.update_store:
        run_update_store(avro_name, args.store_location, file_date)
        if args.delete_avro:
            os.unlink(avro_name)

    return [avro_name]


def main(*args):
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--update-store', action='store_true')
    parser.add_argument('--store-location', default='file://./hrdate={year}{month}/{filename}',
                        help="Upload store location")
    parser.add_argument('--delete-avro', action='store_true', help='Delete avro files after store update')

    sub_parsers = parser.add_subparsers()
    parser_online = sub_parsers.add_parser('online')

    parser_online.add_argument('--overwrite', action='store_true')
    parser_online.add_argument('-s', '--start-date', type=str2date, help='Start date in YYYY-MM format')
    parser_online.add_argument('-e', '--end-date', type=str2date, help='End date in YYYY-MM format')
    parser_online.add_argument('-l', '--location', type=str, required=True, help='Download location')
    parser_online.add_argument('-x', '--exclude', type=str2date, nargs='*', help='Exclude dates')
    parser_online.set_defaults(func=run_online)

    parser_local = sub_parsers.add_parser('parse')
    parser_local.add_argument("-f", "--file", required=True, type=str)
    parser_local.add_argument("-d", "--date", required=True, type=str2date,
                              help="Date (YYYY-MM) on which this file applies")
    parser_local.add_argument('-l', '--location', type=str, required=True, help='Download location')
    parser_local.set_defaults(func=run_parse)

    args = parser.parse_args(args=args)
    return args.func(args)


if __name__ == "__main__":
    import sys

    main(*sys.argv[1:])
