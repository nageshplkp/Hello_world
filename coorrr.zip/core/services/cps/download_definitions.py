from core.rest import client as rest_client
from core.services.cps import shared

import re
import os, os.path
import sys
import logging
import traceback
import datetime

import itertools


class DiscontinuityDefinitionFormatException(Exception):
    def __init__(self, **kwargs):
        super(DiscontinuityDefinitionFormatException, self).__init__(
            'Error parsing definitions file {file}: Layout not continuous after line {line}'.format(**kwargs))


class SizeDefinitionFormatException(Exception):
    def __init__(self, **kwargs):
        super(SizeDefinitionFormatException, self).__init__(
            'Error parsing definitions file {file}: Size doesn\'t match start/end on {line}'.format(**kwargs))


def parse_cpsb_name(name):
    return datetime.datetime.strptime("%s-%s-01" % (name[2], name[1]), "%y-%b-%d").date()


def parse_full_name(name):
    return datetime.datetime.strptime("%s-%s-01" % (name[2], name[1]), "%Y-%B-%d").date()


def __unity(x):
    return x


def __unicode(x):
    if isinstance(x, str):
        return unicode(x, errors='replace').encode('utf-8', errors='replace')
    return x


__filler_fields = None


def is_filler_field(n):
    global __filler_fields
    if __filler_fields is None:
        conf = shared.get_config()
        __filler_fields = [re.compile(p) for p in conf['FillerFields']]

    return any(itertools.imap(lambda x: x.match(n) is not None, __filler_fields))


def parse_txt(name):
    lines = []

    mongo_db = shared.get_config_db()
    file_name = os.path.basename(name)

    size_ignore = list(mongo_db.db_collection('cps_config').find({'Kind': 'DDSizeErrorIgnore', 'Name': file_name}))
    size_ignore = size_ignore[0] if size_ignore else None

    cont_ignore = list(mongo_db.db_collection('cps_config').find({'Kind': 'DDContErrorIgnore', 'Name': file_name}))
    cont_ignore = cont_ignore[0] if cont_ignore else None

    size_ignore = set(tuple(x) for x in size_ignore['Locations']) if size_ignore else {}
    cont_ignore = set(tuple(x) for x in cont_ignore['Locations']) if cont_ignore else {}

    with open(name, "r") as f:
        l = f.readline()
        while l:
            lines.append(l.strip().replace('\x96', "-").replace("\x97", "-").replace('\x85', ' '))
            l = f.readline()

    format_lines = []
    rx = re.compile(r'^([^\s]+)\s+(\d+)\s+(.*?)\s+\(?\s*(\d+)\s*-\s*(\d+)\s*\)?\s*$')
    group_names = ['line', 'name', 'size', 'desc', 'start', 'end']
    transforms = [__unity, __unicode, int, __unicode, int, int]

    for i, l in enumerate(lines):
        m = rx.match(l)
        if m:
            format_lines.append(
                dict(zip(group_names, [f(x) for f, x in zip(transforms, itertools.chain([i], m.groups()))]))
            )

    format_lines = sorted(format_lines, cmp=lambda x, y: cmp(x['line'], y['line']))

    result_lines = []
    for i, l in enumerate(format_lines):
        if i > 0:
            if l['start'] != format_lines[i - 1]['end'] + 1 and l['start'] != format_lines[i - 1]['start'] \
                    and l['end'] != format_lines[i - 1]['end']:
                if (l['name'], l['start'], l['end']) not in cont_ignore:
                    raise DiscontinuityDefinitionFormatException(file=name, **format_lines[i - 1])
                else:
                    l['start'] = format_lines[i - 1]['end'] + 1
                    l['end'] = format_lines[i + 1]['start'] - 1 if i < len(format_lines) - 1 else l['start'] + l['size']
                    l['size'] = l['end'] - l['start'] + 1

        if l['start'] + l['size'] - 1 != l['end']:
            if (l['name'], l['start'], l['end']) not in size_ignore:
                raise SizeDefinitionFormatException(file=name, **l)
            else:
                l['size'] = l['end'] - l['start'] + 1

        j = l['line'] + 1
        while j < len(lines) and lines[j]:
            l['desc'] += ' ' + lines[j]
            j += 1

        if l['start'] == format_lines[i - 1]['start'] and l['end'] != format_lines[i - 1]['end']:
            result_lines[-1] = l
        else:
            result_lines.append(l)

    return [l for l in result_lines if not is_filler_field(l['name'])]


def download_file_formats(start_date=None, end_date=None, download_location=None, overwrite=False):
    return_data = rest_client.get(shared.NBER_ROOT_URL, use_kerberos=False, parse_content_as='text')

    cps_config = shared.get_config()
    possible_defs = cps_config['DefinitionFileRx']

    if download_location is None:
        download_location = os.getcwd()

    result = []
    for file_def in possible_defs:
        rx = re.compile('(%s)' % file_def['rx'], re.IGNORECASE)
        name_func = eval(file_def['name_parse_func'])
        files = rx.findall(return_data)
        dates = [name_func(f) for f in files]

        files = [(d, f) for d, f in zip(dates, files) if
                 (start_date is None or d >= start_date) and (end_date is None or d <= end_date)]

        for d, f in files:

            try:
                logging.info("Downloading file %s", f[0])
                if os.path.exists(os.path.join(download_location, f[0])) and not overwrite:
                    logging.info("File already exists. Skipping download.")
                    continue

                data = rest_client.get(shared.NBER_ROOT_URL + '/' + f[0], use_kerberos=False, parse_content_as='binary')
                with open(os.path.join(download_location, f[0]), "w+b") as out:
                    out.write(data.read())
                result.append((d, file_def['data_parse_func'], os.path.join(download_location, f[0])))
                logging.info("Downloaded file %s", f[0])
            except:
                logging.error("Failed to download file: %s", f[0])
                logging.error(traceback.format_exc())

    return result


def parse_file_formats(dates, parse_funcs, files, update_store=True):
    mongo = shared.get_config_db()
    for f, d, pf in itertools.izip(files, dates, parse_funcs):
        pf = eval(pf)

        try:
            defs = pf(f)

            config = {
                'Kind': 'DataDictionary',
                'Name': d.strftime('%Y-%m'),
                'Fields': defs,
                'Approved': False
            }

            if update_store:
                mongo.db_collection('cps_config').replace_one({'Kind': 'DataDictionary',
                                                               'Name': d.strftime('%Y-%m')}, config, upsert=True)
        except:
            logging.error("Failed to parse file: %s", f)
            logging.error(traceback.format_exc())


def str2date(s):
    return datetime.datetime.strptime("%s-01" % s, "%Y-%m-%d")


def run_online(args):
    results = download_file_formats(args.start_date, args.end_date, args.location, args.overwrite)
    if results:
        dates, funcs, paths = zip(*results)
        parse_file_formats(dates, funcs, paths, update_store=args.update_store)


def run_local(args):
    parse_file_formats([args.date], [args.parse_func], [args.file], update_store=args.update_store)


def get_parse_func(s):
    if s:
        return eval(s)
    return None

def main(*args):
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--update-store', action='store_true')
    sub_parsers = parser.add_subparsers()
    parser_online = sub_parsers.add_parser('online')

    parser_online.add_argument('--overwrite', action='store_true')
    parser_online.add_argument('-s', '--start-date', type=str2date, help='Start date in YYYY-MM format')
    parser_online.add_argument('-e', '--end-date', type=str2date, help='End date in YYYY-MM format')
    parser_online.add_argument('-l', '--location', type=str, required=True, help='Download location')
    parser_online.set_defaults(func=run_online)

    parser_local = sub_parsers.add_parser('local')
    parser_local.add_argument("-f", "--file", required=True, type=str)
    parser_local.add_argument("-d", "--date", required=True, type=str2date,
                              help="Date (YYYY-MM) on which this file applies")
    parser_local.add_argument('-p', '--parse-func', default='parse_txt', type=str)
    parser_local.set_defaults(func=run_local)

    args = parser.parse_args(args=args)
    args.func(args)


if __name__ == "__main__":
    import sys

    main(*sys.argv[1:])
