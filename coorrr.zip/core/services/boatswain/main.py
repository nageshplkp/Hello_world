import collections
import datetime
import logging
import os
import os.path
import pprint
import re
import shlex
import subprocess
import traceback
import types

import yaml

from core.config import config_api
from core.db.mongo_db import MongoDb


def ensure_folder(folder_path):
    if not os.path.isdir(folder_path):
        ensure_folder(os.path.dirname(folder_path))
        os.mkdir(folder_path, 0755)


class EnvConfigurable(object):
    def transform_env_string(self, s):
        if isinstance(s, (str, unicode)):
            return s.replace('$NGINX_ROOT', self.nginx_root).replace('$UWSGI_ROOT', self.uwsgi_root) \
                .replace('$HOSTNAME', self.hostname).replace('$CODE_ROOT', self.code_root)
        elif isinstance(s, (list, tuple)):
            return [self.transform_env_string(v) for v in s]
        return s

    def get_property(self, collection, name, default=None):
        val = collection.get(name, default)
        return self.transform_env_string(val)


class ServiceEntry(EnvConfigurable):
    def __init__(self, runtime_context, service_context, conf_file, cluster_name=None):
        self.service_context = service_context
        self.runtime_context = runtime_context
        self.conf_file = conf_file
        self.__conf_stat = None
        self.__validation_errors = []
        self.cluster_name = cluster_name

        self.service_name = os.path.basename(os.path.dirname(conf_file))
        with open(self.conf_file, "r") as conf_file:
            try:
                self.__service_config = yaml.load(conf_file)
                logging.info('Read service config: %s', pprint.pformat(self.__service_config))
            except yaml.YAMLError as yx:
                self.__service_config = {}
                logging.warning('Error reading service config file: %s\n%s' % (self.conf_file, traceback.format_exc()))
                self.__validation_errors.append('Invalid service config file: %s\n%s' % (self.conf_file, yx))

        logging.info('Ensuring folders exist')
        self.uwsgi_conf_name = service_context['uwsgi_conf_name'].format(service_name=self.service_name, env=self.env,
                                                                         user=self.username)
        self.appd_conf_name = service_context['appd_conf_name'].format(service_name=self.service_name, env=self.env,
                                                                         user=self.username)
        self.nginx_conf_name = service_context['nginx_conf_name'].format(service_name=self.service_name, env=self.env,
                                                                         user=self.username)

        ensure_folder(os.path.dirname(self.uwsgi_conf_name))
        ensure_folder(os.path.dirname(self.appd_conf_name))
        ensure_folder(os.path.dirname(self.nginx_conf_name))

        self.uwsgi_stat = None
        self.appd_stat = None
        self.nginx_stat = None
        if os.path.isfile(self.uwsgi_conf_name):
            self.uwsgi_stat = os.stat(self.uwsgi_conf_name)
        if os.path.isfile(self.appd_conf_name):
            self.appd_stat = os.stat(self.appd_conf_name)

        if os.path.isfile(self.nginx_conf_name):
            self.nginx_stat = os.stat(self.nginx_conf_name)

        if not self.author:
            self.__validation_errors.append('Author is missing')
        if not self.support_email:
            self.__validation_errors.append('SupportEmail is missing')
        if not self.description:
            self.__validation_errors.append('Description is missing')
        if not self.sample_urls:
            self.__validation_errors.append('SampleURLS are missing')

    @property
    def conf_stat(self):
        if self.__conf_stat is None:
            max_stat = os.stat(self.conf_file)
            for dir_path, sub_dirs, file_names in os.walk(os.path.dirname(self.conf_file)):
                for file_name in file_names:
                    try:
                        file_name = os.path.join(dir_path, file_name)
                        file_stat = os.stat(file_name)
                        if file_stat.st_mtime > max_stat.st_mtime:
                            max_stat = file_stat
                    except:
                        logging.error(traceback.format_exc())
            self.__conf_stat = max_stat

        return self.__conf_stat

    @property
    def conf_date(self):
        stat = self.conf_stat.st_mtime
        return datetime.datetime.fromtimestamp(stat)

    @property
    def uwsgi_date(self):
        if self.uwsgi_stat:
            return datetime.datetime.fromtimestamp(self.uwsgi_stat.st_mtime)
        return None

    @property
    def appd_date(self):
        if self.appd_stat:
            return datetime.datetime.fromtimestamp(self.appd_stat.st_mtime)
        return None

    @property
    def nginx_date(self):
        if self.nginx_stat:
            return datetime.datetime.fromtimestamp(self.nginx_stat.st_mtime)
        return None

    @property
    def env(self):
        return self.get_property(self.service_context, 'env')

    @property
    def username(self):
        return self.service_config.get('user', 'svc_refdt' if self.env == 'prod' else 'svc_refdt_np')

    @property
    def uwsgi_threads(self):
        return int(self.service_config.get('uwsgi_threads', 2))

    @property
    def deploy_targets(self):
        return self.service_config.get('deploy_targets', 'legacy').split(',')

    @property
    def gevent(self):
        return int(self.service_config.get('gevent', 0))

    @property
    def appd_enabled(self):
        return int(self.service_config.get('appd_enabled', config_api.get('appd_switch_default')) or 0)

    @property
    def uwsgi_processes(self):
        return int(self.service_config.get('uwsgi_processes', 2))

    @property
    def uwsgi_file(self):
        return self.get_property(self.service_config, 'uwsgi_file', 'resource.py')

    @property
    def uwsgi_callable(self):
        return self.get_property(self.service_config, 'uwsgi_callable', 'app')

    @property
    def uwsgi_enable_threads(self):
        return int(self.service_config.get('uwsgi_enable_threads', 1))

    @property
    def socket_name(self):
        return self.get_property(self.service_context, 'socket_name').format(service_name=self.service_name,
                                                                             env=self.env)

    @property
    def custom_env(self):
        return self.get_property(self.service_config, 'custom_env', dict())

    @property
    def service_root(self):
        return self.get_property(self.service_context, 'service_root').format(service_name=self.service_name,
                                                                              env=self.env)
    @property
    def content_root(self):
        return self.get_property(self.service_context, 'content_root').format(service_name=self.service_name,
                                                                              env=self.env)

    @property
    def ng_service_name_prefix(self):
        return self.get_property(self.service_context, 'ng_service_name_prefix', '')

    @property
    def service_dir(self):
        return self.get_property(self.service_config, 'service_dir', os.path.abspath(os.path.dirname(self.conf_file)))

    @property
    def content_path(self):
        return self.get_property(self.service_config, 'content_path', os.path.join(self.service_dir, 'htdocs'))

    @property
    def appenv(self):
        return self.get_property(self.service_context, 'appenv', self.env).format(env=self.env)

    @property
    def boatswain_config(self):
        return self.get_property(self.runtime_context, 'boatswain_config')

    @property
    def boatswain_log(self):
        return self.get_property(self.runtime_context, 'boatswain_log')

    @property
    def log_to(self):
        return self.get_property(self.service_context, 'log_to').format(service_name=self.service_name, env=self.env)

    @property
    def formatting_context(self):
        uwsgi_file = os.path.join(self.service_dir, self.uwsgi_file)
        return {
            'service_name': self.service_name,
            'env': self.env,
            'appenv': self.appenv,
            'uwsgi_threads': 'threads = %s' % (self.uwsgi_threads,) if self.uwsgi_threads > 1 else '',
            'uwsgi_processes': self.uwsgi_processes,
            'socket_name': self.socket_name,
            'service_root': self.service_root,
            'content_root': self.content_root,
            'service_dir': self.service_dir,
            'uwsgi_file': ('env = APPD_WSGI_SCRIPT_ALIAS=%s' if self.appd_enabled else 'wsgi-file = %s') % uwsgi_file,
            'uwsgi_callable': ('env = APPD_WSGI_CALLABLE_OBJECT=%s' if self.appd_enabled else 'callable = %s') % self.uwsgi_callable,
            'appd_cfg_file': ('env = APPD_CONFIG_FILE=%s' % self.appd_conf_name) if self.appd_enabled else '',
            'appd_module': 'module = appdynamics.scripts.wsgi' if self.appd_enabled else '',
            'uwsgi_enable_threads': self.uwsgi_enable_threads,
            'content_path': self.content_path,
            'boatswain_config': self.boatswain_config,
            'boatswain_log': self.boatswain_log,
            'log_to': self.log_to,
            'host_name': self.hostname,
            'gevent': 'gevent = %s' % (self.gevent,) if self.gevent else '',
            'ng_service_name_prefix': self.ng_service_name_prefix
        }

    @property
    def author(self):
        return self.get_property(self.service_config, 'Author', '')

    @property
    def support_email(self):
        return self.get_property(self.service_config, 'SupportEmail', '')

    @property
    def description(self):
        return self.get_property(self.service_config, 'Description', '')

    @property
    def sample_urls(self):
        return [self.transform_env_string(s) for s in self.service_config.get('SampleURLS', [])]

    @property
    def validation_errors(self):
        return self.__validation_errors

    @property
    def is_valid(self):
        return not bool(self.__validation_errors)

    @property
    def service_config(self):
        return self.__service_config

    @property
    def code_root(self):
        return self.runtime_context.get('code_root', '')

    @property
    def nginx_root(self):
        return self.runtime_context.get('nginx_root', '')

    @property
    def uwsgi_root(self):
        return self.runtime_context.get('uwsgi_root', '')

    @property
    def hostname(self):
        return os.environ.get('HOSTNAME', 'localhost')

    @property
    def uwsgi_template(self):
        with open(self.get_property(self.runtime_context, 'uwsgi_template'), "r") as uwsgi_templ_file:
            return uwsgi_templ_file.read()

    @property
    def appd_template(self):
        with open(self.get_property(self.runtime_context, 'appd_template'), "r") as appd_templ_file:
            return appd_templ_file.read()

    @property
    def nginx_template(self):
        with open(self.get_property(self.runtime_context, 'nginx_template'), "r") as nginx_templ_file:
            return nginx_templ_file.read()

    def write_configs(self):
        logging.info('Ensuring folders exist')
        ensure_folder(os.path.dirname(self.uwsgi_conf_name))
        ensure_folder(os.path.dirname(self.appd_conf_name))
        ensure_folder(os.path.dirname(self.nginx_conf_name))

        logging.info('Writing configuration files with: %s', pprint.pformat(self.formatting_context))
        uwsgi_conf = self.uwsgi_template.format(**self.formatting_context)
        appd_conf = self.appd_template.format(**self.formatting_context)
        nginx_conf = self.nginx_template.format(**self.formatting_context)

        custom_env = self.custom_env
        if isinstance(custom_env, collections.Mapping):
            custom_env = '\n' + '\n'.join(('env = %s=%s' % env_setting) for env_setting in custom_env.iteritems())
            uwsgi_conf += custom_env


        with open(self.nginx_conf_name, "w+") as nginx_file:
            nginx_file.write(nginx_conf)
        logging.info('Wrote %s', self.nginx_conf_name)
        with open(self.uwsgi_conf_name, "w+") as uwsgi_file:
            uwsgi_file.write(uwsgi_conf)
        logging.info('Wrote %s', self.uwsgi_conf_name)
        with open(self.appd_conf_name, "w+") as appd_file:
            appd_file.write(appd_conf)
        logging.info('Wrote %s', self.appd_conf_name)


class Boatswain(EnvConfigurable):
    def __init__(self, config_file, log_file):
        with open(config_file, "r") as f:
            config = yaml.load(f)

        config['boatswain_config'] = config_file
        config['boatswain_log'] = log_file

        self.config = config

        for svc_dir in self.service_directories:
            svc_dir['path'] = os.path.abspath(svc_dir['path'])

    @property
    def log_file(self):
        return self.get_property(self.config, 'boatswain_log', '')

    @property
    def nginx_error_log(self):
        return self.get_property(self.config, 'nginx_error_log', '')

    @property
    def nginx_access_log(self):
        return self.get_property(self.config, 'nginx_access_log', '')

    @property
    def uwsgi_log(self):
        return self.get_property(self.config, 'uwsgi_emperor_log', '')

    @property
    def code_root(self):
        return self.config.get('code_root', '')

    @property
    def nginx_root(self):
        return self.config.get('nginx_root', '')

    @property
    def uwsgi_root(self):
        return self.config.get('uwsgi_root', '')

    @property
    def hostname(self):
        return os.environ.get('HOSTNAME', 'localhost')

    @property
    def service_directories(self):
        return self.config['watch_dirs']

    @property
    def cluster_hosts(self):
        host_name = os.environ.get('CliqrTier_executor_HOSTNAME')
        return self.get_property(self.config, 'cluster_hosts', host_name and host_name.split(',') or [])

    def get_available_services(self, valid_only=True):
        services = []
        for service_context in self.service_directories:
            env = service_context['env']
            if not os.path.isdir(service_context['path']):
                continue

            for dir_path, sub_dir_names, file_names in os.walk(service_context['path']):
                for sub_dir_name in sub_dir_names:
                    sub_dir_name = os.path.abspath(os.path.join(dir_path, sub_dir_name))
                    try:
                        conf_file = os.path.join(sub_dir_name, service_context['conf_file'].format(env=env))
                        logging.debug('Env=%s conf_file=%s', env, conf_file)
                        if not os.path.isfile(conf_file):
                            logging.debug('Conf file not found')
                            continue

                        logging.info('Found %s', conf_file)
                        se = ServiceEntry(self.config, service_context, conf_file)

                        if ('CloudClusterName' in os.environ and os.environ['CloudClusterName'] in se.deploy_targets) \
                                or ('CloudClusterName' not in os.environ and 'legacy' in se.deploy_targets) \
                                or 'all' in se.deploy_targets:
                            services.append(ServiceEntry(self.config, service_context, conf_file,
                                                         cluster_name=os.environ.get('CloudClusterName') or 'legacy'))

                    except:
                        logging.error(traceback.format_exc())

                del sub_dir_names[:]
        services = services if not valid_only else filter(lambda x: x.is_valid, services)
        services = sorted(services, key=lambda x: x.service_name.lower())
        return services

    def restart_servers(self):
        for refresh_cmd in self.config['nginx_refresh_cmdlines']:
            refresh_cmd = self.transform_env_string(refresh_cmd)
            try:
                logging.info('Reloading nginx: %s', refresh_cmd)
                subprocess.call(shlex.split(refresh_cmd))
            except:
                logging.error(traceback.format_exc())

    def generate_refresh_script(self):
        all_services = self.get_available_services()
        file_events = {}
        for service in all_services:
            try:
                logging.debug('Env=%s conf_file=%s', service.env, service.conf_file)

                if not os.path.isfile(service.uwsgi_conf_name):
                    logging.info('UWSGI config not found. Scheduling config refresh. (%s)', service.uwsgi_conf_name)
                    file_events[service.conf_file] = service, 'created'
                elif not os.path.isfile(service.appd_conf_name):
                    logging.info('APPD config not found. Scheduling config refresh. (%s)', service.appd_conf_name)
                    file_events[service.conf_file] = service, 'created'
                elif not os.path.isfile(service.nginx_conf_name):
                    logging.info('NGINX config not found. Scheduling config refresh. (%s)', service.nginx_conf_name)
                    file_events[service.conf_file] = service, 'created'
                elif service.uwsgi_stat.st_mtime < service.conf_stat.st_mtime:
                    logging.info('UWSGI config modified. Scheduling config refresh. (%s)', service.uwsgi_conf_name)
                    file_events[service.conf_file] = service, 'modified'
                elif service.appd_stat.st_mtime < service.conf_stat.st_mtime:
                    logging.info('APPD config modified. Scheduling config refresh. (%s)', service.appd_conf_name)
                    file_events[service.conf_file] = service, 'modified'
                elif service.nginx_stat.st_mtime < service.conf_stat.st_mtime:
                    logging.info('NGINX config modified. Scheduling config refresh. (%s)', service.nginx_conf_name)
                    file_events[service.conf_file] = service, 'modified'

            except:
                logging.error(traceback.format_exc())

        all_uwsgi = dict([(x.uwsgi_conf_name, x) for x in all_services])
        all_nginx = dict([(x.nginx_conf_name, x) for x in all_services])
        all_appd  = dict([(x.appd_conf_name, x) for x in all_services])

        service_name_placeholder = '__service__name__placeholder__'
        user_name_place_holder   = '__user__name__placeholder__'

        def _cleanup_old_conf_files(placeholders, conf_name, conf_desc, all_conf):
            conf_dir = self.get_property(service_context, conf_name)
            conf_dir_root = Boatswain.get_root(conf_dir)

            for place, placeholder in placeholders.iteritems():
                conf_dir = conf_dir.replace(place, placeholder)
            conf_dir = re.escape(conf_dir)

            conf_re = "^" + conf_dir.replace(re.escape(service_name_placeholder), "\w+") \
                .replace(re.escape(user_name_place_holder), "\w+") + "$"

            logging.info("Checking if something needs cleaning: %s: %s", (conf_desc, conf_dir_root))
            logging.info("%s Pattern: %s", (conf_desc, conf_re))

            conf_re = re.compile(conf_re)
            for dir_name, sub_dir_names, file_names in os.walk(conf_dir_root):
                for file_name in file_names:
                    full_path = os.path.join(dir_name, file_name)
                    if conf_re.match(full_path) and full_path not in all_conf:
                        logging.info("Deleting %s: %s", (conf_desc, full_path))
                        file_events[os.path.abspath(full_path)] = os.path.abspath(full_path), 'delete'

        for service_context in self.service_directories:
            env_placeholder = self.get_property(service_context, 'env')
            _placeholders = {
                '{service_name}': service_name_placeholder,
                '{user}'        : user_name_place_holder,
                '{env}'         : env_placeholder,
            }
            _cleanup_old_conf_files(_placeholders, 'nginx_conf_name', 'NGINX', all_nginx)
            _cleanup_old_conf_files(_placeholders, 'uwsgi_conf_name', 'UWSGI', all_uwsgi)
            _cleanup_old_conf_files(_placeholders, 'appd_conf_name', 'APPD', all_appd)

        return file_events

    @staticmethod
    def get_root(dir_path):
        dir_path_root = dir_path.find('{')
        dir_path_root = dir_path[0:dir_path_root] if dir_path_root >= 0 else dir_path

        if dir_path_root.endswith('/'):
            return dir_path_root[:-1]
        else:
            return os.path.dirname(dir_path_root)

    def execute_refresh(self, refresh_script=None, restart_servers=False, persist_to_db=True):
        if refresh_script is None:
            refresh_script = self.generate_refresh_script()

        all_services = dict([(x.conf_file, x) for x in self.get_available_services()])
        for file_path, event_data in refresh_script.iteritems():
            service, file_action = event_data

            if isinstance(service, types.StringTypes) and file_action != 'delete':
                service = all_services.get(service)
            if file_action == 'delete' and not isinstance(service, types.StringTypes):
                logging.warn('Trying to delete the service using service object and not config name.')
                continue

            if not service:
                logging.warn('Service not found')
                continue

            try:
                if file_action == 'delete':
                    if os.path.isfile(service):
                        os.remove(service)
                    logging.info('%s deleted', service)
                    continue

                logging.info("%s(%s): %s %s", file_action, service.env, service.service_name, service.conf_file)
                service.write_configs()

            except:
                logging.error(traceback.format_exc())

        if persist_to_db:
            self.persist_service_entries()

        if restart_servers:
            self.restart_servers()

    def persist_service_entries(self):
        """ store service entries in mongo db """
        try:
            to_persist = []
            for se in self.get_available_services():
                to_persist.append({'cluster_name': se.cluster_name,
                                   'host_name': self.hostname,
                                   'service_name': se.service_name,
                                   'service_root': se.service_root,
                                   'env': se.env,
                                   'url_health': 'http://%s:50000/workshop%s/health' % (self.hostname, se.service_root),
                                   'last_modified_utc': datetime.datetime.utcnow()
                                   })

            cfg = config_api.get_cfg_by_env('prod')
            with MongoDb('pypimco_microsvcs', cfg['mongo_host'], user=cfg['mongo_py_user'],
                         password=cfg['mongo_py_password']) as c:
                c.delete('service_entries', {'host_name': self.hostname})
                c.insert('service_entries', to_persist)
            logging.info('Successfully persisted service entries to mongo db')
        except Exception as ex:
            logging.error('Unable to persist service entries to mongo db.\n'
                          'Reason: %s\nTraceback: \n%s', ex.message, traceback.format_exc())

