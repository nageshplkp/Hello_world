from core.rest import client
from core.rest.utils import popcorn_jcsv_to_dataframe
from urllib import urlencode
import getpass, logging
import pandas as pd
import six

def ptxl(fn_name, arglist=None, env='prod', debug=False, parameters=None):
    """
    :param fn_name: ptxl function name
    :param arglist: ordered list of arguments

    reference PTXL excel plug in for function names and arguments
    sample:
    ptxl.ptxl("Security", ["404280AU3", "ssm_id,pimco_desc,duration"])
    """

    parameters = parameters or {}

    params = {}
    if '_limit' not in parameters and (fn_name or '').lower() not in ('time series', 'security'):
        parameters['_limit'] = 1000000
    func = fn_name.replace(' ', '+')
    uri = 'http://ptp-%s/ptpe/v1/execute?FunctionName=%s' % (env,  func)

    parameters = ','.join('%s=%s' % (k,v) for k,v in six.iteritems(parameters))
    if arglist:
        for i in range(len(arglist)):
            params['arg%i' % (i + 1)] = arglist[i]

    if parameters:
        params['optional'] = parameters

    if params:
        uri = '%s&%s' % (uri, urlencode(params))


    if debug:
        logging.info(uri)

    print uri

    results = client.get(uri, headers={'From':'PIMCO\\' + getpass.getuser()}, use_kerberos=True)

    if debug:
        logging.info('returned json %s' % results)

    if isinstance(results, dict):
        jkeys = [key.upper() for key in results.keys()]
        if 'NAMES' in jkeys or 'TYPES' in jkeys or 'DATA' in jkeys:
            results = {fn_name:results}

        dfs = {}
        for k, v in results.iteritems():
            df = popcorn_jcsv_to_dataframe(v)
            dfs[k] = df

        #  some PTXL calls return 3 different dataset with different schema.  Return a dict if this occurs
        infos = [df.columns.tolist() for df in dfs.values()]
        prev = infos[0]
        for info in infos:
            if info != prev:
                return dfs
                break

        dfs = dfs.values()
    else:
        dfs = [pd.DataFrame(results)]

    return pd.concat(dfs)

#df = ptxl("SecurityByTicker", ["", "Price", ""], debug=False)
#print len(df)