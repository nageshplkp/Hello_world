from core.common.decorate import memoize
from core.common.util import auto_str
from .common import cliqr_url
import requests
import six


@auto_str
class VMDescription(object):
    """
    Describes a cliqr-managed VM resource
    """
    desc = None

    def __init__(self, vm_dict):
        self.desc = vm_dict

        parent_keys = set(VMDescription.__dict__.keys())
        incoming_keys = set(self.desc.keys())

        keys = incoming_keys - parent_keys
        for x in keys:
            self.__dict__[x] = self.desc[x]

    @property
    def service_name(self):
        return self.desc.get('serviceName', '')

    @property
    def tenant_id(self):
        return self.desc.get('tenantId', -1)

    @property
    def status(self):
        return self.desc.get('status', '').lower()

    @property
    def deploy_env(self):
        return self.desc.get('deploymentEnvironmentName', '').lower()

    @property
    def app_name(self):
        return self.desc.get('appName', '')

    @property
    def tier_name(self):
        return self.desc.get('jobName', '')

    @property
    def node_status(self):
        return self.desc.get('nodeStatus', '').lower()

    @property
    def hostname(self):
        return self.desc.get('hostName', '')

    @property
    def id(self):
        return self.desc.get('id')

    @property
    def deployment_name(self):
        return self.desc.get('parentJobName', '')

    @property
    @memoize
    def actions(self):
        return {k['name']: ActionDescription(k) for k in self.desc.get('actions', [])}

    @property
    @memoize
    def tags(self):
        return set((self.desc.get('tags', '') or '').split(';'))


@auto_str
class ActionDescription(object):
    """
    Describes custom action
    """

    desc = None

    def __init__(self, vm_dict):
        self.desc = vm_dict

        parent_keys = set(VMDescription.__dict__.keys())
        incoming_keys = set(self.desc.keys())

        keys = incoming_keys - parent_keys
        for x in keys:
            self.__dict__[x] = self.desc[x]

    @property
    def name(self):
        return self.desc['name']

    @property
    def enabled(self):
        return self.desc['enabled']

    @property
    def name(self):
        return self.desc['name']

    @property
    def resource(self):
        return self.desc['resource']

    @property
    @memoize
    def custom_params(self):
        return {k['paramName']: k for k in self.desc['actionCustomParamSpecs']}

    @property
    def id(self):
        return self.desc['id']


def list_vms(username, api_key):
    """
    Lists all vms visible to username
    
    :param str username: Cliqr username
    :param str api_key: Cliqr api key
    :return: List of VMs visible to the user
    :rtype: list[VMDescription]
    """
    response = requests.get('%s/v1/virtualMachines' % cliqr_url(), dict(size=0, listType='MANAGED_VMS'),
                            auth=(username, api_key), verify=False)
    response.raise_for_status()
    return map(VMDescription, response.json().get('details', {}).get('virtualMachineDetails', []))


def list_vms_filter(username, api_key, status=None, tenant_id=None, service_name=None, deploy_env=None,
                    app_name=None, tier_name=None, id=None, deployment_name=None, tags=None):
    """
    Returns a filtered list of vms visible to username
    
    :param str username: Cliqr username 
    :param str api_key: Cliqr api key
    :param str status: VM status (running, terminated, etc) or None
    :param str tenant_id: Cliqr tenant ID  or None
    :param str service_name: Cliqr service name  or None
    :param str deploy_env: dev, beta, preprod, prod or None
    :param str app_name: Cliqr Application name 
    :param str tier_name: Name of the tier 
    :param str id: Cliqr VM resource id
    :param str deployment_name: Name of the deployed application
    :return: 
    """
    return [v for v in list_vms(username, api_key)
            if (status is None or status == v.status) and
            (tenant_id is None or str(tenant_id) == str(v.tenant_id)) and
            (service_name is None or service_name.lower() == v.service_name) and
            (deploy_env is None or deploy_env.lower() == v.deploy_env) and
            (app_name is None or app_name.lower() == v.app_name.lower()) and
            (tier_name is None or tier_name.lower() == v.job_name.lower()) and
            (id is None or str(id) == v.id) and
            (deployment_name is None or deployment_name.lower() == v.deployment_name.lower()) and
            (tags is None or bool(set(tags).intersection(v.tags)))]


def list_resource_actions(username, api_key, *resource_ids):
    response = requests.get('%s/v1/resourceActions' % cliqr_url(),
                            dict(size=0, resourceType='VIRTUAL_MACHINE', ids=','.join(resource_ids)),
                            auth=(username, api_key), verify=False)

    response.raise_for_status()
    return {k['resourceId']: k['actions'] for k in response.json()}


def run_action(username, api_key, vm, action_name, **custom_param_values):
    """
    Runs given action on a given VM using provided custom parameter values 
    
    :param VMDescription vm: VM to run the action on 
    :param str action_name: name of the action to run
    :param dict custom_param_values: Custom parameter values
    """
    if action_name not in vm.actions:
        raise Exception('Action is not available on vm: %s' % vm.hostname)

    action = vm.actions[action_name]  # type: ActionDescription
    must_provide = {k: v.get('defaultValue') for k, v in six.iteritems(action.custom_params) if
                    v['userEditable'] and v['userVisible']}

    must_provide.update(custom_param_values)
    required = {k for k, v in six.iteritems(action.custom_params) if
                v['userEditable'] and v['userVisible'] and not v['optional']}

    for v in required:
        if not must_provide.get(v):
            raise Exception('Must provide value for parameter %s', v)

    exec_specs = [dict(name=k, value=v) for k, v in six.iteritems(must_provide)]
    req_body = dict(resourceType='VIRTUAL_MACHINE', executionSpecs=exec_specs, executionResources=[dict(id=vm.id)])

    resp = requests.post('%s/v1/actions/%s/executions' % (cliqr_url(), action.id), json=req_body, verify=False,
                         auth=(username, api_key), headers={'Content-Type': 'application/json'})

    try:
        resp.raise_for_status()
    except:
        import logging
        logging.error(resp.json())
        raise
