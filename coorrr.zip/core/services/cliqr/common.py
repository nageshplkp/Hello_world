from core.config import config_api

def cliqr_url():
    return config_api.get('cliqr.url')