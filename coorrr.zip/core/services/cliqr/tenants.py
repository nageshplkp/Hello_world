import requests
from .common import cliqr_url


def list_tenants(username, api_key):
    response = requests.get('%s/v1/tenants/' % cliqr_url(), dict(size=0), auth=(username, api_key), verify=False)
    response.raise_for_status()
    return response.json().get('tenants', [])


def find_tenant(username, api_key, tenant_name):
    tenants = list_tenants(username, api_key)
    my_tenant = [t for t in tenants if t['name'].lower() == tenant_name.lower()]
    return my_tenant[0] if my_tenant else None
