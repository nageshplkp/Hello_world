from core.rest import client as rest_client
from .job import Job, JobView, from_dict
from core.config import config_api


def schedule(name, job_uuid, command_line, description='', allow_multiple=False, job_platform='linux'):
    '''
    Schedules a new long-running job on a remote host.
    Jobs are identified by name and unique_id. Multiple jobs with same unique_id are allowed to run concurrently
    if allow_multiple flag is set to true. Jobs are run by executing provided command line.
    :param name: Name of the job
    :param job_uuid: Unique ID of the job.
    :param command_line: Command line to run
    :param description: Job description
    :param allow_multiple: Allow scheduling this same job multiple times
    :param job_platform: Platform (linux, windows, or custom ones)
    :return: Object describing scheduled job
    :rtype: JobView
    '''
    j = Job(name,job_uuid, command_line, description, allow_multiple, job_platform)
    url = 'http://%s/workshop/service/jeeves/execution' % config_api.get('ptp_base')
    return from_dict(rest_client.post(url, j.to_json()))


def check_status(execution_uuid):
    """
    Checks status of an execution
    :param execution_uuid: Execution UUID (obtained from the object returned by schedule)
    :return: JobView describing current state
    :rtype: JobView
    """
    execution_uuid = str(execution_uuid)
    url = 'http://%s/workshop/service/jeeves/execution' % config_api.get('ptp_base')
    return from_dict(rest_client.get(url, params=dict(execution_id=execution_uuid)))



