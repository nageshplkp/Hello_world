import uuid

from bson import ObjectId

from core.db import MongoDb
from core.config import config_api
from bson.objectid import ObjectId
from pymongo.errors import DuplicateKeyError
import os
import time
import socket
import pymongo
import json

HISTORY_COLLECTION_NAME = 'executions'
RUNNING_EXECUTIONS = 'running_executions'
SCHEDULED_EXECUTIONS = 'scheduled_executions'


class JobAlreadyRunningError(Exception):
    def __init__(self, job):
        self.job = job
        super(JobAlreadyRunningError, self).__init__()

    def __str__(self):
        return 'Job already running: %s %s' % (self.job.execution_uuid, self.job.name)


class JobAlreadyScheduledError(Exception):
    def __init__(self, job):
        self.job = job
        super(JobAlreadyScheduledError, self).__init__()

    def __str__(self):
        return 'Job already scheduled: %s %s' % (self.job.execution_uuid, self.job.name)


class JobNotFoundError(Exception):
    def __init__(self, execution_uuid):
        self.execution_uuid = execution_uuid
        super(JobNotFoundError, self).__init__()

    def __str__(self):
        return 'Job not found: %s' % self.execution_uuid


class JobView(object):
    STATUS_DONE = 'DONE'
    STATUS_ERROR = 'ERROR'
    STATUS_RUNNING = 'RUNNING'
    STATUS_SCHEDULED = 'SCHEDULED'
    STATUS_NEW = 'NEW'

    def __init__(self, name, job_uuid, execution_uuid, command_line, description, allow_multiple,
                 job_status=STATUS_NEW, job_host=None, job_start_time=None, job_schedule_time=None, job_end_time=None,
                 job_status_update_time=None, job_platform='linux'):
        self.command_line = command_line
        self.job_host = job_host
        self.execution_uuid = execution_uuid
        self.name = name
        self.job_status_update_time = job_status_update_time
        self.job_status = job_status
        self.job_schedule_time = job_schedule_time
        self.job_start_time = job_start_time
        self.allow_multiple = allow_multiple
        self.description = description
        self.job_end_time = job_end_time
        self.job_platform = job_platform
        self.job_uuid = job_uuid

    def update_from_doc(self, doc):
        self.job_host = doc['job_host']
        self.job_start_time = doc['job_start_time']
        self.job_schedule_time = doc['job_schedule_time']
        self.job_end_time = doc['job_end_time']
        self.allow_multiple = doc['allow_multiple']
        self.name = doc['name']
        self.command_line = doc['command_line']
        self.description = doc['description']
        self.job_status = doc['job_status']
        self.job_uuid = doc['job_uuid'] if isinstance(doc['job_uuid'], ObjectId) else ObjectId(doc['job_uuid'])
        self.job_status_update_time = doc['job_status_update_time']
        self.execution_uuid = doc['execution_uuid'] if isinstance(doc['execution_uuid'], ObjectId) \
            else ObjectId(doc['execution_uuid'])
        self.job_platform = doc.get('job_platform') or 'linux'

    def to_dict(self, force_allow_multiple=False):
        allow_multiple = force_allow_multiple or self.allow_multiple
        return {
            '_id': self.execution_uuid if allow_multiple else self.job_uuid,
            'execution_uuid': self.execution_uuid,
            'job_uuid': self.job_uuid,
            'job_host': self.job_host,
            'job_start_time': self.job_start_time,
            'job_schedule_time': self.job_schedule_time,
            'job_end_time': self.job_end_time,
            'allow_multiple': self.allow_multiple,
            'name': self.name,
            'command_line': self.command_line,
            'description': self.description,
            'job_status': self.job_status,
            'job_status_update_time': self.job_status_update_time,
            'job_platform': self.job_platform
        }

    def to_json_dict(self):
        d = self.to_dict()
        for k in d.keys():
            if isinstance(d[k], ObjectId):
                d[k] = str(d[k])
        return d

    def to_json(self):
        d = self.to_json_dict()
        return json.dumps(d)


class Job(JobView):
    def __init__(self, name, job_uuid, command_line, description='', allow_multiple=False, job_platform='linux'):
        super(Job, self).__init__(name, job_uuid, ObjectId(), command_line, description, allow_multiple,
                                  job_status=Job.STATUS_NEW, job_platform=job_platform)


class BaseJob(JobView):
    def __init__(self, connection, name, job_uuid, execution_uuid, command_line, description, allow_multiple,
                 job_status=JobView.STATUS_NEW, job_host=None, job_start_time=None, job_schedule_time=None,
                 job_end_time=None, job_status_update_time=None, job_platform='linux'):
        '''

        :param connection: Mongo connection
         :type connection: MongoDb
        :param name:
        :param job_uuid:
        :param execution_uuid:
        :param command_line:
        :param description:
        :param allow_multiple:
        :param job_status:
        :param job_host:
        :param job_start_time:
        :param job_schedule_time:
        :param job_end_time:
        '''
        super(BaseJob, self).__init__(name, job_uuid, execution_uuid, command_line, description, allow_multiple,
                                      job_status=job_status, job_host=job_host, job_start_time=job_start_time,
                                      job_schedule_time=job_schedule_time, job_end_time=job_end_time,
                                      job_status_update_time=job_status_update_time, job_platform=job_platform)
        self.__connection = connection

    @staticmethod
    def get_connection():
        user_name = os.environ.get('USER')
        if not user_name:
            user_name = os.environ.get('USERNAME')
        return MongoDb('jeeves', config_api.get('MONGO_HOST'), user_name)

    @property
    def connection(self):
        return self.__connection

    def update(self, collection=HISTORY_COLLECTION_NAME):
        try:
            conn = self.connection
            doc = conn.db_collection(collection).find_one(filter={'execution_uuid': self.execution_uuid})

            if doc:
                self.update_from_doc(doc)
        except:
            raise


class NewJob(BaseJob):
    def __init__(self, name, job_uuid, command_line, description='', allow_multiple=False, job_platform='linux',
                 job_doc=None, connection=None):

        if job_doc:
            super(NewJob, self).__init__(connection, '', '', '', '', '', '')
            self.update_from_doc(job_doc)
            return

        if not isinstance(job_uuid, ObjectId):
            job_uuid = ObjectId(job_uuid)

        execution_uuid = ObjectId()
        super(NewJob, self).__init__(connection, name, job_uuid, execution_uuid, command_line, description,
                                     allow_multiple,
                                     job_platform=job_platform)

    def schedule(self):
        self.job_status = NewJob.STATUS_SCHEDULED
        self.job_schedule_time = time.time()
        try:
            conn = self.connection
            if not self.allow_multiple:
                running_job = conn.db_collection(RUNNING_EXECUTIONS).find_one({'job_uuid': self.job_uuid})
                if running_job:
                    raise JobAlreadyScheduledError(self)

            conn.db_collection(SCHEDULED_EXECUTIONS).insert_one(self.to_dict())
            return ScheduledJob(self.connection, execution_uuid=self.execution_uuid)
        except DuplicateKeyError, ex:
            self.job_status = NewJob.STATUS_NEW
            self.job_schedule_time = None

            raise JobAlreadyScheduledError(self)
        except:
            self.job_status = NewJob.STATUS_NEW
            self.job_schedule_time = None
            raise

    @staticmethod
    def get(connection, execution_uuid):
        try:
            return ScheduledJob(connection, execution_uuid=execution_uuid)
        except JobNotFoundError:
            pass

        try:
            return RunningJob(connection, execution_uuid=execution_uuid)
        except JobNotFoundError:
            pass

        return CompletedJob(connection, execution_uuid=execution_uuid)

    @staticmethod
    def from_dict(job_dict, connection=None):
        if isinstance(job_dict, list):
            return [NewJob.from_dict(x, connection) for x in job_dict]

        status = job_dict['job_status']
        if not connection:
            v = JobView(None, None, None, None, None, False)
            v.update_from_doc(job_dict)
            return v
        if status == NewJob.STATUS_NEW:
            return NewJob(connection, None, None, None, job_doc=job_dict)
        elif status == NewJob.STATUS_SCHEDULED:
            return ScheduledJob(connection, job_doc=job_dict)
        elif status == NewJob.STATUS_RUNNING:
            return RunningJob(connection, job_doc=job_dict)
        else:
            return CompletedJob(connection, job_doc=job_dict)


class ScheduledJob(BaseJob):
    def __init__(self, connection, execution_uuid=None, job_doc=None):
        '''

        :param connection:
        :type connection: MongoDb
        :param execution_uuid:
        :param job_doc:
        '''
        if execution_uuid:
            execution_uuid = execution_uuid if isinstance(execution_uuid, ObjectId) else ObjectId(execution_uuid)
            job_doc = connection.db_collection(SCHEDULED_EXECUTIONS).find_one({'execution_uuid': execution_uuid})

        if job_doc:
            name = job_doc['name']
            execution_uuid = job_doc['execution_uuid']
            job_uuid = job_doc['job_uuid']
            super(ScheduledJob, self).__init__(connection, name, job_uuid, execution_uuid, '', '', False)
            self.update_from_doc(job_doc)
        else:
            raise JobNotFoundError(execution_uuid)

    @staticmethod
    def get_all(connection):
        '''

        :param connection:
        :type connection: MongoDb
        :return:
        '''
        job_docs = connection.db_collection(SCHEDULED_EXECUTIONS).find({'job_status': NewJob.STATUS_SCHEDULED})
        jobs = map(lambda x: ScheduledJob(connection, job_doc=x), job_docs)
        return jobs

    def run(self):
        self.job_start_time = time.time()
        self.job_status_update_time = time.time()
        self.job_host = socket.gethostname()
        self.job_status = NewJob.STATUS_RUNNING
        try:
            self.connection.db_collection(RUNNING_EXECUTIONS).insert_one(self.to_dict())

            try:
                self.connection.db_collection(SCHEDULED_EXECUTIONS).delete_one({'execution_uuid': self.execution_uuid})
            except:
                import logging
                import traceback
                logging.error(traceback.format_exc())

            return RunningJob(self.connection, execution_uuid=self.execution_uuid)
        except DuplicateKeyError, ex:
            self.job_status = NewJob.STATUS_SCHEDULED
            self.job_status_update_time = None
            self.job_start_time = None

            raise JobAlreadyRunningError(self)
        except:
            self.job_status = NewJob.STATUS_SCHEDULED
            self.job_status_update_time = None
            self.job_start_time = None
            raise


class RunningJob(BaseJob):
    def __init__(self, connection, execution_uuid=None, job_doc=None):
        '''

        :param connection:
        :type connection: MongoDb
        :param execution_uuid:
        :param job_doc:
        '''
        if execution_uuid:
            execution_uuid = execution_uuid if isinstance(execution_uuid, ObjectId) else ObjectId(execution_uuid)
            job_doc = connection.db_collection(RUNNING_EXECUTIONS).find_one({'execution_uuid': execution_uuid})

        if job_doc:
            name = job_doc['name']
            execution_uuid = job_doc['execution_uuid']
            job_uuid = job_doc['job_uuid']
            super(RunningJob, self).__init__(connection, name, job_uuid, execution_uuid, '', '', False)
            self.update_from_doc(job_doc)
        else:
            raise JobNotFoundError(execution_uuid)

    @staticmethod
    def get_all(connection):
        '''

        :param connection:
        :type connection: MongoDb
        :return:
        '''
        job_docs = connection.db_collection(RUNNING_EXECUTIONS).find({'job_status': NewJob.STATUS_RUNNING})
        jobs = map(lambda x: ScheduledJob(connection, job_doc=x), job_docs)
        return jobs

    def ping(self):
        self.job_status_update_time = time.time()

        try:
            self.connection.db_collection(RUNNING_EXECUTIONS).update_one(
                {'execution_uuid': self.execution_uuid},
                {'$set': {'job_status_update_time': self.job_status_update_time}})
        except:
            import logging
            import traceback
            logging.error(traceback.format_exc())

    def complete(self, is_error=False):
        self.job_status_update_time = time.time()
        self.job_status = NewJob.STATUS_ERROR if is_error else NewJob.STATUS_DONE
        self.job_end_time = time.time()

        try:
            self.connection.db_collection(HISTORY_COLLECTION_NAME).insert_one(self.to_dict(force_allow_multiple=True))
            try:
                self.connection.db_collection(RUNNING_EXECUTIONS).delete_one({'execution_uuid': self.execution_uuid})
            except:
                import logging
                import traceback
                logging.error(traceback.format_exc())

            return CompletedJob(self.connection, execution_uuid=self.execution_uuid)

        except:
            self.job_status = NewJob.STATUS_RUNNING
            self.job_end_time = None
            raise


class CompletedJob(BaseJob):
    def __init__(self, connection, execution_uuid=None, job_doc=None):
        '''

        :param connection:
        :type connection: MongoDb
        :param execution_uuid:
        :param job_doc:
        '''
        if execution_uuid:
            execution_uuid = execution_uuid if isinstance(execution_uuid, ObjectId) else ObjectId(execution_uuid)
            job_doc = connection.db_collection(HISTORY_COLLECTION_NAME).find_one({'execution_uuid': execution_uuid})

        if job_doc:
            name = job_doc['name']
            execution_uuid = job_doc['execution_uuid']
            job_uuid = job_doc['job_uuid']
            super(CompletedJob, self).__init__(connection, name, job_uuid, execution_uuid, '', '', False)
            self.update_from_doc(job_doc)
        else:
            raise JobNotFoundError(execution_uuid)

    @staticmethod
    def get_all(connection, skip=None, limit=None, sort=None, count=False):
        '''

        :param connection:
        :type connection: MongoDb
        :return:
        '''
        job_docs = connection.db_collection(HISTORY_COLLECTION_NAME).find()
        if count:
            return job_docs.count()

        if sort is not None:
            if not isinstance(sort, list):
                job_docs = job_docs.sort(sort, pymongo.ASCENDING)
            else:
                job_docs = job_docs.sort(sort)
        if skip is not None:
            job_docs = job_docs.skip(skip)
        if limit is not None:
            job_docs = job_docs.limit(limit)
        jobs = map(lambda x: CompletedJob(connection, job_doc=x), job_docs)
        return jobs

    @staticmethod
    def get_filtered(connection, filter, skip=None, limit=None, sort=None, count=False):
        job_docs = connection.db_collection(HISTORY_COLLECTION_NAME).find(filter)
        if count:
            return job_docs.count()
        if sort is not None:
            if not isinstance(sort, list):
                job_docs = job_docs.sort(sort, pymongo.ASCENDING)
            else:
                job_docs = job_docs.sort(sort)
        if skip is not None:
            job_docs = job_docs.skip(skip)
        if limit is not None:
            job_docs = job_docs.limit(limit)
        jobs = map(lambda x: CompletedJob(connection, job_doc=x), job_docs)
        return jobs


get_connection = NewJob.get_connection


def from_dict(job_dict, connection=None):
    return NewJob.from_dict(job_dict, connection)
