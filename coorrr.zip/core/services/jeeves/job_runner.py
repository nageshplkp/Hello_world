import gevent
import gevent.subprocess

from core.db.mongo_db import MongoDb
from .job import ScheduledJob, RunningJob, JobAlreadyRunningError, BaseJob, RUNNING_EXECUTIONS, CompletedJob
import logging
import traceback
import shlex
import os.path
import shutil
import logging
from core.config import config_api
from core.rest import client as rest_client
from io import BytesIO
import struct

__please_quit = False
__all_running = {}


def running_count():
    return len(__all_running)


def run_process(execution_uuid, cmd_line, log_location):
    output_name = os.path.join(log_location, str(execution_uuid) + '.out.tmp')
    error_name = os.path.join(log_location, str(execution_uuid) + '.err.tmp')

    try:
        with open(output_name, "w+") as output:
            with open(error_name, "w+") as error:
                logging.info("Starting process: %s stdout=%s stderr=%s", ' '.join(cmd_line), output_name, error_name)
                gevent.subprocess.check_call(cmd_line, stdout=output, stderr=error)
        is_error = False
        logging.info("Process finished: %s", ' '.join(cmd_line))

    except:
        is_error = True
        logging.warn("Process aborted: %s", ' '.join(cmd_line))

    try:
        if os.path.isfile(output_name):
            shutil.move(output_name, output_name[:-4])
        if os.path.isfile(error_name):
            shutil.move(error_name, error_name[:-4])
    except:
        logging.error(traceback.format_exc())

    try:
        connection = BaseJob.get_connection()
        job = RunningJob(connection, execution_uuid=execution_uuid)
        job.complete(is_error)

    except:
        try:
            job = CompletedJob(connection, execution_uuid=execution_uuid)
            if job:
                logging.warn('Execution %s was killed due to timeout', execution_uuid)
        except:
            logging.fatal(traceback.format_exc())

    send_logs(execution_uuid, output_name[:-4], error_name[:-4])

    del __all_running[execution_uuid]


def send_logs(execution_uuid, output_file, error_file):
    execution_uuid = str(execution_uuid)

    try:
        data = BytesIO()
        data.write(execution_uuid)
        with open(output_file, "r") as f:
            out_data = f.read()
        data.write(struct.pack('<Q', len(out_data)))
        data.write(out_data)

        with open(error_file, "r") as f:
            error_data = f.read()
        data.write(struct.pack('<Q', len(error_data)))
        data.write(error_data)

        rest_client.post('http://%s/workshop/service/jeeves/logs'%config_api.get('ptp_base'), data=data.getvalue())

        os.remove(output_file)
        os.remove(error_file)
    except:
        logging.fatal(traceback.format_exc())

def gevent_loop(log_location, max_jobs_per_host=50, platform='linux'):
    while not __please_quit:
        gevent.sleep(3)

        process_scheduled_jobs(log_location, max_jobs_per_host, platform=platform)


def process_scheduled_jobs(log_location, max_jobs_per_host, platform='linux'):
    try:
        connection = BaseJob.get_connection()  # type: MongoDb
    except:
        logging.fatal(traceback.format_exc())
        return

    all_running_uuids = __all_running.keys()
    for uuid in all_running_uuids:
        try:
            job = RunningJob(connection,uuid)
            job.ping()
        except:
            logging.fatal(traceback.format_exc())

    all_scheduled = ScheduledJob.get_all(connection)
    for job in all_scheduled:
        if job.execution_uuid in __all_running:
            continue

        if job.job_platform != platform:
            continue

        if len(__all_running) >= max_jobs_per_host:
            break

        try:
            running_job = job.run()
        except JobAlreadyRunningError, ex:
            continue
        except:
            logging.fatal(traceback.format_exc())
            break

        try:
            cmd_line = shlex.split(running_job.command_line, posix=(os.name != 'nt'))
            greenlet = gevent.spawn(run_process, running_job.execution_uuid, cmd_line, log_location)
            __all_running[job.execution_uuid] = greenlet
        except:
            try:
                logging.error(traceback.format_exc())
                running_job.complete(True)
            except:
                logging.fatal(traceback.format_exc())
                break
    connection.mongo.close()


def error_timed_out(timeout_secs=600):
    import time
    connection = BaseJob.get_connection()  # type: MongoDb
    now = time.time()
    cutoff = now - timeout_secs

    cur = connection.db_collection(RUNNING_EXECUTIONS).find({'job_status_update_time': {'$lt': cutoff}})
    jobs = [RunningJob(connection, job_doc=d) for d in cur]
    for j in jobs:
        logging.warn('Timing out %s: %s %s', j.execution_uuid, j.name, j.command_line)
        j.complete(True)
