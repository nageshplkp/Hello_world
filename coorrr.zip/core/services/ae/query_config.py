from lxml import etree
from xml.etree import ElementTree as ET
import core
import re

ORA_ID = re.compile(r'^[_a-z][_a-z0-9]*$', re.IGNORECASE)

def _get_boolean(b):
    return False if not b else str(b).lower() != 'no'


def _id_to_sql(id):
    if isinstance(id, (int, float)):
        return str(id)
    return "'%s'" % id


class JoinConfig(object):
    def __init__(self, id, table_name, join_alias, join_clause, table_alias=None, join_type="INNER",
                 htable="", hjoin_clause="", **kwargs):
        self.id = id
        self.table_name = table_name
        self.join_alias = join_alias
        self.join_clause = join_clause
        self.table_alias = table_alias or table_name
        self.join_type = join_type
        self.htable = htable
        self.hjoin_clause = hjoin_clause


class LevelConfig(object):
    def __init__(self, level, type, select, table_aliases, table, order_by='N', distinct='n', **kwargs):
        self.level = level
        self.type = type
        self.select = select
        table_aliases = table_aliases.split(',')
        table_aliases = [x.split(';') for x in table_aliases]
        self.table_aliases = []
        for tt in table_aliases:
            self.table_aliases += tt

        self.order_by = _get_boolean(order_by)
        self.distinct = _get_boolean(distinct)
        self.table = table


class Attribute(object):
    def __init__(self, tag, dbcol, table_alias, display_name=None, has_hist='N', join_table_id=None, **kwargs):
        self.tag = tag
        self.join_table_id = join_table_id
        self.table_alias = table_alias
        self.dbcol = dbcol
        self.display_name = display_name or self.tag
        self.has_hist = _get_boolean(has_hist)

    def to_ora(self):
        if ORA_ID.match(self.dbcol):
            return '%s.%s "%s"' % (self.table_alias, self.dbcol, self.tag)
        else:
            return '%s "%s"' % (self.dbcol, self.tag)

class QueryConfig(object):
    def __init__(self, xml_file=None, xml_source=None):
        self.levels = {}
        self.join_tables = {}
        self.join_tables_by_alias = {}
        self.attributes = {}

        tree = None
        if xml_file is not None:
            tree = ET.parse(xml_file)
        elif xml_source is not None:
            tree = ET.fromstring(xml_source)

        root = tree.getroot()  # type: ET.Element
        levels = root.findall('./LevelConfig/config')
        levels = [LevelConfig(**dict(l.items())) for l in levels]
        self.levels = dict([(l.level, l) for l in levels])

        join_tables = root.findall('./JoinTables/table')
        join_tables = [JoinConfig(**dict(l.items())) for l in join_tables]
        self.join_tables = dict([(l.id, l) for l in join_tables])
        self.join_tables_by_alias = dict([(l.table_alias, l) for l in join_tables])

        attributes = root.findall('.//Attribute')
        attributes = [Attribute(**dict(l.items())) for l in attributes]
        self.attributes = dict([(l.tag, l) for l in attributes])

    def __table_deps(self, t):
        deps = set()
        t = self.join_tables_by_alias.get(t.join_alias)
        ordered_deps = []
        while t:
            if deps.add(t.table_alias):
                ordered_deps.append(t.table_alias)
            t = self.join_tables_by_alias.get(t.join_alias)
        return list(reversed(ordered_deps))

    def __table_alias_compare(self, level, t1, t2):
        if t1 in level.table_aliases:
            if t2 in level.table_aliases:
                return 0
            return -1
        if t2 in level.table_aliases:
            return 1

        tbl1 = self.join_tables_by_alias[t1]
        tbl2 = self.join_tables_by_alias[t2]

        tbl1_deps = self.__table_deps(tbl1)
        tbl2_deps = self.__table_deps(tbl2)

        if tbl1.table_alias in tbl2_deps:
            return -1
        if tbl2.table_alias in tbl1_deps:
            return 1

        tbl1_deps = ','.join(tbl1_deps)
        tbl2_deps = ','.join(tbl2_deps)
        if tbl1_deps != tbl2_deps:
            return cmp(tbl1_deps, tbl2_deps)

        if tbl1.join_type == 'INNER':
            if tbl2.join_type == 'INNER':
                return 0
            return -1
        elif tbl2.join_type == 'INNER':
            return 1
        return 0


    def create_query(self, level, ids, fields=None):
        lc = self.levels[level]
        attrs = [self.attributes[f] for f in fields]
        ids = ', '.join(_id_to_sql(i) for i in ids)

        table_aliases = set()
        for a in attrs:
            table_aliases.add(a.table_alias)

        for ta in list(table_aliases):
            jc = self.join_tables_by_alias.get(ta)
            if jc:
                table_aliases.add(jc.join_alias)

        table_aliases = sorted(table_aliases, cmp=lambda x,y: self.__table_alias_compare(lc, x, y))

        select_fields = ', '.join([lc.select] + [a.to_ora() for a in attrs])
        select_clause = 'SELECT%s %s' % (' DISTINCT' if lc.distinct else '', select_fields)
        where_clause = ' WHERE %s in (%s)' % (lc.select, ids)

        join_tables = [self.join_tables_by_alias[a] for a in table_aliases if a in self.join_tables_by_alias]
        from_clause = ' %s %s ' % (lc.table, ' '.join(
            ['%s JOIN %s %s ON %s' % (t.join_type, t.table_name, t.table_alias, t.join_clause) for t in join_tables]))
        if lc.order_by:
            order_clause = ' ORDER BY %s' % lc.select
        else:
            order_clause = ''

        query = select_clause + from_clause + where_clause + order_clause
        return query
