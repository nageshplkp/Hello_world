from .query_config import QueryConfig
from core.db.sql_query import query_as_dataframe
import collections
import os.path

__all__ = ['QueryConfig', 'dig_security']

__basedir = os.path.dirname(os.path.abspath(__file__))
__pma_sec = QueryConfig(xml_file=os.path.join(__basedir, 'OraPMA_security.xml'))


def dig_security(cusips, fields=[], conn='default', env='default'):

    if isinstance(cusips, basestring) or not isinstance(cusips, collections.Iterable):
        cusips = [cusips]

    if isinstance(fields, basestring) or not isinstance(fields, collections.Iterable):
        fields = [fields]

    return query_as_dataframe(__pma_sec.create_query('security', cusips, fields), conn=conn, env=conn)
