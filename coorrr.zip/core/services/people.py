from core.rest import client


def get_manager_info(mgr_nos):
    mgr_nos = mgr_nos if isinstance(mgr_nos, (list, tuple)) else [mgr_nos]
    mgr_nos = ','.join([str(x) for x in mgr_nos])
    return client.get('http://pmdservice:9091/pmd/v1/mgrs?_fieldSet=full&mgrNos=%s' % mgr_nos, use_kerberos=False)
