import flask
import werkzeug.exceptions
import flask_restful
import functools
import logging
import datetime
import uuid
import urlparse
import io
import gzip
import os

from core.rest import rest_config
from core.services import pimproxy
from core.log import log_config

__original_flask = flask.Flask
__original_api = flask_restful.Api

try:
    import uwsgi

    uwsgi_configured = True
except:
    uwsgi_configured = False


def logging_decorator(api, f, make_response_conversion=False, app=None):
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        req = flask.request
        req_id = req.headers.get(rest_config.X_REQUEST_ID) or str(uuid.uuid4())
        user = pimproxy.username() or 'Unknown'
        end_point = urlparse.urlparse(req.url)
        end_point = '%s://%s/%s' % (end_point.scheme, end_point.netloc, end_point.path)
        user_ip = req.remote_addr
        if not req.script_root:
            app_name = os.environ.get('PYPIMCO_MS_APP_NAME', 'Unknown PyPimco Microservice')
        else:
            app_name = urlparse.urlparse(req.script_root).path.split('/')[-1]

        try:
            rest_config._set_request_id(req_id)
            start = datetime.datetime.now()
            try:
                log_config.logging_extras.push(dict(ClUser=user, Apptype='microservice', Appname=app_name,
                                                    Appcomponent='',
                                                    ClHost=user_ip, ReqEnd=end_point, Id=req_id,
                                                    Parameters=dict(req.args)))
                resp = f(*args, **kwargs)
                if not isinstance(resp, flask.Response):
                    if make_response_conversion and app is not None:
                        resp = app.make_response(resp)
                end = datetime.datetime.now()
                exec_ms = (end - start).total_seconds() * 100

                if isinstance(resp, flask.Response):
                    resp_code = resp.status_code
                else:
                    resp_code = 200
                logging.info('Done', extra={'kwargs': dict(ExecMs=exec_ms, RespCode=resp_code)})
                return resp
            finally:
                log_config.logging_extras.pop()
        except:
            import traceback
            logging.warn(traceback.format_exc())
        finally:
            rest_config._set_request_id(None)

    return wrapper


class MonkeyFlask(flask.Flask):
    def __init__(self, name, *args, **kwargs):

        super(MonkeyFlask, self).__init__(name, *args, **kwargs)

        if 'LOGGING_HANDLER_POLICY' not in self.config:
            self.config['LOGGING_HANDLER_POLICY'] = 'always'


        self.route('/health')(self.__health)
        self.route('/swagger')(self.__swagger)

        self.before_request(self.logging_before_request)
        self.before_request(self.ungzip)
        self.after_request(self.logging_after_request)
        self.register_error_handler(500, self.logging_after_exception)

    def ungzip(self):
        encoding = flask.request.headers.get('content-encoding', '')
        if encoding == 'gzip':
            gz = flask.request.get_data()
            zb = io.BytesIO(gz)
            zf = gzip.GzipFile(fileobj=zb)
            clear = zf.read()
            flask.request._cached_data = clear

    def logging_after_exception(self, e):
        import traceback
        try:
            end = datetime.datetime.now()
            exec_ms = (end - self.req_start).total_seconds() * 100
            logging.error(traceback.format_exc())
            logging.info('Done', extra={'kwargs': dict(ExecMs=exec_ms, RespCode=500)})
        except:
            logging.error(traceback.format_exc())
        finally:
            log_config.logging_extras.pop()
        return werkzeug.exceptions.InternalServerError()

    def logging_before_request(self):
        req = flask.request
        req_id = req.headers.get(rest_config.X_REQUEST_ID) or str(uuid.uuid4())
        user = pimproxy.username()
        end_point = urlparse.urlparse(req.url)
        end_point = '%s://%s/%s' % (end_point.scheme, end_point.netloc, end_point.path)
        user_ip = req.remote_addr
        app_name = urlparse.urlparse(req.script_root).path.split('/')[-1]
        rest_config._set_request_id(req_id)
        self.req_start = datetime.datetime.now()
        log_config.logging_extras.push(dict(ClUser=user, Apptype='microservice', Appname=app_name,
                                            Appcomponent='',
                                            ClHost=user_ip, ReqEnd=end_point, Id=req_id,
                                            Parameters=dict(req.args)))


    def logging_after_request(self, resp):
        try:
            end = datetime.datetime.now()
            exec_ms = (end - self.req_start).total_seconds() * 100

            resp_code = resp.status_code
            logging.info('Done', extra={'kwargs': dict(ExecMs=exec_ms, RespCode=resp_code)})
        except:
            import traceback
            logging.warn(traceback.format_exc())
        finally:
            log_config.logging_extras.pop()
        return resp

    def __health(self):
        return '{"name":"' + self.import_name + '","status":"HEALTHY"}'

    def __swagger(self):
        from flask import request
        import urlparse
        import json
        parsed_root = urlparse.urlparse(request.url_root)
        paths, tags = self.__get_paths()
        return json.dumps(dict(
            swagger="2.0",
            host=parsed_root.netloc,
            basePath=request.script_root,
            schemes=[parsed_root.scheme],
            consumes=['application/json'],
            produces=['application/json'],
            info=dict(title=request.script_root.split('/')[-1], version="1.0"),
            paths=paths,
            tags=tags
        ))

    def __method_descr(self, view_func, method):
        try:
            return getattr(view_func.view_class, method.lower()).__doc__
        except:
            try:
                return view_func.__doc__
            except:
                return ''

    def __get_paths(self):
        op_swagger = {}
        tags = []
        for rule in self.url_map.iter_rules():
            view_func = self.view_functions[rule.endpoint]
            if not hasattr(view_func,'methods'):
                avail_methods = rule.methods or ['GET']
            else:
                avail_methods = view_func.methods
            if not avail_methods:
                continue
            method_swagger = [(m.lower(), dict(responses=dict(default=dict(description='JSON')),
                                               description=self.__method_descr(view_func, m),
                                               tags=[rule.endpoint]))
                              for m in avail_methods]
            method_swagger = dict(method_swagger)
            op_swagger[rule.rule] = method_swagger
            tag = dict(name=rule.endpoint,description=view_func.__doc__)
            tags.append(tag)
        return op_swagger, tags

    # def route(self, rule, **options):
    #     decorator = super(MonkeyFlask, self).route(rule, **options)
    #
    #     def new_decorator(f):
    #         return decorator(logging_decorator(None, f, make_response_conversion=True, app=self))
    #
    #     return new_decorator


class MonkeyApi(flask_restful.Api):
    def __init__(self, app=None, prefix='',
                 default_mediatype='application/json', decorators=None,
                 catch_all_404s=False, serve_challenge_on_401=False,
                 url_part_order='bae', errors=None):
        #decorators = decorators or []
        #decorators.append(functools.partial(logging_decorator, self))
        super(MonkeyApi, self).__init__(app=app, prefix=prefix, default_mediatype=default_mediatype,
                                        decorators=decorators,
                                        catch_all_404s=catch_all_404s,
                                        serve_challenge_on_401=serve_challenge_on_401,
                                        url_part_order=url_part_order, errors=errors)


flask.Flask = MonkeyFlask
flask_restful.Api = MonkeyApi
