from flask import request, abort
from functools import wraps


def username():
    """
        Gets username from header set by Pimco Proxy inside a FLASK request.
    """
    if not request:
        raise Exception("This function can only be used in FLASK request context")

    val = request.headers.get('X-Remote-User')
    return val


def requires_user(*users):
    def wrap(f):
        @wraps(f)
        def authn(*args, **kwargs):
            un = username()
            if '\\' in un:
                un = un.split('\\')[1]
            if un in users:
                return f(*args, **kwargs)
            abort(403)
        return authn
    return wrap
