from core.db.mongo_db import MongoDb
from core.db import sql_query
from core.config import config_api
import datetime
import xlsxwriter
from bson.objectid import ObjectId


def save_marks(eod_date, rp_marks, user):
    assert isinstance(rp_marks, dict)
    db = get_db()

    utcnow = datetime.datetime.utcnow().isoformat()
    eod_date = eod_date.isoformat()

    coll = db.db_collection('runs')
    r = coll.insert_one({'ts_utc': utcnow, 'asof_date': eod_date, 'user': user})

    run_id = r.inserted_id
    coll = db.db_collection('marks')

    try:
        coll.insert_many([{'ssm_id': x[0], 'mark': x[1], 'run_id': run_id} for x in rp_marks.iteritems()])
    except:
        db.db_collection('runs').delete_one({"_id": run_id})
        raise

    return str(run_id)


def create_distribution(run_id, accounts, pms):
    db = get_db()
    result = db.db_collection('distributions').insert_one(
        {'run_id': ObjectId(run_id), 'accounts': accounts, 'pms': pms})
    return result


def get_distribution(distribution_id):
    db = get_db()
    result = db.db_collection('distributions').find_one({'_id': ObjectId(distribution_id)})
    if not result:
        return None, None, None
    else:
        return str(result['run_id']), result['accounts'], result['pms']


def get_marks(eod_date):
    db = get_db()
    prior_run = None

    result = db.db_collection('runs').find({"$or": [{"asof_date": {"$lt": eod_date.isoformat()}}, {"asof_date": eod_date.isoformat()}]}) \
        .sort([('asof_date', -1), ('ts_utc', -1)]).limit(1)
    for r in result:
        prior_run = r
        break

    if not prior_run:
        return {}
    prior_marks = list(db.db_collection('marks').find({'run_id': prior_run['_id']}))
    return dict([(x['ssm_id'], x['mark']) for x in prior_marks])


def get_run_by_id(run_id):
    db = get_db()
    run_id = ObjectId(run_id)
    result = db.db_collection('runs').find_one({'_id': run_id})
    return result

def get_marks_by_id(run_id):
    db = get_db()
    run_id = ObjectId(run_id)
    prior_marks = list(db.db_collection('marks').find({'run_id': run_id}))
    return dict([(x['ssm_id'], x['mark']) for x in prior_marks])


def get_db():
    db = MongoDb('credit_master_rp', config_api.get('MONGO_HOST'))
    return db


def compute_changes(run_id, since_last_eod=True, since_last=False):
    run_id = ObjectId(run_id)
    db = get_db()

    current_run = db.db_collection('runs').find_one({'_id': run_id})
    eod_date = current_run['asof_date']
    if not current_run:
        raise KeyError('Invalid run_id')

    current_marks = list(db.db_collection('marks').find({'run_id': current_run['_id']}))

    prior_run = None
    if since_last:
        result = db.db_collection('runs').find({"$or": [{"asof_date": {"$lt": eod_date}}, {"asof_date": eod_date}]}) \
            .sort([('asof_date', -1), ('ts_utc', -1)]).limit(1)
        for r in result:
            prior_run = r
            break
    if since_last_eod:
        result = db.db_collection('runs').find({"asof_date": {"$lt": eod_date}}) \
            .sort([('asof_date', -1), ('ts_utc', -1)]).limit(1)
        for r in result:
            prior_run = r
            break

    prior_marks = list(db.db_collection('marks').find({'run_id': prior_run['_id']}))

    current_marks = dict([(m['ssm_id'], m['mark']) for m in current_marks])
    prior_marks = dict([(m['ssm_id'], m['mark']) for m in prior_marks])

    return dict([(c[0], c[1]) for c in current_marks if c[1] != prior_marks.get(c[0])])


def get_ssm_xml(ssm_ids):
    ssm_xml = "<c>" + ''.join(['<r><i>%s</i></r>' % i for i in ssm_ids]) + "</c>"
    query = '''
ssm_ids as (
    SELECT /* +materialize */ t.*
    FROM
    (
        select ROWNUM, xmlt.* FROM XMLTABLE('/c/r' PASSING xmltype(:1) COLUMNS ssm_id  varchar(50) PATH './i') xmlt
    ) t
)'''

    return query, ssm_xml

def get_acct_xml(acct_ids):
    acct_ids_xml = "<c>" + ''.join(['<r><a>%s</a></r>' % a for a in acct_ids]) + "</c>"
    query = '''accts as (
    SELECT /* +materialize */ t.*
    FROM
    (
        select ROWNUM, xmlt.* FROM XMLTABLE('/c/r' PASSING xmltype(:1) COLUMNS acct_no  number(38,0) PATH './a') xmlt
    ) t
)'''

    return query, acct_ids_xml

def get_acct_and_ssm_xml(ssm_ids, acct_ids):
    acct_ids_xml = "<c>" + ''.join(['<r><a>%s</a></r>' % a for a in acct_ids]) + "</c>"
    ssm_query, ssm_xml = get_ssm_xml(ssm_ids)
    query = ssm_query + '''
,
accts as (
    SELECT /* +materialize */ t.*
    FROM
    (
        select ROWNUM, xmlt.* FROM XMLTABLE('/c/r' PASSING xmltype(:2) COLUMNS acct_no  number(38,0) PATH './a') xmlt
    ) t
)   '''

    return query, ssm_xml, acct_ids_xml


def get_holdings_data(ssm_ids, acct_ids, pm_id, include_pm2=False):
    id_query,  acct_xml = get_acct_xml(acct_ids)

    query = '''WITH ''' + id_query + '''
SELECT
  /*+ PARALLEL(2) */

  DISTINCT
  ssm_core.ssm_id,
  sm.currency_issue AS "CCY",
  sm.cusip,
  ssm_core.isin,
  (
    CASE
      WHEN LENGTH(sec_issuer.issuer_name) > 30
      THEN SUBSTR(sec_issuer.issuer_name,1,30)
        || '[...]'
      ELSE SEC_ISSUER.ISSUER_NAME
    END)                      AS "Issuer Name",
  RTRIM(SSM_CORE.STREET_DESC) AS "Description",
  sec_industry_ssm.agg_group_desc as "PIMCO Lev 2 Issuer",
  SM.USER_RATING              AS "Rating",
  SSMC.NXT_CALL_DATE          AS "Call Date",
  SEC_UPI.ISSUER_NAME         AS "Ticker",
  sm.maturity_yr              AS "Tenor",
  ssm_core.bum_class_code,
  SSM_CORE.BUM_SUB_CODE,
  SUM(TXL.QUANTITY)                                      AS "par",
  SUM(TXL.QUANTITY      /TXL.PURCHASE_EXCHANGE_RATE)     AS "$qty",
  SUM(TXL.PURCHASE_PRICE*TXL.QUANTITY/100)               AS "MV",
  SUM(TXL.PURCHASE_PRICE*TXL.QUANTITY)/SUM(TXL.QUANTITY) AS "Px Bot",
  MIN(SM.PRICE)                                          AS "Px Now",
  MIN(SM.PRICE) - MIN(SRMH.PRICE)                        AS "price_1w_chng",
  MIN(SRM.OAS)                                           AS "OAS",
  MIN(srm.oas) - MIN(srmh.oas)                           AS "oas_1w_chng",
  srm3.g297 as OAS_ZScore,
  ssmc.switch_catalog,
  ssmc.bank_capital_tier
FROM
pm_own.manager_master manager_master
   inner join   pm_own.port_trader port_trader on port_trader.mgr_no = manager_master.mgr_no
   inner join   pimco_own.txl txl on port_trader.acct_no = txl.acct_no
   inner join   pm_own.sec_master sm on txl.cusip = sm.ssm_id
   inner join  pm_own.sec_industry_ssm sec_industry_ssm on  sec_industry_ssm.ssm_id    = sm.ssm_id
   inner join  pm_own.sec_issuer sec_issuer  on  sec_issuer.issuer_id       = sm.issuer_id
    and sec_industry_ssm.issuer_id = sec_issuer.issuer_id
   inner join  pm_own.sec_issuer sec_upi on  sec_upi.issuer_id          = sec_issuer.ult_parent_issuer_id
   inner join pm_own.sec_switches sec_switches on   sec_switches.ssm_id        = sm.ssm_id
   inner join  taps_own.ssm_core ssm_core on   ssm_core.ssm_id              = sm.ssm_id
    and  txl.cusip                  = ssm_core.cusip
    and sec_issuer.issuer_id       = ssm_core.issuer_id
   inner join  pm_own.sec_risk_measures srm on   srm.ssm_id                 = sm.ssm_id
   inner join  pm_own.sec_risk_measures3 srm3 on   srm3.ssm_id                 = sm.ssm_id
   inner join  pm_own.sec_switches ssw on   txl.cusip                  = ssw.ssm_id
   inner join  taps_own.ssm_common ssmc on  txl.cusip                  = ssmc.ssm_id
   inner join pm_own.pma_sec_attributes_v psav on psav.ssm_id = ssmc.ssm_id
   left  join  pm_own.sec_risk_measures_hist srmh on  sm.ssm_id                  = srmh.ssm_id
    and srmh.asof_date             = to_timestamp (sysdate- 7)
WHERE
  txl.firm_no                = 1
  AND txl.quantity              <>0
  AND manager_master.mgr_no  = :2
  AND port_trader.acct_role     IN ('P1', :3)
  --- AND sec_switches.sw2='S'
AND SEC_INDUSTRY_SSM.HELDBY_PIMCO_SW='Y'
AND nvl(ssm_core.isin,' ') != ' '
and psav.EUROCSTC != 'Bank Loan'
and psav.EUROCSTC not like '%CDS%'
AND txl.acct_no IN (SELECT acct_no FROM accts)
GROUP BY
  ssm_core.ssm_id,
  sm.currency_issue,
sec_industry_ssm.agg_group_desc,
  ssm_core.bum_class_code,
  ssm_core.bum_sub_code,
  sm.cusip,
  ssm_core.isin,
  (
    CASE
      WHEN LENGTH(sec_issuer.issuer_name) > 30
      THEN SUBSTR(sec_issuer.issuer_name,1,30)
        || '[...]'
      ELSE SEC_ISSUER.ISSUER_NAME
    END),
  rtrim(ssm_core.street_desc),
  sec_upi.issuer_name,
  sm.user_rating,
  sm.maturity_yr,
  sec_switches.sw2,
  sec_industry_ssm.group_no,
  sec_industry_ssm.heldby_pimco_sw,
  sec_industry_ssm.ult_parent_group_no,
  ssmc.nxt_call_date,
  srm3.g297,
  ssmc.switch_catalog,
  ssmc.bank_capital_tier
HAVING
  SUM(txl.quantity) <> 0
'''
    from core.config import config_api
    import cx_Oracle

    env = 'prod' if config_api._env() == 'prod' else 'beta'

    def transform_params(cur, params):

        acct_param = cur.var(cx_Oracle.CLOB)
        acct_param.setvalue(0, acct_xml)

        return [acct_param, pm_id, 'P2' if include_pm2 else 'P1']

    res = sql_query.query_as_dicts(query, params=[], conn='oracle', env=env, param_transformer=transform_params)
    ssm_ids = set(ssm_ids)
    return [r for r in res if r['SSM_ID'] in ssm_ids]

#   ORIGINAL QUERY
#
# SELECT
# /*+ PARALLEL(2) */
# DISTINCT sm.currency_issue AS "CCY",
# sm.cusip,
# ssm_core.isin,
# (
#     CASE
# WHEN LENGTH(sec_issuer.issuer_name) > 30
# THEN SUBSTR(sec_issuer.issuer_name,1,30)
#      || '[...]'
# ELSE SEC_ISSUER.ISSUER_NAME
# END)                      AS "Issuer Name",
# RTRIM(SSM_CORE.STREET_DESC) AS "Description",
# sec_industry_ssm.agg_group_desc as "PIMCO Lev 2 Issuer",
# SM.USER_RATING              AS "Rating",
# SSMC.NXT_CALL_DATE          AS "Call Date",
# SEC_UPI.ISSUER_NAME         AS "Ticker",
# sm.maturity_yr              AS "Tenor",
# ssm_core.bum_class_code,
# SSM_CORE.BUM_SUB_CODE,
# SUM(TXL.QUANTITY)                                      AS "par",
# SUM(TXL.QUANTITY      /TXL.PURCHASE_EXCHANGE_RATE)     AS "$qty",
# SUM(TXL.PURCHASE_PRICE*TXL.QUANTITY/100)               AS "MV",
# SUM(TXL.PURCHASE_PRICE*TXL.QUANTITY)/SUM(TXL.QUANTITY) AS "Px Bot",
# MIN(SM.PRICE)                                          AS "Px Now",
# MIN(SM.PRICE) - MIN(SRMH.PRICE)                        AS "price_1w_chng",
# MIN(SRM.OAS)                                           AS "OAS",
# MIN(srm.oas) - MIN(srmh.oas)                           AS "oas_1w_chng",
# srm3.g297 as OAS_ZScore
#
# FROM
# pm_own.manager_master manager_master
# inner join   pm_own.port_trader port_trader on port_trader.mgr_no = manager_master.mgr_no
# inner join   pimco_own.txl txl on port_trader.acct_no = txl.acct_no
# inner join   pm_own.sec_master sm on txl.cusip = sm.ssm_id
# inner join  pm_own.sec_industry_ssm sec_industry_ssm on  sec_industry_ssm.ssm_id    = sm.ssm_id
# inner join  pm_own.sec_issuer sec_issuer  on  sec_issuer.issuer_id       = sm.issuer_id
# and sec_industry_ssm.issuer_id = sec_issuer.issuer_id
# inner join  pm_own.sec_issuer sec_upi on  sec_upi.issuer_id          = sec_issuer.ult_parent_issuer_id
# inner join pm_own.sec_switches sec_switches on   sec_switches.ssm_id        = sm.ssm_id
# inner join  taps_own.ssm_core ssm_core on   ssm_core.ssm_id              = sm.ssm_id
# and  txl.cusip                  = ssm_core.cusip
# and sec_issuer.issuer_id       = ssm_core.issuer_id
# inner join  pm_own.sec_risk_measures srm on   srm.ssm_id                 = sm.ssm_id
# inner join  pm_own.sec_risk_measures3 srm3 on   srm3.ssm_id                 = sm.ssm_id
# inner join  pm_own.sec_switches ssw on   txl.cusip                  = ssw.ssm_id
# inner join  taps_own.ssm_common ssmc on  txl.cusip                  = ssmc.ssm_id
# left  join  pm_own.sec_risk_measures_hist srmh on  sm.ssm_id                  = srmh.ssm_id
# and srmh.asof_date             = to_timestamp (sysdate- 7)
# WHERE
# txl.firm_no                = 1
# AND txl.quantity              <>0
# AND manager_master.user_name  IN ('Devlin')
# AND port_trader.acct_role     IN ('P1', 'P2')
# AND sm.comp_sec_type_code     IN ('CORP','CDSW','PFD','BKL')
# --- AND sec_switches.sw2='S'
# AND SEC_INDUSTRY_SSM.HELDBY_PIMCO_SW='Y'
#
# AND txl.acct_no                    IN
# (
#     SELECT
# acm.acct_no
# FROM
# pimco_own.acm acm
# WHERE
# acm.special_acct_code NOT IN ('X','T','M','L', 'C', 'A')
# AND acm.firm_no              = 1
# )
# AND
# (
#     ssw.credit_structure_sw  IN (48)
# OR ssw.credit_structure_sw IN (42)
# OR ssw.credit_structure_sw IN (10)
# )
# GROUP BY
# sm.currency_issue,
# sec_industry_ssm.agg_group_desc,
# ssm_core.bum_class_code,
# ssm_core.bum_sub_code,
# sm.cusip,
# ssm_core.isin,
# (
#     CASE
# WHEN LENGTH(sec_issuer.issuer_name) > 30
# THEN SUBSTR(sec_issuer.issuer_name,1,30)
#      || '[...]'
# ELSE SEC_ISSUER.ISSUER_NAME
# END),
# rtrim(ssm_core.street_desc),
# sec_upi.issuer_name,
# sm.user_rating,
# sm.maturity_yr,
# sec_switches.sw2,
# sec_industry_ssm.group_no,
# sec_industry_ssm.heldby_pimco_sw,
# sec_industry_ssm.ult_parent_group_no,
# ssmc.nxt_call_date,
# srm3.g297
# HAVING
# SUM(txl.quantity) <> 0
