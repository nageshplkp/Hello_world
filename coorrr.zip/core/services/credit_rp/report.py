# _*_ coding: utf-8

from .marks import get_holdings_data, get_marks_by_id
from .classifiers import classify
import xlsxwriter
import xlsxwriter.worksheet
from collections import OrderedDict
import logging

column_map = OrderedDict([
    (u"CCY", "CCY"),
    (u"Issuer", "Issuer Name"),
    (u"Description", "Description"),
    (u"Industry", "PIMCO Lev 2 Issuer"),
    (u"Rating", "Rating"),
    (u"$Par", "$qty"),
    (u"Price bought", "Px Bot"),
    (u"Price now", "Px Now"),
    (u"∆ Px 1 wk", "price_1w_chng"),
    (u"OAS now", "OAS"),
    (u"OAS Z-Score", "OAS_ZSCORE"),
    # "∆ OAS since last buy": "",
    # "∆ Index since last buy": "",
    # "Last Buy Date": "",
    # "Discretion": ""
]
)


def write_header(wb, ws):
    assert isinstance(wb, xlsxwriter.Workbook)
    assert isinstance(ws, xlsxwriter.worksheet.Worksheet)

    format = wb.add_format()
    format.set_bg_color('#003366')
    format.set_font_color('white')
    format.set_bold()
    format.set_font_size(9)
    format.set_text_wrap()
    format.set_font('Arial')
    format.set_text_v_align('top')
    for i, n in enumerate(column_map.iterkeys()):
        ws.write_string(1, i + 1, n, format)

    ws.set_row(1, 40.5)


def write_data(wb, ws, bonds, marks):
    assert isinstance(wb, xlsxwriter.Workbook)
    assert isinstance(ws, xlsxwriter.worksheet.Worksheet)


    format = wb.add_format()

    format.set_bg_color('#003366')
    format.set_font_color('white')

    format_map = dict([
        (u"CCY", (ws.write_string, "", 5.71)),
        (u"Issuer", (ws.write_string, "", 24.86)),
        (u"Description", (ws.write_string, "", 20.0)),
        (u"Industry", (ws.write_string, "", 7,43)),
        (u"Rating", (ws.write_string, "", 5.43)),
        (u"$Par", (ws.write_number, "#,##0", 8.57)),
        (u"Price bought", (ws.write_number, "#,##0.00", 6.14)),
        (u"Price now", (ws.write_number, "#,##0.00", 5.43)),
        (u"∆ Px 1 wk", (ws.write_number, "[Color10]#,##0.0_);[Color30](#,##0.0)", 4.86)),
        (u"OAS now", (ws.write_number, "+#,##0;-#,##0;-", 5.29)),
        (u"OAS Z-Score", (ws.write_number, "[Color10]#,##0.0_);[Color30](#,##0.0)", 5.57)),
        # "∆ OAS since last buy": "",
        # "∆ Index since last buy": "",
        # "Last Buy Date": "",
        # "Discretion": ""
    ]
    )

    fmt_rich = wb.add_format()
    fmt_rich.set_bg_color('#c00000')
    fmt_cheap = wb.add_format()
    fmt_cheap.set_bg_color('#92d050')
    fmt_fair = wb.add_format()
    fmt_fair.set_bg_color('#00b050')

    for k in format_map.keys():
        fmt = wb.add_format()
        fmt.set_num_format(format_map[k][1])
        fmt.set_font('Arial')
        fmt.set_font_size(8)
        format_map[k] = format_map[k][0], fmt, format_map[k][2]

    for i, bond in enumerate(bonds):
        for j, col in enumerate(column_map.iterkeys()):
            if col in format_map:
                m, f, w = format_map[col]
            else:
                m, f, w = ws.write, None, None

            val = bond[column_map[col]]
            if val is not None:
                m(2+i, 1+j, bond[column_map[col]], f)
            else:
                ws.write_blank(2+i, 1+j,'', f)

            if w is not None:
                ws.set_column(1+j, 1+j, w)

        mark = marks.get(bond['SSM_ID'])
        if mark:
            if mark.lower() == 'fair':
                ws.write_blank(2+i,0, '', fmt_fair)
            elif mark.lower() == 'cheap':
                ws.write_blank(2+i,0, '', fmt_cheap)
            elif mark.lower() == 'rich':
                ws.write_blank(2+i,0, '', fmt_rich)
        ws.set_column(0,0, 2.14)


def produce_report(pm_no, acct_nos, run_id):
    marks = get_marks_by_id(run_id)
    from core.services.people import get_manager_info

    manager_info = get_manager_info(pm_no)
    logging.info('Got manager info')
    manager_info = manager_info['mgrDtos'][0]
    holding_data = get_holdings_data(marks.keys(), acct_nos, pm_no, False)
    logging.info('Got holdings')
    classes = classify(holding_data)
    logging.info('Classified data')
    wb_name = '/var/tmp/%s_%s_report.xlsx' % (manager_info['mgrLastName'], pm_no)
    wb = xlsxwriter.Workbook(wb_name)
    wb_format = wb.add_format()
    wb_format.set_font('Arial')

    for bond_class, bond_data in classes.iteritems():
        logging.info('Writing data %s', bond_class)
        if not bond_data['bonds']:
            continue

        ws = wb.add_worksheet(bond_class)
        ws.set_column(0,255, cell_format=wb_format)

        header_fmt = wb.add_format()
        header_fmt.set_font_color('#003366')
        header_fmt.set_font_size(12)
        header_fmt.set_bold()
        header_fmt.set_font('Arial')
        ws.write(0, 1, "%s: %s" % (manager_info['mgrLastName'], bond_data['title']), header_fmt)
        ws.set_row(0, 26.25)
        write_header(wb, ws)
        logging.info('Wrote header %s', bond_class)
        write_data(wb, ws, bond_data['bonds'], marks)
        logging.info('Wrote data %s', bond_class)

    wb.close()
    logging.info('Wrote workbook')
    return wb_name, manager_info['empDto']['emailAddr'], manager_info['mgrFirstName'] + ' ' + manager_info['mgrLastName']


def send_report(wb, eod_dt, email, dev_email='roman.bystritskiy@pimco.com'):
    from core.common.mail import send_mail
    from core.config import config_api

    env = config_api._env()
    email = email if env == 'prod' else dev_email
    send_mail('TechnologyRefDataService@pimco.com', email, 'Rich/Cheap report for ' + eod_dt.isoformat(),
              'Rich/Cheap report for ' + eod_dt.isoformat(), attachments=[wb])

