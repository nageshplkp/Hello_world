__lt2_cap_tier = {'T2', 'LT2'}
__coco_cap_tier = {'AT1', 'T1', 'CET', 'UT2'}


def __lt2s(bond):
    return bond['BANK_CAPITAL_TIER'] in __lt2_cap_tier and len(bond['SWITCH_CATALOG']) >= 52 \
           and bond['SWITCH_CATALOG'][51] == 'N'


def __covered(bond):
    return len(bond['SWITCH_CATALOG']) >= 76 and bond['SWITCH_CATALOG'][75] == 'Y'


def __cocos(bond):
    return bond['BANK_CAPITAL_TIER'] in __coco_cap_tier or \
           (len(bond['SWITCH_CATALOG']) >= 52 and bond['SWITCH_CATALOG'][51] == 'Y') or \
           (bond['BUM_CLASS_CODE'] == 94 and bond['BUM_SUB_CODE'] == 9270)


__CLASSES = {
    'LT2': {'title': 'SUB FINS', 'func': __lt2s},
    'Cocos': {'title': 'CoCos & AT1s', 'func': __cocos},
    'Covered': {'title': 'COVERED BONDS', 'func': __covered}
}


def classify(bonds):
    r = dict([(k, {'title': v['title'], 'bonds': []}) for k, v in __CLASSES.iteritems()])
    other = {'title': 'Other', 'bonds': []}
    for bond in bonds:
        classified = False
        for k in r.iterkeys():
            if __CLASSES[k]['func'](bond):
                r[k]['bonds'].append(bond)
                classified = True
        if not classified:
            other['bonds'].append(bond)
    r['Other'] = other
    return r
