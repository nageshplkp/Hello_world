'''
    This library works with local BBG terminal install only.

    Installation of the python libs can be downloaded form
    https://bloomberg.bintray.com/BLPAPI-Experimental-Generic/blpapi_python_3.9.0-win-amd64-py2.7.exe
    Sample code: http://stackoverflow.com/questions/19387868/how-do-i-store-data-from-the-bloomberg-api-into-a-pandas-dataframe

    Ensure the system path is setup properly. For example add C:\blp\ServerAPI\APIv3\C++API\v3.8.18.1\bin
    and C:\blp\ServerAPI\APIv3\C++API\v3.8.18.1\lib are added to your path. Adjust for the proper version.
@author anikolaev
'''
import blpapi
import logging
from collections import defaultdict, Mapping
from datetime import datetime, date
from pandas import DataFrame
import bbg_args
import traceback
import numpy as np
import pandas as pd


class EventType:
    TRADE = 'TRADE'
    BID = 'BID'
    ASK = 'ASK'
    BID_BEST = 'BID_BEST'
    ASK_BEST = 'ASK_BEST'
    BEST_BID = 'BEST_BID'
    BEST_ASK = 'BEST_ASK'


class BbgData(object):
    def __init__(self):
        logging.debug("Bloomberg service created.")
        self.refDataStarted = False
        self.mktDataStarted = False
        self.bbgSession = None
        self.connected = False
        self.identity = None
        self._subscription_options = ""

    def connect(self, session_options=None):
        logging.debug("Connecting to Bloomberg locally.")
        if isinstance(session_options, Mapping):
            options = blpapi.SessionOptions()
            for k, v in session_options.iteritems():
                k = k[0].capitalize() + k[1:]
                getattr(options, 'set' + k)(v)
        else:
            options = blpapi.SessionOptions()

        self.bbgSession = blpapi.Session(options=options)

        if not self.bbgSession.start():
            logging.debug("Unable to connect to bloomberg.")
            return
        logging.debug("Bloomberg local service started.")
        self.connected = True

    def _refdata_session(self):
        if not self.connected:
            logging.fatal("No connection to BBG. Did you issue connect() request?");
            return
        if self.refDataStarted:
            return self.refDS
        # Open service to get hist data from
        if not self.bbgSession.openService("//blp/refdata"):
            self.connected = False
            logging.fatal("Unable to open reference data service!")
            return
        # Get the service reference
        self.refDS = self.bbgSession.getService("//blp/refdata")
        self.refDataStarted = True
        return self.refDS

    def _mktdata_session(self):
        if not self.connected:
            logging.fatal("No connection to BBG. Did you issue connect() request?");
            return
        if self.mktDataStarted:
            return self.mktDS
        # Open service to get hist data from
        if not self.bbgSession.openService("//blp/mktdata"):
            self.connected = False
            logging.fatal("Unable to open market data service!")
            return
        self.mktDS = self.bbgSession.getService("//blp/mktdata")
        self.mktDataStarted = True

        print "Starting mktdata"
        return self.mktDS;

    def close(self):
        self.bbgSession.stop()
        self.mktDataStarted = False
        self.refDataStarted = False
        logging.debug("Bloomberg service stopped!")

    def process_reason(self, reason, ticker, fields, processed, outputdata, fieldId=None):
        errDescription = reason.getElement("description").getValue()
        errCategory = reason.getElement("category").getValue()
        errSource = reason.getElement("source").getValue()
        if errCategory == "BAD_SEC":
            logging.warn("Found bad security %s, description: %s " % (ticker, errDescription))
            # all fields are bad. tag as processed.
            processed.add(ticker)
            for field in fields:
                # reset output data to None
                outputdata[field][ticker] = None
        elif errCategory == "BAD_FLD":
            if reason.hasElement("failureDetails"):
                failureDetails = reason.getElement("failureDetails")
                noOfBadFields = 0
                for fDetails in failureDetails.values():
                    noOfBadFields += 1
                    logging.warn("Found bad subscription for %s field: %s" % (ticker, fDetails.getElement("fieldId")))
                if noOfBadFields == len(fields):
                    # all fields are bad. tag as processed.
                    processed.add(ticker)
                for field in fields:
                    # reset output data to None
                    outputdata[field][ticker] = None
            elif not fieldId:
                # set output to none when field not provided.
                if errDescription and 'All fields are bad' in errDescription:
                    processed.add(ticker)
                outputdata[fieldId][ticker] = None
        elif errCategory == "NOT_MONITORABLE":
            processed.add(ticker)
            logging.warn("%s: %s" % (ticker, errDescription))
        elif errCategory == 'NO_AUTH':
            processed.add(ticker)
            logging.warn("%s: %s" % (ticker, errDescription))
        else:
            logging.warn('UNKNOWN Err Category: %s %s %s' % (ticker, errCategory, errDescription))

    def _subscribe(self, subscription_list, **kwargs):
        self.bbgSession.subscribe(subscription_list, identity=self.identity, **kwargs)

    def _send_request(self, request, **kwargs):
        self.bbgSession.sendRequest(request, identity=self.identity, **kwargs)

    def get_market_data(self, ids, fields):
        """
        Retrieve market data
        :param ids:
        :param fields:
        :return:
        """

        self._mktdata_session()
        if not self.mktDataStarted:
            logging.fatal("No market data service found. Did you issue connect()?");
            return []

        ids, fields = bbg_args.scrub(ids, fields)

        # Create request
        subscription_list = blpapi.SubscriptionList()

        # Set tickers
        subscription_id = 0
        resource_dict = []

        # logging.debug("Sending BBG request... %s, %s" % (ids, fields))

        for id in ids:
            cid = blpapi.CorrelationId(subscription_id)
            subscription_list.add(id, fields, self._subscription_options, cid)
            resource_dict.append((subscription_id, id))
            subscription_id += 1

        self._subscribe(subscription_list)

        processed = set()
        try:
            output_data = defaultdict(dict)
            # Process received events
            keep_running = True
            update_count = 0
            while keep_running:
                # We provide timeout to give the chance for Ctrl+C handling:
                ev = self.bbgSession.nextEvent()
                event_type = ev.eventType()

                if event_type in [blpapi.Event.SUBSCRIPTION_DATA, blpapi.Event.SUBSCRIPTION_STATUS]:
                    for m in ev:
                        correlation_id = m.correlationIds()[0].value()
                        matched_tuple = [item for item in resource_dict if item[0] == correlation_id][0]
                        ticker = matched_tuple[1]

                        if event_type == blpapi.Event.SUBSCRIPTION_STATUS:
                            # check for errors
                            if m.hasElement("exceptions"):
                                exc_details = m.getElement("exceptions")
                                for exc_detail in exc_details.values():
                                    if exc_detail.hasElement("fieldId"):
                                        field_id = exc_detail.getElement("fieldId").getValue()
                                    else:
                                        field_id = None
                                    self.process_reason(exc_detail.getElement("reason"), ticker, fields, processed,
                                                        output_data, field_id)

                            elif m.hasElement("reason"):
                                self.process_reason(m.getElement("reason"), ticker, fields, processed, output_data)
                        else:
                            if not ticker in processed:
                                processed.add(ticker)
                            for field in fields:
                                if m.hasElement(field):
                                    output_data[field][ticker] = m.getElement(field).getValue()
                                else:
                                    output_data[field][ticker] = None

                if len(processed) == len(resource_dict):
                    # Response completly received, so we could exit
                    keep_running = False
        finally:
            # unsubscribe from BBG
            self.bbgSession.unsubscribe(subscription_list)
        data = DataFrame(output_data)
        return data

    @staticmethod
    def __as_value(self, ele):
        # http://pydoc.net/Python/tia/0.1.0/tia.bbg.v3api/
        # Return one value or a datasframe of values
        dtype = ele.datatype()
        if dtype in (1, 2, 3, 4, 5, 6, 7, 9, 12):
            # BOOL, CHAR, BYTE, INT32, INT64, FLOAT32, FLOAT64, BYTEARRAY, DECIMAL)
            return ele.getValue()
        elif dtype == 8:  # String
            val = ele.getValue()
            """
            if val:
                # us centric :)
                val = val.encode('ascii', 'replace')
            """
            return str(val)
        elif dtype == 10:  # Date
            v = ele.getValue()
            return datetime(year=v.year, month=v.month, day=v.day) if v else np.nan
        elif dtype == 11:  # Time
            v = ele.getValue()
            return datetime(hour=v.hour, minute=v.minute, second=v.second).time() if v else np.nan
        elif dtype == 13:  # Datetime
            v = ele.getValue()
            return v
        elif dtype == 14:  # Enumeration
            raise NotImplementedError('ENUMERATION data type needs implemented')
        elif dtype == 16:  # Choice
            raise NotImplementedError('CHOICE data type needs implemented')
        elif dtype == 15:  # SEQUENCE
            return BbgData.__get_sequence_value(self, ele)
        else:
            raise NotImplementedError('Unexpected data type %s. Check documentation' % dtype)

    @staticmethod
    def __get_sequence_value(self, node):
        """Convert an element with DataType Sequence to a DataFrame.
        Note this may be a naive implementation as I assume that bulk data is always a table
        """
        assert node.datatype() == 15
        data = defaultdict(list)
        cols = []
        for i in range(node.numValues()):
            row = node.getValue(i)
            if i == 0:  # Get the ordered cols and assume they are constant
                cols = [str(row.getElement(_).name()) for _ in range(row.numElements())]

            for cidx in range(row.numElements()):
                col = row.getElement(cidx)
                data[str(col.name())].append(BbgData.__as_value(self, col))
        return pd.DataFrame(data, columns=cols)

    def get_refdata(self, ids, fields, overrides={}):
        """

        :param ids:
        :param fields:
        :param overrides: override options in dictionary format. all values must be strings
        :return:
        """
        ref_data_session = self._refdata_session()
        if not self.refDataStarted:
            logging.fatal("No reference data service found. Did you issue connect()?");
            return []

        ids, fields = bbg_args.scrub(ids, fields)

        # Create request
        request = ref_data_session.createRequest("ReferenceDataRequest")
        # Set tickers
        for id in ids:
            request.getElement("securities").appendValue(id)
        # Set fields / mnemonics
        for field in fields:
            request.getElement("fields").appendValue(field)

        if len(overrides) > 0:
            override_list = request.getElement("overrides")
            for key, value in overrides.iteritems():
                override = override_list.appendElement()
                override.setElement("fieldId", key)
                override.setElement("value", value)

        logging.debug("Sending BBG request... {0}".format(str(request)))

        self._send_request(request)

        output_data = defaultdict(dict)
        resultAsMap = False
        # Process received events
        keep_running = True
        while keep_running:
            # We provide timeout to give the chance for Ctrl+C handling:
            ev = self.bbgSession.nextEvent(500)
            event_type = ev.eventType()

            if event_type in [blpapi.Event.SESSION_STATUS, blpapi.Event.SERVICE_STATUS]:
                continue
            if event_type in [blpapi.Event.RESPONSE, blpapi.Event.PARTIAL_RESPONSE]:
                for msg in ev:
                    # print
                    for sec_data in msg.getElement("securityData").values():
                        ticker = sec_data.getElement('security').getValue()
                        field_data = sec_data.getElement('fieldData')
                        for field in fields:
                            if field_data.hasElement(field):
                                value = BbgData.__as_value(self, field_data.getElement(field))
                                if isinstance(value, DataFrame):
                                    resultAsMap = True
                                output_data[field][ticker] = value;

            if event_type == blpapi.Event.RESPONSE:
                # Response completly received, so we could exit
                keep_running = False
        if resultAsMap:
            return output_data
        else:
            data = DataFrame(output_data)
        return data

    def get_intraday(self, id, startDateTime, endDateTime=None, interval_min='10', event_type=EventType.TRADE,
                     returnEids=None, returnRelativeDate=None,
                     adjustmentNormal=None, adjustmentAbnormal=None, adjustmentSplit=None,
                     adjustmentFollowDPDF=None, gapFillInitialBar=None):
        ref_data_session = self._refdata_session()
        if not self.refDataStarted:
            logging.fatal("No reference data service found. Did you issue connect()?")
            return []

        correlation_id = blpapi.CorrelationId(1, blpapi.CorrelationId.INT_TYPE)

        # Create request
        request = ref_data_session.createRequest("IntradayBarRequest")
        # Set tickers
        request.set('security', id)
        request.set('eventType', event_type)
        request.set('interval', interval_min)
        request.set("startDateTime", startDateTime) # bbg_args.date_to_str(startDateTime, isofmt=False, with_time=True))
        if endDateTime:
            request.set("endDateTime", endDateTime) #bbg_args.date_to_str(endDateTime, isofmt=False, with_time=True))

        if returnEids:
            request.set("returnEids", returnEids)
        if returnRelativeDate:
            request.set("returnRelativeDate", returnRelativeDate)
        if adjustmentNormal:
            request.set("adjustmentNormal", adjustmentNormal)
        if adjustmentAbnormal:
            request.set("adjustmentAbnormal", adjustmentAbnormal)
        if adjustmentSplit:
            request.set("adjustmentSplit", adjustmentSplit)
        if adjustmentFollowDPDF:
            request.set("adjustmentFollowDPDF", adjustmentFollowDPDF)
        if gapFillInitialBar:
            request.set("gapFillInitialBar", gapFillInitialBar)

        logging.debug("Sending BBG request... %s" % id)
        self._send_request(request)

        output_data = defaultdict(list)
        # Process received events
        keep_running = True
        while (keep_running):
            # We provide timeout to give the chance for Ctrl+C handling:
            ev = self.bbgSession.nextEvent(500)
            event_type = ev.eventType()

            if event_type in [blpapi.Event.SESSION_STATUS, blpapi.Event.SERVICE_STATUS]:
                continue
            if event_type in [blpapi.Event.RESPONSE, blpapi.Event.PARTIAL_RESPONSE]:
                for msg in ev:
                    tick_data = msg.getElement('barData').getElement('barTickData')
                    for i in range(tick_data.numValues()):
                        bar = tick_data.getValue(i)
                        output_data['time'].append(bar.getElement('time').getValue())
                        output_data['open'].append(bar.getElement('open').getValue())
                        output_data['high'].append(bar.getElement('high').getValue())
                        output_data['low'].append(bar.getElement('low').getValue())
                        output_data['close'].append(bar.getElement('close').getValue())
                        output_data['volume'].append(bar.getElement('volume').getValue())
                        output_data['num_events'].append(bar.getElement('numEvents').getValue())

            if event_type == blpapi.Event.RESPONSE:
                # Response completly received, so we could exit
                keep_running = False
        data = DataFrame(data=output_data)
        return data

    def get_historical(self, ids, fields, startDate, endDate=None, periodicity=None, periodicityAdjustment=None,
                       currency=None, overrideOption=None, pricingOption=None, nonTradingDayFillOption=None,
                       nonTradingDayFillMethod=None, maxDataPoints=None, returnEids=None, returnRelativeDate=None,
                       adjustmentNormal=None, adjustmentAbnormal=None, adjustmentSplit=None,
                       adjustmentFollowDPDF=None):
        """
        Check https://data.bloomberglp.com/labs/sites/2/2014/07/blpapi-developers-guide-2.54.pdf for full reference.
        
        :param ids:
        :param fields:
        :param startDate:
        :param endDate:
        :param periodicity: DAILY|WEEKLY|MONTHLY|QUARTERLY|SEMI_ANNUALLY|YEARLY ...
        :param periodicityAdjustment: ACTUAL|CALENDAR|FISCAL
        :param currency: 3 letter ISO code
        :param overrideOption: OVERRIDE_OPTION_CLOSE - use closing price | OVERRIDE_OPTION_GPA - use average price 
        :param pricingOption: PRICING_OPTION_PRICE - set quote to price | PRICING_OPTION_YIELD - set quote to yield
        :param nonTradingDayFillOption: NON_TRADING_WEEKDAYS | ALL_CALENDAR_DAYS | ACTIVE_DAYS_ONLY
        :param nonTradingDayFillMethod: PREVIOUS_VALUE | NIL_VALUE
        :param maxDataPoints
        :param returnEids: true|false
        :param returnRelativeDate: true|false. Setting this to true will populate fieldData with an extra element containing a name 
                and value for the relative date. For example RELATIVE_DATE = 2002 Q2
        :param adjustmentNormal: true|false. Adjust historical pricing to reflect: Regular Cash, Interim, 1st Interim,
                2nd Interim, 3rd Interim, 4th Interim, 5th Interim, Income, Estimated, Partnership Distribution, Final,
                Interest on Capital, Distribution, Prorated.
        :param adjustmentAbnormal: true|false. Adjust historical pricing to reflect: Regular Cash, Interim, 1st Interim,
                2nd Interim, 3rd Interim, 4th Interim, 5th Interim, Income, Estimated, Partnership Distribution, Final,
                Interest on Capital, Distribution, Prorated.
        :param adjustmentSplit: True | False Adjust historical pricing and/or volume to reflect: Spin-Offs, Stock 
                Splits/Consolidations, Stock Dividend/Bonus, Rights Offerings/Entitlement.
        :param adjustmentFollowDPDF: True | False | Setting to true will follow the DPDF<GO> BLOOMBERG PROFESSIONAL service function.
                True is the default setting for this option.
        
        :return:
        """

        ref_data_session = self._refdata_session()
        if not self.refDataStarted:
            logging.fatal("No reference data service found. Did you issue connect()?")
            return []

        correlation_id = blpapi.CorrelationId(1, blpapi.CorrelationId.INT_TYPE)

        ids, fields = bbg_args.scrub(ids, fields)

        # Create request
        request = ref_data_session.createRequest("HistoricalDataRequest")
        # Set tickers
        for id in ids:
            request.getElement("securities").appendValue(id)
        # Set fields / mnemonics
        for field in fields:
            request.getElement("fields").appendValue(field)

        request.set("startDate", bbg_args.date_to_str(startDate, isofmt=False))
        if endDate:
            request.set("endDate", bbg_args.date_to_str(endDate, isofmt=False))
        # Override periodicity
        if periodicity:
            request.set("periodicitySelection", periodicity)
        # Override adjustment
        if periodicityAdjustment:
            request.set("periodicityAdjustment", periodicityAdjustment)
        # Override currency
        if currency:
            request.set("currency", currency)
        # Override option
        if overrideOption:
            request.set("overrideOption", overrideOption)
        if pricingOption:
            request.set("pricingOption", pricingOption)
        if nonTradingDayFillOption:
            request.set("nonTradingDayFillOption", nonTradingDayFillOption)
        if nonTradingDayFillMethod:
            request.set("nonTradingDayFillMethod", nonTradingDayFillMethod)
        if maxDataPoints:
            request.set("maxDataPoints", maxDataPoints)
        if returnEids:
            request.set("returnEids", returnEids)
        if returnRelativeDate:
            request.set("returnRelativeDate", returnRelativeDate)
        if adjustmentNormal:
            request.set("adjustmentNormal", adjustmentNormal)
        if adjustmentAbnormal:
            request.set("adjustmentAbnormal", adjustmentAbnormal)
        if adjustmentSplit:
            request.set("adjustmentSplit", adjustmentSplit)
        if adjustmentFollowDPDF:
            request.set("adjustmentFollowDPDF", adjustmentFollowDPDF)

        logging.debug("Sending BBG request... %s, %s" % (ids, fields))
        self._send_request(request)

        output_data = defaultdict(dict)
        # Process received events
        keep_running = True
        while (keep_running):
            # We provide timeout to give the chance for Ctrl+C handling:
            ev = self.bbgSession.nextEvent(500)
            event_type = ev.eventType()

            if event_type in [blpapi.Event.SESSION_STATUS, blpapi.Event.SERVICE_STATUS]:
                continue
            if event_type in [blpapi.Event.RESPONSE, blpapi.Event.PARTIAL_RESPONSE]:
                for msg in ev:
                    ticker = msg.getElement('securityData').getElement('security').getValue()
                    field_data = msg.getElement('securityData').getElement('fieldData')
                    for i in range(field_data.numValues()):
                        record = field_data.getValue(i)
                        for j in range(1, field_data.getValue(i).numElements()):
                            output_data[(ticker + " " + fields[j - 1])][
                                record.getElement(0).getValue()] = record.getElement(j).getValue()

            if event_type == blpapi.Event.RESPONSE:
                # Response completly received, so we could exit
                keep_running = False
        data = DataFrame(output_data)
        return data

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, type_, value, tb):
        try:
            self.close()
        except:
            logging.warn(traceback.format_exc())


if __name__ == "__main__":
    import os

    os.environ['PATH'] = r'E:\dev\pypimco_infra_anaconda\integration\anaconda\blpapi_cpp_3.8.18.1\bin;' + os.environ[
        'PATH']

    d = BbgData()
    d.connect()
    print d.get_refdata("SPX Index", "SP_VOL_SURF_MID",
                        dict(REFERENCE_DATE="20160505", VOL_SURF_EXPIRY_OVR="20180119", VOL_SURF_STRIKE_OVR=2300))
