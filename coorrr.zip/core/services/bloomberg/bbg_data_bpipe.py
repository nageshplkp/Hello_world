import blpapi
import logging
import itertools
from . import bbg_data
from core import config_api
from collections import defaultdict
from datetime import datetime, date
from pandas import DataFrame
from blpapi.event import MessageIterator
from blpapi.event import Message

import time

'''

Here is the IP for the appliance (Bloomberg managed appliance) :
===================================================================
69.184.252.4   (deployed at Irvine site)
69.184.252.20 (deployed at Secaucus, NJ).
'''

def first(iterable):
    for x in iterable:
        return x
    return None


class BbgData(bbg_data.BbgData):
    def __init__(self, *args, **kwargs):
        self.msgScrapeService = None
        super(BbgData, self).__init__(*args, **kwargs)
        self._subscription_options = None
        self._token = None

    def wait_for_response(self, queue, processor, response_type=blpapi.Event.RESPONSE):
        while True:
            evt = queue.nextEvent(500)
            if evt.eventType() == response_type:

                is_error = False
                for msg in evt:
                    if msg.messageType() == 'AuthorizationFailure':
                        logging.fatal('Failed authorization: %d %s %s',
                                      msg.getElement('reason').getElement('code').getValue(),
                                      msg.getElement('reason').getElement('message').getValue(),
                                      msg.getElement('reason').getElement('category').getValue())
                        is_error = True
                    elif msg.hasElement('reason'):
                        logging.fatal('Failed request: %s', msg)
                        is_error = True
                processor(evt, is_error)
                break
            else:
                # print evt.eventType()
                pass

    def __open_connection(self, warn=False):
        logging.info("Connecting to Bloomberg @ %s:%d." % (self.bpipe_server, self.bpipe_port))
        session_options = blpapi.SessionOptions()
        session_options.setServerHost(self.bpipe_server)
        session_options.setServerPort(self.bpipe_port)

        # session_options.setClientMode(blpapi.SessionOptions.SAPI)

        auth_options = 'AuthenticationMode=APPLICATION_ONLY;ApplicationAuthenticationType=APPNAME_AND_KEY;ApplicationName=PIMCOMSG1:PIMCO_BPIPE'
        # auth_options = 'AuthenticationType=OS_LOGON'
        session_options.setAuthenticationOptions(auth_options)

        self.bbgSession = blpapi.Session(session_options)

        if not self.bbgSession.start():
            fn = logging.warn if warn else logging.error
            fn("Unable to connect to bloomberg @ %s:%d." % (self.bpipe_server, self.bpipe_port))
            return False

        return True

    def connect(self, auth_against='//blp/apiauth'):
        self.bpipe_server = config_api.get('bpipe_server')
        self.bpipe_port = int(config_api.get('bpipe_port'))

        if not self.__open_connection(warn=True):
            self.bpipe_server = config_api.get('bpipe_backup_server')
            self.bpipe_port = config_api.get('bpipe_backup_port')

            if self.bpipe_server and self.bpipe_port:
                self.bpipe_port = int(self.bpipe_port)
                logging.warn('Failing over to backup BPipe')
                if not self.__open_connection():
                    return
            else:
                return

        q = blpapi.EventQueue()

        self.bbgSession.generateToken(eventQueue=q)
        self.wait_for_response(q, lambda x, e: setattr(self, '_token', x), response_type=blpapi.Event.TOKEN_STATUS)

        if first(self._token).messageType() == "TokenGenerationFailure":
            logging.fatal('Failed to generate token')
            return
        else:
            self._token = first(self._token).getElement('token').getValue()

        logging.info("Bloomberg service connected to %s:%d started." % (self.bpipe_server, self.bpipe_port))

        if not self.bbgSession.openService('//blp/apiauth'):
            logging.fatal('Could not open authorization service')

        auth_svc = self.bbgSession.getService('//blp/apiauth')
        req = auth_svc.createAuthorizationRequest()
        req.set("token", self._token)
        ident = self.bbgSession.createIdentity()

        self.bbgSession.sendAuthorizationRequest(req, ident, eventQueue=q)
        self.wait_for_response(q, lambda x, e: setattr(self, 'identity', ident))

        if not self.identity:
            logging.fatal('Could not obtain bbg identity')
        else:
            logging.info("Obtained bbg identity: %s", self.identity)
        self.connected = True

    def subscribe_msg_feed(self, processor=None):
        if not self.connected:
            raise Exception('Session is not connected')

        if not self.msgScrapeService:
            if not self.bbgSession.openService('//blp/msgscrape'):
                raise Exception("Could not create msgscrape service")

            self.msgScrapeService = self.bbgSession.getService('//blp/msgscrape')

        correlation_id_value = int(time.time())
        correlation_id = blpapi.CorrelationId(correlation_id_value)
        logging.info('Correlation id: %d', correlation_id_value)
        sub_list = blpapi.SubscriptionList()
        sub_list.add('//blp/msgscrape/ticker/MSGSCRP MSG1 Curncy', fields=['MSG_ID_RT'], correlationId=correlation_id)

        hb_correlation_id_value = 1
        hb_correlation_id = blpapi.CorrelationId(hb_correlation_id_value)
        sub_list.add('//blp/msgscrape/ticker/MSGHBEAT Index', fields=['EVENT_TIME'], correlationId=hb_correlation_id)

        self._subscribe(sub_list)
        keep_on_trucking = True
        try:
            sub_event_types = [blpapi.Event.SUBSCRIPTION_DATA, blpapi.Event.SUBSCRIPTION_STATUS]
            while keep_on_trucking:
                event = self.bbgSession.nextEvent(60000)
                event_type = event.eventType()

                if event_type == blpapi.Event.TIMEOUT:
                    raise RuntimeError('BLP Subscription has timed out. Will try to reconnect.')

                if event_type not in sub_event_types:
                    continue

                for message in event:
                    if message.correlationIds()[0].value() != correlation_id_value:
                        continue

                    if event_type == blpapi.Event.SUBSCRIPTION_STATUS:
                        if message.hasElement('reason'):
                            reason = message.getElement('reason')
                            logging.fatal('Subscription failed: %d %s %s',
                                          reason.getElement('errorCode').getValue(),
                                          reason.getElement('category').getValue(),
                                          reason.getElement('description').getValue())
                            raise Exception('Subscription terminated')

                    if message.messageType() == 'MarketDataEvents':
                        event_dict = dict(
                            (str(x.name()), x.getValue()) for x in message.asElement().elements() if not x.isNull())
                        if processor(event_dict):
                            keep_on_trucking = False
                            break
        finally:
            self.bbgSession.unsubscribe(sub_list)

    def get_historical_msg_feed(self, range_start, range_end):

        if not self.connected:
            raise Exception('Session is not connected')

        if not self.msgScrapeService:
            if not self.bbgSession.openService('//blp/msgscrape'):
                raise Exception("Could not create msgscrape service")

            self.msgScrapeService = self.bbgSession.getService('//blp/msgscrape')

        # Create request
        request = self.msgScrapeService.createRequest("replay")
        start_holder = request.getElement('start').setChoice('serial')
        start_holder.setValue(range_start)
        end_holder = request.getElement('end').setChoice('serial')
        end_holder.setValue(range_end)
        request.getElement('filter').setValue('ALL')

        self._send_request(request)

        # Process received events
        keep_on_trucking = True

        messages = []

        while keep_on_trucking:
            # We provide timeout to give the chance for Ctrl+C handling:
            ev = self.bbgSession.nextEvent(500)
            event_type = ev.eventType()

            if event_type in [blpapi.Event.SESSION_STATUS, blpapi.Event.SERVICE_STATUS]:
                for msg in ev:
                    if msg.messageType() == 'SessionTerminated':
                        logging.warn('Session terminated without receiving full response')
                        keep_on_trucking = False
            if event_type in [blpapi.Event.RESPONSE, blpapi.Event.PARTIAL_RESPONSE]:
                for message in ev:
                    if message.hasElement('marketDatas'):
                        for el in message.getElement('marketDatas').values():
                            if el.hasElement('MSG1_SEQUENCE_NUMBER_RT'):
                                event_dict = dict(
                                    (str(x.name()), x.getValue()) for x in el.elements() if not x.isNull()
                                )
                                messages.append(event_dict)
            if event_type == blpapi.Event.RESPONSE:
                # Response completly received, so we could exit
                keep_on_trucking = False

        return messages
