from datetime import date, datetime
from core.common.util import unique
from decimal import Decimal


def scrub(ids, fields):
    if isinstance(ids, (basestring, tuple, set)):
        if isinstance(ids, basestring):
            ids = ids.split(',')
        else:
            ids = list(ids)

    ids = unique(ids)

    if isinstance(fields, (basestring, tuple, set)):
        if isinstance(fields, basestring):
            fields = fields.split(',')
        else:
            fields = list(fields)

    ids = [str(id) for id in ids]
    fields = [str(field) for field in fields]

    return ids, fields


def date_to_str(dt, isofmt=True, with_time=False):
    if isinstance(dt, (date, datetime)):
        if isofmt:
            return dt.strftime("%Y-%m-%d" + (' %H:%M:%S' if with_time else ''))

        return dt.strftime("%y%m%d") + (' %H:%M:%S' if with_time else '')

    return dt


def as_rest_args(bbg_ids, fields, overrides):
    bbg_ids_str = bbg_ids
    if isinstance(bbg_ids, list):
        bbg_ids_str = ','.join(bbg_ids)
    else:
        bbg_ids = bbg_ids_str.split(',')
    bbg_ids_str = bbg_ids_str.upper()
    bbg_ids = [_.upper() for _ in bbg_ids]
    fields_str = fields
    if isinstance(fields, list):
        fields_str = ','.join(fields)
    else:
        fields = fields_str.split(',')
    overrides_list = []
    for k, v in overrides.iteritems():
        field = k.strip().replace('%', '%25')
        value = v.strip().replace('%', '%25')
        overrides_list.append('%s:%s' % (field, value))
    bbg_ids_str = bbg_ids_str.replace('%', '%25')
    fields_str = fields_str.replace('%', '%25')
    return bbg_ids, bbg_ids_str, fields, fields_str, ','.join(overrides_list)


class TypesMapConverters(object):
    _FLOAT = staticmethod(lambda x: float(x) if x is not None else x)
    _DECIMAL = staticmethod(lambda x: Decimal(x) if x is not None else x)
    _INT = staticmethod(lambda x: int(x) if x is not None else x)
    _LONG = staticmethod(lambda x: long(x) if x is not None else x)

