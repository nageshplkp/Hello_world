import requests, logging, getpass, datetime
from pprint import pprint, pformat
from core.config import config_api
import pandas as pd
from pandas import DataFrame
import numpy
import bbg_args, six

"""
 Uses bloomberg sapi to query data. Calls a JAVA server which wraps the actual sapi call
"""

LOGGER_NAME = 'bbg_sapi'
bbg_logger = logging.getLogger(LOGGER_NAME)


def headers():
    username = 'pimco\%s' % getpass.getuser()
    return {'Accept': 'application/json', 'Content-Type': 'application/json', 'X-REMOTE-USER': username}


def query(bbg_ids, fields, as_data_frame=True, return_raw=False, overrides={}):
    """    
    non-historical query using bloomberg server API.  desktop api not required
    :param bbg_ids: list or comma seperated bbg ids. ex: ["SPX Index", "PTTRX US Equity", "XS0468534580 Corp"] 
    :param fields:  list or comma seperated bbg fields as per FLDS command.  ex: LAST_PRICE
    :param as_data_frame: return as pandas dataframe or json
    :param return_raw: return raw format from bbg service
    :param overrides: dictionary of bbg overrides.  fld key and value.  ex: {'CALC_INTERVAL': '12M'}
    :return:   
    """

    bbg_ids, bbg_ids_str, fields, fields_str, overrides_str = bbg_args.as_rest_args(bbg_ids, fields, overrides)
    url = '%s?security=%s&_fields=%s' % (config_api.get('bbg_url'), bbg_ids_str, fields_str)
    if overrides:
        url += '&_overrides=%s' % (overrides_str)

    bbg_logger.info('USER:%s bbg sapi call for id=%s  fields=%s overrides=%s' % \
                    (getpass.getuser(), bbg_ids_str, fields_str, overrides_str))

    r = requests.get(url, headers=headers())
    data = process_error(r)
    return transform_results(data, as_data_frame, bbg_ids, fields, return_raw, time_series=False)


def query_history(bbg_ids, fields, start, end, periodicity='MONTHLY', as_data_frame=True, return_raw=False,
                  overrides={}, quote_type=None, use_dates=False, types_map=None):
    """    
     Non-historical query using bloomberg server API.  desktop api not required
    :param bbg_ids: list or comma seperated bbg ids. ex: ["SPX Index", "PTTRX US Equity", "XS0468534580 Corp"] 
    :param fields:  list or comma seperated bbg fields as per FLDS command.  ex: LAST_PRICE
    :param start: start date for historical query 
    :param end:  end date for historical query
    :param periodicity: MONTHLY, YEARLY, DAILY periods to pull
    :param as_data_frame: return as pandas dataframe or json
    :param return_raw: return raw format from bbg service
    :param overrides: dictionary of bbg overrides.  fld key and value.  ex: {'CALC_INTERVAL': '12M'}
    :param use_dates: If True, the "Date" column on the returned dataframe will be pandas datetime
    :param types_map: A dictionary of column names and converters. Use this to get the data based on your needs
                      For example: types_map = {'PX_LAST': float} - this will convert this column to float values
                      You can pass your own converter function as well. types_map={'PX_LAST': lambda x: Decimal(x)}
                      There are a few pre-defined converter functions in bbg_args.TypesMapConverters. For example:
                      types_map = {'PX_LAST': bbg_args.TypesMapConverters._FLOAT}
    :return: 
    """

    bbg_ids, bbg_ids_str, fields, fields_str, overrides_str = bbg_args.as_rest_args(bbg_ids, fields, overrides)
    start = bbg_args.date_to_str(start)
    end = bbg_args.date_to_str(end)
    url = '%s?security=%s&_fields=%s&_startdate=%s&_enddate=%s&_periodicity=%s' % \
          (config_api.get('bbg_url'), bbg_ids_str, fields_str, start, end, periodicity)
    if overrides:
        url += '&_overrides=%s' % (overrides_str)

    if quote_type:
        quote_type = quote_type.upper()
        if len(quote_type) > 1:
            quote_type = quote_type[:1]

        url += '&quote_type=' + quote_type

    bbg_logger.info('USER:%s bbg sapi call for id=%s  fields=%s start=%s end=%s periodicity=%s overrides=%s quote_type=%s' % \
                    (getpass.getuser(), bbg_ids_str, fields_str, start, end, periodicity, overrides_str, quote_type))

    bbg_logger.info(url)

    r = requests.get(url, headers=headers())
    data = process_error(r)
    return transform_results(data, as_data_frame, bbg_ids, fields, return_raw, use_dates=use_dates, types_map=types_map)


def process_error(r):
    data_text = r.text
    try:
        import json
        data = json.loads(data_text)
        error_fields = ['category', 'subcategory', 'sequenceNumber', 'source']
        data_dict = {}
        for k, v in data.iteritems():
            if not all((x in v) for x in error_fields):
                data_dict[k] = v
            else:
                logging.warn('Service returned errors: %s: %s', k, v)
        data = data_dict
    except:
        data = {}
        logging.error('error with bbg download, %s  %s' % (r.status_code, pformat(data_text)))
    return data


def convert_to_types(data, time_series=True, types_map=None):

    def convert_fields_dict(d):
        if isinstance(d, dict):
            for col, converter in six.iteritems(types_map):
                d[col] = converter(d.get(col))

    if data and types_map:
        if time_series:
            for _, dates_dict in six.iteritems(data):
                for _, fields_dict in six.iteritems(dates_dict):
                    convert_fields_dict(fields_dict)
        else:
            for _, fields_dict in six.iteritems(data):
                convert_fields_dict(fields_dict)

    return data


def transform_results(data, as_data_frame, bbg_ids, fields, return_raw, time_series=True,
                      use_dates=False, types_map=None):
    data = convert_to_types(data, time_series=time_series, types_map=types_map)
    if as_data_frame:
        try:
            return as_dataframe(data, bbg_ids, fields, time_series, use_dates=use_dates)
        except Exception, ex:
            from pprint import pformat
            from core.common import util
            bbg_logger.error(util.error_as_str(ex))
            bbg_logger.error(pformat(data))
            raise ex

    if data and len(data.values()) > 1 or return_raw:
        return data

    return data.values()[0] if data and data.values() else None


def as_dataframe(data, bbg_ids, fields, time_series, use_dates=False):
    if data:
        if not isinstance(bbg_ids, list):
            bbg_ids = [bbg_ids]

        if not isinstance(fields, list):
            fields = [fields]

        if time_series:
            cols = ['Ticker', 'Date'] + fields
        else:
            cols = ['Ticker'] + fields

        rows = []
        for bbgId in bbg_ids:
            row_as_dict = data.get(bbgId)
            if not row_as_dict:
                continue

            if time_series:
                dates = sorted([dt for dt in row_as_dict.keys() if dt != 'security'])
                for dt in dates:
                    row = [bbgId]
                    row = row + [dt] + [row_as_dict.get(dt).get(field) for field in fields]
                    rows.append(row)
            else:
                row = [bbgId]
                for field in fields:
                    row.append(row_as_dict.get(field))
                rows.append(row)

        if rows:
            rows = numpy.array(rows)
        df = DataFrame(rows, columns=cols)
        if time_series and use_dates:
            df['Date'] = pd.to_datetime(df['Date'], format='%Y-%m-%d')
        return df
