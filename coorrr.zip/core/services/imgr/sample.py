from core.services.imgr.imgr_fields import COMMON_FIELDS, MORTGAGE_FIELDS, VAR_SWAP_FIELDS, LCDS_FIELDS, LOAN_FIELDS, \
    CDS_FIELDS
from core.services.imgr.imgr_fields import MUNI_FIELDS, BOND_FIELDS, ALL_FIELDS
from core.services.imgr.imgr_fields import VAR_SWAP_NAME, LCDS_NAME, LOAN_NAME, CDS_NAME, MUNI_NAME, BOND_NAME, \
    MORTGAGE_NAME
from core.services.imgr.imgr_service import get_all_quotes, get_latest_quotes, subscribe
from amps.amps_query import AmpsField, QueryLiteral, EMPTY_QUERY
from amps.amps_client import Client

if __name__ == "__main__":

    import sys
    import logging
    import argparse

    all_asset_types = [VAR_SWAP_NAME, LCDS_NAME, LOAN_NAME, CDS_NAME, MUNI_NAME, BOND_NAME, MORTGAGE_NAME]
    parser = argparse.ArgumentParser('Python IMGR Sample')
    parser.add_argument('--live', action='store_true', help='Print live message feed')
    parser.add_argument('--latest', action='store_true', help='Query latest msgs')
    parser.add_argument('--raw', action='store_true', help='Query raw masg feed (possible to see obsolete msgs')
    parser.add_argument('--time_start', required=False, default=None,
                        help='Start time bound in ISO Format, utc time zone, e.g. 2016-07-01T12:39:11.393666')
    parser.add_argument('--time_end', required=False, default=None,
                        help='End time bound in ISO Format, utc time zone, e.g. 2016-07-01T12:39:11.393666')
    parser.add_argument('--asset', required=False, action='append', default=[], nargs='*', help='Assets to see',
                        choices=all_asset_types)
    parser.add_argument('--query', required=False, type=str, default='', help='Additional amps query')
    parser.add_argument('--top-n', dest='top_n', required=False, type=int, default=10,
                        help='Max records to return per asset type for raw/latest')
    parser.add_argument('--run-for', dest='run_for', required=False, type=int, default=15,
                        help='Number of seconds to run for')
    args = parser.parse_args()
    if not (args.live or args.latest or args.raw):
        print >> sys.stderr, "Must specify either live, latest or raw"
        parser.print_help()
        sys.exit(-1)

    logging.getLogger('').handler = []
    logging.basicConfig(stream=sys.stderr)

    if args.live:
        import time
        import pprint
        def printer(msg):
            pprint.pprint(msg)

        query = EMPTY_QUERY
        for ag in args.asset:
            for a in ag:
                query |= AmpsField('ASSET_CLASS_RT') == a

        query |= QueryLiteral(args.query) if args.query else EMPTY_QUERY

        with Client('imgr_service_client', '') as client:
            sub_id = subscribe(client,printer,args.raw,query)
            time.sleep(args.run_for)
            client.unsubscribe(sub_id)
    else:
        f_ = get_all_quotes if args.raw else get_latest_quotes
        logging.info('Ten latest quotes per asset class')
        for ag in args.asset:
            for a in ag:
                df = get_all_quotes(top_n=args.top_n, as_df=True,
                                    timestamp_end=args.time_end,
                                    timestamp_start=args.time_start,
                                    amps_query=(AmpsField('ASSET_CLASS_RT') == a) & (
                                        QueryLiteral(args.query) if args.query else EMPTY_QUERY))
                logging.info(a)
                logging.info('\n' + df.to_string())
