from .imgr_fields import COMMON_FIELDS, MORTGAGE_FIELDS, VAR_SWAP_FIELDS, LCDS_FIELDS, LOAN_FIELDS, CDS_FIELDS
from .imgr_fields import MUNI_FIELDS, BOND_FIELDS, ALL_FIELDS
from .imgr_fields import VAR_SWAP_NAME, LCDS_NAME, LOAN_NAME, CDS_NAME, MUNI_NAME, BOND_NAME, MORTGAGE_NAME
from .imgr_service import get_all_quotes, get_latest_quotes

if __name__ == "__main__":

    import sys
    import logging

    logging.getLogger('').handler = []
    logging.basicConfig(stream=sys.stderr)

    if len(sys.argv) > 1 and sys.argv[1] == 'live':
        pass
    else:
        all_asset_types = [VAR_SWAP_NAME, LCDS_NAME, LOAN_NAME, CDS_NAME, MUNI_NAME, BOND_NAME, MORTGAGE_NAME]
        logging.info('Ten latest quotes per asset class')
        for a in all_asset_types:
            df = get_all_quotes(top_n=10, ASSET_CLASS_RT=a, as_df=True)
            logging.info('a')
            logging.info(df.to_string())
