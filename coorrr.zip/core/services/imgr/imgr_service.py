from amps.amps_client import Client
from amps.amps_query import QueryElement, AmpsField, QueryLiteral, EMPTY_QUERY

from .imgr_fields import COMMON_FIELDS, MORTGAGE_FIELDS, VAR_SWAP_FIELDS, LCDS_FIELDS, LOAN_FIELDS, CDS_FIELDS
from .imgr_fields import MUNI_FIELDS, BOND_FIELDS, ALL_FIELDS
from datetime import date as date_, datetime as datetime_
import pandas as pd
import json
import functools


def __to_df(result, as_df):
    result = [json.loads(x) for x in result]
    if not as_df:
        return result

    all_fields = set()
    map(lambda x: map(lambda kk: all_fields.add(kk[0]), x.iteritems()), result)
    series = dict((x, [v.get(x) for v in result]) for x in all_fields)
    return pd.DataFrame(data=series)


def __on_message(wrapped, msg):
    try:
        msg = json.loads(msg.get_data())
        wrapped(msg)
    except:
        pass


def subscribe(amps_client, on_message, raw=False, amps_query=EMPTY_QUERY):
    """
    Subscribes to MSG1 feed

    :param amps_client: Amps client to use
    :param on_message: Message processor function. This function will receive a single paramter which is a dict.
            This function will be called on background thread.
    :param raw: If true, will subscribe to raw feed. Otherwise, will only receive latest updated.
            In Raw, updates may arrive out of order. In latest, it's guaranteed to be inorder.
    :param amps_query: amps.amps_query.QueryElement query. See example for how to use
    """

    assert isinstance(amps_client, Client)

    topic = '/bloomberg/imgr' if raw else '/bloomberg/imgr/latest'
    return amps_client.subscribe(amps_query.amps_repr() if amps_query is not EMPTY_QUERY else '',
                          functools.partial(__on_message, on_message), topic=topic)


def get_all_quotes(timestamp_start=None, timestamp_end=None, amps_client=None, top_n=-1, as_df=False,
                   amps_query=EMPTY_QUERY):

    """
    Gets all quotes from the raw feed. Due to how bloomberg implements it's feed quotes might not arrive in order.
    Also, for the raw feed, you might receive multiple quotes for the same broker/asset_class/instrument
    :param timestamp_start: Optional time range start
    :param timestamp_end: Optional time range end
    :param amps_client: Amps client to use. if not provided, a new one will be created.
    :param top_n: Number of records to return, ordered by timestamp descending
    :param as_df: If true, result will be returned as dataframe and not a list of dicts.
    :param amps_query: QueryElement object representing AMPS query. See sample.py for examples on how to use.
    :return: DataFrame or a list of Dicts
    """
    if timestamp_start and isinstance(timestamp_start, (datetime_, date_)):
        timestamp_start = timestamp_start.isoformat()
    if timestamp_end and isinstance(timestamp_end, (datetime_, date_)):
        timestamp_end = timestamp_end.isoformat()

    filter_ = EMPTY_QUERY
    if timestamp_start:
        filter_ &= AmpsField('TIMESTAMP') >= timestamp_start
    if timestamp_end:
        filter_ &= AmpsField('TIMESTAMP') <= timestamp_end

    if amps_query:
        if not isinstance(amps_query, QueryElement):
            amps_query = QueryLiteral(amps_query)
        filter_ = filter_ & amps_query

    filter_ = filter_.amps_repr()
    if amps_client:
        return __to_df(amps_client.sow(filter_, top_n=top_n, topic='/bloomberg/imgr', order_by='/INTERNAL_ID DESC'),
                       as_df)
    else:
        with Client('imgr_service_client', '/bloomberg/imgr') as amps_client:
            return __to_df(amps_client.sow(filter_, top_n=top_n, order_by='/INTERNAL_ID DESC'), as_df)


def get_latest_quotes(timestamp_start=None, timestamp_end=None, amps_client=None, top_n=-1, as_df=False,
                      amps_query=None):
    """
    Gets messages from the "latest" msg1 feed. only latest message for given asset_class/broker/bb_id will be returned.
    :param timestamp_start: Optional time range start
    :param timestamp_end: Optional time range end
    :param amps_client: Amps client to use. if not provided, a new one will be created.
    :param top_n: Number of records to return, ordered by timestamp descending
    :param as_df: If true, result will be returned as dataframe and not a list of dicts.
    :param amps_query: QueryElement object representing AMPS query. See sample.py for examples on how to use.
    :return: DataFrame or a list of Dicts
    """
    if timestamp_start and isinstance(timestamp_start, (datetime_, date_)):
        timestamp_start = timestamp_start.isoformat()
    if timestamp_end and isinstance(timestamp_end, (datetime_, date_)):
        timestamp_end = timestamp_end.isoformat()

    filter_ = EMPTY_QUERY
    if timestamp_start:
        filter_ &= (AmpsField('TIMESTAMP') >= timestamp_start)
    if timestamp_end:
        filter_ &= (AmpsField('TIMESTAMP') <= timestamp_end)

    if amps_query:
        if not isinstance(amps_query, QueryElement):
            amps_query = QueryLiteral(amps_query)
        filter_ = filter_ & amps_query

    filter_ = filter_.amps_repr()

    if amps_client:
        return __to_df(
            amps_client.sow(filter_, top_n=top_n, topic='/bloomberg/imgr/latest', order_by='/INTERNAL_ID DESC'), as_df)
    else:
        with Client('imgr_service_client', '/bloomberg/imgr/latest') as amps_client:
            return __to_df(amps_client.sow(filter_, top_n=top_n, order_by='/INTERNAL_ID DESC'), as_df)
