from core.rest import client
import logging
import json
import urlparse
from distutils.version import LooseVersion

logger = logging.getLogger('artifactory')


class Artifactory(object):
    def __init__(self, url):
        self.__url = url

    @property
    def url(self):
        return self.__url

    def get_storage_data(self, path, jsonify=True):

        url = urlparse.urljoin(self.__url, '/artifactory/api/storage/')
        if path.startswith('/'):
            path = path[1:]
        url = urlparse.urljoin(url, path)

        r = client.get(url, use_kerberos=False, parse_content_as=('json' if jsonify else 'binary'))
        if r is dict:
            return r
        elif jsonify:
            return json.loads(r)

        return r

    def get_data(self, path, jsonify=True):

        url = urlparse.urljoin(self.__url, '/artifactory/')
        if path.startswith('/'):
            path = path[1:]
        url = urlparse.urljoin(url, path)

        r = client.get(url, use_kerberos=False, parse_content_as=('json' if jsonify else 'binary'))
        if r is dict:
            return r
        elif jsonify:
            return json.loads(r)

        return r


class Repository(object):
    def __init__(self, artifactory, repo_name):
        self.__artifactory = artifactory
        self.__repo_name = repo_name

    @property
    def artifactory(self):
        return self.__artifactory

    @property
    def repo_name(self):
        return self.__repo_name

    def list_versions(self, artifact):
        data = self.artifactory.get_storage_data(self.repo_name + '/' + artifact)
        children = data['children']

        result = []
        for c in children:
            if c['folder']:
                uri = c['uri']
                if uri.startswith('/'):
                    uri = uri[1:]

                version = LooseVersion(uri)
                if version.version:
                    result.append((uri, version))
        return result

    def latest_version(self, artifact):
        versions = self.list_versions(artifact)
        if not versions:
            raise Exception('Artifcat is not versioned')

        versions = sorted(versions, lambda x, y: cmp(y[1], x[1]))
        return versions[0]

    def list_artifact_files(self, artifact, version_tuple):
        version = version_tuple[0] if isinstance(version_tuple, tuple) else version_tuple
        data = self.artifactory.get_storage_data(self.repo_name + '/' + artifact + '/' + version)
        children = data['children']

        result = []
        for c in children:
            if not c['folder']:
                uri = c['uri']
                if uri.startswith('/'):
                    uri = uri[1:]

                result.append(uri)
        return result

    def download_artifact_file(self, artifact, version_tuple, file, file_name_or_io=None):
        if file_name_or_io is None:
            file_name_or_io = file

        version = version_tuple[0] if isinstance(version_tuple, tuple) else version_tuple
        io = self.artifactory.get_data(self.repo_name + '/' + artifact + '/'
                                       + version + '/' + file, jsonify=False)
        close_on_exit = False
        if isinstance(file_name_or_io, basestring):
            file_name_or_io = open(file_name_or_io, "w+")
            file_name_or_io.__enter__()
            close_on_exit = True
        try:
            file_name_or_io.write(io.read())
        finally:
            if close_on_exit:
                import sys
                file_name_or_io.__exit__(*sys.exc_info())

    def download_latest_version(self, artifact, file, file_name_or_io=None):
        version = self.latest_version(artifact)

        file = file.format(version=str(version[1]), version_file=str(version[0]))

        self.download_artifact_file(artifact, version, file, file_name_or_io=file_name_or_io)
