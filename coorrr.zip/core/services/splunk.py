import splunklib.client as spc
import splunklib.results as spr
from core.common.util import explicit_param_checker

import logging
import functools

SECOND_MOD = 's'
MINUTE_MOD = 'm'
HOUR_MOD = 'h'
DAY_MOD = 'd'
WEEK_MOD = 'w'
MONTH_MOD = 'mon'
QUARTER_MOD = 'q'
YEAR_MOD = 'y'

OFFSET_NOW = 'now'


def relative_offset(offset, unit=HOUR_MOD):
    return '%d%s' % (offset, unit)


class SplunkService(object):
    def __init__(self, username, password, host='prodpmsplunk1.pimco.imswest.sscims.com', port=8089):
        self.__service = spc.connect(host=host, port=port, username=username, password=password)
        self.logger = logging.getLogger('SplunkService [%s:%d][%s]' % (host, port, username))

    def app_names(self):
        return [a.name for a in self.__service.apps]

    def applications(self):
        d = dict((x.name, x) for x in self.__service.apps)
        for k, v in d.iteritems():
            assert isinstance(v, spc.Application)
            v.post()

    def group_by(self, datamodel, dataset, aggs, group_by_fields=None, filters=None, auto_cancel=60, auto_finalize_ec=0,
                 auto_pause=0, earliest_time=relative_offset(-1, HOUR_MOD), latest_time=OFFSET_NOW, rf=None, app=None):
        query = " | PIVOT %s %s %s %s %s" % (
            datamodel,
            dataset,
            ' '.join(aggs),
            ' '.join('SPLITROW %s' % x for x in (group_by_fields or [])),
            ' '.join('FILTER %s' % x for x in (filters or []))
        )

        params = dict()
        self.process_params(params, app, auto_cancel, auto_finalize_ec, auto_pause, earliest_time, latest_time, rf)
        exj = self.__service.jobs.export(query, **params)
        reader = spr.ResultsReader(exj)

        self.logger.info("Searching for: %s", query)

        i = 1
        for r in reader:
            if isinstance(r, dict):
                yield r
                if i % 1000 == 0:
                    self.logger.info("Retrieved %d results", i)
                i += 1
            else:
                self.logger.info(r)

    def search(self, index, query=None, auto_cancel=60, auto_finalize_ec=0, auto_pause=0
               , earliest_time=relative_offset(-1, HOUR_MOD), latest_time=OFFSET_NOW, rf=None, app=None):
        params = dict()

        query = "search index=" + index + ((" | " + query) if query else '')

        self.process_params(params, app, auto_cancel, auto_finalize_ec, auto_pause, earliest_time, latest_time, rf)

        exj = self.__service.jobs.export(query, **params)
        reader = spr.ResultsReader(exj)

        self.logger.info("Searching for: %s %s", query, ' '.join('%s=%s' % (k, v) for k, v in params.iteritems()))

        i = 1
        for r in reader:
            if isinstance(r, dict):
                yield r
                if i % 1000 == 0:
                    self.logger.info("Retrieved %d results", i)
                i += 1
            else:
                self.logger.info(r)

    def process_params(self, params, app, auto_cancel, auto_finalize_ec, auto_pause, earliest_time, latest_time, rf):
        if app is not None:
            if isinstance(app, spc.Application):
                params['app'] = app['name']
            else:
                params['app'] = app
        params['auto_cancel'] = auto_cancel
        params['auto_finalize_ec'] = auto_finalize_ec
        params['auto_pause'] = auto_pause
        if earliest_time:
            params['earliest_time'] = earliest_time
        if latest_time:
            params['latest_time'] = latest_time
        if rf:
            params['rf'] = rf


def connect(username, password, host='prodpmsplunk1.pimco.imswest.sscims.com', port=8089):
    return SplunkService(username, password, host, port)

def pretty_print(logs):
    import json
    from pprint import pprint as pp
    logs = [x for x in logs]

    for log in logs:
        time = log.get('_time')
        msg = log.get('_raw')
        doc = json.loads(msg)
        doc['time'] = time
        pp(doc)