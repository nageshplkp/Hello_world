__author__ = 'ashah'

CONN_MAP =  {
                'dev' :  {'url':'http://ptp-dev/entitlements/v1', 'kerberos': True},
                'beta' : {'url':'http://ptp-beta/entitlements/v1','kerberos': True},
                'prod' : {'url':'http://ptp-prod/entitlements/v1', 'kerberos': True}
            }

