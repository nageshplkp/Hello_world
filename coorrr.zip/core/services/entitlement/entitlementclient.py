"""
Entitlement Client wrapper
@author ashah
"""

import logging
import getpass
import urllib
import json
from core.rest import client
from core.services.entitlement.decorate import CONN_MAP

# Policy Decision
def get_policy_decision(env='prod', appName=None, userName=None, resource=None, resourceType=None, action=None):
    """
    Retrieve Policy Decision
    :param appName: app name for which policy is to be verified eg: PIMCO Bulletin Board
    :param userName:  user id for which policy is to be verified eg: svc_sifaka_mb_dev
    :param resource: eg: /Front Office Tech
    :param resourceType: eg: CHANNEL
    :param action: eg: Write
    :return:
    """
    try:

        if appName is None:
            logging.exception("App Name not defined")
            return 'DENY'
        else:
            appName = urllib.quote(appName)

        if userName is None:
            logging.exception("User Name not defined")
            return 'DENY'

        if resource is None:
            logging.exception("Resource not defined")
            return 'DENY'

        if resourceType is None:
            logging.exception("ResourceType not defined")
            return 'DENY'

        if action is None:
            logging.exception("Action is not defined")
            return 'DENY'

        urlParams = {}
        urlParams['user'] = userName
        urlParams['resource'] = resource
        urlParams['resourceType'] = resourceType
        urlParams['action'] = action

        url = CONN_MAP[env]['url'] + '/app/' + appName + '/policydecision'
        logging.info('Url: ' + url)
        response = client.get(url=url, params=urlParams, use_kerberos=CONN_MAP[env]['kerberos'])

        logging.debug(response)
        logging.debug('')
        logging.debug('Output:')
        logging.debug(json.dumps(response, indent=4, separators=(',', ': ')))
        logging.info(response['grantPath'])
        return response['grant']
    except Exception, e:
        logging.exception(e)
    return "DENY";

# Find Roles
def get_roles(env='dev', appName=None):
    """
    Retrieve Roles for a given application
    :param env:
    :param appName: app name for which policy is to be verified eg: PIMCO Bulletin Board
    :return:
    """
    try:

        if appName is None:
            logging.exception("App Name not defined")
        else:
            appName = urllib.quote(appName)

        url = CONN_MAP[env]['url'] + '/app/' + appName
        logging.info('Url: ' + url)
        response = client.get(url=url, use_kerberos=CONN_MAP[env]['kerberos'])

        logging.debug(response)
        logging.debug('')
        logging.debug('Output:')
        logging.debug(json.dumps(response, indent=4, separators=(',', ': ')))

    except Exception, e:
        logging.exception(e)

    return