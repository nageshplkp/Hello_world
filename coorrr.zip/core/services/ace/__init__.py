# -*- coding: utf-8 -*-
"""
Created on Thu Feb 09 08:20:03 2017

@author: shgupta
"""


from core.services.ace.ae_protocol.com.pimco.ae import protocol as AE
from core.services.ace.ae_protocol import SpecificDatumReader as _AEReader
from core.config import config_api
from core.rest import client as rest_client
import os

__all__ = ['AE', 'get_security_values']


def get_security_values():
    """

    :return: SecurityResponse
    :rtype: AE.SecurityResponse
    """
    server = config_api.get('ace.server')
    url = '/pretrade/0500/SecurityValues'

    req = AE.SecurityRequest()
    # .... fill something out here

    return rest_client.post(server + url,req, use_kerberos=False, request_serializer=rest_client.AVRO_SERIALIZER,
                            parse_content_as='avro', avro_reader_cls=_AEReader)

def make_ae_reader(reader_schema):
    def factory(*args, **kwargs):
        kwargs['readers_schema'] = kwargs.get('readers_schema') or  reader_schema
        kwargs['writers_schema'] = kwargs.get('writers_schema') or reader_schema

        return _AEReader(**kwargs)

    return factory


def get_ssa_spend_amount(location, accounts, security, side, price, broker, settleDate, showRules, cellCustomDataList):
    requests = AE.Requests()
    requestList = []

    request = AE.Request()
    request.requestId = 1001
    request.header = AE.Header()
    request.header.login = os.environ.get('USERNAME') #System.Environment.UserName
    print request.header.login
    request.header.type = AE.FuncType.AMOUNT

    request.autoInquiry = False
    request.filterRule = False
    request.linkType = AE.LinkType.NONE



    valueRequestList = []
    valueRequest = AE.ValueRequest()
    valueRequest.requestId = 100000
    valueRequest.fieldId = 1204
    valueRequest.accounts = accounts
    valueRequest.side = side
    valueRequest.security = security
    print valueRequest.security
    valueRequest.broker = broker
    valueRequest.showRules = showRules
    valueRequest.settleDate = str(settleDate)

    parameters = []
    parameter = AE.RequestParameter()
    parameter.name = "price"
    parameter.operation = "="
    parameter.value = "100"

    parameters.append(parameter)

    valueRequest.cells = cellCustomDataList
    valueRequest.parameters = parameters
    valueRequestList.append(valueRequest)
    request.valueRequests = valueRequestList

    requestList.append(request)
    requests.requests = requestList

    #server = "http://betaace:9995/pretrade/0500/ComplianceRoom"

    url = "http://" + location + "/pretrade/0500/ComplianceRoom;"



    # responses = AE.Responses()


    responses = rest_client.post(url, requests, use_kerberos=False, request_serializer=rest_client.AVRO_SERIALIZER,
                                 parse_content_as='avro', avro_reader_cls=make_ae_reader(AE.Responses.RECORD_SCHEMA))

    return responses

if __name__ == '__main__':
    import datetime
    print get_ssa_spend_amount('betaace:9995', [90], '3EZ700004', 'Buy',None,None , datetime.date(2017,2,14),None ,[])

