

from .schema_classes import SchemaClasses, PROTOCOL as my_proto, get_schema_type
from avro.io import DatumReader
from avrogen import logical

class SpecificDatumReader(logical.LogicalDatumReader):
    SCHEMA_TYPES = {
        "com.pimco.ae.protocol.FieldTrees": SchemaClasses.com.pimco.ae.protocol.FieldTreesClass,
        "com.pimco.ae.protocol.SecurityRequest": SchemaClasses.com.pimco.ae.protocol.SecurityRequestClass,
        "com.pimco.ae.protocol.Field": SchemaClasses.com.pimco.ae.protocol.FieldClass,
        "com.pimco.ae.protocol.Header": SchemaClasses.com.pimco.ae.protocol.HeaderClass,
        "com.pimco.ae.protocol.AccountCell": SchemaClasses.com.pimco.ae.protocol.AccountCellClass,
        "com.pimco.ae.protocol.Responses": SchemaClasses.com.pimco.ae.protocol.ResponsesClass,
        "com.pimco.ae.protocol.Requests": SchemaClasses.com.pimco.ae.protocol.RequestsClass,
        "com.pimco.ae.protocol.LinkType": SchemaClasses.com.pimco.ae.protocol.LinkTypeClass,
        "com.pimco.ae.protocol.FieldTree": SchemaClasses.com.pimco.ae.protocol.FieldTreeClass,
        "com.pimco.ae.protocol.AccountCellError": SchemaClasses.com.pimco.ae.protocol.AccountCellErrorClass,
        "com.pimco.ae.protocol.FieldQuery": SchemaClasses.com.pimco.ae.protocol.FieldQueryClass,
        "com.pimco.ae.protocol.Notify": SchemaClasses.com.pimco.ae.protocol.NotifyClass,
        "com.pimco.ae.protocol.Request": SchemaClasses.com.pimco.ae.protocol.RequestClass,
        "com.pimco.ae.protocol.SecurityCell": SchemaClasses.com.pimco.ae.protocol.SecurityCellClass,
        "com.pimco.ae.protocol.BlockView": SchemaClasses.com.pimco.ae.protocol.BlockViewClass,
        "com.pimco.ae.protocol.Fields": SchemaClasses.com.pimco.ae.protocol.FieldsClass,
        "com.pimco.ae.protocol.ValueResponse": SchemaClasses.com.pimco.ae.protocol.ValueResponseClass,
        "com.pimco.ae.protocol.Pair": SchemaClasses.com.pimco.ae.protocol.PairClass,
        "com.pimco.ae.protocol.Response": SchemaClasses.com.pimco.ae.protocol.ResponseClass,
        "com.pimco.ae.protocol.AccountValueError": SchemaClasses.com.pimco.ae.protocol.AccountValueErrorClass,
        "com.pimco.ae.protocol.SecurityResponse": SchemaClasses.com.pimco.ae.protocol.SecurityResponseClass,
        "com.pimco.ae.protocol.CacheType": SchemaClasses.com.pimco.ae.protocol.CacheTypeClass,
        "com.pimco.ae.protocol.Properties": SchemaClasses.com.pimco.ae.protocol.PropertiesClass,
        "com.pimco.ae.protocol.InquiryRequest": SchemaClasses.com.pimco.ae.protocol.InquiryRequestClass,
        "com.pimco.ae.protocol.FieldParameter": SchemaClasses.com.pimco.ae.protocol.FieldParameterClass,
        "com.pimco.ae.protocol.RuleRequest": SchemaClasses.com.pimco.ae.protocol.RuleRequestClass,
        "com.pimco.ae.protocol.FieldType": SchemaClasses.com.pimco.ae.protocol.FieldTypeClass,
        "com.pimco.ae.protocol.CallRequest": SchemaClasses.com.pimco.ae.protocol.CallRequestClass,
        "com.pimco.ae.protocol.ErrorResponse": SchemaClasses.com.pimco.ae.protocol.ErrorResponseClass,
        "com.pimco.ae.protocol.ValueRequest": SchemaClasses.com.pimco.ae.protocol.ValueRequestClass,
        "com.pimco.ae.protocol.RequestParameter": SchemaClasses.com.pimco.ae.protocol.RequestParameterClass,
        "com.pimco.ae.protocol.AceRule": SchemaClasses.com.pimco.ae.protocol.AceRuleClass,
        "com.pimco.ae.protocol.SecurityCellError": SchemaClasses.com.pimco.ae.protocol.SecurityCellErrorClass,
        "com.pimco.ae.protocol.FuncType": SchemaClasses.com.pimco.ae.protocol.FuncTypeClass,
        "com.pimco.ae.protocol.Cell": SchemaClasses.com.pimco.ae.protocol.CellClass,
        "com.pimco.ae.protocol.CellCustomData": SchemaClasses.com.pimco.ae.protocol.CellCustomDataClass,
        "com.pimco.ae.protocol.AccountRules": SchemaClasses.com.pimco.ae.protocol.AccountRulesClass,
    }
    def __init__(self, readers_schema=None, **kwargs):
        writers_schema = kwargs.pop("writers_schema", readers_schema)
        writers_schema = kwargs.pop("writer_schema", writers_schema)
        super(SpecificDatumReader, self).__init__(writers_schema, readers_schema, **kwargs)
    def read_record(self, writers_schema, readers_schema, decoder):
        
        result = super(SpecificDatumReader, self).read_record(writers_schema, readers_schema, decoder)
        
        if readers_schema.fullname in SpecificDatumReader.SCHEMA_TYPES:
            result = SpecificDatumReader.SCHEMA_TYPES[readers_schema.fullname](result)
        
        return result