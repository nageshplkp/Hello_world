import json
import os.path
import decimal
import datetime
import six
import core.io.pimavro
from avrogen.dict_wrapper import DictWrapper
from avrogen import avrojson
from avrogen import logical
from avro import schema as avro_schema
if six.PY3:    
	from avro.schema import SchemaFromJSONData as make_avsc_object
    
else:
    from avro.schema import make_avsc_object
    


def __read_file(file_name):
    with open(file_name, "r") as f:
        return f.read()

from avro import protocol as avro_protocol
import core.io.pimavro

from avrogen import logical

def __get_protocol(file_name):
    proto = avro_protocol.Parse(__read_file(file_name)) if six.PY3 else avro_protocol.parse(__read_file(file_name))
    return proto

PROTOCOL = __get_protocol(os.path.join(os.path.dirname(__file__), "protocol.avpr"))
__SCHEMAS = {}
def get_schema_type(fullname):
    return __SCHEMAS.get(fullname)
for rec in PROTOCOL.types:
    __SCHEMAS[rec.fullname] = rec
for resp in (six.itervalues(PROTOCOL.messages) if six.PY2 else PROTOCOL.messages):
    if isinstance(resp.response, (avro_schema.RecordSchema, avro_schema.EnumSchema)):
        __SCHEMAS[resp.response.fullname] = resp.response
PROTOCOL_MESSAGES = {m.name.lstrip("."):m for m in (six.itervalues(PROTOCOL.messages) if six.PY2 else PROTOCOL.messages)}



class SchemaClasses(object):
    
    
    pass
    class com(object):
        class pimco(object):
            class ae(object):
                class protocol(object):
                    
                    class FuncTypeClass(object):
                        
                        """
                        INQUIRY
                        """
                        
                        AMOUNT = "AMOUNT"
                        CHECK = "CHECK"
                        BROKER = "BROKER"
                        LINKTRADE = "LINKTRADE"
                        FIELD = "FIELD"
                        RULES = "RULES"
                        INQUIRY = "INQUIRY"
                        
                    class HeaderClass(DictWrapper):
                        
                        """
                        Header
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.Header")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.HeaderClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.type = SchemaClasses.com.pimco.ae.protocol.FuncTypeClass.AMOUNT
                                self.login = SchemaClasses.com.pimco.ae.protocol.HeaderClass.RECORD_SCHEMA.fields[1].default
                                self.token = SchemaClasses.com.pimco.ae.protocol.HeaderClass.RECORD_SCHEMA.fields[2].default
                        
                        
                        @property
                        def type(self):
                            """
                            :rtype: SchemaClasses.com.pimco.ae.protocol.FuncTypeClass
                            """
                            return self._inner_dict.get('type')
                        
                        @type.setter
                        def type(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.ae.protocol.FuncTypeClass value:
                            #"""
                            self._inner_dict['type'] = value
                        
                        
                        @property
                        def login(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('login')
                        
                        @login.setter
                        def login(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['login'] = value
                        
                        
                        @property
                        def token(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('token')
                        
                        @token.setter
                        def token(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['token'] = value
                        
                        
                    class AccountValueErrorClass(object):
                        
                        """
                        Other
                        """
                        
                        NoError = "NoError"
                        InvalidField = "InvalidField"
                        InvalidAccount = "InvalidAccount"
                        InvalidMaturity = "InvalidMaturity"
                        InvalidCoupon = "InvalidCoupon"
                        MissingParameter = "MissingParameter"
                        SecurityNotUnique = "SecurityNotUnique"
                        SecurityRequired = "SecurityRequired"
                        UnknownParameter = "UnknownParameter"
                        UnknownRegion = "UnknownRegion"
                        UnknownSecurity = "UnknownSecurity"
                        UnknownSecurityIdType = "UnknownSecurityIdType"
                        UnknownSecurityOption = "UnknownSecurityOption"
                        AccountDisallowed = "AccountDisallowed"
                        AccountNotLive = "AccountNotLive"
                        MissingBroker = "MissingBroker"
                        Timeout = "Timeout"
                        FieldDisabled = "FieldDisabled"
                        InvalidParameter = "InvalidParameter"
                        SecurityInactive = "SecurityInactive"
                        SecurityInAudit = "SecurityInAudit"
                        SecurityInReview = "SecurityInReview"
                        SecurityIsCollateral = "SecurityIsCollateral"
                        SecurityIssuerNotSetup = "SecurityIssuerNotSetup"
                        SecurityNotInScope = "SecurityNotInScope"
                        SecurityNotSetup = "SecurityNotSetup"
                        SecurityReconExcluded = "SecurityReconExcluded"
                        AceRequestsDisabled = "AceRequestsDisabled"
                        Other = "Other"
                        
                    class LinkTypeClass(object):
                        
                        """
                        basket
                        """
                        
                        NONE = "NONE"
                        LINKED = "LINKED"
                        BASKET = "BASKET"
                        
                    class RequestParameterClass(DictWrapper):
                        
                        """
                        RequestParameter
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.RequestParameter")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.RequestParameterClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.name = str()
                                self.value = str()
                                self.operation = str()
                        
                        
                        @property
                        def name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('name')
                        
                        @name.setter
                        def name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['name'] = value
                        
                        
                        @property
                        def value(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('value')
                        
                        @value.setter
                        def value(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['value'] = value
                        
                        
                        @property
                        def operation(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('operation')
                        
                        @operation.setter
                        def operation(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['operation'] = value
                        
                        
                    class SecurityRequestClass(DictWrapper):
                        
                        """
                        SecurityRequest
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.SecurityRequest")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.SecurityRequestClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.requestID = long()
                                self.fieldID = long()
                                self.securities = list()
                                self.parameters = list()
                        
                        
                        @property
                        def requestID(self):
                            """
                            :rtype: long
                            """
                            return self._inner_dict.get('requestID')
                        
                        @requestID.setter
                        def requestID(self, value):
                            #"""
                            #:param long value:
                            #"""
                            self._inner_dict['requestID'] = value
                        
                        
                        @property
                        def fieldID(self):
                            """
                            :rtype: long
                            """
                            return self._inner_dict.get('fieldID')
                        
                        @fieldID.setter
                        def fieldID(self, value):
                            #"""
                            #:param long value:
                            #"""
                            self._inner_dict['fieldID'] = value
                        
                        
                        @property
                        def securities(self):
                            """
                            :rtype: list[str]
                            """
                            return self._inner_dict.get('securities')
                        
                        @securities.setter
                        def securities(self, value):
                            #"""
                            #:param list[str] value:
                            #"""
                            self._inner_dict['securities'] = value
                        
                        
                        @property
                        def parameters(self):
                            """
                            :rtype: list[str]
                            """
                            return self._inner_dict.get('parameters')
                        
                        @parameters.setter
                        def parameters(self, value):
                            #"""
                            #:param list[str] value:
                            #"""
                            self._inner_dict['parameters'] = value
                        
                        
                    class CellClass(DictWrapper):
                        
                        """
                        Cell
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.Cell")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.CellClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.value = SchemaClasses.com.pimco.ae.protocol.CellClass.RECORD_SCHEMA.fields[0].default
                                self.stringValue = SchemaClasses.com.pimco.ae.protocol.CellClass.RECORD_SCHEMA.fields[1].default
                                self.info = SchemaClasses.com.pimco.ae.protocol.CellClass.RECORD_SCHEMA.fields[2].default
                                self.flag = SchemaClasses.com.pimco.ae.protocol.CellClass.RECORD_SCHEMA.fields[3].default
                        
                        
                        @property
                        def value(self):
                            """
                            :rtype: float
                            """
                            return self._inner_dict.get('value')
                        
                        @value.setter
                        def value(self, value):
                            #"""
                            #:param float value:
                            #"""
                            self._inner_dict['value'] = value
                        
                        
                        @property
                        def stringValue(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('stringValue')
                        
                        @stringValue.setter
                        def stringValue(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['stringValue'] = value
                        
                        
                        @property
                        def info(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('info')
                        
                        @info.setter
                        def info(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['info'] = value
                        
                        
                        @property
                        def flag(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('flag')
                        
                        @flag.setter
                        def flag(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['flag'] = value
                        
                        
                    class SecurityCellClass(DictWrapper):
                        
                        """
                        SecurityCell
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.SecurityCell")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.SecurityCellClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.security = SchemaClasses.com.pimco.ae.protocol.SecurityCellClass.RECORD_SCHEMA.fields[0].default
                                self.cell = SchemaClasses.com.pimco.ae.protocol.CellClass()
                        
                        
                        @property
                        def security(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('security')
                        
                        @security.setter
                        def security(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['security'] = value
                        
                        
                        @property
                        def cell(self):
                            """
                            :rtype: SchemaClasses.com.pimco.ae.protocol.CellClass
                            """
                            return self._inner_dict.get('cell')
                        
                        @cell.setter
                        def cell(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.ae.protocol.CellClass value:
                            #"""
                            self._inner_dict['cell'] = value
                        
                        
                    class SecurityCellErrorClass(DictWrapper):
                        
                        """
                        SecurityCellError
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.SecurityCellError")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.SecurityCellErrorClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.security = str()
                                self.errorCode = SchemaClasses.com.pimco.ae.protocol.AccountValueErrorClass.NoError
                                self.errorSummary = SchemaClasses.com.pimco.ae.protocol.SecurityCellErrorClass.RECORD_SCHEMA.fields[2].default
                        
                        
                        @property
                        def security(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('security')
                        
                        @security.setter
                        def security(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['security'] = value
                        
                        
                        @property
                        def errorCode(self):
                            """
                            :rtype: SchemaClasses.com.pimco.ae.protocol.AccountValueErrorClass
                            """
                            return self._inner_dict.get('errorCode')
                        
                        @errorCode.setter
                        def errorCode(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.ae.protocol.AccountValueErrorClass value:
                            #"""
                            self._inner_dict['errorCode'] = value
                        
                        
                        @property
                        def errorSummary(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('errorSummary')
                        
                        @errorSummary.setter
                        def errorSummary(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['errorSummary'] = value
                        
                        
                    class SecurityResponseClass(DictWrapper):
                        
                        """
                        SecurityResponse
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.SecurityResponse")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.SecurityResponseClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.requestID = long()
                                self.securityCells = list()
                                self.errors = None
                        
                        
                        @property
                        def requestID(self):
                            """
                            :rtype: long
                            """
                            return self._inner_dict.get('requestID')
                        
                        @requestID.setter
                        def requestID(self, value):
                            #"""
                            #:param long value:
                            #"""
                            self._inner_dict['requestID'] = value
                        
                        
                        @property
                        def securityCells(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.SecurityCellClass]
                            """
                            return self._inner_dict.get('securityCells')
                        
                        @securityCells.setter
                        def securityCells(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.SecurityCellClass] value:
                            #"""
                            self._inner_dict['securityCells'] = value
                        
                        
                        @property
                        def errors(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.SecurityCellErrorClass]
                            """
                            return self._inner_dict.get('errors')
                        
                        @errors.setter
                        def errors(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.SecurityCellErrorClass] value:
                            #"""
                            self._inner_dict['errors'] = value
                        
                        
                    class CellCustomDataClass(DictWrapper):
                        
                        """
                        CellCustomData
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.CellCustomData")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.CellCustomDataClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.account = int()
                                self.strValue = SchemaClasses.com.pimco.ae.protocol.CellCustomDataClass.RECORD_SCHEMA.fields[1].default
                                self.value = SchemaClasses.com.pimco.ae.protocol.CellCustomDataClass.RECORD_SCHEMA.fields[2].default
                        
                        
                        @property
                        def account(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('account')
                        
                        @account.setter
                        def account(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['account'] = value
                        
                        
                        @property
                        def strValue(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('strValue')
                        
                        @strValue.setter
                        def strValue(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['strValue'] = value
                        
                        
                        @property
                        def value(self):
                            """
                            :rtype: float
                            """
                            return self._inner_dict.get('value')
                        
                        @value.setter
                        def value(self, value):
                            #"""
                            #:param float value:
                            #"""
                            self._inner_dict['value'] = value
                        
                        
                    class ValueRequestClass(DictWrapper):
                        
                        """
                        ValueRequest
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.ValueRequest")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.ValueRequestClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.requestId = SchemaClasses.com.pimco.ae.protocol.ValueRequestClass.RECORD_SCHEMA.fields[0].default
                                self.fieldId = int()
                                self.security = SchemaClasses.com.pimco.ae.protocol.ValueRequestClass.RECORD_SCHEMA.fields[2].default
                                self.accounts = list()
                                self.side = SchemaClasses.com.pimco.ae.protocol.ValueRequestClass.RECORD_SCHEMA.fields[4].default
                                self.broker = SchemaClasses.com.pimco.ae.protocol.ValueRequestClass.RECORD_SCHEMA.fields[5].default
                                self.settleDate = SchemaClasses.com.pimco.ae.protocol.ValueRequestClass.RECORD_SCHEMA.fields[6].default
                                self.price = SchemaClasses.com.pimco.ae.protocol.ValueRequestClass.RECORD_SCHEMA.fields[7].default
                                self.showRules = SchemaClasses.com.pimco.ae.protocol.ValueRequestClass.RECORD_SCHEMA.fields[8].default
                                self.ruleFilter = SchemaClasses.com.pimco.ae.protocol.ValueRequestClass.RECORD_SCHEMA.fields[9].default
                                self.checkBrokerRuleOnly = SchemaClasses.com.pimco.ae.protocol.ValueRequestClass.RECORD_SCHEMA.fields[10].default
                                self.validateSpendAmount = SchemaClasses.com.pimco.ae.protocol.ValueRequestClass.RECORD_SCHEMA.fields[11].default
                                self.clrBrokerOnly = SchemaClasses.com.pimco.ae.protocol.ValueRequestClass.RECORD_SCHEMA.fields[12].default
                                self.reasonCode = SchemaClasses.com.pimco.ae.protocol.ValueRequestClass.RECORD_SCHEMA.fields[13].default
                                self.priority = SchemaClasses.com.pimco.ae.protocol.ValueRequestClass.RECORD_SCHEMA.fields[14].default
                                self.fxStrategy = SchemaClasses.com.pimco.ae.protocol.ValueRequestClass.RECORD_SCHEMA.fields[15].default
                                self.parameters = list()
                                self.cells = list()
                        
                        
                        @property
                        def requestId(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('requestId')
                        
                        @requestId.setter
                        def requestId(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['requestId'] = value
                        
                        
                        @property
                        def fieldId(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('fieldId')
                        
                        @fieldId.setter
                        def fieldId(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['fieldId'] = value
                        
                        
                        @property
                        def security(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('security')
                        
                        @security.setter
                        def security(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['security'] = value
                        
                        
                        @property
                        def accounts(self):
                            """
                            :rtype: list[int]
                            """
                            return self._inner_dict.get('accounts')
                        
                        @accounts.setter
                        def accounts(self, value):
                            #"""
                            #:param list[int] value:
                            #"""
                            self._inner_dict['accounts'] = value
                        
                        
                        @property
                        def side(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('side')
                        
                        @side.setter
                        def side(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['side'] = value
                        
                        
                        @property
                        def broker(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('broker')
                        
                        @broker.setter
                        def broker(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['broker'] = value
                        
                        
                        @property
                        def settleDate(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('settleDate')
                        
                        @settleDate.setter
                        def settleDate(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['settleDate'] = value
                        
                        
                        @property
                        def price(self):
                            """
                            :rtype: float
                            """
                            return self._inner_dict.get('price')
                        
                        @price.setter
                        def price(self, value):
                            #"""
                            #:param float value:
                            #"""
                            self._inner_dict['price'] = value
                        
                        
                        @property
                        def showRules(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('showRules')
                        
                        @showRules.setter
                        def showRules(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['showRules'] = value
                        
                        
                        @property
                        def ruleFilter(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('ruleFilter')
                        
                        @ruleFilter.setter
                        def ruleFilter(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['ruleFilter'] = value
                        
                        
                        @property
                        def checkBrokerRuleOnly(self):
                            """
                            :rtype: bool
                            """
                            return self._inner_dict.get('checkBrokerRuleOnly')
                        
                        @checkBrokerRuleOnly.setter
                        def checkBrokerRuleOnly(self, value):
                            #"""
                            #:param bool value:
                            #"""
                            self._inner_dict['checkBrokerRuleOnly'] = value
                        
                        
                        @property
                        def validateSpendAmount(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('validateSpendAmount')
                        
                        @validateSpendAmount.setter
                        def validateSpendAmount(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['validateSpendAmount'] = value
                        
                        
                        @property
                        def clrBrokerOnly(self):
                            """
                            :rtype: bool
                            """
                            return self._inner_dict.get('clrBrokerOnly')
                        
                        @clrBrokerOnly.setter
                        def clrBrokerOnly(self, value):
                            #"""
                            #:param bool value:
                            #"""
                            self._inner_dict['clrBrokerOnly'] = value
                        
                        
                        @property
                        def reasonCode(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('reasonCode')
                        
                        @reasonCode.setter
                        def reasonCode(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['reasonCode'] = value
                        
                        
                        @property
                        def priority(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('priority')
                        
                        @priority.setter
                        def priority(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['priority'] = value
                        
                        
                        @property
                        def fxStrategy(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('fxStrategy')
                        
                        @fxStrategy.setter
                        def fxStrategy(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['fxStrategy'] = value
                        
                        
                        @property
                        def parameters(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.RequestParameterClass]
                            """
                            return self._inner_dict.get('parameters')
                        
                        @parameters.setter
                        def parameters(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.RequestParameterClass] value:
                            #"""
                            self._inner_dict['parameters'] = value
                        
                        
                        @property
                        def cells(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.CellCustomDataClass]
                            """
                            return self._inner_dict.get('cells')
                        
                        @cells.setter
                        def cells(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.CellCustomDataClass] value:
                            #"""
                            self._inner_dict['cells'] = value
                        
                        
                    class RuleRequestClass(DictWrapper):
                        
                        """
                        RuleRequest
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.RuleRequest")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.RuleRequestClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.studyId = SchemaClasses.com.pimco.ae.protocol.RuleRequestClass.RECORD_SCHEMA.fields[0].default
                                self.msgId = SchemaClasses.com.pimco.ae.protocol.RuleRequestClass.RECORD_SCHEMA.fields[1].default
                        
                        
                        @property
                        def studyId(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('studyId')
                        
                        @studyId.setter
                        def studyId(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['studyId'] = value
                        
                        
                        @property
                        def msgId(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('msgId')
                        
                        @msgId.setter
                        def msgId(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['msgId'] = value
                        
                        
                    class InquiryRequestClass(DictWrapper):
                        
                        """
                        InquiryRequest
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.InquiryRequest")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.InquiryRequestClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.studyId = SchemaClasses.com.pimco.ae.protocol.InquiryRequestClass.RECORD_SCHEMA.fields[0].default
                        
                        
                        @property
                        def studyId(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('studyId')
                        
                        @studyId.setter
                        def studyId(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['studyId'] = value
                        
                        
                    class RequestClass(DictWrapper):
                        
                        """
                        Request
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.Request")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.RequestClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.header = SchemaClasses.com.pimco.ae.protocol.HeaderClass(_json_converter.from_json_object(SchemaClasses.com.pimco.ae.protocol.RequestClass.RECORD_SCHEMA.fields[0].default, writers_schema=SchemaClasses.com.pimco.ae.protocol.RequestClass.RECORD_SCHEMA.fields[0].type))
                                self.requestId = SchemaClasses.com.pimco.ae.protocol.RequestClass.RECORD_SCHEMA.fields[1].default
                                self.linkType = SchemaClasses.com.pimco.ae.protocol.RequestClass.RECORD_SCHEMA.fields[2].default
                                self.autoInquiry = SchemaClasses.com.pimco.ae.protocol.RequestClass.RECORD_SCHEMA.fields[3].default
                                self.filterRule = SchemaClasses.com.pimco.ae.protocol.RequestClass.RECORD_SCHEMA.fields[4].default
                                self.valueRequests = list()
                                self.ruleRequest = SchemaClasses.com.pimco.ae.protocol.RuleRequestClass(_json_converter.from_json_object(SchemaClasses.com.pimco.ae.protocol.RequestClass.RECORD_SCHEMA.fields[6].default, writers_schema=SchemaClasses.com.pimco.ae.protocol.RequestClass.RECORD_SCHEMA.fields[6].type))
                                self.inquiryRequest = SchemaClasses.com.pimco.ae.protocol.InquiryRequestClass(_json_converter.from_json_object(SchemaClasses.com.pimco.ae.protocol.RequestClass.RECORD_SCHEMA.fields[7].default, writers_schema=SchemaClasses.com.pimco.ae.protocol.RequestClass.RECORD_SCHEMA.fields[7].type))
                        
                        
                        @property
                        def header(self):
                            """
                            :rtype: SchemaClasses.com.pimco.ae.protocol.HeaderClass
                            """
                            return self._inner_dict.get('header')
                        
                        @header.setter
                        def header(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.ae.protocol.HeaderClass value:
                            #"""
                            self._inner_dict['header'] = value
                        
                        
                        @property
                        def requestId(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('requestId')
                        
                        @requestId.setter
                        def requestId(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['requestId'] = value
                        
                        
                        @property
                        def linkType(self):
                            """
                            :rtype: SchemaClasses.com.pimco.ae.protocol.LinkTypeClass
                            """
                            return self._inner_dict.get('linkType')
                        
                        @linkType.setter
                        def linkType(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.ae.protocol.LinkTypeClass value:
                            #"""
                            self._inner_dict['linkType'] = value
                        
                        
                        @property
                        def autoInquiry(self):
                            """
                            :rtype: bool
                            """
                            return self._inner_dict.get('autoInquiry')
                        
                        @autoInquiry.setter
                        def autoInquiry(self, value):
                            #"""
                            #:param bool value:
                            #"""
                            self._inner_dict['autoInquiry'] = value
                        
                        
                        @property
                        def filterRule(self):
                            """
                            :rtype: bool
                            """
                            return self._inner_dict.get('filterRule')
                        
                        @filterRule.setter
                        def filterRule(self, value):
                            #"""
                            #:param bool value:
                            #"""
                            self._inner_dict['filterRule'] = value
                        
                        
                        @property
                        def valueRequests(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.ValueRequestClass]
                            """
                            return self._inner_dict.get('valueRequests')
                        
                        @valueRequests.setter
                        def valueRequests(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.ValueRequestClass] value:
                            #"""
                            self._inner_dict['valueRequests'] = value
                        
                        
                        @property
                        def ruleRequest(self):
                            """
                            :rtype: SchemaClasses.com.pimco.ae.protocol.RuleRequestClass
                            """
                            return self._inner_dict.get('ruleRequest')
                        
                        @ruleRequest.setter
                        def ruleRequest(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.ae.protocol.RuleRequestClass value:
                            #"""
                            self._inner_dict['ruleRequest'] = value
                        
                        
                        @property
                        def inquiryRequest(self):
                            """
                            :rtype: SchemaClasses.com.pimco.ae.protocol.InquiryRequestClass
                            """
                            return self._inner_dict.get('inquiryRequest')
                        
                        @inquiryRequest.setter
                        def inquiryRequest(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.ae.protocol.InquiryRequestClass value:
                            #"""
                            self._inner_dict['inquiryRequest'] = value
                        
                        
                    class RequestsClass(DictWrapper):
                        
                        """
                        Requests
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.Requests")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.RequestsClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.requests = list()
                        
                        
                        @property
                        def requests(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.RequestClass]
                            """
                            return self._inner_dict.get('requests')
                        
                        @requests.setter
                        def requests(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.RequestClass] value:
                            #"""
                            self._inner_dict['requests'] = value
                        
                        
                    class NotifyClass(DictWrapper):
                        
                        """
                        Notify
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.Notify")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.NotifyClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.msg = str()
                                self.studyId = int()
                        
                        
                        @property
                        def msg(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('msg')
                        
                        @msg.setter
                        def msg(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['msg'] = value
                        
                        
                        @property
                        def studyId(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('studyId')
                        
                        @studyId.setter
                        def studyId(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['studyId'] = value
                        
                        
                    class ErrorResponseClass(DictWrapper):
                        
                        """
                        ErrorResponse
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.ErrorResponse")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.ErrorResponseClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.errorCode = SchemaClasses.com.pimco.ae.protocol.AccountValueErrorClass.NoError
                                self.summary = SchemaClasses.com.pimco.ae.protocol.ErrorResponseClass.RECORD_SCHEMA.fields[1].default
                                self.details = SchemaClasses.com.pimco.ae.protocol.ErrorResponseClass.RECORD_SCHEMA.fields[2].default
                        
                        
                        @property
                        def errorCode(self):
                            """
                            :rtype: SchemaClasses.com.pimco.ae.protocol.AccountValueErrorClass
                            """
                            return self._inner_dict.get('errorCode')
                        
                        @errorCode.setter
                        def errorCode(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.ae.protocol.AccountValueErrorClass value:
                            #"""
                            self._inner_dict['errorCode'] = value
                        
                        
                        @property
                        def summary(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('summary')
                        
                        @summary.setter
                        def summary(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['summary'] = value
                        
                        
                        @property
                        def details(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('details')
                        
                        @details.setter
                        def details(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['details'] = value
                        
                        
                    class AceRuleClass(DictWrapper):
                        
                        """
                        AceRule
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.AceRule")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.AceRuleClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.ruleId = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[0].default
                                self.ruleName = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[1].default
                                self.compType = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[2].default
                                self.spendAmt = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[3].default
                                self.qty = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[4].default
                                self.actualAmount = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[5].default
                                self.operatorType = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[6].default
                                self.condVal1 = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[7].default
                                self.condVal2 = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[8].default
                                self.overrideNote = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[9].default
                                self.blotterNote = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[10].default
                                self.ruleBlotterNote = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[11].default
                                self.groupBy = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[12].default
                                self.validationStatus = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[13].default
                                self.priorActualAmt = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[14].default
                                self.ruleComment = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[15].default
                                self.gComment = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[16].default
                                self.c2c = SchemaClasses.com.pimco.ae.protocol.AceRuleClass.RECORD_SCHEMA.fields[17].default
                        
                        
                        @property
                        def ruleId(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('ruleId')
                        
                        @ruleId.setter
                        def ruleId(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['ruleId'] = value
                        
                        
                        @property
                        def ruleName(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('ruleName')
                        
                        @ruleName.setter
                        def ruleName(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['ruleName'] = value
                        
                        
                        @property
                        def compType(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('compType')
                        
                        @compType.setter
                        def compType(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['compType'] = value
                        
                        
                        @property
                        def spendAmt(self):
                            """
                            :rtype: float
                            """
                            return self._inner_dict.get('spendAmt')
                        
                        @spendAmt.setter
                        def spendAmt(self, value):
                            #"""
                            #:param float value:
                            #"""
                            self._inner_dict['spendAmt'] = value
                        
                        
                        @property
                        def qty(self):
                            """
                            :rtype: float
                            """
                            return self._inner_dict.get('qty')
                        
                        @qty.setter
                        def qty(self, value):
                            #"""
                            #:param float value:
                            #"""
                            self._inner_dict['qty'] = value
                        
                        
                        @property
                        def actualAmount(self):
                            """
                            :rtype: float
                            """
                            return self._inner_dict.get('actualAmount')
                        
                        @actualAmount.setter
                        def actualAmount(self, value):
                            #"""
                            #:param float value:
                            #"""
                            self._inner_dict['actualAmount'] = value
                        
                        
                        @property
                        def operatorType(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('operatorType')
                        
                        @operatorType.setter
                        def operatorType(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['operatorType'] = value
                        
                        
                        @property
                        def condVal1(self):
                            """
                            :rtype: float
                            """
                            return self._inner_dict.get('condVal1')
                        
                        @condVal1.setter
                        def condVal1(self, value):
                            #"""
                            #:param float value:
                            #"""
                            self._inner_dict['condVal1'] = value
                        
                        
                        @property
                        def condVal2(self):
                            """
                            :rtype: float
                            """
                            return self._inner_dict.get('condVal2')
                        
                        @condVal2.setter
                        def condVal2(self, value):
                            #"""
                            #:param float value:
                            #"""
                            self._inner_dict['condVal2'] = value
                        
                        
                        @property
                        def overrideNote(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('overrideNote')
                        
                        @overrideNote.setter
                        def overrideNote(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['overrideNote'] = value
                        
                        
                        @property
                        def blotterNote(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('blotterNote')
                        
                        @blotterNote.setter
                        def blotterNote(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['blotterNote'] = value
                        
                        
                        @property
                        def ruleBlotterNote(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('ruleBlotterNote')
                        
                        @ruleBlotterNote.setter
                        def ruleBlotterNote(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['ruleBlotterNote'] = value
                        
                        
                        @property
                        def groupBy(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('groupBy')
                        
                        @groupBy.setter
                        def groupBy(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['groupBy'] = value
                        
                        
                        @property
                        def validationStatus(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('validationStatus')
                        
                        @validationStatus.setter
                        def validationStatus(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['validationStatus'] = value
                        
                        
                        @property
                        def priorActualAmt(self):
                            """
                            :rtype: float
                            """
                            return self._inner_dict.get('priorActualAmt')
                        
                        @priorActualAmt.setter
                        def priorActualAmt(self, value):
                            #"""
                            #:param float value:
                            #"""
                            self._inner_dict['priorActualAmt'] = value
                        
                        
                        @property
                        def ruleComment(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('ruleComment')
                        
                        @ruleComment.setter
                        def ruleComment(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['ruleComment'] = value
                        
                        
                        @property
                        def gComment(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('gComment')
                        
                        @gComment.setter
                        def gComment(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['gComment'] = value
                        
                        
                        @property
                        def c2c(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('c2c')
                        
                        @c2c.setter
                        def c2c(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['c2c'] = value
                        
                        
                    class AccountRulesClass(DictWrapper):
                        
                        """
                        AccountRules
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.AccountRules")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.AccountRulesClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.account = int()
                                self.bindingRuleId = int()
                                self.rules = list()
                        
                        
                        @property
                        def account(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('account')
                        
                        @account.setter
                        def account(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['account'] = value
                        
                        
                        @property
                        def bindingRuleId(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('bindingRuleId')
                        
                        @bindingRuleId.setter
                        def bindingRuleId(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['bindingRuleId'] = value
                        
                        
                        @property
                        def rules(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.AceRuleClass]
                            """
                            return self._inner_dict.get('rules')
                        
                        @rules.setter
                        def rules(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.AceRuleClass] value:
                            #"""
                            self._inner_dict['rules'] = value
                        
                        
                    class AccountCellClass(DictWrapper):
                        
                        """
                        AccountCell
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.AccountCell")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.AccountCellClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.account = int()
                                self.cell = SchemaClasses.com.pimco.ae.protocol.CellClass()
                                self.accountRules = SchemaClasses.com.pimco.ae.protocol.AccountRulesClass(_json_converter.from_json_object(SchemaClasses.com.pimco.ae.protocol.AccountCellClass.RECORD_SCHEMA.fields[2].default, writers_schema=SchemaClasses.com.pimco.ae.protocol.AccountCellClass.RECORD_SCHEMA.fields[2].type))
                        
                        
                        @property
                        def account(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('account')
                        
                        @account.setter
                        def account(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['account'] = value
                        
                        
                        @property
                        def cell(self):
                            """
                            :rtype: SchemaClasses.com.pimco.ae.protocol.CellClass
                            """
                            return self._inner_dict.get('cell')
                        
                        @cell.setter
                        def cell(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.ae.protocol.CellClass value:
                            #"""
                            self._inner_dict['cell'] = value
                        
                        
                        @property
                        def accountRules(self):
                            """
                            :rtype: SchemaClasses.com.pimco.ae.protocol.AccountRulesClass
                            """
                            return self._inner_dict.get('accountRules')
                        
                        @accountRules.setter
                        def accountRules(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.ae.protocol.AccountRulesClass value:
                            #"""
                            self._inner_dict['accountRules'] = value
                        
                        
                    class AccountCellErrorClass(DictWrapper):
                        
                        """
                        AccountCellError
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.AccountCellError")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.AccountCellErrorClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.account = int()
                                self.errorCode = SchemaClasses.com.pimco.ae.protocol.AccountValueErrorClass.NoError
                                self.errorSummary = SchemaClasses.com.pimco.ae.protocol.AccountCellErrorClass.RECORD_SCHEMA.fields[2].default
                                self.details = SchemaClasses.com.pimco.ae.protocol.AccountCellErrorClass.RECORD_SCHEMA.fields[3].default
                        
                        
                        @property
                        def account(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('account')
                        
                        @account.setter
                        def account(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['account'] = value
                        
                        
                        @property
                        def errorCode(self):
                            """
                            :rtype: SchemaClasses.com.pimco.ae.protocol.AccountValueErrorClass
                            """
                            return self._inner_dict.get('errorCode')
                        
                        @errorCode.setter
                        def errorCode(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.ae.protocol.AccountValueErrorClass value:
                            #"""
                            self._inner_dict['errorCode'] = value
                        
                        
                        @property
                        def errorSummary(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('errorSummary')
                        
                        @errorSummary.setter
                        def errorSummary(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['errorSummary'] = value
                        
                        
                        @property
                        def details(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('details')
                        
                        @details.setter
                        def details(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['details'] = value
                        
                        
                    class ValueResponseClass(DictWrapper):
                        
                        """
                        ValueResponse
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.ValueResponse")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.ValueResponseClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.requestId = int()
                                self.cells = list()
                                self.errors = list()
                        
                        
                        @property
                        def requestId(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('requestId')
                        
                        @requestId.setter
                        def requestId(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['requestId'] = value
                        
                        
                        @property
                        def cells(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.AccountCellClass]
                            """
                            return self._inner_dict.get('cells')
                        
                        @cells.setter
                        def cells(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.AccountCellClass] value:
                            #"""
                            self._inner_dict['cells'] = value
                        
                        
                        @property
                        def errors(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.AccountCellErrorClass]
                            """
                            return self._inner_dict.get('errors')
                        
                        @errors.setter
                        def errors(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.AccountCellErrorClass] value:
                            #"""
                            self._inner_dict['errors'] = value
                        
                        
                    class ResponseClass(DictWrapper):
                        
                        """
                        Response
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.Response")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.ResponseClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.requestId = SchemaClasses.com.pimco.ae.protocol.ResponseClass.RECORD_SCHEMA.fields[0].default
                                self.studyId = SchemaClasses.com.pimco.ae.protocol.ResponseClass.RECORD_SCHEMA.fields[1].default
                                self.notify = SchemaClasses.com.pimco.ae.protocol.NotifyClass(_json_converter.from_json_object(SchemaClasses.com.pimco.ae.protocol.ResponseClass.RECORD_SCHEMA.fields[2].default, writers_schema=SchemaClasses.com.pimco.ae.protocol.ResponseClass.RECORD_SCHEMA.fields[2].type))
                                self.errorResponse = SchemaClasses.com.pimco.ae.protocol.ErrorResponseClass(_json_converter.from_json_object(SchemaClasses.com.pimco.ae.protocol.ResponseClass.RECORD_SCHEMA.fields[3].default, writers_schema=SchemaClasses.com.pimco.ae.protocol.ResponseClass.RECORD_SCHEMA.fields[3].type))
                                self.valueResponses = list()
                        
                        
                        @property
                        def requestId(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('requestId')
                        
                        @requestId.setter
                        def requestId(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['requestId'] = value
                        
                        
                        @property
                        def studyId(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('studyId')
                        
                        @studyId.setter
                        def studyId(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['studyId'] = value
                        
                        
                        @property
                        def notify(self):
                            """
                            :rtype: SchemaClasses.com.pimco.ae.protocol.NotifyClass
                            """
                            return self._inner_dict.get('notify')
                        
                        @notify.setter
                        def notify(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.ae.protocol.NotifyClass value:
                            #"""
                            self._inner_dict['notify'] = value
                        
                        
                        @property
                        def errorResponse(self):
                            """
                            :rtype: SchemaClasses.com.pimco.ae.protocol.ErrorResponseClass
                            """
                            return self._inner_dict.get('errorResponse')
                        
                        @errorResponse.setter
                        def errorResponse(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.ae.protocol.ErrorResponseClass value:
                            #"""
                            self._inner_dict['errorResponse'] = value
                        
                        
                        @property
                        def valueResponses(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.ValueResponseClass]
                            """
                            return self._inner_dict.get('valueResponses')
                        
                        @valueResponses.setter
                        def valueResponses(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.ValueResponseClass] value:
                            #"""
                            self._inner_dict['valueResponses'] = value
                        
                        
                    class ResponsesClass(DictWrapper):
                        
                        """
                        Responses
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.Responses")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.ResponsesClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.responses = list()
                                self.errorResponse = SchemaClasses.com.pimco.ae.protocol.ErrorResponseClass(_json_converter.from_json_object(SchemaClasses.com.pimco.ae.protocol.ResponsesClass.RECORD_SCHEMA.fields[1].default, writers_schema=SchemaClasses.com.pimco.ae.protocol.ResponsesClass.RECORD_SCHEMA.fields[1].type))
                        
                        
                        @property
                        def responses(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.ResponseClass]
                            """
                            return self._inner_dict.get('responses')
                        
                        @responses.setter
                        def responses(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.ResponseClass] value:
                            #"""
                            self._inner_dict['responses'] = value
                        
                        
                        @property
                        def errorResponse(self):
                            """
                            :rtype: SchemaClasses.com.pimco.ae.protocol.ErrorResponseClass
                            """
                            return self._inner_dict.get('errorResponse')
                        
                        @errorResponse.setter
                        def errorResponse(self, value):
                            #"""
                            #:param SchemaClasses.com.pimco.ae.protocol.ErrorResponseClass value:
                            #"""
                            self._inner_dict['errorResponse'] = value
                        
                        
                    class BlockViewClass(DictWrapper):
                        
                        """
                        BlockView
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.BlockView")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.BlockViewClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.field = str()
                                self.security = None
                                self.param = None
                                self.accounts = int()
                        
                        
                        @property
                        def field(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('field')
                        
                        @field.setter
                        def field(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['field'] = value
                        
                        
                        @property
                        def security(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('security')
                        
                        @security.setter
                        def security(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['security'] = value
                        
                        
                        @property
                        def param(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('param')
                        
                        @param.setter
                        def param(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['param'] = value
                        
                        
                        @property
                        def accounts(self):
                            """
                            :rtype: int
                            """
                            return self._inner_dict.get('accounts')
                        
                        @accounts.setter
                        def accounts(self, value):
                            #"""
                            #:param int value:
                            #"""
                            self._inner_dict['accounts'] = value
                        
                        
                    class CallRequestClass(DictWrapper):
                        
                        """
                        CallRequest
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.CallRequest")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.CallRequestClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.callId = long()
                                self.poolName = str()
                                self.poolStatus = str()
                                self.userName = str()
                                self.arrivalTime = long()
                                self.currentTime = SchemaClasses.com.pimco.ae.protocol.CallRequestClass.RECORD_SCHEMA.fields[5].default
                                self.blocks = list()
                                self.studyId = SchemaClasses.com.pimco.ae.protocol.CallRequestClass.RECORD_SCHEMA.fields[7].default
                        
                        
                        @property
                        def callId(self):
                            """
                            :rtype: long
                            """
                            return self._inner_dict.get('callId')
                        
                        @callId.setter
                        def callId(self, value):
                            #"""
                            #:param long value:
                            #"""
                            self._inner_dict['callId'] = value
                        
                        
                        @property
                        def poolName(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('poolName')
                        
                        @poolName.setter
                        def poolName(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['poolName'] = value
                        
                        
                        @property
                        def poolStatus(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('poolStatus')
                        
                        @poolStatus.setter
                        def poolStatus(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['poolStatus'] = value
                        
                        
                        @property
                        def userName(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('userName')
                        
                        @userName.setter
                        def userName(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['userName'] = value
                        
                        
                        @property
                        def arrivalTime(self):
                            """
                            :rtype: long
                            """
                            return self._inner_dict.get('arrivalTime')
                        
                        @arrivalTime.setter
                        def arrivalTime(self, value):
                            #"""
                            #:param long value:
                            #"""
                            self._inner_dict['arrivalTime'] = value
                        
                        
                        @property
                        def currentTime(self):
                            """
                            :rtype: long
                            """
                            return self._inner_dict.get('currentTime')
                        
                        @currentTime.setter
                        def currentTime(self, value):
                            #"""
                            #:param long value:
                            #"""
                            self._inner_dict['currentTime'] = value
                        
                        
                        @property
                        def blocks(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.BlockViewClass]
                            """
                            return self._inner_dict.get('blocks')
                        
                        @blocks.setter
                        def blocks(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.BlockViewClass] value:
                            #"""
                            self._inner_dict['blocks'] = value
                        
                        
                        @property
                        def studyId(self):
                            """
                            :rtype: long
                            """
                            return self._inner_dict.get('studyId')
                        
                        @studyId.setter
                        def studyId(self, value):
                            #"""
                            #:param long value:
                            #"""
                            self._inner_dict['studyId'] = value
                        
                        
                    class FieldTreeClass(DictWrapper):
                        
                        """
                        FieldTree
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.FieldTree")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.FieldTreeClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.treeID = long()
                                self.name = str()
                                self.sort = long()
                                self.region = str()
                                self.linkto = long()
                                self.create_date = str()
                                self.update_date = str()
                        
                        
                        @property
                        def treeID(self):
                            """
                            :rtype: long
                            """
                            return self._inner_dict.get('treeID')
                        
                        @treeID.setter
                        def treeID(self, value):
                            #"""
                            #:param long value:
                            #"""
                            self._inner_dict['treeID'] = value
                        
                        
                        @property
                        def name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('name')
                        
                        @name.setter
                        def name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['name'] = value
                        
                        
                        @property
                        def sort(self):
                            """
                            :rtype: long
                            """
                            return self._inner_dict.get('sort')
                        
                        @sort.setter
                        def sort(self, value):
                            #"""
                            #:param long value:
                            #"""
                            self._inner_dict['sort'] = value
                        
                        
                        @property
                        def region(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('region')
                        
                        @region.setter
                        def region(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['region'] = value
                        
                        
                        @property
                        def linkto(self):
                            """
                            :rtype: long
                            """
                            return self._inner_dict.get('linkto')
                        
                        @linkto.setter
                        def linkto(self, value):
                            #"""
                            #:param long value:
                            #"""
                            self._inner_dict['linkto'] = value
                        
                        
                        @property
                        def create_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('create_date')
                        
                        @create_date.setter
                        def create_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['create_date'] = value
                        
                        
                        @property
                        def update_date(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('update_date')
                        
                        @update_date.setter
                        def update_date(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['update_date'] = value
                        
                        
                    class PairClass(DictWrapper):
                        
                        """
                        Pair
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.Pair")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.PairClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.key = str()
                                self.value = SchemaClasses.com.pimco.ae.protocol.PairClass.RECORD_SCHEMA.fields[1].default
                        
                        
                        @property
                        def key(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('key')
                        
                        @key.setter
                        def key(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['key'] = value
                        
                        
                        @property
                        def value(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('value')
                        
                        @value.setter
                        def value(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['value'] = value
                        
                        
                    class PropertiesClass(DictWrapper):
                        
                        """
                        Properties
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.Properties")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.PropertiesClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.values = list()
                        
                        
                        @property
                        def values(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.PairClass]
                            """
                            return self._inner_dict.get('values')
                        
                        @values.setter
                        def values(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.PairClass] value:
                            #"""
                            self._inner_dict['values'] = value
                        
                        
                    class FieldTreesClass(DictWrapper):
                        
                        """
                        FieldTrees
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.FieldTrees")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.FieldTreesClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.fieldTrees = list()
                        
                        
                        @property
                        def fieldTrees(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.FieldTreeClass]
                            """
                            return self._inner_dict.get('fieldTrees')
                        
                        @fieldTrees.setter
                        def fieldTrees(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.FieldTreeClass] value:
                            #"""
                            self._inner_dict['fieldTrees'] = value
                        
                        
                    class FieldClass(DictWrapper):
                        
                        """
                        Field
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.Field")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.FieldClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.fieldID = long()
                                self.fieldCode = str()
                                self.securityBatchable = SchemaClasses.com.pimco.ae.protocol.FieldClass.RECORD_SCHEMA.fields[2].default
                        
                        
                        @property
                        def fieldID(self):
                            """
                            :rtype: long
                            """
                            return self._inner_dict.get('fieldID')
                        
                        @fieldID.setter
                        def fieldID(self, value):
                            #"""
                            #:param long value:
                            #"""
                            self._inner_dict['fieldID'] = value
                        
                        
                        @property
                        def fieldCode(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('fieldCode')
                        
                        @fieldCode.setter
                        def fieldCode(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['fieldCode'] = value
                        
                        
                        @property
                        def securityBatchable(self):
                            """
                            :rtype: bool
                            """
                            return self._inner_dict.get('securityBatchable')
                        
                        @securityBatchable.setter
                        def securityBatchable(self, value):
                            #"""
                            #:param bool value:
                            #"""
                            self._inner_dict['securityBatchable'] = value
                        
                        
                    class FieldsClass(DictWrapper):
                        
                        """
                        Fields
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.Fields")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.FieldsClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.fields = list()
                        
                        
                        @property
                        def fields(self):
                            """
                            :rtype: list[SchemaClasses.com.pimco.ae.protocol.FieldClass]
                            """
                            return self._inner_dict.get('fields')
                        
                        @fields.setter
                        def fields(self, value):
                            #"""
                            #:param list[SchemaClasses.com.pimco.ae.protocol.FieldClass] value:
                            #"""
                            self._inner_dict['fields'] = value
                        
                        
                    class CacheTypeClass(DictWrapper):
                        
                        """
                        CacheType
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.CacheType")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.CacheTypeClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.name = str()
                        
                        
                        @property
                        def name(self):
                            """
                            :rtype: str
                            """
                            return self._inner_dict.get('name')
                        
                        @name.setter
                        def name(self, value):
                            #"""
                            #:param str value:
                            #"""
                            self._inner_dict['name'] = value
                        
                        
                    class FieldParameterClass(DictWrapper):
                        
                        """
                        FieldParameter
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.FieldParameter")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.FieldParameterClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.fieldID = long()
                        
                        
                        @property
                        def fieldID(self):
                            """
                            :rtype: long
                            """
                            return self._inner_dict.get('fieldID')
                        
                        @fieldID.setter
                        def fieldID(self, value):
                            #"""
                            #:param long value:
                            #"""
                            self._inner_dict['fieldID'] = value
                        
                        
                    class FieldQueryClass(DictWrapper):
                        
                        """
                        FieldQuery
                        """
                        
                        
                        RECORD_SCHEMA = get_schema_type("com.pimco.ae.protocol.FieldQuery")
                        
                        
                        def __init__(self, inner_dict=None):
                            super(SchemaClasses.com.pimco.ae.protocol.FieldQueryClass, self).__init__(inner_dict)
                            if inner_dict is None:
                                self.fieldID = long()
                        
                        
                        @property
                        def fieldID(self):
                            """
                            :rtype: long
                            """
                            return self._inner_dict.get('fieldID')
                        
                        @fieldID.setter
                        def fieldID(self, value):
                            #"""
                            #:param long value:
                            #"""
                            self._inner_dict['fieldID'] = value
                        
                        
                    class FieldTypeClass(object):
                        
                        """
                        Security
                        """
                        
                        Data = "Data"
                        Security = "Security"
                        
                    
                    pass


class RequestClasses(object):
    
    
    
    pass
__SCHEMA_TYPES = {
'com.pimco.ae.protocol.FuncType': SchemaClasses.com.pimco.ae.protocol.FuncTypeClass,
    'com.pimco.ae.protocol.Header': SchemaClasses.com.pimco.ae.protocol.HeaderClass,
    'com.pimco.ae.protocol.AccountValueError': SchemaClasses.com.pimco.ae.protocol.AccountValueErrorClass,
    'com.pimco.ae.protocol.LinkType': SchemaClasses.com.pimco.ae.protocol.LinkTypeClass,
    'com.pimco.ae.protocol.RequestParameter': SchemaClasses.com.pimco.ae.protocol.RequestParameterClass,
    'com.pimco.ae.protocol.SecurityRequest': SchemaClasses.com.pimco.ae.protocol.SecurityRequestClass,
    'com.pimco.ae.protocol.Cell': SchemaClasses.com.pimco.ae.protocol.CellClass,
    'com.pimco.ae.protocol.SecurityCell': SchemaClasses.com.pimco.ae.protocol.SecurityCellClass,
    'com.pimco.ae.protocol.SecurityCellError': SchemaClasses.com.pimco.ae.protocol.SecurityCellErrorClass,
    'com.pimco.ae.protocol.SecurityResponse': SchemaClasses.com.pimco.ae.protocol.SecurityResponseClass,
    'com.pimco.ae.protocol.CellCustomData': SchemaClasses.com.pimco.ae.protocol.CellCustomDataClass,
    'com.pimco.ae.protocol.ValueRequest': SchemaClasses.com.pimco.ae.protocol.ValueRequestClass,
    'com.pimco.ae.protocol.RuleRequest': SchemaClasses.com.pimco.ae.protocol.RuleRequestClass,
    'com.pimco.ae.protocol.InquiryRequest': SchemaClasses.com.pimco.ae.protocol.InquiryRequestClass,
    'com.pimco.ae.protocol.Request': SchemaClasses.com.pimco.ae.protocol.RequestClass,
    'com.pimco.ae.protocol.Requests': SchemaClasses.com.pimco.ae.protocol.RequestsClass,
    'com.pimco.ae.protocol.Notify': SchemaClasses.com.pimco.ae.protocol.NotifyClass,
    'com.pimco.ae.protocol.ErrorResponse': SchemaClasses.com.pimco.ae.protocol.ErrorResponseClass,
    'com.pimco.ae.protocol.AceRule': SchemaClasses.com.pimco.ae.protocol.AceRuleClass,
    'com.pimco.ae.protocol.AccountRules': SchemaClasses.com.pimco.ae.protocol.AccountRulesClass,
    'com.pimco.ae.protocol.AccountCell': SchemaClasses.com.pimco.ae.protocol.AccountCellClass,
    'com.pimco.ae.protocol.AccountCellError': SchemaClasses.com.pimco.ae.protocol.AccountCellErrorClass,
    'com.pimco.ae.protocol.ValueResponse': SchemaClasses.com.pimco.ae.protocol.ValueResponseClass,
    'com.pimco.ae.protocol.Response': SchemaClasses.com.pimco.ae.protocol.ResponseClass,
    'com.pimco.ae.protocol.Responses': SchemaClasses.com.pimco.ae.protocol.ResponsesClass,
    'com.pimco.ae.protocol.BlockView': SchemaClasses.com.pimco.ae.protocol.BlockViewClass,
    'com.pimco.ae.protocol.CallRequest': SchemaClasses.com.pimco.ae.protocol.CallRequestClass,
    'com.pimco.ae.protocol.FieldTree': SchemaClasses.com.pimco.ae.protocol.FieldTreeClass,
    'com.pimco.ae.protocol.Pair': SchemaClasses.com.pimco.ae.protocol.PairClass,
    'com.pimco.ae.protocol.Properties': SchemaClasses.com.pimco.ae.protocol.PropertiesClass,
    'com.pimco.ae.protocol.FieldTrees': SchemaClasses.com.pimco.ae.protocol.FieldTreesClass,
    'com.pimco.ae.protocol.Field': SchemaClasses.com.pimco.ae.protocol.FieldClass,
    'com.pimco.ae.protocol.Fields': SchemaClasses.com.pimco.ae.protocol.FieldsClass,
    'com.pimco.ae.protocol.CacheType': SchemaClasses.com.pimco.ae.protocol.CacheTypeClass,
    'com.pimco.ae.protocol.FieldParameter': SchemaClasses.com.pimco.ae.protocol.FieldParameterClass,
    'com.pimco.ae.protocol.FieldQuery': SchemaClasses.com.pimco.ae.protocol.FieldQueryClass,
    'com.pimco.ae.protocol.FieldType': SchemaClasses.com.pimco.ae.protocol.FieldTypeClass,
    
}
_json_converter = avrojson.AvroJsonConverter(use_logical_types=True, schema_types=__SCHEMA_TYPES)

