'''
This utility class provides APIS to update the CMEF data base. Store data and retrive data
'''
from distutils.command.config import config
import os
from core.rest import client
import pandas
from core.services.cmef import  process_cmef_job_params
_run_id = None
_is_debug = False
_env = None
_use_kerberos = True
import json as js
import pickle as pkl
from core.services.cmef import CmefContentTypes
import logging
import socket
from datetime import datetime
from dateutil.tz import tzlocal
import urllib
import json
import uuid
from amps import amps_client
from core.db import sql_db


def _setup_ids(run_id,env):
    global _run_id, _env
    _run_id, _env = run_id,env

def debug_cmef(runid, env='dev', use_kerberos=True):
    global _run_id, _is_debug, _env
    _is_debug, _run_id, _env, _use_kerberos = True, runid, env, use_kerberos


CONNECTIONURLMAP = {
    'dev':  'http://ptp-dev/cmef/v1/',
    #'dev': 'http://localhost:10999/cmef/v1/',
    'beta': 'http://ptp-beta/cmef/v1/',
    'prod': 'http://ptp-prod/cmef/v1/',
    # 'prod': 'http://prodpmwsv7:52808/cmef/v1/',
}


CMEFRUNURL = {
    'dev': 'http://ptp-dev/cmef/home/runs/',
    'beta': 'http://ptp-beta/cmef/home/runs/',
    'prod': 'http://ptp-prod/cmef/home/runs/',
}


CMEFLANGUAGES = ['PYTHON', 'MATLAB', 'R']

CMEFNOTIFICATIONLEVELS = ['NOTIFY_ALWAYS', 'NOTIFY_ONLY_ON_ERROR', 'DO_NOT_NOTIFY']
AMPS_CONFIG_MAP = {
                'dev' :  {'servers':'devpmampv4', 'topic': 'CMEF_JOB_RUN_DETAILS_DEV','instance':'fot'},
                'beta' : {'servers':'betapmamp1,betapmamp2','topic': 'CMEF_JOB_RUN_DETAILS_BETA','instance':'fot'},
                'prod' : {'servers':'prodpmamp2,prodpmamp3,prodpmamp1', 'topic': 'CMEF_JOB_RUN_DETAILS_PROD','instance':'fot'}
            }


def get_run_info():
    return _run_id, _env


def get_db_connection_without_pool(env):
    """
    Get connection for oracle without using SqlDbPool
    :param env:
    :return:
    """
    db_name = {
        'dev': 'ORADEVPIM',
        'beta': 'ORABTAPIM',
        'prod': 'ORAPRDPIM',
    }
    try:
        conn = sql_db.SqlDb(server=db_name.get(env), vendor='oracle', user='', password='')
    except Exception as e:
        logging.exception('Unable to connect to database: {0}'.format(db_name.get(env)))
        return None
    return conn


def get_run_url(run_id=None, env=None):
    '''return the url to get the run details and links to data and log
    :param run_id:
    :param env:
    :return:
    '''
    if run_id is None and env is None:
        run_url = CMEFRUNURL.get(_env) + str(_run_id)
    else:
        if run_id and env:
            run_url = CMEFRUNURL.get(env) + str(run_id)
        else:
            raise ValueError('Invalid run_id "{0}" or env "{1}" parameter'.format(run_id, env))
    return run_url


def register_model(modelName='', entryFunction='', gridPlatform='DASK', owner='', modelVersion='1.0', description='',
                   language='PYTHON', contactEmail=None, env='dev'):
    logging.warning("DEPRECATED: use create_model or update_model")
    if modelName and modelVersion:
        model_details = get_model_details(model_name=modelName, model_version=modelVersion, env=env)
        if model_details:
            return update_model(model_name=modelName, model_version=modelVersion, model_id=None, entry_function=entryFunction, description=description, language=language, owner=owner,
                                grid_platform=gridPlatform, contact_email=contactEmail, model_hierarchy=None, env=env)
        else:
            return create_model(modelName, model_version=modelVersion, entry_function=entryFunction, description=description, language=language, owner=owner,
                                grid_platform=gridPlatform, contact_email=contactEmail, model_hierarchy=None, env=env)

def get_content(dataname):
    '''return the content of the data for the run , this needs _run_id set. Use _setup_ids or debug_cmef before using the API
    :param dataname:
    :return:
    '''
    logging.warning("DEPRECATED use get_run_content")
    _url = CONNECTIONURLMAP.get(_env)
    if not _run_id: return
    url = _url + 'content/%d/%s/' % (_run_id, dataname)
    headers, contents = client.getWithContenType(url, use_kerberos=_use_kerberos,parse_content_as='binary')
    contentType = headers.get('Content-Type')
    if (contentType.find('application/x-dataframe') >= 0):
        return pkl.loads(contents.getvalue())
    elif (contentType.find('application/json') >= 0):
        return json.loads(contents.getvalue())
    else:
        return contents.getvalue()


def get_run_content(data_name, run_id=None, env=None):
    ''' get the content for the data_name and give run_id and env.
     If run_id and env is not passed it uses the value set from _run_id and _env
    :param data_name:
    :param run_id:
    :param env:
    :return:
    '''
    if run_id is None:
        run_id = _run_id
    if env is None:
        env = _env

    _url = CONNECTIONURLMAP.get(env)
    content_url = _url + 'content/{0}/{1}/'.format(run_id, data_name)
    try:
        headers, contents = client.getWithContenType(content_url, use_kerberos=_use_kerberos, parse_content_as='binary')
        contentType = headers.get('Content-Type')
        if (contentType.find('application/x-dataframe') >= 0):
            return pkl.loads(contents.getvalue())
        elif (contentType.find('application/json') >= 0):
            return json.loads(contents.getvalue())
        else:
            return contents.getvalue()
    except Exception as e:
        logging.exception(e.message)
        raise Exception('Unable to download content "{0}" for run "{1}"'.format(data_name, get_run_url(run_id=run_id, env=env)))


def del_data(dataname):
    '''
    :param dataname:
    :return:
    '''
    _url = CONNECTIONURLMAP.get(_env)
    if not _run_id: return
    url = _url + 'deldata/%d/%s/' % (_run_id, dataname)
    client.delete(url, use_kerberos=_use_kerberos)


def setup_model_job(modelid=None, modelName='', modelVersion='',
                    inputparam={},
                    job_name=None,
                    env='dev'):
    ''' Setup JOB for existing model
    :param modelid:
    :param modelName:
    :param modelVersion:
    :param inputparam:
    :param job_name:
    :param env:
    :return:
    '''
    job_details = get_job_details(job_name=job_name, env=env)
    if job_details:
        return update_job(job_name,input_params=inputparam,env=env)
    else:
        return create_job(job_name, model_id=modelid, model_name=modelName, model_version=modelVersion,
                          input_params=inputparam, env=env)


def get_job_details(job_name=None, job_id=None , env='dev'):
    ''' Get the job information
    :param job_name:
    :param job_id:
    :param env:
    :return:
    '''
    if not any([job_name, job_id]):
        raise ValueError('Missing job_name or job_id parameter')

    _url = CONNECTIONURLMAP.get(env)
    jobs_url = _url + 'jobs/'
    if job_name:
        logging.info('Getting job details by job_name "{0}"'.format(job_name))
        search_url = jobs_url + '?search={0}'.format(job_name)
        try:
            job_list = client.get(url=search_url, use_kerberos=_use_kerberos)
        except Exception as e:
            logging.exception(e.message)
            return {}
        for each_job in job_list:
            if each_job['jobName'] == job_name:
                return each_job
        return {}

    if job_id:
        logging.info('Getting job details by job_id "{0}"'.format(job_id))
        job_id_url = jobs_url + '{0}'.format(job_id)
        try:
            job_details = client.get(url=job_id_url, use_kerberos=_use_kerberos)
            return job_details
        except Exception as e:
            logging.exception(e.message)
            return {}
    return {}


def get_model_details(model_name=None, model_id=None, model_version=None, env='dev'):
    ''' Get model details
    :param model_name:
    :param model_id:
    :param model_version:
    :param env:
    :return:
    '''
    if not model_id:
        if not (model_name and model_version):
            raise ValueError('Missing model_id or (model_name and model_version) parameter')

    _url = CONNECTIONURLMAP.get(env)
    models_url = _url + 'models/'
    if model_name and model_version:
        logging.info('Getting model details by model_name "{0}" and model_version "{1}"'.format(model_name, model_version))
        search_url = models_url + '?search={0}'.format(model_name)
        try:
            model_list = client.get(url=search_url, use_kerberos=_use_kerberos)
        except Exception as e:
            logging.exception(e.message)
            return {}
        for each_model in model_list:
            if each_model['modelName'] == model_name and each_model['modelVersion'] == str(model_version):
                return each_model
        return {}

    if model_id:
        logging.info('Getting model details by model_id "{0}"'.format(model_id))
        model_id_url = models_url + '{0}'.format(model_id)
        try:
            model_details = client.get(url=model_id_url, use_kerberos=_use_kerberos)
            return model_details
        except Exception as e:
            logging.exception(e.message)
            return {}
    return {}


def create_model(model_name, model_version='1.0', entry_function=None, description=None, language='PYTHON', owner=None,
                 grid_platform=None, contact_email=None, model_hierarchy=None, env='dev'):
    ''' Creates new Model.
    :param model_name: Must be unique name
    :param model_version: Version must be unique for the model.
        New version are registered when the model name is the same but has diff function as entry point.
    :param entry_function: the function that is called , in case of python full path to function
    :param description: Model description
    :param language: valid PYTHON,MATLAB
    :param owner: Owner of the model
    :param grid_platform:
    :param contact_email: Email to notify when model run fails
    :param model_hierarchy: This defines the permissions
    :param env: dev/beta/prod
    :return:
    '''
    if get_model_details(model_name=model_name, model_version=model_version, env=env):
        raise Exception('Model name "{0}" with model version "{1}" already exists'.format(model_name, model_version))

    language = language.upper()
    if language not in CMEFLANGUAGES:
        raise ValueError('Language paramter incorrect. CMEF supported languges are: {0}'.format(str(CMEFLANGUAGES)))
    _url = CONNECTIONURLMAP.get(env)
    models_url = _url + 'models/'
    post_data = {'modelName': model_name, 'modelVersion': model_version, 'entryFunction' : entry_function,
                 'description': description, 'language': language, 'owner': owner, 'contactEmail': contact_email,
                 'gridPlatform': grid_platform, 'modelHierarchy': model_hierarchy}
    try:
        json_data = client.post(url=models_url, data=post_data, use_kerberos=_use_kerberos)
    except Exception as e:
        logging.exception(e.message)
        return {}
    return json_data


def update_model(model_name=None, model_version=None, model_id=None, entry_function=None, description=None, language=None, owner=None,
                 grid_platform=None, contact_email=None, model_hierarchy=None, env='dev'):
    ''' Update the models
    :param model_name:
    :param model_version:
    :param model_id:
    :param entry_function:
    :param description:
    :param language:
    :param owner:
    :param grid_platform:
    :param contact_email:
    :param model_hierarchy:
    :param env:
    :return:
    '''
    if not model_id:
        if model_name and model_version:
            model_details = get_model_details(model_name=model_name, model_version=model_version, env=env)
            if model_details:
                model_id = model_details['modelId']
            else:
                logging.warning('Model Name "{0}" with Version "{1}" not found'.format(model_name, model_version))
                logging.warning('Creating Model "{0}" with Version "{1}"'.format(model_name, model_version))
                return create_model(model_name=model_name, model_version=model_version, entry_function=entry_function,
                                    description=description, language=language, owner=owner, grid_platform=grid_platform,
                                    contact_email=contact_email, model_hierarchy=model_hierarchy, env=env)
        else:
            raise ValueError('Missing model_id or (model_name and model_version) parameter')
    else:
        model_details = get_model_details(model_id=model_id, env=env)
        if not model_details:
            raise Exception('Model with model_id "{0}" not found'.format(model_id))

    if language:
        language = language.upper()
        if language not in CMEFLANGUAGES:
            raise ValueError('Language parameter incorrect. CMEF supported languges are: {0}'.format(str(CMEFLANGUAGES)))

    _url = CONNECTIONURLMAP.get(env)
    models_url = _url + 'models/'
    model_id_url = models_url + '{0}'.format(model_id)
    post_data = {'modelId': model_id, 'entryFunction': entry_function,
                 'description': description, 'language': language, 'owner': owner, 'contactEmail': contact_email,
                 'gridPlatform': grid_platform, 'modelHierarchy': model_hierarchy}
    try:
        json_data = client.put(url=model_id_url, data=post_data, use_kerberos=_use_kerberos)
    except Exception as e:
        logging.exception(e.message)
        return {}
    return json_data


def create_job(job_name, model_id=None, model_name=None, model_version=None, input_params={},
               notification_level='NOTIFY_ALWAYS', notification_email=None, env='dev'):
    '''
    :param job_name:
    :param model_id:
    :param model_name:
    :param model_version:
    :param input_params:
    :param env:
    :return:
    '''
    if get_job_details(job_name=job_name, env=env):
        raise Exception('Job Name "{0}" already exists'.format(job_name))

    if not model_id:
        if model_name and model_version:
            model_details = get_model_details(model_name=model_name, model_version=model_version, env=env)
            if model_details:
                model_id = model_details['modelId']
            else:
                raise Exception('Model Name "{0}" with Version "{1}" not found'.format(model_name, model_version))
        else:
            raise ValueError('Missing model_id or (model_name and model_version) parameter')
    else:
        model_details = get_model_details(model_id=model_id, env=env)
        if not model_details:
            raise Exception('Model with model_id "{0}" not found'.format(model_id))

    if notification_level:
        if notification_level.upper() not in CMEFNOTIFICATIONLEVELS:
            raise ValueError('Notification Level parameter incorrect. CMEF supported levels are: {0}'.format(str(CMEFNOTIFICATIONLEVELS)))
        else:
            notification_level = notification_level.upper()
    else:
        raise ValueError('Notification Level parameter incorrect. CMEF supported levels are: {0}'.format(str(CMEFNOTIFICATIONLEVELS)))

    _url = CONNECTIONURLMAP.get(env)
    cmef_input_params = process_cmef_job_params(input_params)
    jobs_url = _url + 'jobs/'
    post_data = {'jobName': job_name, 'cmefModelId': model_id, 'inputData': cmef_input_params,
                 'notification_level': notification_level, 'notification_email': notification_email}
    try:
        json_data = client.post(url=jobs_url, data=post_data, use_kerberos=_use_kerberos)
    except Exception as e:
        logging.exception(e.message)
        return {}
    return json_data


def update_job(job_name, input_params={}, notification_level=None, notification_email=None, model_id=None,
               model_name=None, model_version=None, env='dev'):
    '''
    :param job_name:
    :param input_params:
    :param env:
    :return:
    '''
    job_details = get_job_details(job_name=job_name, env=env)
    if job_details:
        job_id = job_details['jobId']
    else:
        logging.warning('Job Name "{0}" not found'.format(job_name))
        logging.warning('Creating Job "{0}" with inputs provided'.format(job_name))
        if notification_level is None:
            notification_level = 'NOTIFY_ALWAYS'
        return create_job(job_name=job_name, model_id=model_id, model_name=model_name, model_version=model_version,
                          input_params=input_params, notification_level=notification_level,
                          notification_email=notification_email, env=env)

    _url = CONNECTIONURLMAP.get(env)
    cmef_input_params = process_cmef_job_params(input_params)
    jobs_url = _url + 'jobs/'
    post_data = {'jobId': job_id, 'jobName': job_name, 'inputData': cmef_input_params,
                 'notification_level': notification_level, 'notification_email': notification_email}
    logging.debug(post_data)
    try:
        json_data = client.put(url=jobs_url, data=post_data, use_kerberos=_use_kerberos)
    except Exception as e:
        logging.exception(e.message)
        return {}
    return get_job_details(job_id=job_id, env=env)


def get_amps_client(env):
    '''
    get amps client instance based on environment
    :param env: 
    :return: amps client instance
    '''
    try:
        server_list = AMPS_CONFIG_MAP[env]['servers'].split(",")
        amps_topic = AMPS_CONFIG_MAP[env]['topic']
        amps_instance = AMPS_CONFIG_MAP[env]['instance']
        amps_client_id = 'CMEF-DATAAPI-AMPS-{0}-{1}'.format(env.upper(),uuid.uuid4())

        ampsClient = amps_client.Client(amps_client_id,
                                    amps_topic,
                                    instance=amps_instance,
                                    hosts=server_list)
        ampsClient.start_amps()

        logging.info('cmef amps client created with topic=%s amps server hosts=%s and amps client id=%s', amps_topic,",".join(server_list),amps_client_id)

        return ampsClient
    except Exception as ex:
        logging.error("Error when trying to create cmef amps client instance.\nException:{}".format(str(ex)))
        raise


def publish_to_amps(data,env='prod'):
    '''
    publish dictionary data to amps topic
    :param data: amps payload
    :param env: environment
    :return: None
    '''
    try:
        amps_topic = AMPS_CONFIG_MAP[env]['topic']
        amps_payload = json.dumps(data)
        logging.info('start to create amps client to publish json msg=%s',amps_payload)
        with get_amps_client(env) as ampsclient:
            ampsclient.publish(data, amps_topic)
            logging.info('publish to amps topic=%s  and payload=%s', amps_topic, amps_payload)

    except Exception as ex:
        logging.error("Error when trying to publish data into amps!\nException:{}".format(str(ex)))


def assemble_amps_payload(job_name,job_run_id,error_msg):
    payload_data = dict(cmef_job=job_name,
                        job_run_id=job_run_id,
                        status='FAILED',
                        job_log_url='',
                        job_owner='',
                        job_id='',
                        run_user='',
                        contact_email='CMEFDEV@pimco.com',
                        error_msg=error_msg,
                        utc_time_stamp=datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
    return payload_data


def assemble_amps_payload(job_run_details):
    payload_data = dict(cmef_job=job_run_details['jobName'],
                    job_run_id =job_run_details['runId'],
                    status=job_run_details['status'],
                    job_log_url=job_run_details['logUrl'],
                    job_owner=job_run_details['owner'],
                    job_id = job_run_details['jobId'],
                    run_user=job_run_details['runUser'],
                    contact_email=job_run_details['contactEmail'],
                    error_msg='',
                    utc_time_stamp=datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
    return payload_data


def monitor_job(run_id,job_name,env='dev',timeout_seconds=600):
    '''
    monitor cmef job run by pulling, then publish job run details to amps
    :param run_id: 
    :param job_name: 
    :param env: 
    :param timeout_seconds: default time before declaring job time-out
    :return: None
    '''
    run_monitor_details = monitor_run(run_id=run_id, timeout_seconds=timeout_seconds, env=env)
    if run_monitor_details:
        amps_data = assemble_amps_payload(run_monitor_details)
        publish_to_amps(amps_data,env)
    else:
        error_msg = 'Unable to monitor run for job "{0}" with run_id "{1}"'.format(job_name, run_id)
        amps_data=assemble_amps_payload(job_name,run_id,error_msg)
        publish_to_amps(amps_data, env)


def async_execute_job(job_name,env='dev',override_params={},**kwargs):
    '''
        asychronously kicks off cmef job and return run_id
    :param job_name: 
    :param env: 
    :param override_params: 
    :param kwargs: 
    :return: dictionary with run_id, job_name as well as any error
    '''
    job_details = get_job_details(job_name=job_name, env=env)
    if job_details:
        job_id = job_details['jobId']
    else:
        return {'run_id': -1, 'error': 'job definition could not be found from cmef env:{0}'.format(env),'job_name': job_name,'env': env}

    _url = CONNECTIONURLMAP.get(env)
    jobs_url = _url + 'jobs/'
    execute_url = jobs_url + 'execute/{0}'.format(job_name)
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    post_data = {}
    if isinstance(override_params, dict):
        post_data['INPUTPARAMS'] = override_params
    if kwargs:
        post_data.update(kwargs)
    try:
        run_details = client.post(execute_url, headers=headers, data=urllib.urlencode(post_data), use_kerberos=_use_kerberos, request_serializer=None)
    except Exception as e:
        logging.exception(e.message)
        error_for_client = "Calling cmef restful api with url:{0} errors out. Exception:{1}".format(execute_url,e.message)
        return {'run_id': -1, 'error': error_for_client,'job_name': job_name, 'env': env}

    run_id = run_details.get('runId')
    return {'run_id': run_id, 'error': '', 'job_name': job_name, 'env': env}


def execute_job(job_name, timeout_seconds=600, env='dev', override_params={}, exception_on_failure=True, **kwargs):
    '''
    :param job_name:
    :param timeout_seconds:
    :param env:
    :param override_params:
    :param exception_on_failure:
    :param kwargs:
    :return:
    '''
    job_details = get_job_details(job_name=job_name, env=env)
    if job_details:
        job_id = job_details['jobId']
    else:
        raise Exception('Job Name {0} not found'.format(job_name))

    _url = CONNECTIONURLMAP.get(env)
    jobs_url = _url + 'jobs/'
    execute_url = jobs_url + 'execute/{0}'.format(job_name)
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    post_data = {}
    if isinstance(override_params, dict):
        post_data['INPUTPARAMS'] = override_params
    if kwargs:
        post_data.update(kwargs)
    try:
        run_details = client.post(execute_url, headers=headers, data=urllib.urlencode(post_data), use_kerberos=_use_kerberos, request_serializer=None)
    except Exception as e:
        logging.exception(e.message)
        if exception_on_failure:
            raise Exception('Unable to execute job')
        else:
            return {}
    run_id = run_details.get('runId')
    run_monitor_details = monitor_run(run_id=run_id, timeout_seconds=timeout_seconds, env=env)
    if run_monitor_details:
        if run_monitor_details['status'] == 'SUCCESS':
            return run_monitor_details
        if run_monitor_details['status'] in ['CANCELLED']:
            if exception_on_failure:
                logging.info(run_monitor_details)
                raise Exception("Job Cancelled")
            else:
                return run_monitor_details
        if run_monitor_details['status'] in ['FAILED', 'STD_RUNTIME_ERROR', 'TIMEOUT']:
            if exception_on_failure:
                logging.info(run_monitor_details)
                raise Exception("Job Failed")
            else:
                return run_monitor_details
    else:
        raise Exception('Unable to monitor run for job "{0}" with run_id "{1}"'.format(job_name, run_id))


def setup_model_run(modelid=None, modelName='', modelVersion='',
                    inputparam={},
                    jobid=None,
                    job_name=None, env='dev', ):
    logging.warning("DEPRECATED: use create_job and execute_job ")
    model_details = get_model_details(model_id=modelid,model_name=modelName, model_version=modelVersion, env=env)
    if not model_details:
        raise Exception("Model name not found %s , %s" , ( modelName ,modelVersion ))
    else:
        if not job_name and not jobid: job_name = modelName + "-SYSGEN-JOB"
        job_details = get_job_details(job_name=job_name,job_id=jobid, env=env)
        if not job_details:
            job = create_job(job_name, model_name=modelName, model_version=modelVersion, input_params=inputparam,
                             env=env)
        else:
            job = update_job(job_name,input_params=inputparam,env=env)

    return execute_job(job.get('jobName'),env=env)


def setup_job_run(jobid=None, env='dev', job_name=''):
    if jobid or job_name:
        return _setup_run(jobid=jobid, env=env, job_name=job_name)


def create_run(job_name=None, job_id=None , env='dev'):
    '''
    :param jobid:
    :param env:
    :param job_name:
    :return:
    '''
    job_details = get_job_details(job_name=job_name, job_id=job_id, env=env)
    if job_details:
        job_id = job_details['jobId']
    else:
        raise Exception('Job Name {0} not found'.format(job_name))

    _url = CONNECTIONURLMAP.get(env)
    runs_url = _url + 'runs/'
    post_data = {'jobId': job_id, 'jobName': job_name, 'inputData': {}}
    logging.debug(post_data)
    try:
        json_data = client.post(url=runs_url, data=post_data, use_kerberos=_use_kerberos)
    except Exception as e:
        logging.exception(e.message)
        return {}
    return json_data


def _setup_run(jobid=None, env='dev', job_name=None):
    run_details = create_run(job_id=jobid, env=env, job_name=job_name)
    global _run_id, _is_debug, _env
    _run_id = run_details.get('runId')
    _is_debug = False
    _env = env
    return run_details


def save_logdata(filename=None, contents=None):
    '''
    :param filename:
    :param contents:
    :return:
    '''
    if not contents and not filename: return
    if filename:
        f = open(filename, "rb")
        try:
            contents = f.read()
        finally:
            f.close()
    _url = CONNECTIONURLMAP.get(_env)
    if not _run_id: return
    url = _url + 'runs/%d/log' % (_run_id)
    client.post(url, contents, use_kerberos=_use_kerberos, headers={
        'content-type': 'application/octet-stream'
    })


def save_pydata(dataname, data):
    '''
    :param dataname:
    :param data:
    :return:
    '''
    contents = None
    contentType = None
    if isinstance(data, pandas.DataFrame):
        contents = pkl.dumps(data)
        contentType = CmefContentTypes.DATAFRAME
    if isinstance(data, dict) or isinstance(data, list):
        contents = js.dumps(data)
        contentType = CmefContentTypes.JSON
    if not contents: return
    _url = CONNECTIONURLMAP.get(_env)
    if not _run_id: return
    url = _url + 'savedata/%d/' % (_run_id)
    client.post(url, contents, use_kerberos=_use_kerberos, headers={
        'content-type': 'application/octet-stream',
        'X-CMEF-ContentType': str(contentType),
        'X-CMEF-ContentName': dataname
    })


def get_run_status(run_id, env='dev'):
    ''' Get run status
    :param run_id:
    :param env:
    :return:
    '''
    _url = CONNECTIONURLMAP.get(env)
    runs_url = _url + 'runs/'
    status_url = runs_url + '{0}/status'.format(run_id)
    try:
        status = client.get(url=status_url, use_kerberos=_use_kerberos)
    except Exception as e:
        logging.exception(e.message)
        return None
    return status


def get_run_details(run_id, env='dev'):
    ''' Get the run details
    :param run_id:
    :param env:
    :return:
    '''
    _url = CONNECTIONURLMAP.get(env)
    runs_url = _url + 'runs/'
    run_id_url = runs_url + '{0}'.format(run_id)
    try:
        run_details = client.get(url=run_id_url, use_kerberos=_use_kerberos)
        return run_details
    except Exception as e:
        logging.exception(e.message)
        return {}


def monitor_run(run_id, timeout_seconds=600, env='dev'):
    ''' Checks the status of the CMEF job
    :param run_id:
    :param timeout_seconds:
    :param env:
    :return:
    '''
    begin = datetime.datetime.now()
    while True:
        try:
            status = get_run_status(run_id=run_id, env=env)
            if status in ['SUCCESS', 'FAILED', 'CANCELLED', 'STD_RUNTIME_ERROR']:
                run_details = get_run_details(run_id=run_id, env=env)
                return run_details
            if (datetime.datetime.now() - begin).total_seconds() > timeout_seconds:
                run_details = get_run_details(run_id=run_id, env=env)
                run_details['status'] = 'TIMEOUT'
                return run_details
            if status is None:
                return {}
        except Exception as e:
            logging.exception(e.message)
            return {}
        time.sleep(5)


import time
import datetime


def execute_cmef_job(job_name, timeout_seconds=600, model_id = None, model_name= None, model_version = None, env='dev'):
    '''
    :param job_name:
    :param timeout:
    :param env:
    :return:
    '''
    _url = CONNECTIONURLMAP.get(env)
    logging.warning("Deprecated")
    #search for job name
    jobs_url = _url + 'jobs?search=%s' % ( job_name )
    jobs = client.get(jobs_url, use_kerberos=_use_kerberos)
    url = _url + 'executejob?jobName=%s&async=true' % (
        job_name)  # if async call is made check the run status and then return

    #lets do some checks
    if len(jobs) > 1 and model_id is None and model_name is None and model_version is None:
        logging.info("More than one job specified, please indicate the model_name nad version")
        logging.info("List of vailable models names are ")
        for job in jobs:
            logging.info("Model Nmae : %s , model Version : %s , Model ID : %d " % ( jobs['modelData']['modelName'] ,
                                                                                     jobs['modelData']['modelVersion'] ,
                                                                                     jobs['modelData']['modelId']) )
        raise Exception("Duplicate Jobs found ")


    runDetails = client.get(url, use_kerberos=_use_kerberos)
    runid = runDetails.get('runId')
    statusurl = _url + 'getrunstatus/%s/' % (runid)
    begin = datetime.datetime.now()
    while True:
        status = client.get(statusurl)
        if status in ['SUCCESS']:
            return runDetails
        if status in ['FAILED', 'STD_RUNTIME_ERROR']:
            raise Exception("Job Failed")
        if (datetime.datetime.now() - begin).total_seconds() > timeout_seconds:
            raise Exception("TIMEOUT")
        time.sleep(10)


def save_data(dataname='', filename='', contentType=None):
    '''
    :param dataname:
    :param filename:
    :param contents:
    :return:
    '''
    contents = None
    if not dataname: dataname = os.path.basename(filename)
    if filename and isinstance(filename, str) and os.path.isfile(filename):
        if os.path.getsize(filename) <= 10485760:    # Checking if file size <= 10MB
            f = open(filename, "rb")
            try:
                contents = f.read()
            finally:
                f.close()
        else:
            logging.debug('File size is greter than 10MB')
            logging.debug('Setting content to filepath and contentType to CmefContentTypes.FILELOCATION')
            contents = os.path.abspath(filename)
            contentType = CmefContentTypes.FILELOCATION

    if not contentType:
        name, file_extension = os.path.splitext(filename)
        if file_extension.lower() == '.xls':
            contentType = CmefContentTypes.EXCEL
        elif file_extension.lower() == '.xlsx':
            contentType = CmefContentTypes.XLSX
        elif file_extension.lower() == '.xlsm':
            contentType = CmefContentTypes.XLSM
        elif file_extension.lower() == '.csv':
            contentType = CmefContentTypes.CSV
        elif file_extension.lower() == '.pdf':
            contentType = CmefContentTypes.PDF
        elif file_extension.lower() == '.xml':
            contentType = CmefContentTypes.XML
        elif file_extension.lower() == '.json':
            contentType = CmefContentTypes.JSON
        elif file_extension.lower() == '.mat':
            contentType = CmefContentTypes.MAT
        else:
            contentType = CmefContentTypes.BINARY

    if not contents:
        logging.info("no filename or contents provided")
        return
    _url = CONNECTIONURLMAP.get(_env)
    if not _run_id: return
    url = _url + 'savedata/%d/' % (_run_id)
    client.post(url, contents, use_kerberos=_use_kerberos, headers={
        'content-type': 'application/octet-stream',
        'X-CMEF-ContentType': str(contentType),
        'X-CMEF-ContentName': dataname
    })


def create_job_status_object(run_id, env, job_id, job_name, status, user, grid, message=None):
    '''
    :param run_id:
    :param env:
    :param job_id:
    :param job_name:
    :param status:
    :param user:
    :param grid:
    :param message:
    :return:
    '''
    host_name = socket.gethostname()
    update_ts = datetime.datetime.now(tzlocal()).isoformat()
    if not grid:
        grid = 'N/A'
    status_obj = {'run_id': run_id, 'env': env, 'job_id': job_id,'job_name': job_name, 'status': status, 'user': user,
                  'grid': grid, 'host_name': host_name, 'update_ts': update_ts, 'message': message}
    return status_obj


def update_run_status(run_id, env, job_id, job_name, status, user, grid, message=None):
    ''' Update the status of the run
    :param run_id:
    :param env:
    :param job_id:
    :param job_name:
    :param status: CREATED, STARTED, SUCCESS, FAILED
    :param user:
    :param grid:
    :param message:
    :return:
    '''
    try:
        status_obj = create_job_status_object(run_id, env, job_id, job_name, status, user, grid, message)
    except Exception as e:
        logging.exception(e.message)
        raise Exception('Unable to create status object')

    _url = CONNECTIONURLMAP.get(env)
    runs_url = _url + 'runs/'
    status_url = runs_url + '{0}/status'.format(run_id)
    post_data = status_obj
    headers = {'X-CMEF-USER': user}
    try:
        client.post(url=status_url, data=post_data, headers=headers, use_kerberos=_use_kerberos)
        return True
    except Exception as e:
        logging.exception(e.message)
        raise Exception('Unable to update status for run_id "{0}"'.format(run_id) + e.message)


def update_run_status_legacy(status, run_id=None, env=None, grid='LOCAL', message=None):
    if run_id is None and env is None:
        run_id = _run_id
        env = _env
    else:
        if not run_id and not env:
            raise ValueError('Invalid run_id "{0}" or env "{1}" parameter'.format(run_id, env))

    run_details = get_run_details(run_id=run_id, env=env)
    if run_details:
        job_name = run_details.get('jobName')
        job_id = run_details.get('jobId')
    else:
        raise Exception('Run details for run "{0}" not found'.format(run_id))

    import getpass
    current_user = getpass.getuser()
    update_run_status(run_id=run_id, env=env, job_id=job_id, job_name=job_name, status=status, user=current_user,
                      grid=grid, message=message)


def get_smarts_dates(date_names, result_format='dataframe', env='dev'):
    """
    API to get REGION_CODE and DATE_VALUE from pimco_own.smarts_dates
    :param date_names: list or tuple of date names found in description column
    :param result_format: Return data as dataframe or dictionary. Options - dataframe or dict
    :param env:
    :return: Dataframe or Dictionary of query results
    """
    if len(date_names) > 1:
        sql = """select DESCRIPTION, REGION_CODE, DATE_VALUE from pimco_own.smarts_dates where description in {0}""".format(tuple(date_names))
    else:
        sql = """select DESCRIPTION, REGION_CODE, DATE_VALUE from pimco_own.smarts_dates where description = '{0}'""".format(date_names[0])

    logging.info('Getting smarts dates using query: {0}'.format(sql))
    with get_db_connection_without_pool(env) as sql_conn:
        try:
            query_result_df = sql_conn.query_as_df(sql)
        except Exception as e:
            logging.exception('Unable to execute query')
            query_result_df = pandas.DataFrame(columns=['DESCRIPTION', 'REGION_CODE', 'DATE_VALUE'])
    if result_format == 'dict':
        return query_result_df.to_dict(orient='records')
    else:
        return query_result_df


def get_ops_cycle_date(region_code='U', env='dev'):
    """
    API to get Ops Cycle Date (autosys global var cycle_date) from smarts_dates table
    :param region_code: Options - A, E, U
    :param env:
    :return: date object
    """
    result_df = get_smarts_dates(date_names=['BATCH CYCLE CLOSE DATE'], env=env)
    if not result_df.empty:
        result_df = result_df[result_df['REGION_CODE'] == region_code]
        logging.debug(result_df)
        if not result_df.empty:
            return result_df.iloc[0]['DATE_VALUE'].date()
        else:
            return None
    else:
        return None


def get_ops_current_business_date(region_code='U', env='dev'):
    """
    API to get Ops Curr Business Date (autosys global var curr_business_date) from smarts_dates table
    :param region_code: Options - A, E, U
    :param env:
    :return: date object
    """
    result_df = get_smarts_dates(date_names=['CURRENT PROCESS DATE'], env=env)
    if not result_df.empty:
        result_df = result_df[result_df['REGION_CODE'] == region_code]
        logging.debug(result_df)
        if not result_df.empty:
            return result_df.iloc[0]['DATE_VALUE'].date()
        else:
            return None
    else:
        return None


def get_cmef_service_property(property_name, env='dev'):
    """
    Get CMEF java service property
    :param property_name:
    :param env:
    :return:
    """
    _url = CONNECTIONURLMAP.get(env)
    cmef_property_url = _url + 'cmefproperty/{0}'.format(property_name)
    headers = {'Accept': 'text/plain'}
    try:
        property_value = client.get(url=cmef_property_url, headers=headers, use_kerberos=_use_kerberos)
    except Exception as e:
        logging.exception(e.message)
        return None
    if property_value:
        return str(property_value)
    else:
        return None

