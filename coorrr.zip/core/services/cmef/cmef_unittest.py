import sys
import logging
import unittest
import time


class CMEFTextTestResult(unittest.TextTestResult):
    def getCMEFErrors(self):
        msg = ''
        if self.dots or self.showAll:
            self.stream.writeln()
        msg += self.getCMEFErrorList('ERROR', self.errors)
        msg += self.getCMEFErrorList('FAIL', self.failures)
        return msg

    def getCMEFErrorList(self, flavour, errors):
        msg = ''
        for test, err in errors:
            msg += self.separator1 + '\n'
            msg += "%s: %s\n" % (flavour, self.getDescription(test))
            msg += self.separator2 + '\n'
            msg += "%s\n" % err
        return msg


class CMEFTextTestRunner(unittest.TextTestRunner):
    resultclass = CMEFTextTestResult


def getCMEFUnittestLogger():
    logger = logging.getLogger('cmef_unittest_logger')
    logger.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler(sys.stderr)
    formatter = logging.Formatter('%(asctime)s [%(name)s] [%(module)s:%(lineno)d] %(levelname)s - %(message)s')
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    return logger


def execute_cmef_unittest(test_case, exception_on_failure=True):
    msg = '\n\n'
    global cmef_unittest_logger
    cmef_unittest_logger = getCMEFUnittestLogger()
    test_case_list = unittest.TestLoader().getTestCaseNames(test_case)
    suite = unittest.TestLoader().loadTestsFromTestCase(test_case)
    start_time = time.time()
    results = CMEFTextTestRunner(stream=sys.stderr, verbosity=2).run(suite)
    end_time = time.time()
    time_taken = end_time - start_time
    msg += '-' * 70
    msg += '\nTEST SUMMARY: [{0}]\n'.format(test_case.__name__)
    msg += '-' * 70 + '\n'
    msg += 'Total Test Executed : {0} in {1:.3f}s\n'.format(results.testsRun, time_taken)
    msg += 'Test Errors : {0}\n'.format(len(results.errors))
    msg += 'Test Failures : {0}\n'.format(len(results.failures))
    msg += 'Test List :\n'
    for each_case in test_case_list:
        msg += '{0}\n'.format(each_case)
    if results.errors or results.failures:
        msg += 'Test Error Details : \n'
        msg += '\n' + results.getCMEFErrors()
    if results.wasSuccessful():
        msg += 'Tests Execution Status : SUCCESSFUL\n'
        msg += '--------------------------------------------------------------------\n'
        cmef_unittest_logger.info(msg)
        if exception_on_failure:
            return 0
        else:
            return {'status': 'SUCCESSFUL', 'status_code': 0, 'summary': msg, 'test_suite': test_case.__name__,
                    'total_runs': results.testsRun, 'run_time': time_taken, 'total_errors': len(results.errors),
                    'total_failures': len(results.failures), 'test_case_list': test_case_list}
    else:
        msg += 'Tests Execution Status : FAILED\n\n'
        msg += '--------------------------------------------------------------------\n'
        cmef_unittest_logger.info(msg)
        if exception_on_failure:
            raise Exception('Test Execution for test suite "{0}" FAILED'.format(test_case.__name__))
        else:
            return {'status': 'FAILED', 'status_code': 1, 'summary': msg, 'test_suite': test_case.__name__,
                    'total_runs': results.testsRun, 'run_time': time_taken, 'total_errors': len(results.errors),
                    'total_failures': len(results.failures), 'test_case_list': test_case_list}
