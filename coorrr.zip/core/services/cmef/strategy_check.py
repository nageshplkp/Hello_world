
import logging
from core.db.conn_pool import PooledConnection, SqlDbPool
from datetime import datetime, timedelta
from core.reporting.prettytable import PrettyTable
import calendar
import pandas as pd
import argparse
import sys

enable_log = False

def get_args(args):
    parser = argparse.ArgumentParser(description = 'Generate Strategy Check Report')
    parser.add_argument('-e', '--environment', action='store', type=str, choices=['dev', 'beta', 'prod'], default='dev',
                        help='Select environment for the run')
    parser.add_argument('-t', '--timeline', action='store', type=int, default=0,
                        help='TimeLine in days - Perform checks for asof date since t days from current date')
    parser.add_argument('-l', '--emaillist', action='store', type=str, required=True,
                        help='Report emailing list (Comma Separated)')
    parser.add_argument('-d', '--debug', action='store_true', default=False,
                        help='Set logging to debug')
    return parser.parse_args(args)


def _connect_db(server, user='', password=''):
    """
    connecting to the standard databases

    :param str server: one of 'ORADEVPIM', 'ORABTAPIM", 'ORAPRDPIM'
    :param str user: the user name, if this and the password are not specified, will use kerberos
    :param str password: password
    :return: PooledConnection

    """
    try:
        obj = PooledConnection(SqlDbPool(server, 'oracle', log=enable_log), server, 'oracle',
                               user=user, password=password, log=enable_log)
        return obj
    except Exception:
        logging.exception('Unable to connect to server: {0}'.format(server))
        return None


_db_pool = {
    'dev': _connect_db('ORADEVPIM', 'PM_QUANT_OWN', 'dev'),
    #'beta': _connect_db('ORABTAPIM'),
    #'prod': _connect_db('ORAPRDPIM'),
}


def get_connection(env='dev'):
    return _db_pool.get(env)


def get_weekday_abbr(date):
    day_of_week_int = datetime.weekday(date)
    day_of_week = calendar.day_name[day_of_week_int]
    return day_of_week[:2].upper()


def convert_date_to_str(date):
    return date.strftime('%Y-%m-%d')


def get_delta_date(date, timeline):
    datesettings = date - timedelta(days=timeline)
    return datesettings


def _cell_color(col_name, col_index, row_index, col_value):
    if col_value == 'GOOD' and col_name == 'CHECKS':
        return {'background': 'green'}
    elif col_value == 'BAD' and col_name == 'CHECKS':
        return {'background': 'red'}
    elif col_value == 'NO RUN' and col_name == 'CHECKS':
        return {'background': 'orange'}


def get_query_results(query, env='dev'):
    logging.debug(query)
    try:
        with get_connection(env) as sqldb:
            logging.debug('Search Query:')
            logging.debug(query)
            query_results = sqldb.query_as_df(sql=query, log=enable_log)
            logging.debug('Query Results:')
            logging.debug(query_results)
            return query_results
    except Exception:
        logging.exception('SQL Query Failure')
        return pd.DataFrame()


def get_check_master_data_query(env='dev'):
    search_query = """select ACCOUNT , STRATEGY , DAYS_TO_RUN from PM_QUANT_OWN.STRATEGY_CHECK_MASTER"""
    results = get_query_results(query=search_query, env=env)
    return results


def get_transactions_data_query(search_date, env='dev'):
    search_query = """select ACCOUNT,STRATEGY,ASOF_DATE,TICKER,TARGET_TRADE,EXECUTED
                      from PM_QUANT_OWN.STRATEGY_CHECK
                      where ASOF_DATE >= DATE '{0}'
                   """.format(search_date)
    results = get_query_results(query=search_query, env=env)
    return results


def update_dataframe_dtype(dframe, inputs):
    for column, datatype in inputs.iteritems():
        dframe[column] = dframe[column].astype(datatype)
    return dframe


def check_missing_runs(start, end, master_info, results):
    while start <= end:
        logging.debug('Checking for missing runs for date {0} ...'.format(convert_date_to_str(end)))
        for row in master_info.loc[master_info['DAYS_TO_RUN'].str.contains(get_weekday_abbr(end))].itertuples():
            if results.loc[(results['ACCOUNT'] == row.ACCOUNT) & (results['STRATEGY'] == row.STRATEGY) & \
                           (results['ASOF_DATE'] == convert_date_to_str(end))].empty:
                logging.debug('No run found for account - {0} and strategy - {1}'.format(row.ACCOUNT, row.STRATEGY))
                results.loc[len(results)] = {'ACCOUNT': row.ACCOUNT, 'STRATEGY': row.STRATEGY, 'ASOF_DATE': convert_date_to_str(end),
                                             'TICKER': '-', 'TARGET_TRADE': None, 'EXECUTED': None, 'CHECKS': 'NO RUN'}
        end = get_delta_date(end, 1)
    return results


def check_invalid_runs(account, strategy, date, master_info):
    if master_info.loc[(master_info['ACCOUNT'] == account) & (master_info['STRATEGY'] == strategy) & \
                       (master_info['DAYS_TO_RUN'].str.contains(get_weekday_abbr(date)))].empty:
        return True
    else:
        return False


def check_trades(target, executed):
    if target == executed:
        return 'GOOD'
    else:
        return 'BAD'


def generate_report(pdf, emaillist, invalid):
    try:
        logging.info('Generating Report ...')
        PrettyTable([pdf]).bg(start_row=0, end_row=0, start_col=0, end_col=-1, colors='#4c68a2') \
            .bg(start_row=1, end_row=-1, start_col=0, end_col=-1, colors='white') \
            .font(start_row=0, end_row=0, start_col=0, end_col=-1, weight='bold', family='Tahoma', size='14px') \
            .padding(start_row=0, end_row=0, start_col=0, end_col=-1, length='10') \
            .padding(start_row=1, end_row=-1, start_col=0, end_col=-1, length='6') \
            .border(start_row=0, end_row=-1, start_col=0, end_col=-1, color='black', thickness='1px', mechanism=1) \
            .row_bg(rows=invalid, color='yellow') \
            .col_numeric(nan_space='-', prec=0, cols=['TARGET_TRADE', 'EXECUTED']).cell_applyfn([_cell_color]) \
            .sendmail('TEST', [emaillist], 'TEST Report')
        logging.info('Report sent to users: {0}'.format(emaillist))
        return 0
    except Exception:
        logging.exception('Unable to Generate and Email Report')
        return 1


def main(sysargs=None):
    if sysargs is not None:
        args = get_args(sysargs)
        env = args.environment
        timeline = args.timeline
        email_list = args.emaillist
        if args.debug:
            logging.basicConfig(level=logging.DEBUG)
    else:
        env = 'dev'
        timeline = 0

    logging.info('Setting environment to {0}'.format(env))
    logging.info('Setting timeline to {0}'.format(timeline))

    end_date = datetime.now().date()
    start_date = get_delta_date(datetime.now().date(), timeline)
    end_date_str = convert_date_to_str(end_date)
    start_date_str = convert_date_to_str(start_date)
    invalid_row_index = []
    final_results = pd.DataFrame(columns=['ACCOUNT','STRATEGY','ASOF_DATE','TICKER','TARGET_TRADE','EXECUTED','CHECKS'])
    update_dtype_inputs = {'ACCOUNT' : 'int64',
                           'TARGET_TRADE' : 'object',
                           'EXECUTED' : 'object',
                           'ASOF_DATE' : 'datetime64[ns]'
                          }
    final_results = update_dataframe_dtype(final_results, update_dtype_inputs)

    logging.info('Retrieving Strategies and Account from STRATEGY_CHECK_MASTER ...')
    check_master_data = get_check_master_data_query(env=env)
    logging.debug(check_master_data)
    if check_master_data.empty:
        logging.warn('No Accounts and Strategies found ...')
    else:
        logging.info('Retrieving data for [start date: {0}] and [end date: {1}] ...'.format(start_date_str, end_date_str))
        final_results = final_results.append(get_transactions_data_query(start_date), ignore_index=True)
        logging.debug(final_results)
        logging.info('Checking for missing runs for date ...')
        final_results = check_missing_runs(start_date, end_date, check_master_data, final_results)
        logging.debug(final_results)

    final_results = update_dataframe_dtype(final_results, update_dtype_inputs)
    final_results.sort_values(by=['ASOF_DATE'], inplace=True)
    final_results = final_results.reset_index(drop=True)
    final_results = final_results.reindex(columns=['ACCOUNT','STRATEGY','ASOF_DATE','TICKER','TARGET_TRADE','EXECUTED','CHECKS'])

    logging.info('Results for processing ...')
    logging.info(final_results)

    logging.info('Performing trade checks ...')
    for row in final_results.itertuples():
        print('row: {0}'.format(row.Index))
        if pd.isnull(row.CHECKS):
            if check_invalid_runs(row.ACCOUNT, row.STRATEGY, row.ASOF_DATE, check_master_data):
                invalid_row_index.append(row.Index)
            final_results.loc[row.Index, 'CHECKS'] = check_trades(target=row.TARGET_TRADE, executed=row.EXECUTED)

    logging.info('Check Results:')
    logging.info(final_results)
    logging.info('Invalid Run Index - {0}'.format(invalid_row_index))
    return generate_report(final_results, email_list, invalid_row_index)


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
