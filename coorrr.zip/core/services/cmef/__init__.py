import sys
import enum
AVROTYPES = ['null', 'boolean', 'int', 'long', 'float', 'double', 'bytes', 'string', 'record', 'enum', 'array', 'map', 'fixed']
def getLogDir():
    if sys.platform == 'win32':
        return "//nasprodpm3//PIRANHA_DEV//cmef//logs//"
    return "/appl/piranha_dev/cmef/logs/"

class CmefContentTypes(enum.Enum):
    '''
    Enum for data types
    '''
    JSON          = 'JSON'
    XML           = 'XML'
    INTEGER       = 'INTEGER'
    STRING        = 'STRING'
    FLOAT         = 'FLOAT'
    BLOB          = 'BLOB'
    DATAFRAME     = 'DATAFRAME'
    BINARY        = 'BINARY'
    PDF           = 'PDF'
    TXT           = 'TXT'
    CSV           = 'CSV'
    EXCEL         = 'EXCEL'
    MAT           = 'MAT'
    XLSM          = 'XLSM'
    XLSX          = 'XLSX'
    FILELOCATION  = 'FILELOCATION'

    def __str__(self):
        return self.value

    def __repr__(self):
        return self.value

class ModelStatus(enum.Enum):
    '''
    Enum that says the status of Dask Job
    '''
    SUBMITTED = 'SUBMITTED'
    SUCCESS = 'SUCCESS'
    STARTED = 'STARTED'
    IN_PROGRESS = 'IN_PROGRESS'
    INVALID_MESSAGE = 'INVALID_MESSAGE'
    INVALID_REQUEST_TYPE = 'INVALID_REQUEST_TYPE'
    INVALID_PARAMETER = 'INVALID_PARAMETER'
    INVALID_INPUT_DATA = 'INVALID_INPUT_DATA'
    EMPTY_REQUEST = 'EMPTY_REQUEST'
    INVALID_MODEL = 'INVALID_MODEL'
    INVALID_MODEL_VERSION = 'INVALID_MODEL_VERSION'
    STD_RUNTIME_ERROR = 'STD_RUNTIME_ERROR'
    STD_EXCEPTION = 'STD_EXCEPTION'
    AVRO_EXCEPTION = 'AVRO_EXCEPTION'
    IO_ERROR = 'IO_ERROR'
    FILE_NOT_FOUND = 'FILE_NOT_FOUND'
    UNKNOWN_EXCEPTION = 'UNKNOWN_EXCEPTION'
    FAILED = 'FAILED'
    NOT_USED = 'NOT_USED'

    def __str__(self):
        return self.value

    def __repr__(self):
        return self.value



def process_cmef_job_params(input_params):
    cmef_params = {}
    if isinstance(input_params, dict):
        for param_key, param_value in input_params.iteritems():
            if isinstance(param_value, dict):
                if len(param_value) == 1:
                    for pv_key, pv_value in param_value.iteritems():
                        if pv_key in AVROTYPES:
                            if pv_key in ['map', 'array', 'null']:
                                raise Exception('Type "{0}" not supported for input param "{1}" having value "{2}"'
                                                .format(str(pv_key), str(param_key), str(pv_value)))
                            cmef_params.update({param_key: {pv_key: pv_value}})
                        else:
                            # cmef_params.update({param_key: {'map': param_value}})
                            raise Exception('Type "map" not supported for input param "{0}" having value "{1}"'
                                            .format(str(param_key), str(param_value)))
                else:
                    # cmef_params.update({param_key: {'map': param_value}})
                    raise Exception('Type "map" not supported for input param "{0}" having value "{1}"'
                                    .format(str(param_key), str(param_value)))
            elif isinstance(param_value, bool):
                cmef_params.update({param_key: {'boolean': param_value}})
            elif isinstance(param_value, str):
                cmef_params.update({param_key: {'string': param_value}})
            elif isinstance(param_value, int):
                cmef_params.update({param_key: {'int': param_value}})
            elif isinstance(param_value, float):
                cmef_params.update({param_key: {'float': param_value}})
            elif isinstance(param_value, long):
                cmef_params.update({param_key: {'long': param_value}})
            elif isinstance(param_value, bytes):
                cmef_params.update({param_key: {'bytes': param_value}})
            elif isinstance(param_value, list):
                # cmef_params.update({param_key: {'array': param_value}})
                raise Exception('Type "array" not supported for input param "{0}" having value "{1}"'
                                .format(str(param_key), str(param_value)))
            elif isinstance(param_value, tuple):
                # cmef_params.update({param_key: {'array': param_value}})
                raise Exception('Type "array" not supported for input param "{0}" having value "{1}"'
                                .format(str(param_key), str(param_value)))
            elif param_value is None:
                # cmef_params.update({param_key: {'null': param_value}})
                raise Exception('Type "null" not supported for input param "{0}" having value "{1}"'
                                .format(str(param_key), str(param_value)))
    else:
        raise Exception('Input / Override Params should be of type Dictionary')
    return cmef_params
