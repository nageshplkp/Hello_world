import importlib
import threading
from amps.amps_query import AmpsField
from amps import amps_client
import os, json, sys
import time, datetime, inspect, traceback
import logging
from distributed import Client, wait, get_client
from core.services.cmef.config import CmefConfigParser
from core.config import config_api
from flask import make_response, jsonify
from core.services.cmef.dataapi import create_job_status_object, update_run_status, get_cmef_service_property

_dask_client = None
_env = config_api.get('appenv') or 'dev'
import platform

if any(platform.win32_ver()):
    _configlfile = 'W:\pim%s\pimco_common\model-execution\conf\current\python.conf' % (_env)
else:
    _configlfile = '/appl/pim%s/pimco_common/model-execution/conf/current/python.conf' % (_env)

_pr = CmefConfigParser(_configlfile)

def getDaskClient(grid_url=None):
    daskUrl = _pr.getDaskScheduler()
    if grid_url:
        return Client(grid_url)
    if daskUrl.strip():
        return Client(daskUrl)
    else:
        return Client()


_ampsClient = None


def getAmpsClient(env):
    import uuid
    # hard code it to dev for now as prod does not have amps setup
    if any(platform.win32_ver()):
        _configlfile = 'W:\pim%s\pimco_common\model-execution\conf\current\python.conf' % (env)
    else:
        _configlfile = '/appl/pim%s/pimco_common/model-execution/conf/current/python.conf' % (env)

    pr = CmefConfigParser(_configlfile)

    ampsClient = amps_client.Client('cmef-{0}'.format(uuid.uuid4().get_hex()),
                                    pr.getAmpsCmefTopic(),
                                    instance=pr.getAmpsInstance(),
                                    hosts=[pr.getAmpsServer()])
    ampsClient.start_amps()
    return ampsClient


from core.common.mail import send_mail


def getmethodRef(methodpackagepath=''):
    '''
    :param methodpackagepath:
    :return:
    '''
    pathlist = methodpackagepath.split(".")
    modulepath = ".".join(pathlist[:len(pathlist) - 1])
    md = importlib.import_module(modulepath)
    methodRef = getattr(md, pathlist[-1])
    return methodRef


CMEFRUNURL = {
        'dev': 'http://ptp-dev/cmef/home/runs/',
        'beta': 'http://ptp-beta/cmef/home/runs/',
        'prod': 'http://ptp-prod/cmef/home/runs/',
}

LOGFILELOC = {
        'dev':  '//nasprodpm5/cmef_dev/dask/logs/',
        'beta': '//nasprodpm5/cmef_beta/dask/logs/',
        'prod': '//nasprodpm4/cmef/dask/logs',
}


def get_run_url_msg(env,runid):
    runurl = CMEFRUNURL.get(env) + str(runid)
    return '''
    Run Url : %s
    ''' % (runurl)


def setup_cmef_logging(run_id, log_level, env, log_file=None):
    import socket
    if log_level:
        logger_level = logging.getLevelName(log_level.upper())
        if not isinstance(logger_level, int):
            logger_level = logging.INFO
    else:
        if env == 'beta' or env == 'prod':
            logger_level = logging.INFO
        else:
            logger_level = logging.DEBUG

    if log_file is None:
        log_dir = LOGFILELOC.get(env)
        log_file = os.path.join(log_dir,socket.gethostname() + "_" + str(run_id) + ".log" )
    # Setting raising of log exceptions to False as stderr is being redirected and can cause a recursive loop causing python recursion limit issue
    logging.raiseExceptions = False
    from logging.handlers import RotatingFileHandler
    fhandler = RotatingFileHandler(log_file)
    # Setting root logger to DEBUG so that handler can then select INFO or DEBUG
    logging.getLogger('').setLevel(logging.DEBUG)
    fhandler.setLevel(logger_level)
    formatter = logging.Formatter('%(asctime)s [%(name)s] [%(module)s:%(lineno)d] %(levelname)s - %(message)s')
    fhandler.setFormatter(formatter)
    logging.getLogger('').addHandler(fhandler)
    # Setting stdout and stderr to logger to capture print and other outputs
    orig_stdout = sys.stdout    # Backing up original sys.stdout setting
    orig_stderr = sys.stderr    # Backing up original sys.stderr setting
    stdout_logger = StreamToLogger(logger=logging.getLogger(''), log_level=logging.INFO)
    stderr_logger = StreamToLogger(logger=logging.getLogger(''), log_level=logging.ERROR)
    sys.stdout = stdout_logger
    sys.stderr = stderr_logger
    return log_file, fhandler, orig_stdout, orig_stderr


def cmef_setup_subprocess_logging(run_id, log_level, env):
    if log_level:
        logger_level = logging.getLevelName(log_level.upper())
        if not isinstance(logger_level, int):
            logger_level = logging.INFO
    else:
        if env == 'beta' or env == 'prod':
            logger_level = logging.INFO
        else:
            logger_level = logging.DEBUG
    # Setting root logger to DEBUG so that handler can then select INFO or DEBUG
    logging.getLogger('').setLevel(logging.DEBUG)
    cmef_log_format = '%(asctime)s [%(name)s] [%(module)s:%(lineno)d] %(levelname)s - %(message)s'
    # Check to see if pypimco initialization sets up handlers for loggers
    # Set their format and level as by default one of them is a streamhandler captured by subprocess communicate command
    # Else utilize basicConfig to set format and level of new streamhandler
    if logging.getLogger('').handlers:
        formatter = logging.Formatter(cmef_log_format)
        for each_handler in logging.getLogger('').handlers:
            each_handler.setFormatter(formatter)
            each_handler.setLevel(logger_level)
    else:
        logging.basicConfig(format=cmef_log_format, level=logger_level)
    # Setting raising of log exceptions to False as stderr is being redirected and can cause a recursive loop causing python recursion limit issue
    logging.raiseExceptions = False
    orig_stdout = sys.stdout  # Backing up original sys.stdout setting
    orig_stderr = sys.stderr  # Backing up original sys.stderr setting
    stdout_logger = StreamToLogger(logger=logging.getLogger(''), log_level=logging.INFO)
    stderr_logger = StreamToLogger(logger=logging.getLogger(''), log_level=logging.ERROR)
    sys.stdout = stdout_logger
    sys.stderr = stderr_logger
    return orig_stdout, orig_stderr


def cmef_r_job(entry_function, run_id, input_data, env, job_name=None, log_level=None):
    import subprocess
    import socket
    import gc
    from core.services.cmef.dataapi import _setup_ids, save_logdata
    _setup_ids(run_id, env)

    log_file, fhandler, orig_stdout, orig_stderr = setup_cmef_logging(run_id=run_id, log_level=log_level, env=env)
    # TODO : Find a way to handle cmef runtime environments rather than hard coding them below
    cmef_runtime_vars = ['cmef_unix_work_dir', 'cmef_win_work_dir', 'cmef_report_name',
                         'cmef_desk_name', 'cmef_job_name', 'cmef_current_timestamp', 'cmef_env']

    r_search_path_vars = ['PYTHONPATH']
    if platform.system() == 'Windows':
        entry_function = entry_function.replace('/','\\')
    logging.info('CMEF Inputs: {0}'.format(input_data))
    # Extracting R inputs from CMEF inputs
    r_inputs = {}
    for key, data in input_data.iteritems():
        if isinstance(data, dict):
            for data_type, value in data.iteritems():
                r_inputs.update({key: value})
        else:
            r_inputs.update({key: data})
    # Preparing R execution environment
    try:
        # Preparing cmef inputs and runtime args
        logging.info('Processing CMEF Inputs')
        cmef_runtime_args = {}
        for each_var in cmef_runtime_vars:
            if each_var in r_inputs:
                cmef_runtime_args.update({each_var: r_inputs.get(each_var)})
                del r_inputs[each_var]
        cmef_runtime_args.update({'cmef_run_id': run_id, 'cmef_env': env})

        # Setting up path environment for use for R execution
        logging.info('Setting up R environment')
        r_env = os.environ.copy()
        r_env["PATH"] = '{0}{1}{2}{3}{4}'.format(os.path.join(os.environ.get('R_HOME'), 'bin'), os.pathsep,
                                                 os.environ.get('PANDOC_HOME'), os.pathsep, os.environ.get('PATH'))
        for arg, value in cmef_runtime_args.iteritems():
            logging.info('Adding "{0}" to R Environment with value "{1}"'.format(arg.upper(), value))
            r_env[arg.upper()] = str(value)
        r_env = validate_environ_vars(r_env)
        logging.info('Environment Path: {0}'.format(r_env["PATH"]))

        # Preparing script arguments
        logging.info('Preparing R script inputs')
        r_input_params = ''
        if 'args' in r_inputs:
            for each_value in r_inputs.get('args').split(','):
                r_input_params += '"{0}" '.format(each_value)
        else:
            for arg, arg_value in r_inputs.iteritems():
                if len(arg) == 1:
                    arg_separator = '-'
                else:
                    arg_separator = '--'
                r_input_params += '{0}{1} "{2}" '.format(arg_separator, arg, arg_value)

        # Searching for entry function in R Scripts search path
        r_script_path = search_r_script(env_vars=r_search_path_vars, entry_function=entry_function)
        if r_script_path is None:
            raise Exception('Unable to find R Script "{0}" under search path defined by environment vars "{1}"'.format(entry_function, r_search_path_vars))
        r_exe_cmd = 'Rscript --verbose {0} {1}'.format(r_script_path, r_input_params)
    except:
        import traceback
        msg = traceback.format_exc() or ''
        msg += get_run_url_msg(env, run_id)
        logging.error(msg)
        fhandler.flush()
        try:
            save_logdata(log_file)
        except Exception as e:
            sys.stdout = orig_stdout
            logging.getLogger('').removeHandler(fhandler)
            fhandler.close()
            msg += 'Unable to save log data for run_id "{0}":\n{1}'.format(run_id, str(e))
            raise Exception(msg)
        sys.stdout = orig_stdout
        logging.getLogger('').removeHandler(fhandler)
        fhandler.close()
        result_as_dict = {'status': 'FAILED', 'message': msg}
        return result_as_dict

    # capture path variable prior to job run for debugging
    path_prior_run = os.environ.get('PATH')

    logging.info('Running on: {0}'.format(socket.gethostname()))
    logging.info('Dask Version: {0}'.format(os.environ.get('daskVersion')))
    logging.info('Pypimco Version: {0}'.format(os.environ.get('pypimcoVersion')))
    logging.info('R Scripts Search Path: {0}'.format(os.environ.get('PYTHONPATH')))
    logging.info('R HOME: {0}'.format(os.environ.get('R_HOME')))
    logging.info('PANDOC HOME: {0}'.format(os.environ.get('PANDOC_HOME')))
    logging.info('Log File Path: {0}'.format(log_file.replace('/', '\\')))
    logging.info('Running the following')
    logging.info('=========================================================================================================================')
    logging.info(r_exe_cmd)
    try:
        execution = subprocess.Popen(r_exe_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     cwd=os.path.dirname(r_script_path), env=r_env, shell=True)
        exec_out, exec_err = execution.communicate()
        if exec_out:
            logging.info(exec_out)
        if exec_err:
            logging.error(exec_err)
        if execution.returncode == 0:
            msg = '{0}'.format(entry_function)
            msg += get_run_url_msg(env, run_id)
            result_as_dict = {'status': 'SUCCESS', 'message': msg}
        else:
            raise Exception(exec_err)
    except:
        import traceback
        msg = traceback.format_exc() or ''
        logging.error(msg)
        msg += get_run_url_msg(env, run_id)
        result_as_dict = {'status': 'FAILED', 'message': msg}

    finally:
        # capture path variable after job run for debugging
        path_after_run = os.environ.get('PATH')
        if path_prior_run != path_after_run and env == 'dev':
            email_msg = 'Job Name: {0}\n\nPath Prior Run:\n{1}\n\nPath After Run:\n{2}'.format(job_name, path_prior_run,
                                                                                               path_after_run)
            send_mail(mailFrom='CMEFDEV@pimco.com', mailTo='ashah@pimco.com,sumgowda@pimco.com',
                      subj='[{0}] {1} - Path Variable Changed: {2}'.format(env.upper(), job_name, socket.gethostname()),
                      msg=email_msg)
        logging.info("=========================================================================================================================")
        cleanup_counter = gc.collect()
        logging.debug('Unreferenced objects deleted as part of GC: {0}'.format(cleanup_counter))
        fhandler.flush()
        try:
            save_logdata(log_file)
        except Exception as e:
            sys.stdout = orig_stdout
            logging.getLogger('').removeHandler(fhandler)
            fhandler.close()
            msg += 'Unable to save log data for run_id "{0}":\n{1}'.format(run_id, str(e))
            raise Exception(msg)
        sys.stdout = orig_stdout
        logging.getLogger('').removeHandler(fhandler)
        fhandler.close()
        return result_as_dict


def cmef_python_job(entry_function, run_id, input_data, env, job_name=None, log_level=None):
    """
    Decorator to capture standard output
    """
    log_file, fhandler, orig_stdout, orig_stderr = setup_cmef_logging(run_id=run_id, log_level=log_level, env=env)
    cmef_subprocess_flag = False
    subprocess_cmd = ''
    cmef_runtime_args = {'cmef_run_id': run_id, 'cmef_env': env}

    from core.services.cmef.cmef import getmethodRef
    import inspect
    from core.services.cmef.dataapi import _setup_ids
    _setup_ids(run_id,env)
    from core.services.cmef.dataapi import save_logdata
    #get grid worker env and print them

    import socket
    import gc
    # capture path variable prior to job run for debugging
    path_prior_run = os.environ.get('PATH')

    logging.info("Running on : %s " % ( socket.gethostname() ))
    logging.info("dask version  : %s " % (os.environ.get('daskVersion')))
    logging.info("Pypimco version  : %s " % (os.environ.get('pypimcoVersion')))
    logging.info("PYTHONPATH: %s " % (os.environ.get('PYTHONPATH')))
    logging.info("PYPIMLIB_ORACLE_HOME: %s " % (os.environ.get('PYPIMLIB_ORACLE_HOME')))
    logging.info("PYPIMLIB_SYBASE_HOME: %s " % (os.environ.get('PYPIMLIB_SYBASE_HOME')))
    logging.info("PYPIMLIB_HOME: %s " % (os.environ.get('PYPIMLIB_HOME')))
    logging.info("PYPIMLIB_LIB_PATH: %s " % (os.environ.get('PYPIMLIB_LIB_PATH')))
    logging.info("PYPIMLIB_OCS: %s " % (os.environ.get('PYPIMLIB_OCS')))
    logging.info("Log File Path: %s " % (log_file.replace('/', '\\')))
    logging.info("Running the following")
    logging.info(
        "=========================================================================================================================")
    import_cmd = "from %s import %s" % (".".join(entry_function.split(".")[:-1]), entry_function.split(".")[-1])

    try:
        f = getmethodRef(entry_function)
        # Setting root logger to DEBUG incase the imports have modified the logger settings
        logging.getLogger('').setLevel(logging.DEBUG)
        argsinfo = inspect.getargspec(f)
        paramKeys = input_data.keys()
        additionalArgs = {}
        additionalArgs.update(cmef_runtime_args)
        # check if cmef_subprocess flag is set
        if 'cmef_forkprocess' in paramKeys:
            temp_data = input_data.get('cmef_forkprocess')
            if isinstance(temp_data, dict):
                for data_type, value in temp_data.iteritems():
                    temp_value = value
            else:
                temp_value = temp_data
            if temp_value:
                cmef_subprocess_flag = True
        # if there are keys not needed remove them from input and add them to additionalArgs
        for key in paramKeys:
            if key not in argsinfo[0]:
                temp_data = input_data.get(key)
                if isinstance(temp_data, dict):
                    for data_type, value in temp_data.iteritems():
                        additionalArgs.update({key: value})
                elif temp_data:
                    additionalArgs.update({key: temp_data})
                del input_data[key]

        argsParamsData = inspect.getcallargs(f, **input_data)

    except:
        import traceback
        msg = traceback.format_exc() or ''
        msg += get_run_url_msg(env,run_id)
        logging.error(msg)
        fhandler.flush()
        try:
            save_logdata(log_file)
        except Exception as e:
            sys.stdout = orig_stdout
            sys.stderr = orig_stderr
            logging.getLogger('').removeHandler(fhandler)
            fhandler.close()
            msg += 'Unable to save log data for run_id "{0}":\n{1}'.format(run_id, str(e))
            raise Exception(msg)
        sys.stdout = orig_stdout
        sys.stderr = orig_stderr
        logging.getLogger('').removeHandler(fhandler)
        fhandler.close()
        result_as_dict = {'status': 'FAILED', 'message': msg}
        return result_as_dict
    mandatoryArgs = []
    numberOfDefaultArgs = 0
    numberofArgs = 0
    if argsinfo[0]: numberofArgs =  len(argsinfo[0])
    if argsinfo[3]: numberOfDefaultArgs = len(argsinfo[3])
    usedArgs = []
    if argsinfo[0]:
        for each in argsinfo[0][:numberofArgs-numberOfDefaultArgs]:
            argData = argsParamsData.get(each)
            usedArgs.append(each)
            if isinstance(argData, dict):
                #TODO what happens if the data type to be passed is dict
                for k, value in argData.iteritems():
                    mandatoryArgs.append(value)
            elif argData:
                mandatoryArgs.append(argData)

    optionalArgs = {}
    if argsinfo[3]:
        for each in argsinfo[0][numberofArgs-numberOfDefaultArgs:]:
            argData = argsParamsData.get(each)
            usedArgs.append(each)
            if isinstance(argData, dict):
                # TODO what happens if the data type to be passed is dict
                for k, value in argData.iteritems():
                    optionalArgs[each] = value
            elif argData is not None:
                optionalArgs[each] = argData

    #*args
    starArgs = []
    if argsinfo[1]:
        pass
    #**kwargs
    if argsinfo[2]:
        optionalArgs.update(additionalArgs)


    def cmef_print_format(value):
        if isinstance(value, (str, unicode)):
            return "'" + str(value) + "'"
        return str(value)


    func_call = f.__name__ + "(" + ",".join([cmef_print_format(each) for each in mandatoryArgs]) + ("," if mandatoryArgs else "") \
                + ",".join([ key + "=" + cmef_print_format(kv) for key, kv in optionalArgs.iteritems() ]) + ")"
    if not cmef_subprocess_flag:
        logging.info(import_cmd)
        logging.info(func_call)
    else:
        function_name = entry_function.split(".")[-1]
        temp_imports = '{0}; from core.services.cmef.cmef import cmef_forkprocess;'.format(import_cmd)
        temp_decorator_cmd = 'wrapper = cmef_forkprocess({0}, \'{1}\'); {2} = wrapper({3}); {4}'.format(run_id, env, function_name, function_name, func_call)
        subprocess_cmd = 'python -c "{0} {1}"'.format(temp_imports, temp_decorator_cmd)
        logging.info(subprocess_cmd)
    logging.info("======================== CMEF RUN command with runid =====================================================================")
    logging.info("from core.services.cmef.cmef import cmef_main")
    logging.info("cmef_main" + "('" + job_name + "'," + str(run_id) + ",'" + env + "'," + ",".join([cmef_print_format(each) for each in mandatoryArgs]) + ("," if mandatoryArgs else "")
                 + ",".join([ key + "=" + cmef_print_format(kv) for key, kv in optionalArgs.iteritems() ])
                 + ")")
    logging.info("======================== CMEF RUN command with new runid====================================================================")
    logging.info("from core.services.cmef.cmef import cmef_main")
    logging.info("cmef_main" + "('" + job_name + "',None,'" + env + "'," + ",".join(
        [cmef_print_format(each) for each in mandatoryArgs]) + ("," if mandatoryArgs else "")
                 + ",".join([key + "=" + cmef_print_format(kv) for key, kv in optionalArgs.iteritems()])
                 + ")")
    logging.info(
        "=====================================================================================================================================")
    try:
        if not cmef_subprocess_flag:
            f(*mandatoryArgs,**dict(optionalArgs))
            msg = "%s" % (entry_function)
            msg += get_run_url_msg(env, run_id)
            result_as_dict = {'status': 'SUCCESS', 'message': msg}
        else:
            import subprocess
            # Get scheduler info to store as environment variable
            try:
                current_client = get_client()    # Getting client from worker node
            except:
                current_client = None
            # Setting up path environment for use for R execution
            subprocess_env = os.environ.copy()
            # Setting scheduler address as environment variable to pass to subprocess
            if current_client:
                subprocess_env['CMEF_GRID_URL'] = str(current_client.scheduler.address)
            else:
                subprocess_env['CMEF_GRID_URL'] = ''
            subprocess_env = validate_environ_vars(subprocess_env)
            execution = subprocess.Popen(subprocess_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                         env=subprocess_env, shell=True)
            exec_out, exec_err = execution.communicate()
            if exec_out:
                logging.info('\n' + exec_out)
            if execution.returncode != 0:
                if not exec_err:
                    exec_err = 'CMEF Subprocess Job Execution FAILED'
                raise Exception(exec_err)
            else:
                logging.info('\n' + exec_err)    # printing stderr even without error as logging writes to stderr when subprocess captures output
        msg = '{0}'.format(entry_function)
        msg += get_run_url_msg(env, run_id)
        result_as_dict = {'status': 'SUCCESS', 'message': msg}

    except:
        import traceback
        msg = traceback.format_exc() or ''
        logging.error(msg)
        msg += get_run_url_msg(env, run_id)
        result_as_dict = {'status': 'FAILED', 'message': msg}

    finally:
        # capture path varaible after job run for debugging
        path_after_run = os.environ.get('PATH')
        if path_prior_run != path_after_run and env == 'dev':
            email_msg = 'Job Name: {0}\n\nPath Prior Run:\n{1}\n\nPath After Run:\n{2}'.format(job_name, path_prior_run,
                                                                                               path_after_run)
            send_mail(mailFrom='CMEFDEV@pimco.com', mailTo='ashah@pimco.com,sumgowda@pimco.com',
                      subj='[{0}] {1} - Path Variable Changed: {2}'.format(env.upper(), job_name, socket.gethostname()),
                      msg=email_msg)
        logging.info("=========================================================================================================================")
        cleanup_counter = gc.collect()
        logging.debug('Unreferenced objects deleted as part of GC: {0}'.format(cleanup_counter))
        fhandler.flush()
        try:
            save_logdata(log_file)
        except Exception as e:
            sys.stdout = orig_stdout
            sys.stderr = orig_stderr
            logging.getLogger('').removeHandler(fhandler)
            fhandler.close()
            msg += 'Unable to save log data for run_id "{0}":\n{1}'.format(run_id, str(e))
            raise Exception(msg)
        sys.stdout = orig_stdout
        sys.stderr = orig_stderr
        logging.getLogger('').removeHandler(fhandler)
        fhandler.close()
        return result_as_dict


def amps_add_new_job( runid=None, status=None,
              start_date=None, errorMsg='', env=config_api.get('appenv')):
    '''
    :param ampsclient:
    :param runid:
    :param status:
    :param start_date:
    :param errorMsg:
    :return:
    '''

    with getAmpsClient(env) as ampsclient:
        jobdata = dict(runid=runid,
                   status=str(status),
                   start_date=start_date,
                   errorMsg=errorMsg)

        ampsclient.publish(jobdata, _pr.getAmpsCmefTopic())


def amps_update_job_status(runid=None, status=None, errorMsg='', log='', env=config_api.get('appenv')):
    '''

    :param rnid:
    :param status:
    :param errorMsg:
    :return:
    '''
    with getAmpsClient(env) as ampsclient:
        amps_filter = AmpsField('key') != runid
        amps_filter = amps_filter.amps_repr()
        msgs = ampsclient.sow()
        for each in msgs:
            try:
                # print each , jobid
                jsonob = json.loads(each)
                if u'runid' in jsonob and jsonob['runid'] == runid:
                    jsonob['status'] = str(status)
                    jsonob['errorMsg'] = str(errorMsg)
                    jsonob['log'] = log
                    ampsclient.publish(jsonob, _pr.getAmpsCmefTopic())
            except:
                import traceback
                print traceback.format_exc()
                print "Error in looking at apms job"


def getmethodRef(methodpackagepath=''):
    pathlist = methodpackagepath.split(".")
    modulepath = ".".join(pathlist[:len(pathlist) - 1])
    md = importlib.import_module(modulepath)
    methodRef = getattr(md, pathlist[-1])
    return methodRef


def check_dask_job_status(run_id, env, job_id, job_name, user, grid, notify_email, is_async, fut_job, dask_client):
    from core.services.cmef.dataapi import _run_id, _env, save_logdata, _setup_ids, get_run_status
    import time
    _setup_ids(run_id,env)
    if not notify_email:
        notify_email = "CMEFDEV@pimco.com"
    logging.info('Checking Status for run_id "{0}"'.format(run_id))
    try:
        while not fut_job.done():
            if get_run_status(run_id=run_id, env=env) == 'CANCELLED':
                logging.info('Dask Job Cancel request received for run_id "{0}"'.format(run_id))
                try:
                    dask_client.cancel([fut_job])
                    while not fut_job.cancelled():
                        logging.info('Waiting on cancellation of Dask job with run_id "{0}"'.format(run_id))
                except Exception as e:
                    logging.exception('Unable to cancel dask job with run_id "{0}"'.format(run_id))
            else:
                time.sleep(1)
        if fut_job.status == 'error':
            result_exception = fut_job.exception()
            logging.error('Dask Job executon FAILED for run_id "{0}"'.format(run_id))
            msg = result_exception.__repr__()   # Using repr to is prints the exception class as well for worker killed errors
            logging.error(msg)
            try:
                save_logdata(contents=msg)
            except Exception as e:
                logging.exception('Unable to save log data for run_id "{0}"'.format(run_id))
            if is_async:
                try:
                    update_run_status(run_id=run_id, env=env, job_id=job_id, job_name=job_name, status='FAILED',
                                      user=user, grid=grid, message=msg)
                except Exception as e2:
                    logging.exception('Unable to update status for run_id "{0}" for job_name "{1}" to FAILED\n'.format(run_id, job_name))
                    try:
                        # Adding cmefdev to notifications for critical errors
                        msg += get_run_url_msg(env, run_id)
                        notify_email = notify_email + ',CMEFDEV@pimco.com'
                        send_mail('CMEFDEV@pimco.com', notify_email,
                                  subj="[{0}][FAILED] {1} ".format(env, job_name), msg=msg)
                    except Exception as e1:
                        logging.exception('Unable to send email on failure for run_id "{0}"'.format(run_id))
            else:
                response_as_dict = {'run_id': run_id, 'env': env, 'job_id': job_id, 'job_name': job_name,
                                    'status': 'FAILED', 'user': user, 'grid': grid, 'message': msg}
                return response_as_dict
        elif fut_job.status == 'cancelled':
            logging.info('Dask Job execution CANCELLED for run_id "{0}"'.format(run_id))
            # Capturing exception from future.result() call for cancelled task to get cancel exception
            try:
                fut_job.result()
            except Exception as e3:
                msg = traceback.format_exc()
                try:
                    save_logdata(contents=msg)
                except Exception as e:
                    logging.exception('Unable to save log data for run_id "{0}"'.format(run_id))
        else:
            result_response = fut_job.result()
            logging.info('Dask Job execution COMPLETE for run_id "{0}"'.format(run_id))
            if is_async:
                try:
                    update_run_status(run_id=run_id, env=env, job_id=job_id, job_name=job_name,
                                      status=result_response.get('status'), user=user, grid=grid, message=result_response.get('message'))
                except Exception as e:
                    logging.exception('Unable to update status for run_id "{0}" for job_name "{1}" to {2}\n'
                                      .format(run_id, job_name, result_response.get('status')))
                    try:
                        # Adding cmefdev to notifications for critical errors
                        notify_email = notify_email + ',CMEFDEV@pimco.com'
                        send_mail('CMEFDEV@pimco.com', notify_email,
                                  subj='[{0}][{1}] {2} '.format(env, result_response.get('status'), job_name),
                                  msg=result_response.get('message'))
                    except Exception as e:
                        logging.exception('Unable to send email on failure for run_id "{0}"'.format(run_id))
            else:
                response_as_dict = {'run_id': run_id, 'env': env, 'job_id': job_id, 'job_name': job_name,
                                    'status': result_response.get('status'), 'user': user, 'grid': grid,
                                    'message': result_response.get('message')}
                return response_as_dict
    except Exception as e:
        msg = traceback.format_exc() or ''
        logging.error(msg)
        try:
            save_logdata(contents=msg)
        except Exception as e:
            logging.exception('Unable to save log data for run_id "{0}"'.format(run_id))
        if is_async:
            try:
                update_run_status(run_id=run_id, env=env, job_id=job_id, job_name=job_name, status='FAILED',
                                  user=user, grid=grid, message=msg)
            except Exception as e1:
                logging.exception('Unable to update status for run_id "{0}"'.format(run_id))
                try:
                    # Adding cmefdev to notifications for critical errors
                    msg += get_run_url_msg(env, run_id)
                    notify_email = notify_email + ',CMEFDEV@pimco.com'
                    send_mail('CMEFDEV@pimco.com', notify_email,
                              subj='[{0}][FAILED] {1} '.format(env, job_name), msg=msg)
                except Exception as e:
                    logging.exception('Unable to send email on failure for run_id "{0}"'.format(run_id))
        else:
            response_as_dict = {'run_id': run_id, 'env': env, 'job_id': job_id, 'job_name': job_name,
                                'status': 'FAILED', 'user': user, 'grid': grid, 'message': msg}
            return response_as_dict
    logging.info('Status Checking COMPLETE for run_id "{0}"'.format(run_id))
    return


def execute_job_wrapper(run_id, run_user, entry_function, input_data, job_id, job_name, language, env='dev',
                        notify_email='', is_async=True, grid_url= None, grid_platform='', log_level = None):
    # For older jobs where language was not set to upper case
    language = language.upper()
    if not notify_email:
        notify_email = 'CMEFDEV@pimco.com'

    from core.services.cmef.dataapi import _run_id, _env, save_logdata, _setup_ids
    _setup_ids(run_id,env)
    try:
        #set the cmef env
        logging.info('Running run_id "{0}" on "{1}"'.format(run_id, _env))
        if grid_url:
            logging.info('Running job with run id "{0}" on user specified grid - "{0}"'.format(run_id, grid_url))
        else:
            grid_url = get_cmef_service_property(property_name='dask.scheduler.url', env=env)
            logging.info('Running job with run id "{0}" on default grid - "{1}"'.format(run_id, grid_url))
        with get_dask_client(scheduler=grid_url) as client:
            if language == 'PYTHON':
                daskfut = client.submit(cmef_python_job, entry_function, run_id, input_data, env, job_name,
                                        log_level, pure=False, priority=1000)
            elif language == 'R':
                daskfut = client.submit(cmef_r_job, entry_function, run_id, input_data, env, job_name,
                                        log_level, pure=False, priority=1000)
            if is_async:
                check_dask_job_status(run_id=run_id, env=env, job_id=job_id, job_name=job_name, user=run_user,
                                      grid=grid_platform, notify_email=notify_email, is_async=is_async, fut_job=daskfut,
                                      dask_client=client)
                return
            else:
                response_as_dict = check_dask_job_status(run_id=run_id, env=env, job_id=job_id, job_name=job_name,
                                                         user=run_user, grid=grid_platform, notify_email=notify_email,
                                                         is_async=is_async, fut_job=daskfut, dask_client=client)
                return response_as_dict
    except Exception as exc:
        msg = traceback.format_exc()
        logging.error(msg)
        try:
            save_logdata(contents=msg)
        except Exception as e:
            logging.exception('Unable to save log data for run_id "{0}"'.format(run_id))
        if is_async:
            try:
                update_run_status(run_id=run_id, env=env, job_id=job_id, job_name=job_name, status='FAILED',
                                  user=run_user, grid=grid_platform, message=msg)
            except Exception as e1:
                logging.exception('Unable to update status for run_id "{0}"'.format(run_id))
                try:
                    # Adding cmefdev to notifications for critical errors
                    msg += get_run_url_msg(env, run_id)
                    notify_email = notify_email + ',CMEFDEV@pimco.com'
                    send_mail('CMEFDEV@pimco.com', notify_email,
                              subj='[{0}][FAILED] {1} '.format(env, job_name), msg=msg)
                except Exception as e:
                    logging.exception('Unable to send email on failure for run_id "{0}"'.format(run_id))
        else:
            response_as_dict = {'run_id': run_id, 'env': env, 'job_id': job_id, 'job_name': job_name, 'status': 'FAILED',
                                'user': run_user, 'grid': grid_platform, 'message': msg}
            return response_as_dict


def get_dask_client(scheduler=None):
    '''
    :param scheduler: name of the scheduler to connect to
    :return:
    If running withng CMEF framework it will automaticlaly connecto to scheduler on that env
    If running locally , it creates a local scheduler which can spawn processes.
    '''
    from distributed import get_client, Client
    if scheduler:
        return Client(scheduler)
    else:
        try:
            return get_client()
        except:
            return Client()


def create_cmef_response(run_id, env, job_id, job_name, status, user, grid, status_code=200, message=None):
    status_obj = create_job_status_object(run_id=run_id, env=env, job_id=job_id, job_name=job_name,
                                          status=status, user=user, grid=grid, message=message)
    response = make_response(jsonify(status_obj), status_code)
    response.headers['X-CMEF-USER'] = user
    response.headers['Content-Type'] = 'application/json'
    return response


class StreamToLogger(object):
    """
    Fake file-like stream object that redirects writes to a logger instance.
    """

    def __init__(self, logger, log_level=logging.INFO):
        self.logger = logger
        self.log_level = log_level
        self.linebuf = ''

    def write(self, buf):
        for line in buf.rstrip().splitlines():
            self.logger.log(self.log_level, line.rstrip())

    def flush(self):
        pass


from functools import wraps
def cmef_multi_task(f):
    '''
    Use this as a wrapper if you want to capture the logs of a parallel job
    :param f: function that needs to be run as seperate task
    :return: returns set with 3 items , result of the job , list of log messages and exception message if there was any
    '''
    @wraps(f)
    def decorated_function(*args, **kwargs):
        import tempfile, os,sys
        # get temp file
        tfile = tempfile.NamedTemporaryFile(suffix=".log")
        tfilename = tfile.name
        tfile.close()
        import logging
        from logging.handlers import RotatingFileHandler
        fhandler = RotatingFileHandler(tfilename)
        fhandler.setLevel(logging.DEBUG)
        logging.getLogger('').addHandler(fhandler)
        root_log_level = logging.getLogger('').level
        logging.getLogger('').setLevel(logging.DEBUG)
        orig_stdout = sys.stdout  # Backing up original sys.stdout setting
        stdout_logger = StreamToLogger(logger=logging.getLogger(''), log_level=logging.INFO)
        sys.stdout = stdout_logger
        exception = None
        results = None
        try:
            results =  f(*args, **kwargs)

        except:
            import traceback
            exception = traceback.format_exc()

        fhandler.flush()
        logfile = open(tfilename ,'r')
        log_data = logfile.readlines()
        logfile.close()
        logging.getLogger('').removeHandler(fhandler)
        #restore log level
        logging.getLogger('').setLevel(root_log_level)
        fhandler.close()
        os.remove(tfilename)
        sys.stdout = orig_stdout
        return ( results  , log_data, exception)
    return decorated_function


def cmef_parallel_log_collector(f):
    '''
    Use this decorator to create cmef response object containing result, exception and output
    :param f: function that needs to be run as separate task for multi processing or in separate process
    :return: returns set with 3 items , result of the job , output / logs and exception message if there was any error
    '''
    @wraps(f)
    def decorated_function(*args, **kwargs):
        import tempfile
        import os
        import sys
        import gc
        results = None
        log_data = None
        exception = None
        # Get temp file
        with tempfile.NamedTemporaryFile(suffix=".log") as temp_file:
            temp_file_name = temp_file.name
        root_log_level = logging.getLogger('').level
        log_file, fhandler, orig_stdout, orig_stderr = setup_cmef_logging(run_id=None, log_level='DEBUG', env=None, log_file=temp_file_name)
        try:
            results = f(*args, **kwargs)
        except Exception as e:
            import traceback
            exception = traceback.format_exc()
        finally:
            cleanup_counter = gc.collect()
            logging.debug('Unreferenced objects deleted as part of GC: {0}'.format(cleanup_counter))
            fhandler.flush()
            with open(temp_file_name, 'r') as log_file:
                log_data = log_file.read()
            # Restore log level
            logging.getLogger('').setLevel(root_log_level)
            sys.stdout = orig_stdout
            sys.stderr = orig_stderr
            logging.getLogger('').removeHandler(fhandler)
            fhandler.close()
            os.remove(temp_file_name)
            return {'result': results, 'exception': exception, 'output': log_data}
    return decorated_function


def cmef_main(job_name , run_id = None, run_env = 'dev', *args , **kwargs):
    '''
    :param job_name: Name of the job to execute, use this to run a cmef job locally
    :param run_id:  Provide run id if you want to override, else pass None
    :param run_env: the end you jobs to be created of saved
    :param args:
    :param kwargs:
    :return:
    '''
    from core.services.cmef.dataapi import get_job_details
    from core.services.cmef.dataapi import create_run
    from core.services.cmef.dataapi import update_run_status
    job_details = get_job_details(job_name,run_env)
    if not job_details:
        raise Exception("job not found %s " % ( job_name ) )
    from core.services.cmef.dataapi import _setup_ids
    if not run_id:
        run_details = create_run(job_name,env=run_env)
        run_id = run_details.get('runId')
    _setup_ids(run_id , run_env)
    functin_path = job_details.get('modelData').get('entryFunction')
    import getpass
    username = getpass.getuser()
    update_run_status(run_id, run_env, job_details.get('jobId'), job_name, 'CREATED', username, None, message=None)
    try:
        f = getmethodRef(functin_path)
        f(*args , **kwargs)
        update_run_status(run_id, run_env, job_details.get('jobId'), job_name, 'SUCCESS', username, None,
                          message=None)
    except:
        import traceback
        message = traceback.format_exc()
        update_run_status(run_id, run_env, job_details.get('jobId'), job_name, 'FAILED',username, None, message=message)


def forkprocess(fork_func, timeout_seconds, *args, **kwargs):
    """
    Allows user to execute a given function in a separate process
    :param fork_func: function to be executed
    :param timeout_seconds: time out for the process execution
    :param args: args for the function
    :param kwargs: keyword args for the function
    :return: results from function execution
    """
    import multiprocessing
    from distributed import get_worker
    is_worker = False
    # Overriding multiprocessing module property for dask runs as daemonic processes are not allowed to have child processes
    # This has side effect where child processes can spin additional child processes
    # Only setting this for worker processes
    # TODO: Find way to stop recursive child process creations if forkprocess is used recursively
    try:
        current_worker = get_worker()
        is_worker = True
    except:
        pass
    if is_worker:
        if multiprocessing.process._current_process._daemonic:
            multiprocessing.process._current_process._daemonic = False
    pool = multiprocessing.Pool(processes=1)
    try:
        fork_process = pool.apply_async(func=fork_func, args=args, kwds=kwargs)
        results = fork_process.get(timeout=timeout_seconds)
        pool.close()
        pool.join()
        if is_worker:
            if not multiprocessing.process._current_process._daemonic:
                multiprocessing.process._current_process._daemonic = True
    except Exception as e:
        pool.terminate()
        pool.join()
        if is_worker:
            if not multiprocessing.process._current_process._daemonic:
                multiprocessing.process._current_process._daemonic = True
        raise Exception(e)
    if results.get('output'):
        logging.info('\n' + results.get('output'))
    if results.get('exception'):
        logging.error('\n' + results.get('exception'))
    return results.get('result')


def cmef_forkprocess(run_id, env, log_level=None):
    def cmef_subprocess_decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            from core.services.cmef.dataapi import _run_id, _env, _setup_ids
            _setup_ids(run_id, env)
            import sys
            import gc
            root_log_level = logging.getLogger('').level
            orig_stdout, orig_stderr = cmef_setup_subprocess_logging(run_id=run_id, log_level=None, env=env)
            try:
                func(*args, **kwargs)
            except Exception as e:
                import traceback
                exception = traceback.format_exc()
                raise Exception(exception)
            finally:
                cleanup_counter = gc.collect()
                logging.debug('Unreferenced objects deleted as part of GC: {0}'.format(cleanup_counter))
                sys.stdout = orig_stdout
                sys.stderr = orig_stderr
                logging.getLogger('').setLevel(root_log_level)
        return wrapper
    return cmef_subprocess_decorator


def cmef_parallel_execution(func, timeout_seconds, args_list=[]):
    """
    Parallelize function execution on cmef grid using the input params passed for each iteration
    :param func: function to be executed
    :param timeout_seconds: timeout for parallelization
    :param args_list: list of tuples (args) or dictionaries (kwargs) to be passed to function
    :return: Response object - list of dictionaries containing result and exception for each execution
    """
    # Analyze Inputs
    tuple_args = None
    dict_args = None
    if args_list:
        if not isinstance(args_list, list) and not isinstance(args_list, tuple):
            raise ValueError('arg_list should be of type list of tuples (args) or dictionaries (kwargs)')
    if len(args_list) > 0:
        if all(isinstance(each_arg, tuple) for each_arg in args_list):
            tuple_args = True
        elif all(isinstance(each_arg, dict) for each_arg in args_list):
            dict_args = True
        else:
            raise ValueError('arg_list should be of type list of tuples (args) or dictionaries (kwargs)')
    else:
        args_list = ['None']
    # Decorating the func with cmef_parallel_log_collector
    func = cmef_parallel_log_collector(func)
    # Submit tasks to dask
    logging.info('CMEF Parallel Execution Inputs:')
    logging.info(str(args_list))
    try:
        client = get_client()    # Getting client from worker node
        close_client = False     # DO NOT CLOSE CLIENT from get_client() as it closes worker client
    except:
        # Setting up client using grid url as not running on worker
        if os.environ.get('CMEF_GRID_URL'):
            client = get_dask_client(scheduler=os.environ.get('CMEF_GRID_URL'))
        else:
            client = None
        close_client = True
    try:
        consolidated_futures = []
        consolidated_results = []
        start_index = 0
        end_index = calculate_throttle_limit(client)
        if end_index > len(args_list):
            end_index = len(args_list)
        while args_list[start_index:end_index]:
            current_inputs = args_list[start_index:end_index]
            if tuple_args:
                futures = [client.submit(func, *args) for args in current_inputs]
            elif dict_args:
                futures = [client.submit(func, **kwargs) for kwargs in current_inputs]
            else:
                futures = [client.submit(func)]
            logging.info('Processing Inputs: {0} of {1}'.format(end_index, len(args_list)))
            consolidated_futures.extend(futures)
            # Monitor futures execution time
            monitor_result = monitor_futures(futures, timeout_seconds)
            if monitor_result:
                consolidated_results.extend(gather_future_results(futures=futures, args_list=current_inputs))
                # Cancelling futures to remove them from the client.processing api list
                # Future.cancel is also used for deleting completed futures
                client.cancel(futures)
            elif not monitor_result:
                logging.error('Following tasks with listed inputs are not complete')
                i = 0
                for each_future in futures:
                    if not each_future.done():
                        logging.error('Task Input: {0}     Status: {1}'.format(current_inputs[i], each_future.status))
                    i = i + 1
                logging.error('Cancelling all tasks')
                client.cancel(futures=consolidated_futures, force=True)
                if all(each_future.cancelled() for each_future in consolidated_futures):
                    logging.error('Task Cancellation Complete')
                else:
                    logging.error('Task Cancellation NOT Complete')
                raise Exception('CMEF Parallel Execution: TIMEOUT')
            start_index = end_index
            end_index = end_index + calculate_throttle_limit(client)
            if end_index > len(args_list):
                end_index = len(args_list)
        return consolidated_results
    except:
        raise
    finally:
        if close_client:
            client.close()
            del client


def calculate_throttle_limit(client):
    free_workers = 0
    throttle_percent = 75
    for worker, load in client.processing().iteritems():
        if not load:
            free_workers += 1
    throttle_limit = free_workers * throttle_percent / 100
    if throttle_limit <= 5:
        throttle_limit = 1
    return throttle_limit


def gather_future_results(futures, args_list):
    i = 0
    consolidated_result = []
    for each_future in futures:
        if each_future.status == 'error':
            logging.error('-' * 120)
            logging.error('Task Input: {0}     Status: {1}'.format(args_list[i], each_future.status))
            result_exception = each_future.exception()
            msg = result_exception.__repr__()  # Using repr to is prints the exception class as well for worker killed errors
            logging.error(msg)
            consolidated_result.append({'result': None, 'exception': msg})
            logging.error('-' * 120)
        elif each_future.status == 'cancelled':
            logging.error('-' * 120)
            logging.error('Task Input: {0}     Status: {1}'.format(args_list[i], each_future.status))
            logging.error('Task Cancelled')
            consolidated_result.append({'result': None, 'exception': 'Future Cancelled'})
            logging.error('-' * 120)
        else:
            logging.info('-' * 120)
            logging.info('Task Input: {0}     Status: {1}'.format(args_list[i], each_future.status))
            task_result = each_future.result()
            if task_result.get('output'):
                logging.info('\n' + task_result.get('output'))
            if task_result.get('exception'):
                logging.error('\n' + task_result.get('exception'))
            del task_result['output']  # Output / logs removed from returned data
            consolidated_result.append(task_result)
            logging.info('-' * 120)
        i = i + 1
    return consolidated_result


def monitor_futures(futures, timeout_seconds):
    begin = datetime.datetime.now()
    while True:
        if all(each_future.done() for each_future in futures):
            return True
        if (datetime.datetime.now() - begin).total_seconds() > timeout_seconds:
            return False
    time.sleep(5)


def search_r_script(env_vars, entry_function):
    for each_var in env_vars:
        if os.environ.get(each_var):
            for each_path in os.environ.get(each_var).split(os.pathsep):
                file_path = os.path.join(each_path, entry_function)
                if os.path.isfile(file_path):
                    return file_path
    return None


def validate_environ_vars(env_dict):
    """
    This function helps validate all values for environment variables in os.environ / os.environ.copy() are of type str
    Any environment variable not of type str will be converted to string
    NOTE: IF os.environ IS PASSED AS ARGUMENT, THIS FUNCTION WILL UPDATE os.environ AFFECTING ENTIRE PROCESS
    :param env_dict: Dictionary containing os.environ values using os.environ.copy()
    :return: Updated dictionary of values of type string
    """
    if not isinstance(env_dict, dict) and env_dict.__class__.__name__ != '_Environ':
        raise ValueError('Input needs to be of type dictionary or type instance (os.environ)')
    for key, value in env_dict.iteritems():
        if not isinstance(value, str):
            logging.warning('Environment Variable "{0}" is of type "{1}"'.format(key, str(type(value))))
            logging.warning('Converting Variable "{0}" to type "str"'.format(key))
            env_dict[key] = str(env_dict[key])
    return env_dict

