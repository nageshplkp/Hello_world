import os
import json
import logging
import argparse
import sys
from glob import iglob
from shutil import copy2, rmtree
from datetime import datetime
from fnmatch import fnmatch

logging.basicConfig(filename='create_staging_dir.log',filemode='w',level=logging.DEBUG,format='%(asctime)s %(levelname)-8s: %(message)s')
console = logging.StreamHandler()
formatter = logging.Formatter('%(levelname)-8s: %(message)s')
console.setFormatter(formatter)
logging.getLogger('').addHandler(console)

def get_args(args):
    parser = argparse.ArgumentParser(description = 'Generate analytics subset package')
    parser.add_argument('-e', '--environment', action='store', type=str, choices=['dev', 'beta', 'delta', 'prod'], default='prod',
                        help='Select environment for the run')
    parser.add_argument('-f', '--json_file', action='store', type=str, required=True,
                        help='Json file path for input')
    parser.add_argument('-o', '--outputdir', action='store', type=str, default=datetime.now().strftime("%Y%m%d_%H%M%S"),
                        help='Output directory to copy files')
    parser.add_argument('-d', '--debug', action='store_true', default=False,
                        help='Set logging to debug')
    return parser.parse_args(args)


def process_input(input, basedir, env):
    mode = 'recursive'
    for target, details in input.iteritems():
        logging.info('Processing target: {0}'.format(target))
        if not os.path.exists(os.path.join(basedir,target)):
            logging.info('Creating directory {0}'.format(os.path.join(basedir,target)))
            try:
                os.makedirs(os.path.join(basedir,target), 0755)
            except Exception:
                logging.exception('Unable to create directory {0} ...'.format(os.path.join(basedir,target)))
                return 3

        if details and isinstance(details, list):
            for detail in details:
                if detail and isinstance(detail, dict):
                    if 'patterns' in detail and 'source' in detail:
                        source_path = detail['source']
                        target_path = os.path.join(basedir,target)
                        source_path = source_path.replace('E-N-V', env)
                        target_path = target_path.replace('E-N-V', env)
                        if 'mode' in detail:
                            mode = detail['mode']
                        if mode == 'flat':
                            ret_code = flat_copy(source=source_path, target=target_path,
                                       pattern_list=detail['patterns'], overwrite=False)
                        else:
                            ret_code = recursive_copy(source=source_path, target=target_path,
                                       pattern_list=detail['patterns'], overwrite=False)
                        if ret_code > 0:
                            return ret_code
                    else:
                        logging.info('Details for {0} target do not contain patterns or source attributes'.format(target))
                        logging.info('Skipping ...')
                else:
                    if detail:
                        logging.warning('Target details should be a list of dict objects')
                        logging.warning('No dict object found for target: {0}'.format(target))
                    else:
                        logging.warning('Dict object is empty for target: {0}'.format(target))
                    logging.warning('Skipping ...')
        else:
            if details:
                logging.warning('Target details should be a list of dict objects')
                logging.warning('No list object found for target: {0}'.format(target))
            else:
                logging.warning('List object is empty for target: {0}'.format(target))
            logging.warning('Skipping ...')
    return


def flat_copy(source, target, pattern_list, overwrite):
    if os.path.isdir(source):
        for pattern in pattern_list:
            logging.info('Finding matches for pattern: {0}'.format(pattern))
            for filepath in iglob(os.path.join(source, pattern)):
                if os.path.exists(filepath):
                    if os.path.isfile(filepath):
                        target_full_path = os.path.join(target, os.path.basename(filepath))
                        try:
                            logging.info('Copying {0} to {1} ...'.format(filepath, target_full_path))
                            if not overwrite:
                                if os.path.exists(target_full_path):
                                    logging.error('File {0} already exists under {1}'.format(filepath, target))
                                    return 4
                            copy2(filepath, target_full_path)
                        except Exception:
                            logging.exception('Unable to copy file {0} to {1}'.format(filepath, target_full_path))
                            return 5
                    else:
                        logging.warning('Skipping {0} as it is not a file'.format(filepath))
                else:
                    logging.warning('Skipping {0} as it does not exist'.format(filepath))
    else:
        logging.warning('Source {0} does not exist or is not a directory'.format(source))
        logging.warning('Skipping ...')
        return
    return


def recursive_copy(source, target, pattern_list, overwrite):
    if os.path.isdir(source):
        for root, dir_list, file_list in os.walk(source):
            relative_path = root.replace(source, '').lstrip(os.sep)
            dest_path = os.path.join(target, relative_path)
            if check_pattern_match(dest_path, pattern_list):
                logging.info('Skipping {0} as it matched ignore pattern'.format(dest_path))
                continue
            for eachdir in dir_list:
                target_dir = os.path.join(dest_path, eachdir)
                if not os.path.exists(target_dir):
                    if not check_pattern_match(target_dir, pattern_list):
                        try:
                            logging.info('Creating directory {0}'.format(target_dir))
                            os.makedirs(target_dir, 0755)
                        except Exception:
                            logging.exception('Unable to create directory {0} ...'.format(target_dir))
                            return 6
                    else:
                        logging.info('Skipping {0} as it matched ignore pattern'.format(target_dir))
            for eachfile in file_list:
                source_file = os.path.join(root, eachfile)
                target_file = os.path.join(dest_path, eachfile)
                if not check_pattern_match(target_file, pattern_list):
                    try:
                        logging.info('Copying {0} to {1} ...'.format(source_file, target_file))
                        if not overwrite:
                            if os.path.exists(target_file):
                                logging.error('File {0} already exists under {1}'.format(source_file, dest_path))
                                return 7
                        copy2(source_file, target_file)
                    except Exception:
                        logging.exception('Unable to copy file {0} to {1}'.format(source_file, target_file))
                        return 8
                else:
                    logging.info('Skipping {0} as it matched ignore pattern'.format(target_file))
    else:
        logging.warning('Source {0} does not exist or is not a directory'.format(source))
        logging.warning('Skipping ...')
        return



def check_pattern_match(name, patterns):
    for pattern in patterns:
        if fnmatch(name, pattern):
            return True
    return False


def main(sysargs=None):
    if sysargs is not None:
        args = get_args(sysargs)
        env = args.environment
        json_file = args.json_file
        outputdir = args.outputdir
        if args.debug:
            console.setLevel(logging.DEBUG)
            console.setFormatter(formatter)
            logging.getLogger('').addHandler(console)
    else:
        env = 'prod'
        json_file = 'temp.json'
        outputdir = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    try:
        with open(json_file) as data_file:
            json_data = json.load(data_file)
    except Exception:
        logging.exception('Unable to read file: {0}'.format(json_file))
        return 1

    if os.path.exists(outputdir):
        logging.info('Deleting output directory {0} ...'.format(outputdir))
        try:
            rmtree(outputdir)
        except Exception:
            logging.exception('Unable to delete output directory')
            return 2

    ret_code = process_input(input=json_data, basedir=outputdir, env=env)
    return ret_code

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
