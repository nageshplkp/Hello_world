#!/bin/bash

ENV=$1

export PYTHONPATH=/appl/pim${ENV}/pimco_common/pypimco
export PATH=/appl/pimprod/pimco_common/pypimco_infra/anaconda_linux/bin:${PATH}

SCRIPTS_PATH=/appl/pimdev/pimco_common/pypimco/core/services/cmef/scripts
JSON_FILE=/appl/pimdev/pimco_common/pypimco/core/services/cmef/scripts/cmef_analytics_subset.json
OUTPUT=deploy
ZIP_FILE_NAME=analytics.zip

echo "Executing Command: python ${SCRIPTS_PATH}/create_staging_dir.py -e ${ENV} -o ${OUTPUT} -f ${JSON_FILE}"
python ${SCRIPTS_PATH}/create_staging_dir.py -e ${ENV} -o ${OUTPUT} -f ${JSON_FILE}

RET=$?
if [[ $RET != 0 ]]; then
    echo ""
    echo "ERR: Create Staging Directory Failed. Return code: ${RET}."
    echo ""
    exit 1
else
    echo ""
    echo "Create Staging Directory Completed Successfully"
    echo ""
fi

cd ${OUTPUT}

echo "Executing Command: zip -r ${ZIP_FILE_NAME} *"
zip -r ${ZIP_FILE_NAME} *

RET=$?
if [[ $RET != 0 ]]; then
    echo ""
    echo "ERR: ZIP Creation Failed. Return code: ${RET}."
    echo ""
    exit 1
else
    echo ""
    echo "ZIP Created Successfully"
    echo ""
fi

exit 0