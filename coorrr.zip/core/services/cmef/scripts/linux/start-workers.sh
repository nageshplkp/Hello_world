#!/bin/bash
ENV=$1
SCHEDULER=$2
export PYTHONPATH=/appl/pim$ENV/pimco_common/pypimco/;export appenv=$ENV
PYTHONBIN=/appl/pimbeta/pimco_common/pypimco_infra/anaconda_linux/
if [[ ${ENV} == "prod" ]] ; then
    $PYTHONBIN=/appl/pimprod/pimco_common/pypimco_infra/anaconda_linux/
fi
${PYTHONBIN}/bin/python ${PYTHONBIN}/bin/dask-worker --pid-file /tmp/cmef.dask.worker.pid $SCHEDULER &