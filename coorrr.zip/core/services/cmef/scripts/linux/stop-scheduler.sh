#!/bin/bash
cmd="ps -ef | grep dask-scheduler | grep python | awk '{print $2}' | xargs kill -9"
eval $cmd