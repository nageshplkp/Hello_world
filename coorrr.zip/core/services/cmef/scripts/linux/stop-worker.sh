#!/bin/bash
cmd="ps -ef | grep dask-worker | grep python | awk '{print $2}' | xargs kill -9"
eval $cmd