'''
Created on Jun 28, 2016

@author: sumgowda
'''
import ConfigParser
import sys
import getopt
from  Crypto.Cipher import AES
import getpass
import base64
# os is for urandom, which is an accepted producer of randomness that
# is suitable for cryptology.
import os
import logging
import uuid
        
def encryption(privateInfo):
    #32 bytes = 256 bits
    #16 = 128 bits
    # the block size for cipher obj, can be 16 24 or 32. 16 matches 128 bit.
    BLOCK_SIZE = 16
    # the character used for padding
    # used to ensure that your value is always a multiple of BLOCK_SIZE
    PADDING = '{'
    # function to pad the functions. Lambda
    # is used for abstraction of functions.
    # basically, its a function, and you define it, followed by the param
    # followed by a colon,
    # ex = lambda x: x+5
    pad = lambda s: s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * PADDING
    # encrypt with AES, encode with base64
    EncodeAES = lambda c, s: base64.b64encode(c.encrypt(pad(s)))
    # generate a randomized secret key with urandom
    secret = str(uuid.uuid4().get_hex().upper()[0:16])
    print secret
    # print 'encryption key:',secret
    # creates the cipher obj using the key
    cipher = AES.new(secret)
    # encodes you private info!
    encoded = EncodeAES(cipher, privateInfo)
    # print 'Encrypted string:', encoded
    return (encoded, secret)

def decryption(encryptedString, key):
    PADDING = '{'
    DecodeAES = lambda c, e: c.decrypt(base64.b64decode(e)).rstrip(PADDING)
    #Key is FROM the printout of 'secret' in encryption
    #below is the encryption.
    encryption = encryptedString
    cipher = AES.new(key)
    decoded = DecodeAES(cipher, encryption)
    return decoded

class CmefConfigParser:
    def __init__(self, configfile=""):
        self.config = ConfigParser.ConfigParser()
        if os.path.exists(configfile):
            self.config.readfp(open(configfile))
    
    def _get(self,section,key):
        return self.config.get(section,key,raw=False)
        
    
    def getDbName(self):
        return self._get('DATABASE','dbname')
    
    def getDbUsername(self):
        return self._get('DATABASE','user')
    
    def getDbPassword(self):
        encryptpass = self._get('DATABASE','pass')
        key = self._get('DATABASE','key')
        passData = [encryptpass , r'%s' % key ]
        return decryption(passData[0],passData[1])

    def getDaskScheduler(self):
        return self._get('DASK','scheduler')

    def getAmpsServer(self):
        return self._get('AMPS', 'server')

    def getAmpsCmefTopic(self):
        return self._get('AMPS', 'topic')

    def getAmpsInstance(self):
        return self._get('AMPS', 'instance')

    def getCmefServer(self):
        return self._get('CMEFSERVER', 'server')

    def getCmefErrorNotificationId(self):
        return self._get('NOTIFICATIONS', 'error')

    def getCmefSuccessNotificationId(self):
        return self._get('NOTIFICATIONS', 'success')

if __name__ == "__main__":
    pr = CmefConfigParser(configfile="C:\workspace\piranha\devconfigs\src\environments\dev\piranhapython.conf")
    
