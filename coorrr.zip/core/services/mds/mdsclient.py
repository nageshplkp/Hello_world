"""
MDS Client wrapper
"""
from core.rest import client
import datetime
import logging
import json
import pandas as pd
import isodate
import six

from core.rest.utils import popcorn_jcsv_to_dataframe
from core.services.mds.decorate import CONN_MAP
from core.services.mds.decorate import CONN_MAP_MONITORING
from core.services.mds.decorate import CONN_MAP_OVERRIDES

def __get_header(user):
    headers = {"User_Agent": "Mozilla/5.0",
               "Accept-Language": "en-US,en,q=0.5",
               "content-type": "application/json;fmt=avro",
               "accept": "application/json",
               "X-Remote-User": user}
    return headers

def __get_override_header(user):
    headers = {"User_Agent": "Mozilla/5.0",
               "Accept-Language": "en-US,en,q=0.5",
               #"content-type": "application/json;fmt=avro",
               "accept": "application/json",
               "X-Remote-User": user,
               "requestId": user,
                "userId": user,
                "clientAppName": "MDSCLIENT"}
    return headers

def __request_header(user, app, instance='LIVE'):
    rh = {}
    rh["requestId"] = {"string":user+ "@" + user}
    rh["userId"] = user+"@"+user
    rh["clientAppName"] = {"string":app}
    rh["action"] = "get_marketdata"
    # TODO: Iso Dates
    rh["requestTimestamp"] = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    rh["dataContext"] = {"string":instance}
    return rh

def __get_date_range():
    return {"com.pimco.portia.common.message.avro.mds.MdsDateRange":{"asOfDate":{"string":datetime.datetime.now().strftime("%Y%m%d")},"startDate":None,"endDate":None,"dates":None}}

def __get_quote(ticker, field, source, instance="LIVE", provider="BBG"):
    res = {}
    res["exchange"] = None
    res["instance"] = {"string":instance}
    res["provider"] = {"string":provider}
    res["quoteId"] = {"type":"TICKER", "value":ticker.upper()}
    res["requiredFields"]={"array": [field.upper()]}
    if isinstance(source,str):
        res["source"] = {"string":source}
    else:
        res["source"] = None
    return res

def __requested_items(tickers, instance, provider):
    r = {}
    ar = []
    rec = {}
    ar.append(rec)
    r["array"] = ar
    rec["dateRange"] = __get_date_range()
    rec["marketDataSpecs"] = None
    list = []
    rec["quoteKeys"] = {"array":list}
    for indedx, row in tickers.iterrows():
        list.append(__get_quote(row['TICKER'],row['FIELD'],row['SOURCE'], instance=instance, provider=provider))
    return r

def __get_request_url(env_map, suffix):
    base_url = env_map['url']
    return base_url+suffix

def __execute_mds_get_request(env, user, end_point, server_url, params=None):
    if server_url:
        base_url = server_url
    elif env:
        map = CONN_MAP.get(env);
        base_url = __get_request_url(map, end_point)
        use_kerberos = map['kerberos']
    return client.get(base_url, params, __get_header(user), use_kerberos=use_kerberos)

def __execute_mds_market_history_request(params, user, env, use_kerberos, server_url):
    if server_url:
        base_url = server_url
    elif env:
        #map = CONN_MAP_MONITORING.get(env)
        map = CONN_MAP.get(env)
        base_url = __get_request_url(map, "/snapshotMarketData")
        use_kerberos = map['kerberos']

    return client.get(base_url, params, __get_header(user), use_kerberos=use_kerberos)

def __execute_mds_request(json, user, env, use_kerberos, server_url):
    if server_url:
        base_url = server_url
    elif env:
        map = CONN_MAP.get(env)
        base_url = __get_request_url(map, "/req")
        use_kerberos = map['kerberos']

    return client.post(base_url, json, __get_header(user), use_kerberos=use_kerberos)

def __execute_mds_overrides_request(user, env, params, suffix):
    map = CONN_MAP.get(env)
    base_url = __get_request_url(map, suffix)
    use_kerberos = map['kerberos']

    return client.get(base_url, params=params, headers=__get_override_header(user), use_kerberos=use_kerberos)

def __adjust_timestamps(data, data_types):
    """
    Service layer returns iso data stamps. Convert to timestamps.
    @param data:
    @param data_types:
    @return:
    """
    # Convert to pandas date time format
    col = 0
    for col_type in data_types:
        if col_type == u'STRING/ISODATE':
            datavector = data.iloc[:, col]
            try:
                xdatavector = pd.to_datetime([s.encode('ascii') for s in datavector], format='%Y%m%d')
            except ValueError:
                xdatavector = pd.to_datetime([s.encode('ascii') for s in datavector], format='%Y-%m-%d')
            data.iloc[:, col] = xdatavector
        if col_type == u'STRING/ISODATETIME':
            datavector = data.iloc[:, col]
            try:
                xdatavector = [(x if (x == None or len(x)==0) else isodate.parse_datetime(x)) \
                               for x in [(s if (s == None or len(s)==0) else s.encode('ascii')) for s in datavector]]
                data.iloc[:, col] = xdatavector
            except Exception, e:
                logging.exception(e)
        col = col + 1
    return data


def get_curve_data(curve_asof_date, curve_name, env='prod', user='devmtg', server_url=None):
    """
    Retrieve the curve data
    @param curve_asof_date: 'LIVE' or a date yyyy-mm-dd format
    @param curve_name:
    @param env:
    @param user:
    @param server_url:
    @return: a map of datasets, keyed by type. for example LIBOR, LIBOR_BASIS etc...
    """

    params = {}
    params["_Accept"] = "application/json;fmt=csvs"  # always add csv encoding for the data.
    params["asof"] = curve_asof_date
    params["name"] = curve_name
    json = __execute_mds_get_request(env, end_point="/v2/marketDataCurve", user=user, params=params, server_url=server_url)


    res={}
    for key in json:
        columns = json[key]["names"]
        data = json[key]["data"]
        types = json[key]["types"]
        data = __adjust_timestamps(pd.DataFrame.from_records(data, columns=columns), types)
        res[key]= data

    return res

def get_vol_data(curve_asof_date, curve_name, env='prod', user='devmtg', server_url=None):
    """
    Retrieve the vol data
    @param curve_asof_date: 'LIVE' or a date yyyy-mm-dd format
    @param curve_name:
    @param env:
    @param user:
    @param server_url:
    @return: a map of ATM straddle prices or normal vols
    """

    params = {}
    params["_Accept"] = "application/json;fmt=csvs"  # always add csv encoding for the data.
    params["asof"] = curve_asof_date
    params["name"] = curve_name
    json = __execute_mds_get_request(env, end_point="/v2/marketDataVol", user=user, params=params, server_url=server_url)


    res={}
    for key in json:
        columns = json[key]["names"]
        data = json[key]["data"]
        types = json[key]["types"]
        data = __adjust_timestamps(pd.DataFrame.from_records(data, columns=columns), types)
        res[key]= data

    return res

def get_curve_list(env='prod',  user="devmtg", server_url=None):
    """
    Get the list of curves
    @param env:
    @return:
    """
    params = {}
    params["_Accept"] = "application/json;fmt=csvs"  # always add csv encoding for the data.
    json = __execute_mds_get_request(env, end_point="/v2/marketDataCurves", user=user, params=params, server_url=server_url)
    columns = json["marketDataList"]["names"]
    data = json["marketDataList"]["data"]
    types = json["marketDataList"]["types"]
    cdata = pd.DataFrame.from_records(data, columns=["CURRENCY","CURVE_TYPE","CURVE_CONTEXT","NAME"])
    return cdata

def query_intraday_history(ticker, field, env='prod', app="MDSCLIENT", user="devmtg", use_kerberos=False,
                             server_url=None):
    """
    Query MDS for market info on current ticker (current snapshot)
    :ticker      the ticker of interest
    :field       the field for which market info is requested
    :env          optional parameter pointing to a specific environment
    :user         optional user. when kerberos is enabled this is not needed.
    :use_kerberos optional parameter to turn kerberos on|off
    :server_url   optional specifying which url to use
    """

    # TODO: Deal with user authentication
    # TODO: Currently default user is devmtg
    params = {}
    params['_id'] = ticker
    params['_field'] = field
    # params['_accept'] = 'application/json'
    res = __execute_mds_market_history_request(params=params,env=env,user=user, use_kerberos=use_kerberos, server_url=server_url)
    logging.debug("Received: "+json.dumps(res))

    #hist = res["marketHistory"]
    #info = res["marketConfig"]
    return popcorn_jcsv_to_dataframe(res["marketHistory"])

def __get_ucase_string_or_none(value):
    if isinstance(value, str):
        return value.upper()
    elif six.PY2 and isinstance(value, six.string_types) and not isinstance(value, str):
        value = value.encode('latin - 1')
        return value.upper()
    return None


def query(tickers, context='LIVE', provider='BBG', env='prod', app="MDSCLIENT", user="devmtg", use_kerberos=True, server_url=None):
    """
    Query MDS for market data (current snapshot)
    :tickers      pandas data set with two columns: TICKER, FIELD, SOURCE
    :context      LIVE - latest. PREV_OFFICIAL - previous day official quaote, PREVCLOSE - previous day PRH quote
    :provider     By default provider is BBG. Other providers MDS - eod official snaps etc.
    :env          optional parameter pointing to a specific environment
    :user         optional user. when kerberos is enabled this is not needed.
    :use_kerberos optional parameter to turn kerberos on|off
    :server_url   optional specifying which url to use
    """

    # Uppercase all fields and sources
    for indedx, row in tickers.iterrows():
        row.FIELD = row.FIELD.upper()
        row.SOURCE = __get_ucase_string_or_none(row.SOURCE)

    request = {"header": __request_header(user, app, instance=context),
               "snapshotId": {"string": "CURRENT_SNAPSHOT"},
               "requestedItems": __requested_items(tickers, instance=context, provider=provider)}

    json_request = json.dumps(request)

    if logging.getLogger('').isEnabledFor(logging.DEBUG):
        logging.debug("Sending: " + json_request)

    # Turn off kerberos?

    res=__execute_mds_request(json_request, user,  env, use_kerberos, server_url)
    if logging.getLogger('').isEnabledFor(logging.DEBUG):
        logging.debug("Received: "+json.dumps(res))

    status=res['status']
    if not status=='OK':
        logging.error(res['comment'])
        return None

    quotes = res['quotes']
    data = []
    for record in quotes:
        updateTime = record['updateTime']
        asOfDate = record['asOfDate']
        quote = record['quoteKey']
        instance = quote['instance']
        quoteIdDict = quote['quoteId']
        quoteType = quoteIdDict['type']
        quoteId = quoteIdDict['value']
        exchange = quote['exchange']
        source = quote['source']
        provider = quote['provider']
        mdsId = record['mdsId']
        # skip ids
        ids = record['ids']
        ticker = ids['TICKER']
        # MDS may return the fields block
        quoteFields = record['fields']
        if quoteFields:
            fldCusip = quoteFields.get('ID_CUSIP')
            fldSecNumDes = quoteFields.get('ID_BB_SEC_NUM_DES')
            fldIssueDate = quoteFields.get('ISSUE_DT')
            fldMaturity= quoteFields.get('MATURITY')
            fldYellowKey = quoteFields.get('YELLOWKEY')
            fldfutDlvDtFirst = quoteFields.get('FUT_DLV_DT_FIRST')
        else:
            fldCusip = ''
            fldSecNumDes = ''
            fldIssueDate = ''
            fldMaturity= ''
            fldYellowKey = ''


        temp1 = tickers[tickers.TICKER.isin([ticker])]
        # values are list of fields mapped to values
        # Match quotes and fields
        values = record['values']
        for index, row in temp1.iterrows():
            # Match on field?
            field = row.FIELD.upper()
            quoteValue = values.get(field, None)
            if quoteValue:
                mnemonic = quoteValue['name']
                mnemonic_value = quoteValue['value']
                mnemonic_type = quoteValue['type']
                vendor_stamp = quoteValue['vendorUpdateTime']
                data.append((ticker, mnemonic, mnemonic_type, mnemonic_value, context, asOfDate, updateTime,
                             vendor_stamp, instance, provider, source, exchange, quoteId, quoteType, mdsId,
                             fldCusip, fldSecNumDes, fldIssueDate, fldMaturity, fldYellowKey, fldfutDlvDtFirst
                             ))
            else:
                # Not found in values.
                # Check if in fields
                quoteField = quoteFields.get(field, None)
                if quoteField:
                    data.append((ticker, field, 'FIELD', quoteField, context, asOfDate, updateTime,
                                 None, instance, provider, source, exchange, quoteId, quoteType, mdsId,
                                 fldCusip, fldSecNumDes, fldIssueDate, fldMaturity, fldYellowKey, fldfutDlvDtFirst
                                 ))

    columns = ['TICKER', 'FIELD', 'FIELD_TYPE', 'VALUE', 'CONTEXT', 'ASOF_DATE', 'STAMP', 'VENDOR_STAMP', 'INSTANCE', 'PROVIDER', 'SOURCE',  'EXCHANGE', 'QUOTE_ID', 'QUOTE_TYPE', 'MDS_ID',
               'FLD_CUSIP','FLD_BB_SEC_NUM_DES','FLD_ISSUE_DATE','FLD_MATURITY','FLD_YELLOWKEY','FLD_FUT_DLV_DT_FIRST']
    pdata = pd.DataFrame.from_records(data, columns=columns)
    pdata = pdata.drop_duplicates()
    pdata = pdata.reset_index(drop=True)
    return pdata

def __request_header_overrides(user, app, instance='LIVE'):
    rh = {}
    rh["requestId"] = {"string":user}
    rh["userId"] = user
    rh["clientAppName"] = {"string":app}
    return rh

def query_with_overrides(tickers, fields, overrides, context='LIVE', provider='BBG', env='prod', app="MDSCLIENT", user="devmtg", use_kerberos=True, server_url=None):
    """
    Query MDS for market data (current snapshot)
    :tickers      pandas data set with two columns: TICKER
    :fields       array of bloomberg fields
    :overrdes     Bloomberg overrides
    :context      LIVE - latest. PREV_OFFICIAL - previous day official quaote, PREVCLOSE - previous day PRH quote
    :provider     By default provider is BBG. Other providers MDS - eod official snaps etc.
    :env          optional parameter pointing to a specific environment
    :user         optional user. when kerberos is enabled this is not needed.
    :use_kerberos optional parameter to turn kerberos on|off
    :server_url   optional specifying which url to use
    """

    request = {"header": __request_header_overrides(user, app, instance=context)
               }

    json_request = json.dumps(request)
    list = []

    for  row in tickers:
        list.append(row)

    params = dict()
    params["_id"]=",".join(list)
    params["_fields"] = ",".join(fields)


    if not overrides is None:
        override_string = None
        for key, value in overrides.iteritems():
            if not override_string is None:
                override_string = override_string + ","
            else:
                override_string = ""
            override_string = override_string + key + "=" + value
        params["overrides"] = override_string

    logging.debug("Sending: " + json_request +" with params: "+str(params))
    res=__execute_mds_overrides_request(user,  params=params, env=env, suffix="/v2/bloombergData")

    if 'error' in res:  # In case of error, send the warning and return a dataframe with no actual data
        err_msg = res.get('error')
        logging.warning(err_msg)
        logging.info("returning dummy data.")
        len_flds = len(fields)
        res['data'] = [[x] + [''] * len_flds for x in tickers]
        res['names'] = [u'TICKER'] + fields
        res['types'] = ['STRING'] * len(fields)

    columns = res["names"]
    data = res["data"]
    types = res["types"]
    data = __adjust_timestamps(pd.DataFrame.from_records(data, columns=columns), types)
    return data
