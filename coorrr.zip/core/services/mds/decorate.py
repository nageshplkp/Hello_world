__author__ = 'anikolaev'

CONN_MAP =  {
        'beta' : {'url':'http://ptp-beta/mds','kerberos':False},
        'prod' : {'url':'http://ptp-prod/mds', 'kerberos':True},
        'dev' : {'url':'http://ptp-beta/mds','kerberos':False}
    }

CONN_MAP_MONITORING = {
    'beta': {'url': 'http://prodpmmdsv2:50028/monitoring', 'kerberos': False},
    'prod': {'url': 'http://prodpmmdsv2:50028/monitoring', 'kerberos': False},
    'dev': {'url': 'http://prodpmmdsv2:50028/monitoring', 'kerberos': False}
}

CONN_MAP_OVERRIDES = {
    'beta': {'url': 'http://ptpcore-webfarm6-beta:50020/mds', 'kerberos': False},
    'prod': {'url': 'http://ptpcore-webfarm3-prod:50020/mds', 'kerberos': False},
    'dev': {'url': 'http://ptpcore-webfarm6-beta:50020/mds', 'kerberos': False}
}
