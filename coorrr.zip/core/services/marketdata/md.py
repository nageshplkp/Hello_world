'''
    Abstract access to data services such as BBG, Haver and custom timeseries.

    Based on execution environment parameters, default to most appropriate data source.
    For example, if running on Desktop and BBG Desktop Connectivity is available default to BBG API, while in a server
    side environment default to MDS or SAPI etc.
'''
import logging
import traceback
import datetime

from core.common import util

enable_bb_desktop = util.isWindows()
if enable_bb_desktop:
    try:
        from core.services.bloomberg import bbg_data as bbg_desktop
    except:
        logging.warn(traceback.format_exc())
        logging.warn("Can't instantiate BBG Desktop API.")
        enable_bb_desktop = False

from core.services.bloomberg import bbg_args
from core.services.bloomberg import bbg_data_server as bbg_server
from core.services.mds import mdsclient as mds
from core.services.timeseries import ts_query as tss
import pandas as pd
from enum import Enum
from core.services.marketdata.util import pandas_from_bbg_dict, pandas_from_mds_pd

class DataProvider(Enum):
    NONE = 0
    BBG_DESKTOP = 1
    BBG_SAPI = 2
    BBG_BPIPE = 3
    PIMCO_MDS = 4
    PIMCO_TSS = 5


class MarketData(object):


    def __init__(self, providerWaterFall = [ DataProvider.BBG_DESKTOP, DataProvider.PIMCO_MDS, DataProvider.BBG_SAPI ], env="prod"):
        """
        Main intialization routine.
        @param providerWaterFall: order of data providers to be attempted during connect attempts.
        """
        logging.debug("Market Generic Data Service Created. Env: {0}".format(env))
        self.__dsProviderWaterFall = providerWaterFall
        self.__ds = []
        self.__dsProvider = DataProvider.NONE
        self.__env = env

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, type_, value, tb):
        try:
            self.close()
        except:
            logging.warn(traceback.format_exc())

    def __IsBBGDesktopAvailable(self):
        if not enable_bb_desktop:
            return False
        with bbg_desktop.BbgData() as bbg_temp:
            return bbg_temp.connected

    def connect(self):
        self.__ds = None
        self.__dsProvider = DataProvider.NONE
        for p in self.__dsProviderWaterFall:
            if p == DataProvider.BBG_DESKTOP:
                # test bbg connectivity first.
                if self.__IsBBGDesktopAvailable():
                    # shared instance to BBG desktop created.
                    self.__ds = bbg_desktop.BbgData()
                    self.__ds.connect()
                    self.__dsProvider = DataProvider.BBG_DESKTOP
                    break
            if p == DataProvider.BBG_SAPI:
                # Assume connection ok
                self.__dsProvider = DataProvider.BBG_SAPI
                break
            if p == DataProvider.BBG_BPIPE:
                # Assume connection ok
                self.__dsProvider = DataProvider.BBG_BPIPE
                break
            if p == DataProvider.PIMCO_MDS:
                # Assume connection ok
                self.__dsProvider = DataProvider.PIMCO_MDS
                break
            if p == DataProvider.PIMCO_TSS:
                # Assume connection ok
                self.__dsProvider = DataProvider.PIMCO_TSS
                break
        if self.__dsProvider is None:
            raise ValueError("No available providers. Please verify your configuration.")
        logging.debug("Connected to {0} data provider.".format(self.provider.name))

    @property
    def provider(self):
        return self.__dsProvider

    def close(self):
        # Should close bllomberg instance if any
        if (self.__dsProvider == DataProvider.BBG_DESKTOP):
            self.__ds.close()
        logging.debug("Closed instance {0}.".format(self.__dsProvider.name))
        self.__ds = None
        self.__dsProvider = DataProvider.NONE

    def __buildMDSInputDS(self, ids, fields, sources):
        template = pd.DataFrame(columns=['TICKER', 'FIELD', 'SOURCE'])
        request = template.copy()
        if sources is None:
            sources = [None]
        for id in ids:
            for field in fields:
                for source in sources:
                    map = MarketData.parseBBGSecurity(id)
                    request.loc[len(request)]= [ id, field, source]
        return request

    def __buildIdFieldArgsFromDS(self, pd_request):
        ids = []
        fields = []
        for index, row in pd_request.iterrows():
            ids.append(row["TICKER"])
            fields.append(row["FIELD"])
        return ids, fields



    BBG_SEC_NAME = 'NAME'
    BBG_SEC_YELLOW = 'YELLOW'
    BBG_SEC_TYPE = 'TYPE'
    BBG_SEC_EXCHANGE = 'EXCHANGE'
    BBG_SEC_COUPON = 'COUPON'
    BBG_SEC_MATURITY = 'MATURITY'
    BBG_SEC_MATURITY_DATE = 'MATURITY_DATETIME'
    BBG_SEC_PRICING_SOURCE = 'PRICING_SOURCE'
    BBG_SEC_SESSION = 'SESSION'

    __BBG_SEC_YELLOW_KEYS  = ('GOVT','CORP','MTGE','M-MKT','MUNI','PFD','EQUITY','COMDTY','INDEX','CURNCY')
    __BBG_SEC_TYPES  = ('AIBD','AUSTRIA','BELG','CINS','COMNUM','CUSIP8','CUSIPX','CUSIP','DENMARK','DUTCH',
                        'EUROCLR','FIRMID','FRENCH','IRELAND','ISIN','ISMA','ITALY','JAPAN','JNCOMNUM',
                        'LUXEMBRG','MALAYSIA','MISC','NORWAY','RGA','SEDOL1','SEDOL2','SPAIN','SCM','STCM',
                        'SWEDENV','TCAV','TCM','TICKERDIV','TICKER','VALOREN','WERTP')
    _BBG_SEC_PRICING_SOURCES = ('BGN','BVAL','MSG1','TRAC','CBBT','CMPN','BMRK','ICPL','PREB','GBN','BRRT','BFIX')
    _BBG_SEC_SESSION = ('PIT','ELEC','COMB')

    @classmethod
    def __isBbgTickerSyntax(self, map):
        """
        For now check for the existince of a yellow key.
        @param map: 
        @return: 
        """
        return map.has_key(MarketData.BBG_SEC_YELLOW)

    @classmethod
    def parseBBGSecurity(self, ticker):
        """
        syntax: < Name > [Exchange][Coupon][Maturity][Pricing Source][Session] < Yellow Key > [Type]
        For full syntax of BBG Ticker format check https://pimcowiki:8443/download/attachments/327843853/DAPI_ALL.pdf

        @param ticker: 
        @return: 
        """
        words = ticker.split(' ')


        res = dict()
        res[MarketData.BBG_SEC_EXCHANGE] = None

        for (i, w) in enumerate(words):
            if i==0:
                res[MarketData.BBG_SEC_NAME] = w
                continue
            wu = w.upper()
            if wu in MarketData.__BBG_SEC_YELLOW_KEYS:
                res[MarketData.BBG_SEC_YELLOW] = w
                continue
            # Capture type. Always after yellow or at index 1.
            # Sedol1 in 2005973 Equity Sedol1 and Cusip in 882330AF0 Cusip
            if wu in MarketData.__BBG_SEC_TYPES and \
                    (res.has_key(MarketData.BBG_SEC_YELLOW) or i==1):
                res[MarketData.BBG_SEC_TYPE] = w
            # Capture two letter codes for exchange.
            if len(wu) == 2:
                res[MarketData.BBG_SEC_EXCHANGE] = w
            # Capture Coupon for fixed income tickers
            if i==1:
                try:
                    if util.is_number(w):
                        res[MarketData.BBG_SEC_COUPON] = float(w)
                except ValueError:
                    ignore = 1
            # Maturity
            if '/' in w:
                parts = w.split('/')
                if len(parts) == 2:
                    # Formats: mm/yy, mm/yyyy
                    try:
                        res[MarketData.BBG_SEC_MATURITY_DATE] = datetime.datetime.strptime(w, '%m/%y')
                        res[MarketData.BBG_SEC_MATURITY] = w
                    except ValueError:
                        try:
                            res[MarketData.BBG_SEC_MATURITY_DATE] = datetime.datetime.strptime(w, '%m/%Y')
                            res[MarketData.BBG_SEC_MATURITY] = w
                        except:
                            print 'Can''t parse date!'.format(w)
                else:
                    # Formats: mm/dd/yy, mm/dd/yyyy
                    try:
                        res[MarketData.BBG_SEC_MATURITY_DATE] = datetime.datetime.strptime(w,'%m/%d/%y')
                        res[MarketData.BBG_SEC_MATURITY] = w
                    except ValueError:
                        try:
                            res[MarketData.BBG_SEC_MATURITY_DATE] = datetime.datetime.strptime(w, '%m/%d/%Y')
                            res[MarketData.BBG_SEC_MATURITY] = w
                        except:
                            print 'Can''t parse date!'.format(w)
            #Pricing Source
            if len(w) in (3,4) and not res.has_key(MarketData.BBG_SEC_YELLOW) :
                if '@' in w and wu[1:] in MarketData._BBG_SEC_PRICING_SOURCES:
                    res[MarketData.BBG_SEC_PRICING_SOURCE] = wu[1:]
                elif wu in MarketData._BBG_SEC_PRICING_SOURCES:
                    res[MarketData.BBG_SEC_PRICING_SOURCE] = wu

            #Commodity Futures Session
            if wu in MarketData._BBG_SEC_SESSION:
                res[MarketData.BBG_SEC_SESSION] = wu

        # Drop exchange if missing
        if res[MarketData.BBG_SEC_EXCHANGE] is None:
            del res[MarketData.BBG_SEC_EXCHANGE]
        elif not res[MarketData.BBG_SEC_YELLOW].upper() == 'EQUITY':
            # Drop exchange unless equity security
            res[MarketData.BBG_SEC_EXCHANGE] = None

        if res.has_key(MarketData.BBG_SEC_SESSION) \
            and not res[MarketData.BBG_SEC_YELLOW].upper() == 'COMDTY':
            del res[MarketData.BBG_SEC_SESSION]

        return res



    def get_marketdata(self, ids=None, fields=None, pd_input=None, mds_context='LIVE', mds_provider='BBG'):
        """
        Retrieve latest avaiable data for the specified list of tickers, fields (mnemonics).
        @param ids: list of identifiers / tickers
        @param fields: list of fields / mnemonics
        @param pd_input: pandas data set with three columns: TICKER, FIELD, SOURCE.
        @param env: Optional parameter pointing to a specific PIMCO environment - prod|beta|dev.
        @param mds_context: LIVE - latest, PREV_OFFICIAL - previous day official quaote, PREVCLOSE - previous day PRH quote
        @param mds_provider: By default provider is BBG. Other providers MDS - eod official snaps etc.
        @return: pandas data frame.
        """

        # Ensure ids and fields are empty if the input data set is supplied
        if pd_input is not None:
            if not isinstance(pd_input, pd.DataFrame):
                raise TypeError("pd_request argument must be a pandas data frame.")
            if ids is not None or fields is not None:
                raise ValueError("ids and fields arguments not allowed when using pandas style input argument pd_input.")
        else:
            # Ensure ids and fields are both provided
            if ids is None or fields is None:
                raise ValueError("both ids and fields must be provided.")
            ids, fields = bbg_args.scrub(ids, fields)

        if self.__dsProvider == DataProvider.BBG_DESKTOP:
            if pd_input is not None:
                ids, fields = self.__buildIdFieldArgsFromDS(pd_input)
            return self.__ds.get_market_data(ids, fields)

        if self.__dsProvider == DataProvider.PIMCO_MDS:
            if pd_input is None:
                request = self.__buildMDSInputDS(ids, fields, None)
            else:
                request = pd_input
            return mds.query(request, context=mds_context, provider=mds_provider, env=self.__env)
        raise NotImplementedError("Function Not implemented for provider: "+self.__dsProvider.name)

    def get_histdata(self, ids, fields, start_date, end_date = None, periodicity=None, periodicity_adjustment=None,
                       currency=None, override_option=None, pricing_option=None, non_trading_day_fill_option=None,
                       non_trading_day_fill_method=None, max_data_points=None, return_eids=None, return_relative_date=None,
                       adjustment_normal=None, adjustment_abnormal=None , adjustment_split=None,
                       adjustment_follow_dpdf=None):
        """
        Retrieve data for the specified list of tickers, fields (mnemonics) startDate and endDate.

        @param ids:
        @param fields:
        @param start_date: yyyymmdd
        @param end_date: yyyymmdd - optional
        
        Check https://data.bloomberglp.com/labs/sites/2/2014/07/blpapi-developers-guide-2.54.pdf for full reference.
        
        @param periodicity: DAILY|WEEKLY|MONTHLY|QUARTERLY|SEMI_ANNUALLY|YEARLY ...
        @param periodicity_adjustment: ACTUAL|CALENDAR|FISCAL
        @param currency: 3 letter ISO code
        @param override_option: OVERRIDE_OPTION_CLOSE - use closing price | OVERRIDE_OPTION_GPA - use average price 
        @param pricing_option: PRICING_OPTION_PRICE - set quote to price | PRICING_OPTION_YIELD - set quote to yield
        @param non_trading_day_fill_option: NON_TRADING_WEEKDAYS | ALL_CALENDAR_DAYS | ACTIVE_DAYS_ONLY
        @param non_trading_day_fill_method: PREVIOUS_VALUE | NIL_VALUE
        @param max_data_points
        @param return_eids: true|false
        @param return_relative_date: true|false. Setting this to true will populate fieldData with an extra element containing a name 
               and value for the relative date. For example RELATIVE_DATE = 2002 Q2
        @param adjustment_normal: true|false. Adjust historical pricing to reflect: Regular Cash, Interim, 1st Interim,
               2nd Interim, 3rd Interim, 4th Interim, 5th Interim, Income, Estimated, Partnership Distribution, Final,
               Interest on Capital, Distribution, Prorated.
        @param adjustment_abnormal: true|false. Adjust historical pricing to reflect: Regular Cash, Interim, 1st Interim,
               2nd Interim, 3rd Interim, 4th Interim, 5th Interim, Income, Estimated, Partnership Distribution, Final,
               Interest on Capital, Distribution, Prorated.
        @param adjustment_split: True | False Adjust historical pricing and/or volume to reflect: Spin-Offs, Stock 
               Splits/Consolidations, Stock Dividend/Bonus, Rights Offerings/Entitlement.
        @param adjustment_follow_dpdf: True | False | Setting to true will follow the DPDF<GO> BLOOMBERG PROFESSIONAL service function.
               True is the default setting for this option.
        @return: pandas data frame.
        """
        # Ensure ids and fields are both provided
        if ids is None or fields is None:
            raise ValueError("both ids and fields must be provided.")
        ids, fields = bbg_args.scrub(ids, fields)

        if self.__dsProvider == DataProvider.BBG_DESKTOP:
            return self.__ds.get_historical(ids, fields, start_date, end_date,
                                            periodicity=periodicity, periodicityAdjustment=periodicity_adjustment,
                                            currency=currency, overrideOption=override_option, pricingOption=pricing_option,
                                            nonTradingDayFillOption=non_trading_day_fill_option,
                                            nonTradingDayFillMethod=non_trading_day_fill_method, maxDataPoints=max_data_points,
                                            returnEids=return_eids,
                                            returnRelativeDate=return_relative_date,
                                            adjustmentNormal=adjustment_normal, adjustmentAbnormal=adjustment_abnormal,
                                            adjustmentSplit=adjustment_split,
                                            adjustmentFollowDPDF=adjustment_follow_dpdf
                                            )
        if self.__dsProvider == DataProvider.PIMCO_TSS:
            return tss.ts_query(ids, fields, start_date, end_date)
        #if self.__dsProvider == DataProvider.PIMCO_MDS:
        #    tickers = ids
        #    field_defs = fields
        #    request = pd.DataFrame(columns=['TICKER', 'FIELD', 'SOURCE'])
        #    mds.query(request)
        raise NotImplementedError("Function Not implemented for provider: "+self.__dsProvider.name)

    def get_refdata(self, ids, fields, overrides={}):
        """
        @param ids:
        @param fields:
        @param overrides: override options in dictionary format. all values must be strings
        @return:
        """
        # Ensure ids and fields are both provided
        if ids is None or fields is None:
            raise ValueError("both ids and fields must be provided.")
        ids, fields = bbg_args.scrub(ids, fields)

        if self.__dsProvider == DataProvider.BBG_DESKTOP:
            return pandas_from_bbg_dict(self.__ds.get_refdata(ids, fields, overrides))
        if self.__dsProvider == DataProvider.PIMCO_MDS:
            return pandas_from_mds_pd(ids=ids, mds_result=mds.query_with_overrides(tickers=ids,fields=fields,overrides=overrides))
        raise NotImplementedError("Function Not implemented for provider: "+self.__dsProvider.name)
