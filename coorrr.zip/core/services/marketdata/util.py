import pandas as pd
def pandas_from_bbg_dict(res):
    """
    If the result is returned as dictionary convert to data frame.
    BBG can return dictionary of dictionaries, where key is the field being looked up
    and the values are dictionary of keys to dataframes.
    field -> (ticker -> dataframe)
    
    @param res: 
    @return:
    """
    if isinstance(res, dict):
        rows = []
        headers = ["TICKER"]
        tickers = set()
        fields = set()
        for field, value in res.iteritems():
            fields.add(field)
            headers.append(field)
            if isinstance(value, dict):
                for ticker, df in value.iteritems():
                    tickers.add(ticker)
                    if not len(df.columns) == 1:
                        raise NotImplementedError("Only dataframes with one columns are supported.")
            else:
                raise NotImplemented("Unsuported result set.")

        for ticker in tickers:
            row = [ticker]
            for field in fields:
               if res[field].has_key(ticker):
                   df = res[field][ticker]
                   row.append(",".join([x[0] for i, x in df.iterrows()]))
            rows.append(row)
        return pd.DataFrame(rows, columns=headers)
    return res

def pandas_from_mds_pd(ids=None, mds_result=None):
    """
    use MDS result, set and convert TICKER column to an Index. Note BBG sets the ids as the Index of 
    the resulting data sets.
    @param ids: 
    @param mds_result: 
    @return: 
    """
    if "TICKER" in mds_result.columns:
        upper_ids = [x.upper() for x in ids]
        new_index = []
        for i in range(0, len(mds_result["TICKER"])):
            row = mds_result.iloc[i]
            key = row["TICKER"].upper()
            new_index.append(ids[upper_ids.index(key)])
        mds_result["TICKER"] = new_index
        res = mds_result.set_index("TICKER")
    return res
