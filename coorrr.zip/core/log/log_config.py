import getpass
import json
import logging
import logging.handlers
import os
import os.path
import sys
import threading
import traceback

import pytz
import six
import tzlocal

empty_rec = logging.makeLogRecord({})
_tz_pacific = pytz.timezone('US/Pacific')
_tz_local = tzlocal.get_localzone()


def _get_script_name():
    cwd = os.getcwd()
    return os.path.realpath(os.path.join(cwd, sys.argv[0]))


def _initial_extra_stack():
    is_microservice = False
    try:
        import uwsgi
        is_microservice = True
    except:
        pass

    return dict(Apptype='microservice' if is_microservice else 'batch',
                Appname=_get_script_name() if not is_microservice else '')


def _get_user_name():
    return os.environ.get('USER', os.environ.get('USERNAME')) or ''


_USERNAME = _get_user_name()
_APPENV = os.environ.get('appenv', 'dev')


class _LoggingExtras(threading.local):
    extra_stack = [_initial_extra_stack()]
    initialized = False

    def __init__(self, **kwargs):
        if self.initialized:
            raise Exception('Initialized was called too many times')
        self.initialized = True
        self.__dict__.update(kwargs)

    def push(self, extra_dict):
        self.extra_stack.append(extra_dict)

    def pop(self):
        if self.extra_stack:
            return self.extra_stack.pop()
        return {}

    def get_extras(self, merge=None):
        x = {}
        for z in self.extra_stack:
            x.update(z)
        if merge:
            x.update(merge)

        if 'username' not in x:
            x['username'] = _USERNAME

        if 'appenv' not in x:
            x['appenv'] = _APPENV

        return x


logging_extras = _LoggingExtras()


class NigelFormatter(logging.Formatter):
    enc = json.JSONEncoder()

    def tuple_of_tuples(self, args):
        if type(args) is not tuple:
            return False
        for o in args:
            if type(o) is not tuple:
                return False
            elif len(o) != 2:
                return False
        return True

    def format(self, record):
        import datetime as dt
        ct = dt.datetime.fromtimestamp(record.created)
        ts = _tz_local.localize(ct).astimezone(_tz_pacific).isoformat()  # convert local to pacific
        # Splunk expects pacific time
        jmsg = str(record.msg) if not isinstance(record.msg, six.string_types) else record.msg
        jmsg = self.enc.encode((jmsg % record.args) if record.args else jmsg)
        msg = '{"ts":"' + ts + '", "tid":"' + record.threadName + '", "level":"' + record.levelname \
              + '", "class":"' + record.filename + '.' + record.funcName + ':' + str(record.lineno) + '", "msg":' + jmsg

        extra = {}
        if hasattr(record, 'kwargs'):
            extra = record.kwargs

        extra = logging_extras.get_extras(extra)

        if type(extra) is dict:
            # Flatten a map
            for k, v in six.iteritems(extra):
                msg = msg + ', ' + self.enc.encode(str(k)) + ':' + self.enc.encode(str(v))

        msg = msg + '}'
        if six.PY3:
            return msg.encode('utf8')
        return msg


class RomanHandler(logging.handlers.DatagramHandler):
    def makePickle(self, record):
        fmt = self.format(record)
        return fmt


def set_debug():
    logging.getLogger('').setLevel(logging.DEBUG)


def set_info():
    logging.getLogger('').setLevel(logging.INFO)


def set_log_dir(path):
    '''
    override default log dir
    '''
    os.environ['logdir'] = path
    
def is_ipy():
    try:
        return __IPYTHON__ is not None
    except:
        return False


def is_interactive():
    try:
        import uwsgi
        return False
    except:
        pass

    try:
        import __main__ as main
        return not hasattr(main, '__file__')
    except:
        return True


def is_notebook():
    import sys
    return is_ipy() and 'ipykernel' in sys.modules


def get_logging_level():
    if hasattr(logging, 'PYPIMCO_LEVEL_OVERRIDE'):
        return logging.PYPIMCO_LEVEL_OVERRIDE
    elif 'PYPIMCO_LOG_LEVEL_OVERRIDE' in os.environ:
        return getattr(logging, os.environ['PYPIMCO_LOG_LEVEL_OVERRIDE'])
    else:
        level = logging.WARN if is_notebook() else logging.INFO
        return level


def init_logging(log_file_path=None, reload=False):
    for handler in logging.getLogger('').handlers:
        if hasattr(handler, '__pypimco_tag__') and not reload:
            return  # prevent double logging in spyder

    if reload:
        logger = logging.getLogger('')
        for handler in logger.handlers:
            logger.removeHandler(handler)

    logging.getLogger('').setLevel(logging.DEBUG)
    logging_level = get_logging_level()
    fmt = logging.Formatter('%(asctime)s %(name)s %(levelname)s %(message)s')

    console_handler = logging.StreamHandler()
    console_handler.__pypimco_tag__ = True
    console_handler.setFormatter(fmt)
    console_handler.setLevel(logging_level)
    #logging.getLogger('').setLevel(logging_level)
    logging.getLogger('luigi-interface').setLevel(logging.WARNING)

    # don't remove dis - dis used for boatswain
    logging.getLogger('').addHandler(console_handler)
    if os.environ.get('PYPIMCO_CONSOLE_LOG_ONLY', '').lower() != 'y':
        try:
            file_handler = create_file_handler(log_file_path, logging_level)
            file_handler.setFormatter(fmt)
            logging.getLogger('').addHandler(file_handler)
        except:
            logging.warn(traceback.format_exc())

    if 'PYPIMCO_ADDITIONAL_LOGFILE' in os.environ:
        try:
            custom_logging_level = logging._levelNames.get(os.environ.get('PYPIMCO_ADDITIONAL_LOGFILE_LEVEL', 'INFO'),
                                                    logging_level)
            file_handler = create_file_handler(os.environ['PYPIMCO_ADDITIONAL_LOGFILE'], custom_logging_level)
            file_handler.setFormatter(fmt)
            logging.getLogger('').addHandler(file_handler)
        except:
            logging.warn(traceback.format_exc())

    if not is_interactive():
        add_udp_logger(logging_level)


def create_file_handler(log_file_path, logging_level):
    # 10 meg rotating file handler, keep 5 files only
    try:
        if not log_file_path:
            log_dir = _log_dir()
            log_file_path = _logFileName(log_dir)

        if logging_level in (logging.DEBUG, logging.INFO):
            print('logPath = %s' % log_file_path)
        file_handler = logging.handlers.RotatingFileHandler(log_file_path, maxBytes=10485760, backupCount=5)
    except Exception as ex:  # in case file get locked up
        print(ex.message)
        file_name = '%s.%s.log' % (log_file_path, os.getpid())
        log_file_path = file_name
        file_handler = logging.handlers.RotatingFileHandler(log_file_path, maxBytes=10485760, backupCount=5)
    os.environ['log_path'] = log_file_path
    file_handler.setLevel(logging_level)
    return file_handler


def add_udp_logger(logging_level=logging.INFO):
    udp_handler = get_udp_handler(logging_level)
    logging.getLogger('').addHandler(udp_handler)
    #print "Set up udp logger: %s" % server


def get_udp_handler(logging_level):
    server = 'prodpmsplunk1.pimco.imswest.sscims.com'
    # server = 'devpmsplunk1.pimco.imswest.sscims.com'
    # if os.environ.get('appenv', 'dev') == 'prod':
    #     server = 'prodpmsplunk1.pimco.imswest.sscims.com'
    udp_handler = RomanHandler(server, 8708)
    fmt = NigelFormatter()
    udp_handler.setFormatter(fmt)
    udp_handler.setLevel(logging_level)
    return udp_handler


def _log_dir():
    from core.common import util
    from core.io import files
    if 'logdir' in os.environ:
        return os.environ['logdir']

    if util.isWindows():
        logDir = r'c:\temp'
    else:
        logDirs = {
            'dev': _user_log_dir(),
            'beta': '/appl/coreservicebeta/logs',
            'prod': '/appl/coreservice/logs',
        }

        env = os.getenv('appenv').lower() if os.getenv('appenv') else 'dev'
        logDir = logDirs.get(env)

        # handle cases when /appl is not mounted, store the log locally in the /base/logs directory
        if env in ('beta', 'prod') and not files.exists(logDir):
            logDir = '/base/logs'

        # default to /home/user/logs directory if cant write to log directory
        if not files.can_create_file(logDir):
            logDir = logDirs.get('dev')
            if not files.exists(logDir):
                files.create_dir(logDir)

    files.create_dir(logDir)
    return logDir


def _user_log_dir():
    userName = getpass.getuser()
    return '/home/%s/logs' % userName


def _logFileName(logDir):

    if 'PYPIMCO_LOG_FILE_PATH' in os.environ:
        return os.environ['PYPIMCO_LOG_FILE_PATH']

    from core.io import files
    from core.common import util
    moduleDir = 'unknown'
    moduleName = 'unknown'
    try:
        import __main__
        moduleDir = os.path.dirname(os.path.realpath(__main__.__file__)).split(os.sep)[-1]
        moduleName = os.path.realpath(__main__.__file__).split(os.sep)[-1].replace('.py', '')
        os.environ['app_module'] = moduleName
        os.environ['app_module_dir'] = moduleDir

        fileName = 'pypimco_%s_%s.log' % (moduleDir, moduleName)
        log_file_path = os.path.join(logDir, fileName)
        files.create_file(log_file_path)
        os.chmod(log_file_path, 0o777)
    except Exception as ex:
        if 'app_module' not in os.environ:
            os.environ['app_module'] = moduleDir
            os.environ['app_module_dir'] = moduleName

        fileName = 'pypimco_%s_%s.log' % (moduleDir, moduleName)
        if util.isWindows():
            log_file_path = os.path.join(logDir, fileName)
        else:
            log_file_path = os.path.join(_user_log_dir(), fileName)

    return log_file_path
