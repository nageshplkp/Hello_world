import etl.pimco_live.mapper.bbg_exchange_mapper as bbg_exchange_mapper
from etl.pimco_live.exceptions import PimcoLiveException, ExchangeNotFoundInTickerException
import re

__code_list = None


def _get_code_list():
    global __code_list
    if __code_list is None:
        mapper = bbg_exchange_mapper.get_instance()
        __code_list = mapper.get_single_primary_key_list()

    return __code_list


def find_exchange_in_ticker(ticker):
    """Returns exchange code if found in ticker
       Throws ExchangeNotFoundInTickerException if not found
       Throws PimcoLiveException if more than 1 exchanges found
    """
    code_list = _get_code_list()
    value = None
    for code in code_list:
        pattern = ' ' + code + r'($|\s)'

        if re.search(pattern, ticker):
            if value:
                raise PimcoLiveException("More than 1 exchange codes found in ticker {} - [{} & {}]".format(
                    ticker, value, code
                ))
            value = code

    if value:
        return value
    else:
        raise ExchangeNotFoundInTickerException("Could not find an exchange code in ticker {}".format(ticker))
