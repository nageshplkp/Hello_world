import uuid
import datetime

from etl.pimco_live.exceptions import PimcoLiveException
import pl_request_provider
from pl_benchmark_driver_provider import bbg_triplet_exists, \
    get_series_id_from_bbg_triplet
import pl_refresh_provider
import etl.pimco_live.constants as constants
import etl.pimco_live.mapper.pl_benchmark_driver_mapper as driver_mapper
import etl.pimco_live.mapper.pl_schedule_mapper as schedule_mapper


def add_new_request(pl_request_login_id, bbg_ticker, bbg_yellow_key,
                    bbg_mnemonic, data_tag, ):
    if pl_request_provider.is_duplicate_new_req(bbg_ticker, bbg_yellow_key,
                                                bbg_mnemonic):
        raise PimcoLiveException(
            "BBG Triplet {} is already queued as a NEW request in pl_request "
            "table".format(
                BbgTriplet(bbg_ticker, bbg_yellow_key, bbg_mnemonic))
        )

    if pl_request_provider.is_duplicate_valid_req(bbg_ticker, bbg_yellow_key,
                                                  bbg_mnemonic):
        raise PimcoLiveException(
            "BBG Triplet {} is already a VALID request in pl_request "
            "table".format(
                BbgTriplet(bbg_ticker, bbg_yellow_key, bbg_mnemonic))
        )

    if pl_request_provider.is_duplicate_onhold_req(bbg_ticker, bbg_yellow_key,
                                                   bbg_mnemonic):
        raise PimcoLiveException(
            "BBG Triplet {} is already ONHOLD in pl_request table".format(
                BbgTriplet(bbg_ticker, bbg_yellow_key, bbg_mnemonic))
        )

    guid = str(uuid.uuid4())
    pl_request_id = pl_request_provider.add_request(guid, pl_request_login_id,
                                                    bbg_ticker,
                                                    bbg_yellow_key,
                                                    bbg_mnemonic, data_tag, )
    return pl_request_id


def add_new_refresh_request(pl_refresh_login_id,
                            bbg_ticker,
                            bbg_yellow_key,
                            bbg_mnemonic,
                            search_tag=''):
    triplet = BbgTriplet(bbg_ticker, bbg_yellow_key, bbg_mnemonic)
    if not is_triplet_refreshable(triplet):
        raise PimcoLiveException(
            'BBG Triplet {} is not refreshable'.format(triplet))

    guid = str(uuid.uuid4())
    series_id = get_series_id_from_bbg_triplet(bbg_ticker,
                                               bbg_yellow_key, bbg_mnemonic)
    schedule_dt = get_refresh_date_for_series(series_id)
    req_id = pl_refresh_provider.add_refresh_request(guid, pl_refresh_login_id,
                                                     series_id,
                                                     schedule_dt, search_tag)
    return req_id


def get_refresh_date_for_series(series_id):
    schedule_code = driver_mapper.get_instance().get_schedule_code_from_series_id(
        series_id)
    bbg_interface = schedule_mapper.get_instance().get_bbg_interface_code(
        schedule_code)
    if bbg_interface == constants.BBG_DL_CODE:
        # return upcoming day's 7pm
        return get_next_7pm()
    elif bbg_interface == constants.BBG_SAPI_CODE:
        return get_next_saturday_2am()


def get_next_7pm(now=datetime.datetime.now()):
    if now.hour < 19:
        time = datetime.datetime(now.year, now.month, now.day, 19)
        return time
    else:
        tomorrow_am = now + datetime.timedelta(hours=12)
        time = datetime.datetime(tomorrow_am.year, tomorrow_am.month,
                                 tomorrow_am.day, 19)
        return time


def get_next_saturday_2am(now=datetime.datetime.now()):
    """Mo-Fr get scheduled for this sat
       Sa-Su go to next week's Saturday
    """
    if now.isoweekday() < 6:  # 7 is Sunday
        days_delta = 6 - now.isoweekday()
    elif now.isoweekday() == 7:
        days_delta = 6
    else:
        assert now.isoweekday() == 6
        days_delta = 7

    new_day = now + datetime.timedelta(days=days_delta)
    scheduled_time = datetime.datetime(new_day.year, new_day.month, new_day.day,
                                       2)

    return scheduled_time


def is_triplet_refreshable(bbg_triplet):
    t = bbg_triplet
    if pl_refresh_provider.is_duplicate_refresh_req(t.ticker, t.yellow,
                                                    t.mnemonic):
        raise PimcoLiveException(
            'BBG Triplet {} is already queued as a new request in pl_refresh table'.format(
                t))

    series_id = get_series_id_from_bbg_triplet(t.ticker, t.yellow, t.mnemonic)
    schedule_code = driver_mapper.get_instance().get_schedule_code_from_series_id(
        series_id)
    bbg_program = schedule_mapper.get_instance().get_bbg_program_code(
        schedule_code)

    if bbg_program == constants.BBG_GETHIST_CODE:
        return True
    else:
        raise PimcoLiveException(
            "The download method for {} is not {}, so it is not refreshable".format(
                bbg_triplet, constants.BBG_GETHIST_CODE
            ))


class BbgTriplet:  # Todo: Change to triplet wherever possible
    def __init__(self, bbg_ticker, bbg_yellow, bbg_mnemonic):
        self.ticker = bbg_ticker
        self.yellow = bbg_yellow
        self.mnemonic = bbg_mnemonic

    def __str__(self):
        return '({}, {}, {})'.format(self.ticker, self.yellow, self.mnemonic)


if __name__ == '__main__':
    print get_next_7pm()
    nine_pm = datetime.datetime(day=28, month=2, year=2017, hour=21)
    r = get_next_7pm(nine_pm)
    assert r.day == 1 and r.month == 3
    assert r.hour == 19

    print get_next_saturday_2am()
    tuesday = datetime.datetime(day=22, month=8, year=2017, hour=21)
    r = get_next_saturday_2am(tuesday)
    assert r.day == 26 and r.hour == 2

    print 'Success!'
