from etl.pimco_live.mapper import bbg_yellow_key_mapper as mapper
from etl.pimco_live.exceptions import PimcoLiveException


def get_matching_key(key):
    yellow_key_mapper = mapper.get_instance()
    key = key.strip()
    result = yellow_key_mapper.model.query.filter(yellow_key_mapper.model.bbg_yellow_key.ilike(key))
    if not result.count():
        raise PimcoLiveException("Not a valid yellow key [{}]".format(key))
    row = result.first()
    return row.bbg_yellow_key
