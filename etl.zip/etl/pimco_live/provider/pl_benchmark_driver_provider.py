from etl.pimco_live.mapper import pl_benchmark_driver_mapper as mapper
from etl.pimco_live.exceptions import PimcoLiveException


def bbg_triplet_exists(bbg_ticker, bbg_yellow, bbg_mnemonic):
    pl_benchmark_driver_mapper = mapper.get_instance()
    result_set = pl_benchmark_driver_mapper.list_by_bbg_triplet(
        bbg_ticker, bbg_yellow, bbg_mnemonic)
    return result_set.count()


def get_series_id_from_bbg_triplet(bbg_ticker,
                                   bbg_yellow, bbg_mnemonic):
    pl_benchmark_driver_mapper = mapper.get_instance()
    result_set = pl_benchmark_driver_mapper.list_by_bbg_triplet(
        bbg_ticker, bbg_yellow, bbg_mnemonic)

    if result_set.count() == 0:
        raise PimcoLiveException('No series found for triplet ({}, {}, {})'.format(
            bbg_ticker, bbg_yellow, bbg_mnemonic
        ))
    elif result_set.count() > 1:
        raise PimcoLiveException('More than 1 series found for triplet ({}, {}, {})'.format(
            bbg_ticker, bbg_yellow, bbg_mnemonic
        ))
    else:  # only 1 series found
        row = result_set.first()
        return row.pl_series_id
