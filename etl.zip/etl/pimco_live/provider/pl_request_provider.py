from etl.pimco_live.mapper import pl_request_mapper2 as req_mapr
from etl.pimco_live.mapper.pl_request_status_mapper import Status


def is_duplicate_new_req(bbg_ticker, bbg_yellow_key, mnemonic):
    pl_request_mapper = req_mapr.get_instance()
    result = pl_request_mapper.model.query.filter_by(
        req_ticker=bbg_ticker,
        req_yellow_key=bbg_yellow_key,
        req_mnemonic=mnemonic,
        pl_request_status_code=Status.NEW
    )
    return result.count()


def is_duplicate_valid_req(bbg_ticker, bbg_yellow_key, mnemonic):
    pl_request_mapper = req_mapr.get_instance()
    result = pl_request_mapper.model.query.filter_by(
        req_ticker=bbg_ticker,
        req_yellow_key=bbg_yellow_key,
        req_mnemonic=mnemonic,
        pl_request_status_code=Status.VALID
    )
    return result.count()


def is_duplicate_onhold_req(bbg_ticker, bbg_yellow_key, mnemonic):
    pl_request_mapper = req_mapr.get_instance()
    result = pl_request_mapper.model.query.filter_by(
        req_ticker=bbg_ticker,
        req_yellow_key=bbg_yellow_key,
        req_mnemonic=mnemonic,
        pl_request_status_code=Status.ONHOLD
    )
    return result.count()


def add_request(pl_request_guid, pl_request_login_id, bbg_ticker,
                bbg_yellow_key, mnemonic, data_tag=''):
    """:return pl_request_id for the new request added"""
    pl_request_mapper = req_mapr.get_instance()
    row = pl_request_mapper.new_row(pl_request_guid=pl_request_guid,
                                    pl_request_login_id=pl_request_login_id,
                                    pl_request_status_code=Status.NEW,
                                    req_ticker=bbg_ticker,
                                    req_yellow_key=bbg_yellow_key,
                                    req_mnemonic=mnemonic,
                                    data_tag=data_tag, )
    # bbg_pricing_source=prc_src,
    # bbg_exchange_code=exch_code)
    pl_request_mapper.save(row)
    return get_request_id_from_guid(pl_request_guid)


def get_status_from_request_id(pl_request_id):
    pl_request_mapper = req_mapr.get_instance()
    row = pl_request_mapper.get(pl_request_id)
    return row.pl_request_status_code


def get_request_id_from_guid(guid):
    pl_request_mapper = req_mapr.get_instance()
    row = pl_request_mapper.get_by_guid(guid)
    return row.pl_request_id


def get_request(pl_request_id):
    """Returns Pimco Live Request Data Transfer Object"""
    pl_request_mapper = req_mapr.get_instance()
    req = pl_request_mapper.get(pl_request_id)
    return PlRequestDto(req)


def get_requests_from_data_tag(data_tag):
    pl_request_mapper = req_mapr.get_instance()
    result = pl_request_mapper.get_from_data_tag(data_tag)
    req_list = []
    for row in result.all():
        req_list.append(PlRequestDto(row))
    return req_list


class PlRequestDto:  # Data Transfer Object
    def __init__(self, result_row):
        self.pl_request_id = result_row.pl_request_id
        self.pl_request_guid = result_row.pl_request_guid
        self.pl_request_login_id = result_row.pl_request_login_id
        self.pl_request_status_code = result_row.pl_request_status_code
        self.bbg_ticker = result_row.req_ticker
        self.bbg_yellow_key = result_row.req_yellow_key
        self.mnemonic = result_row.req_mnemonic
        self.data_tag = result_row.data_tag
        # self.bbg_pricing_source = result_row.bbg_pricing_source
        # self.exchange_code = result_row.bbg_exchange_code
        self.public_msg = result_row.public_msg
