from etl.pimco_live.mapper import pl_refresh_mapper as refresh_mapper
from etl.pimco_live.mapper.pl_request_status_mapper import Status
import pl_benchmark_driver_provider
from etl.pimco_live.exceptions import PimcoLiveException


def add_refresh_request(pl_refresh_guid, pl_refresh_login_id, pl_series_id, refresh_schedule_date,
                        search_tag=''):
    """:return pl_refresh_id for the new request added"""
    pl_refresh_mapper = refresh_mapper.get_instance()
    row = pl_refresh_mapper.new_row(pl_refresh_guid=pl_refresh_guid,
                                    pl_refresh_login_id=pl_refresh_login_id,
                                    pl_series_id=pl_series_id,
                                    pl_refresh_status_code=Status.NEW,
                                    refresh_schedule_date=refresh_schedule_date,
                                    search_tag=search_tag
                                    )
    pl_refresh_mapper.save(row)
    return get_refresh_id_from_guid(pl_refresh_guid)


def get_status_from_refresh_id(pl_refresh_id):
    pl_refresh_mapper = refresh_mapper.get_instance()
    row = pl_refresh_mapper.get(pl_refresh_id)
    return row.pl_refresh_status_code


def get_refresh_id_from_guid(guid):
    pl_refresh_mapper = refresh_mapper.get_instance()
    row = pl_refresh_mapper.get_by_guid(guid)
    return row.pl_refresh_id


def is_duplicate_refresh_req(bbg_ticker, bbg_yellow_key, mnemonic):
    pl_refresh_mapper = refresh_mapper.get_instance()
    series_id = pl_benchmark_driver_provider.get_series_id_from_bbg_triplet(
        bbg_ticker, bbg_yellow_key, mnemonic
    )
    result = pl_refresh_mapper.model.query.filter_by(
        pl_series_id=series_id,
        pl_refresh_status_code=Status.NEW
    )
    return result.count()


def get_request(pl_refresh_id):
    """:return Pimco Live Refresh Data Transfer Object"""
    mapper = refresh_mapper.get_instance()
    req = mapper.get(pl_refresh_id)
    if req is None:
        raise PimcoLiveException("pl_refresh_id {} doesn't exist".format(pl_refresh_id))
    else:
        req_dto = PlRefreshDto(req)
        return req_dto


class PlRefreshDto:  # Data Transfer Object
    def __init__(self, result_row):
        self.pl_refresh_id = result_row.pl_refresh_id
        self.pl_refresh_guid = result_row.pl_refresh_guid
        self.pl_refresh_login_id = result_row.pl_refresh_login_id
        self.pl_series_id = result_row.pl_series_id
        self.pl_refresh_status_code = result_row.pl_refresh_status_code
        self.refresh_schedule_date = str(result_row.refresh_schedule_date)
        self.refresh_complete_date = result_row.refresh_complete_date
        self.search_tag = result_row.search_tag
        self.public_msg = result_row.public_msg
