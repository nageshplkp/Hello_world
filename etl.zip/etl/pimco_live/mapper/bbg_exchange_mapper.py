"""Db adapter for PM_OWN.BBG_EXCHANGE"""
from etl.core.mapper_base import BaseMapperWithPK

_instance = None


def get_instance():
    global _instance
    if _instance is None:
        _instance = BbgExchangeMapper()
    return _instance


class BbgExchangeMapper(BaseMapperWithPK):
    def __init__(self):
        super(BbgExchangeMapper, self).__init__('PM_OWN', 'BBG_EXCHANGE', ['bbg_exchange_code'])
