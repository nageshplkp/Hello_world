"""Db adapter for PM_OWN.BBG_YELLOW_KEY"""
from etl.core import db

_instance = None


def get_instance():
    global _instance
    if _instance is None:
        _instance = BbgYellowKeyMapper()
    return _instance


class BbgYellowKeyMapper(object):
    def __init__(self):
        self.db_context = db.ora_pim('PM_OWN')
        self.model = self.db_context.create_model('BBG_YELLOW_KEY')
