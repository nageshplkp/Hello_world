"""Db adapter for PM_OWN.PL_REQUEST"""
from etl.core import db

_instance = None


def get_instance():
    global _instance
    if _instance is None:
        _instance = PlRequestMapper()
    return _instance


class PlRequestMapper(object):
    def __init__(self):
        self.db_context = db.ora_pim('PM_OWN')
        self.model = self.db_context.create_model('PL_REQUEST')

    def new_row(self, **kwargs):
        return self.model(**kwargs)

    def get(self, pl_request_id):
        return self.model.query.get(pl_request_id)

    def get_by_guid(self, pl_request_guid):
        return self.model.query.filter_by(
            pl_request_guid=pl_request_guid).first()

    def get_from_data_tag(self, data_tag):
        return self.model.query.filter(self.model.data_tag.ilike(data_tag))

    def save(self, row):
        self.db_context.save(row)
