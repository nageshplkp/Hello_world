"""Db adapter for PM_OWN.BBG_PRICING_SOURCE"""
from etl.core.mapper_base import BaseMapperWithPK

_instance = None


def get_instance():
    global _instance
    if _instance is None:
        _instance = BbgPricingSourceMapper()
    return _instance


class BbgPricingSourceMapper(BaseMapperWithPK):
    def __init__(self):
        super(BbgPricingSourceMapper, self).__init__('PM_OWN', 'BBG_PRICING_SOURCE',
                                                     ['bbg_pricing_source'])

