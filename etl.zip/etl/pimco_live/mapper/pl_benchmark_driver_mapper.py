"""Db adapter for PM_OWN.PL_BENCHMARK_DRIVER"""
from etl.core import db

_instance = None


def get_instance():
    global _instance
    if _instance is None:
        _instance = PlBenchmarkDriverMapper()
    return _instance


class PlBenchmarkDriverMapper(object):
    def __init__(self):
        self.db_context = db.ora_pim('PM_OWN')
        self.model = self.db_context.create_model('PL_BENCHMARK_DRIVER')

    def new_row(self, **kwargs):
        return self.model(**kwargs)

    def list_by_bbg_triplet(self, bbg_ticker, bbg_yellow, bbg_mnemonic):
        return self.model.query.filter_by(bbg_ticker=bbg_ticker,
                                          bbg_yellow=bbg_yellow,
                                          bbg_mnemonic=bbg_mnemonic)

    def get_schedule_code_from_series_id(self, series_id):
        """You are responsible for passing a valid series_id"""
        return self.model.query.filter_by(
            pl_series_id=series_id).first().pl_schedule_code

    def save(self, row):
        self.db_context.save(row)
