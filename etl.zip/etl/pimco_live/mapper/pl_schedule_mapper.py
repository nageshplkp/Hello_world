"""Db adapter for PM_OWN.PL_SCHEDULE"""
from etl.core import db
from etl.pimco_live.exceptions import PimcoLiveException

_instance = None


def get_instance():
    global _instance
    if _instance is None:
        _instance = PlScheduleMapper()
    return _instance


class PlScheduleMapper(object):
    def __init__(self):
        self.db_context = db.ora_pim('PM_OWN')
        self.model = self.db_context.create_model('PL_SCHEDULE')

    def get(self, pl_schedule_code):
        return self.model.query.get(pl_schedule_code)

    def get_bbg_program_code(self, pl_schedule_code):
        row = self.model.query.get(pl_schedule_code)
        if not row:
            raise PimcoLiveException("Couldn't find schedule_code [{}] in PL_SCHEDULE".format(
                pl_schedule_code))
        else:
            return row.bbg_program_code

    def get_bbg_interface_code(self, pl_schedule_code):
        row = self.model.query.get(pl_schedule_code)
        if not row:
            raise PimcoLiveException("Couldn't find schedule_code [{}] in PL_SCHEDULE".format(
                pl_schedule_code))
        else:
            return row.bbg_interface_code
