"""Db adapter for PM_OWN.PL_REFRESH"""
from etl.core import db

_instance = None


def get_instance():
    global _instance
    if _instance is None:
        _instance = PlRefreshMapper()
    return _instance


class PlRefreshMapper(object):
    def __init__(self):
        self.db_context = db.ora_pim('PM_OWN')
        self.model = self.db_context.create_model('PL_REFRESH')

    def new_row(self, **kwargs):
        return self.model(**kwargs)

    def get(self, pl_refresh_id):
        return self.model.query.get(pl_refresh_id)

    def get_by_guid(self, pl_refresh_guid):
        return self.model.query.filter_by(
            pl_refresh_guid=pl_refresh_guid).first()

    def get_from_search_tag(self, search_tag):
        return self.model.query.filter(self.model.search_tag.ilike(search_tag))

    def save(self, row):
        self.db_context.save(row)
