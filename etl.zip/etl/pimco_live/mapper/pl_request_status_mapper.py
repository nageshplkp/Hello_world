__author__ = 'vmaithan'

class Status:
    NEW = 'NEW'
    DONE = 'DONE'
    IP = 'IP'
    VALID = 'VALID'
    INVALID = 'INVALID'
    ONHOLD = 'ONHOLD'