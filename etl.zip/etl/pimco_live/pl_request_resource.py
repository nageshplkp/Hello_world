import getpass
import logging
import re
import traceback
from httplib import NOT_FOUND

from flask import request
from flask_restful import reqparse, abort, Resource

import etl.pimco_live.provider.bbg_yellow_key_provider as yellow_key_provider
from core.services import pimproxy
from etl.pimco_live.exceptions import PimcoLiveException
from etl.pimco_live.provider.pimco_live_provider import add_new_request
from etl.pimco_live.provider.pl_request_provider import \
    get_status_from_request_id, get_requests_from_data_tag, \
    get_request
# import etl.pimco_live.bbg_helper as bbg_helper
from etl.repo.pim_pm import PlRequestRepo


class PimcoLiveRequestListApi(Resource):
    def __init__(self):
        self.parser = PimcoLiveRequestListApi.get_request_parser()

    @classmethod
    def check_param_and_to_upper(cls, args, param_name):
        param_val = args[param_name]
        if not param_val:
            raise PimcoLiveException("{} cannot be empty - value []".format(param_name, param_val))
        param_val = param_val.upper()
        return param_val

    def validate_args(self, args):
        bbg_yellow = args['bbg_yellow']
        yellow_key = yellow_key_provider.get_matching_key(bbg_yellow)
        bbg_ticker = self.check_param_and_to_upper(args, 'bbg_ticker')
        bbg_mnemonic = self.check_param_and_to_upper(args, 'bbg_mnemonic')
        data_tag = self.check_param_and_to_upper(args, 'data_tag')        
        """Very Important : Remove multiple spaces or the comparisons
           with benchmark table won't work"""
        bbg_ticker = re.sub(' +', ' ', bbg_ticker)

        # exchange_code, pricing_source = bbg_helper.get_exchange_and_price_src(bbg_ticker)
        return bbg_ticker, yellow_key, bbg_mnemonic, data_tag

    def post(self):
        args = self.parser.parse_args()
        login_id = pimproxy.username() or getpass.getuser()
        try:
            bbg_ticker, yellow_key, mnemonic, data_tag = self.validate_args(
                args)
            request_id = add_new_request(login_id, bbg_ticker, yellow_key, mnemonic, data_tag)
            url_path = '/requests/{}/status'.format(request_id)
            return {'request_id': request_id, 'status_uri': request.url_root.rstrip('/') + url_path}

        except PimcoLiveException as e:
            abort(400, message=str(e))

        except Exception:
            logging.exception("Exception occurred: ")
            abort(500, message="Exception occurred: " + traceback.format_exc())

    def get(self, req_id):
        try:
            req_dto = get_request(int(req_id))
            return req_dto.__dict__
        except AttributeError:
            abort(404, message="req_id {} doesn't exist".format(req_id))

    @classmethod
    def get_request_parser(cls):
        parser = reqparse.RequestParser(bundle_errors=True, trim=True)
        parser.add_argument('bbg_ticker', required=True)
        parser.add_argument('bbg_yellow', required=True)
        parser.add_argument('bbg_mnemonic', required=True)
        parser.add_argument('data_tag', required=True)
        return parser


class PimcoLiveRequestSearchApi(Resource):
    def get(self, data_tag):
        data_tag = data_tag.strip().upper()
        req_list = get_requests_from_data_tag(data_tag)
        return {'request_list': [req_dto.__dict__ for req_dto in req_list]}


class PimcoLiveRequestStatusApi(Resource):
    def get(self, req_id):
        try:
            return {'status': get_status_from_request_id(int(req_id))}
        except AttributeError:
            abort(404, message="req_id {} doesn't exist".format(req_id))


class PimcoLiveRequestSkippedApi(Resource):
    @staticmethod
    def put(req_id):
        update_for_pl_request_id(req_id, pl_request_status_code='SKIPPED')


class PimcoLiveRequestValidApi(Resource):
    @staticmethod
    def put(req_id):
        update_for_pl_request_id(req_id, pl_request_status_code='VALID')


def update_for_pl_request_id(req_id, **kwargs):
    do_upd = PlRequestRepo.instance.update_for_pl_request_id
    if not do_upd(req_id, **kwargs):
        abort(NOT_FOUND, message="pl_request_id %d doesn't exist" % req_id)
