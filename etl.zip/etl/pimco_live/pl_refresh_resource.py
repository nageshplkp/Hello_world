import getpass
import traceback
import logging

from flask import request
from flask_restful import reqparse, Resource, abort
from core.services import pimproxy

from etl.pimco_live.provider.pimco_live_provider import add_new_refresh_request
from etl.pimco_live.exceptions import PimcoLiveException
from etl.pimco_live.provider.pl_refresh_provider import get_request, get_status_from_refresh_id
import etl.pimco_live.provider.bbg_yellow_key_provider as yellow_key_provider
from etl.pimco_live.pl_request_resource import PimcoLiveRequestListApi


class PimcoLiveRefreshRequestListApi(Resource):
    def __init__(self):
        self.parser = PimcoLiveRefreshRequestListApi.get_request_parser()

    def post(self):
        args = self.parser.parse_args()
        bbg_yellow = args['bbg_yellow']
        bbg_ticker = PimcoLiveRequestListApi.check_param_and_to_upper(args, 'bbg_ticker')
        mnemonic = PimcoLiveRequestListApi.check_param_and_to_upper(args, 'bbg_mnemonic')
        search_tag = args['search_tag'] or ''
        if search_tag:
            search_tag = search_tag.upper()

        man_override_str = 'MANUAL_OVERRIDE'
        if man_override_str in search_tag:
            abort(400, message='data_tag contains {}'.format(man_override_str))

        login_id = pimproxy.username() or getpass.getuser()
        try:
            yellow_key = yellow_key_provider.get_matching_key(bbg_yellow)
            request_id = add_new_refresh_request(login_id, bbg_ticker, yellow_key, mnemonic, search_tag=search_tag)
            url_path = '/refresh_requests/{}/status'.format(request_id)
            return {'request_id': request_id,
                    'status_uri': request.url_root.rstrip('/') + url_path}

        except PimcoLiveException as e:
            abort(400, message=str(e))
        except Exception:
            logging.exception("Exception occurred: ")
            abort(500, message="Exception occurred: " + traceback.format_exc())

    def get(self, req_id):
        try:
            req_dto = get_request(int(req_id))
            return req_dto.__dict__
        except PimcoLiveException:
            abort(404, message="req_id {} doesn't exist".format(req_id))

    @classmethod
    def get_request_parser(cls):
        parser = reqparse.RequestParser(bundle_errors=True, trim=True)
        parser.add_argument('bbg_ticker', required=True)
        parser.add_argument('bbg_yellow', required=True)
        parser.add_argument('bbg_mnemonic', required=True)
        parser.add_argument('search_tag', required=False)
        return parser


class PimcoLiveRefreshRequestStatusApi(Resource):
    def get(self, req_id):
        try:
            return {'status': get_status_from_refresh_id(int(req_id))}
        except AttributeError:
            abort(404, message="req_id {} doesn't exist".format(req_id))
