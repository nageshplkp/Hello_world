import etl.pimco_live.constants as constants
import etl.pimco_live.provider.bbg_pricing_source_provider as bbg_pricing_source_provider
import etl.pimco_live.provider.bbg_exchange_provider as bbg_exchange_provider
from etl.pimco_live.exceptions import PricingSourceNotFoundInTickerException, \
                                      ExchangeNotFoundInTickerException


def get_exchange_and_price_src(bbg_ticker):
    """Returns exchange code and pricing source for the supplied ticker"""
    bbg_ticker = bbg_ticker.upper()
    try:
        exchange_code = bbg_exchange_provider.find_exchange_in_ticker(bbg_ticker)
    except ExchangeNotFoundInTickerException:
        exchange_code = constants.UNDEF

    try:
        pricing_source = bbg_pricing_source_provider.find_pricing_source_in_ticker(bbg_ticker)
    except PricingSourceNotFoundInTickerException:
        pricing_source = constants.UNDEF

    return exchange_code, pricing_source
