import getpass
import json
import logging
import os
import re
from datetime import datetime
from os import path
from os.path import getmtime, exists
from socket import gethostname
from time import sleep
from xml.etree import ElementTree

import requests
from werkzeug.exceptions import BadRequest
from werkzeug.utils import cached_property

from core.common.decorate import ExceptionHandler
from core.log.log_config import create_file_handler
from etl.core.util import deep_substitute, download_file, sub_dhash, \
    replace_date, struct, dirtree, cp_files, tmp_dir, \
    unzip, rsync_path_delim_insert, ensuredir
from etl.repo.fnd_cfdw import VEtlSourceMergedRepo, EtlFileRepo

ETL_SOURCE_CODE = 'INTEX_MTG_CMO_DEAL'
TEXT_CDI = 'User ! Download Data Deal Models CDI/CDU/etc'
TEXT_PP = 'User - Download Data - PrePrice Models'
TEXT_PP_GO = TEXT_PP + ' ? Go'
PRE_PRICE_PWD_KEY = 'DealPwd'
URL_ISAPI = '/scripts/isapi/intexnet19.dll'
URL_LOGIN = '/qc?function=Login'
URL_REQUEST = '/qc?function=WebtraderAction'
URL_REQUEST_STATUS = '/qc?function=WebtraderRequestStatus'
TMPL_PAYLOAD_LOGIN = dict(
    bForceVersion=0, bExtendedDetails=1, version='prod', shemp='$http_password',
    sEntryPoint='Website')
TMPL_PAYLOAD_SESSION = dict(
    version='$sVersion', SESSION_KEY='$sSessionKey', cmid='$cmid')
TMPL_PAYLOAD_REQUEST_COMMON = dict(
    TMPL_PAYLOAD_SESSION,
    PAGE_TYPE='submit', VER='PROD', CF_COUNTER='$sXgene', ScenActive=0,
    xgene='$sXgene', BasePath='$sBasePath', Last_Form_Var='Last_Form_Var')
TMPL_PAYLOAD_REQUEST = dict(
    TMPL_PAYLOAD_REQUEST_COMMON,
    ACTION=TEXT_CDI, OPENER_ACTION=TEXT_CDI, PREVACTION=TEXT_CDI,
    DOD_DEAL='$deal_name', DOD_DNLD_ALL=2, DOD_POST_TO_FTP=1, DOD_MODE=1)
TMPL_PAYLOAD_REQUEST_PP = dict(
    TMPL_PAYLOAD_REQUEST_COMMON,
    ACTION=TEXT_PP_GO, OPENER_ACTION=TEXT_PP, PREVACTION=TEXT_PP_GO,
    ORIGACTION=TEXT_PP_GO, IsapiURL=URL_ISAPI,
    DealName='$deal_name', DealPwd='$DealPwd')
TMPL_PAYLOAD_REQUEST_STATUS = dict(
    TMPL_PAYLOAD_SESSION, iStatusVersion='$iStatusVersion',
    iWebtraderRequestId='$request_id', iConnectionErrorCount=0)


class IntexDeal(object):
    def __init__(self, deal_name, creds=None, etl_source_code=None):
        self.creds = creds or {'user': getpass.getuser()}
        self.deal_name = deal_name.lower()
        self.etl_source_code = etl_source_code or ETL_SOURCE_CODE
        self.rgx = struct(deal_upd=re.compile(r'\.cd[pu]$'),
                          deal_tail=re.compile(r'\b(?:[0-9]{4}[/\\])?[^/\\]+$'),
                          non_idx=re.compile(r'\.(?!id[lx]$)'),
                          yydd=re.compile(r'\d{4}[/\\]'),
                          yyyymmdd=re.compile(r'\d{8}'))
        self.vetl_source_merged_repo = VEtlSourceMergedRepo.instance
        self.etl_file_repo = EtlFileRepo(self.vetl_source_merged_repo.db)
        add_log_file_handler(self.log_file)
        self.published_files = None

    def download_and_publish(self):
        self.download()
        self.publish()

    @ExceptionHandler()
    def download(self):
        download_file(self.download_url, self.zip_file)

    @ExceptionHandler()
    def publish(self, stage_dir=None):
        if not self.publish_dir or not exists(self.publish_dir):
            raise RuntimeError('%s: output_file_folder not found for %s' %
                               (str(self.publish_dir), self.etl_source_code))
        stage_dir = stage_dir or self._unzip
        with tmp_dir(self.track_dir, stage_dir) as d:
            files = filter(self._is_valid_deal, dirtree(d))
            self._backup_files(files)
            self._publish_files(d, files)
        self._populate_etl_file_entries(files)

    @property
    def backup_dir(self):
        _dir = path.join(self.cfg['backup_dir'], self.file_name_base)
        return self._interpolate(_dir, **self.cfg)

    @property
    def download_url(self):
        (request_id, base_f) = (
            (self.pre_price_request, self.deal_name) if self.is_pre_price else
            (self.request, 'DownloadData'))
        url = self.url + path.dirname(self._download_url_for(request_id))
        return url + '/%s.zip' % base_f

    @property
    def file_name_base(self):
        return path.splitext(path.basename(self.zip_file))[0]

    @property
    def is_pre_price(self):
        return 'password' in self.creds

    @property
    def log_file(self):
        return self._interpolate(self.cfg['log_file_path_template'])

    @property
    def pre_price_request(self):
        d = {'deal_name': self.deal_name,
             PRE_PRICE_PWD_KEY: self.creds['password']}
        d.update(self.session_data)
        r = self._post_subst(URL_REQUEST, TMPL_PAYLOAD_REQUEST_PP, d)
        return self._xml2dict(r.content)['iWebtraderRequestId']

    @property
    def publish_dir(self):
        return self._interpolate(self.cfg['output_file_folder'])

    @property
    def request(self):
        d = dict(self.session_data, deal_name=self.deal_name)
        r = self._post_subst(URL_REQUEST, TMPL_PAYLOAD_REQUEST, d)
        return self._xml2dict(r.content)['iWebtraderRequestId']

    @property
    def request_dir(self):
        return self._interpolate(self.cfg['request_dir'])

    @property
    def track_dir(self):
        _dir = path.join(self.cfg['local_file_folder'], self.file_name_base)
        return self._interpolate(_dir)

    @property
    def url(self):
        return self._interpolate(self.cfg['url'])

    @cached_property
    def cfg(self):
        get_by_source_code = self.vetl_source_merged_repo.get_by_source_code
        cfg = get_by_source_code(self.etl_source_code)
        d = json.loads(cfg.process_config) if cfg.process_config else {}
        d.update(vars(cfg))
        return d

    @cached_property
    def session_data(self):
        r = self._post_subst(URL_LOGIN, TMPL_PAYLOAD_LOGIN, self.cfg)
        return self._xml2dict(r.content)

    @cached_property
    def zip_file(self):
        _f = path.join(self.request_dir, self.cfg['file_names'])
        _f = sub_dhash(_f, lambda m: self.deal_name if m == 'DEAL_NAME' else m)
        return self._interpolate(_f)

    def _backup_files(self, files):
        files = [self._deal_path_tail(f) for f in files]
        src, dst = self.publish_dir, self.backup_dir
        cp_files([(path.join(src, f), path.join(dst, f)) for f in files])

    def _deal_path_tail(self, deal_path):
        return self.rgx.deal_tail.search(deal_path).group(0)

    def _download_url_for(self, request_id):
        resp = self._request_status(request_id)
        while resp['sStatus'] != 'DONE':
            if resp['sStatus'] == 'ERROR':
                raise BadRequest(resp['sMessage'])
            sleep(1)
            resp = self._request_status(request_id, resp['iStatusVersion'])
        return resp['sUrl']

    def _is_valid_deal(self, f):
        if self.rgx.deal_upd.search(f):
            return self.rgx.yydd.search(f)
        return self.rgx.non_idx.search(f)

    def _populate_etl_file_entries(self, files):
        rows = [self._new_etl_file_entry(f) for f in files]
        self.etl_file_repo.save(rows)

    def _new_etl_file_entry(self, f):
        src = self.track_dir + '/' + f
        rsync_path_limit = self.rgx.deal_tail.search(src).start()
        src = rsync_path_delim_insert(src, rsync_path_limit)
        ymd = self.rgx.yyyymmdd.search(self.file_name_base).group(0)
        cmd = 'rsync -DRilprtuz %s %s' % (src, self.publish_dir)
        return self.etl_file_repo.new_row(
            file_source=ETL_SOURCE_CODE, local_file_name=f, is_enabled=1,
            dw_insert_by=self.creds['user'],
            file_yyyymmdd=ymd, file_frequency='V', ftp_cmd=cmd,
            ftp_file_folder=self.track_dir, ftp_file_name=f,
            ftp_server_name=gethostname(), log_file_path=self.log_file)

    def _post_subst(self, url, tmpl, cfg):
        data = deep_substitute(tmpl, cfg)
        url = self.url + url
        logging.info('%s: [POST]%s', url, json.dumps(data))
        r = requests.post(url, data)
        logging.info('%s: %s', url, str(r))
        return r

    def _publish_files(self, src_dir, files):
        def _is_newer(src_dst):
            src, dst = src_dst
            if not exists(dst):
                return True
            src_dt = datetime.fromtimestamp(getmtime(src))
            dst_dt = datetime.fromtimestamp(getmtime(dst))
            return src_dt > dst_dt

        cps = [(path.join(src_dir, f),
                path.join(self.publish_dir, self._deal_path_tail(f)))
               for f in files]
        cps = filter(_is_newer, cps)
        cp_files(cps)
        self.published_files = dict(cps).values()

    def _request_status(self, request_id, status_version=None):
        d = dict(self.session_data, request_id=request_id,
                 iStatusVersion=status_version or 'undefined')
        r = self._post_subst(URL_REQUEST_STATUS, TMPL_PAYLOAD_REQUEST_STATUS, d)
        return self._xml2dict(r.content)

    def _unzip(self, out_dir):
        unzip(self.zip_file, out_dir)

    @staticmethod
    def _interpolate(s, **kwargs):
        from string import Template
        s = sub_dhash(replace_date(s), kwargs)
        return s if s is None else Template(s).safe_substitute(os.environ)

    @staticmethod
    def _xml2dict(xml):
        root = ElementTree.fromstring(xml)
        attrs = root.findall('.//String/..')
        return {attr.attrib['key']: attr[0].text for attr in attrs}


def add_log_file_handler(log_file_path):
    ensuredir(path.dirname(log_file_path))
    logger = logging.getLogger('')
    handler = create_file_handler(log_file_path, logging.DEBUG)
    handler.setFormatter(logger.handlers[0].formatter)
    logger.addHandler(handler)
    return logging


if __name__ == '__main__':  # pragma no cover
    IntexDeal('schol11b').download_and_publish()
