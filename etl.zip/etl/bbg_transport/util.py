import logging
from shutil import copyfile

from etl.bbg_transport.config import config_api
from etl.core.db import Db
from etl.core.util import struct
from etl.enum.cor_da import BtStatusEnum
from etl.repo.cor_da.bt_config import BtConfigRepo
from etl.repo.cor_da.bt_option_config import BtOptionConfigRepo
from etl.repo.cor_da.bt_request import BtRequestRepo
from etl.repo.cor_da.bt_request_batch import BtRequestBatchRepo
from etl.repo.cor_da.bt_requestor import BtRequestorRepo
from etl.repo.pim_da.bbg_bulk_fmt_translation_vw import BbgBulkFmtTranslationVwRepo


class BtRepoBase(object):
    def __init__(self):
        logging.getLogger(__name__).setLevel(int(config_api().get('log_level')))
        self._sqla_logger = logging.getLogger('sqlalchemy')
        self._sqla_logger.propagate = bool(config_api().get('sqla_log'))
        self._request_repo = None
        self._batch_repo = None
        self._requestor_repo = None
        self._config_repo = None
        self._opt_config_repo = None
        self._bulk_fmt_repo = None
        self._db_cor_da = None
        self._db_pim_da = None

    @property
    def db_cor_da(self):
        if self._db_cor_da is None:
            self._db_cor_da = Db('ORACOR_DBP', 'oracle')
        return self._db_cor_da

    @property
    def db_pim_da(self):
        if self._db_pim_da is None:
            self._db_pim_da = Db('ORAPIM_DBP', 'oracle')
        return self._db_pim_da

    @property
    def request_repo(self):
        if self._request_repo is None:
            self._request_repo = BtRequestRepo(self.db_cor_da)
        return self._request_repo

    @property
    def batch_repo(self):
        if self._batch_repo is None:
            self._batch_repo = BtRequestBatchRepo(self.db_cor_da)
        return self._batch_repo

    @property
    def requestor_repo(self):
        if self._requestor_repo is None:
            self._requestor_repo = BtRequestorRepo(self.db_cor_da)
        return self._requestor_repo

    @property
    def config_repo(self):
        if self._config_repo is None:
            self._config_repo = BtConfigRepo(self.db_cor_da)
        return self._config_repo

    @property
    def opt_config_repo(self):
        if self._opt_config_repo is None:
            self._opt_config_repo = BtOptionConfigRepo(self.db_cor_da)
        return self._opt_config_repo

    @property
    def bulk_fmt_repo(self):
        if self._bulk_fmt_repo is None:
            self._bulk_fmt_repo = BbgBulkFmtTranslationVwRepo(self.db_pim_da)
        return self._bulk_fmt_repo

    def _sync_lookback_requests(self, request):
        if request is None:
            return
        children = self.request_repo.list_by_lookback_bt_request_id(request.bt_request_id)
        if children is None:
            return
        for child in children:
            child.bt_status_code = request.bt_status_code
            child.status_date = request.status_date
            child.process_date = request.process_date
            child.retry_count = request.retry_count
            if request.data_file_path and request.bt_status_code == BtStatusEnum.SUCCESS.value:
                child.data_file_path = request.data_file_path.replace(str(request.bt_request_id),
                                                                      str(child.bt_request_id))
                copyfile(request.data_file_path, child.data_file_path)
            self.request_repo.save(child)
            if child.bt_status_code in BbgConfig.STATUS_LIST_COMPLETE:
                batches = self.batch_repo.list_by_bt_request_id(request.bt_request_id)
                for batch in batches:
                    child_batch = self.batch_repo.get_by_bt_request_id_file_sequence_no(child.bt_request_id,
                                                                                        batch.file_sequence_no)
                    if child_batch is None:
                        child_batch = self.batch_repo.BtRequestBatch()
                    child_batch.bt_request_id = child.bt_request_id
                    child_batch.file_sequence_no = batch.file_sequence_no
                    child_batch.request_file_path = batch.request_file_path
                    child_batch.response_file_path = batch.response_file_path
                    child_batch.response_received_date = batch.response_received_date
                    child_batch.is_error_response = batch.is_error_response
                    child_batch.error_text = batch.error_text
                    child_batch.bbg_time_started = batch.bbg_time_started
                    child_batch.bbg_time_finished = batch.bbg_time_finished
                    self.batch_repo.save(child_batch)
            self._sync_lookback_requests(child)


class BbgConfig(BtRepoBase):
    AGENT_DIRECTION_REQUEST = 'REQUEST'
    AGENT_DIRECTION_RESPONSE = 'RESPONSE'
    BBG_RESPONSE_TYPE = struct(ERROR=-1, NONE=0, VALID=1)
    ERROR_FILE_EXT = 'err'
    ZIP_FILE_EXT = 'gz'
    FILE_SECTIONS = struct(PRE=-1,
                           NONE=0,
                           OPTIONS=1,
                           FIELDS=2,
                           START_TIME=3,
                           END_TIME=4,
                           DATA=5)
    FILE_TAGS = struct(FILE_START='START-OF-FILE',
                       FILE_END='END-OF-FILE',
                       FIELDS_START='START-OF-FIELDS',
                       FIELDS_END='END-OF-FIELDS',
                       TIME_STARTED='TIMESTARTED',
                       TIME_FINISHED='TIMEFINISHED',
                       DATA_START='START-OF-DATA',
                       DATA_END='END-OF-DATA',
                       SECURITY_START='START SECURITY',
                       SECURITY_END='END SECURITY')
    INTERNAL_HOST_FLAG = '#INTERNAL#'
    VERTICAL_MNEMONIC_COLUMN = 'MNEMONIC'
    VERTICAL_DATA_COLUMN = 'VALUE'
    KEY_BBG_FTP_HOST = 'BBG_FTP_HOST'
    KEY_BBG_FTP_HOST_2 = 'BBG_FTP_HOST2'
    KEY_BBG_FTP_PORT = 'BBG_FTP_PORT'
    KEY_BBG_FTP_PASSWORD = 'BBG_FTP_X'
    KEY_BBG_FTP_USER = 'BBG_FTP_USER'
    KEY_BBG_FTP_IN_LOC = 'BBG_FTP_IN_LOC'
    KEY_BBG_FTP_OUT_LOC = 'BBG_FTP_OUT_LOC'
    KEY_DATA_FILE_IN_LOC = 'DATA_FILE_IN_LOC'
    KEY_DATA_FILE_IN_LOC_WIN = 'DATA_FILE_IN_LOC_WIN'
    KEY_MAX_REQUEST_ITEMS = 'MAX_REQUEST_ITEMS'
    KEY_REQ_FILE_OUT_LOC = 'REQ_FILE_OUT_LOC'
    KEY_ENVIRONMENT = 'ENV'
    KEY_MAX_RETRY = 'MAX_RETRY'
    OPTION_KEY_REPLY_FILE = 'REPLYFILENAME'
    REQUEST_FILE_NAME_TEMPLATE = '##YYYYMMDD##.##ENV##.##REQUEST_ID##.##SEQ_NO##.req'
    STATUS_LIST_COMPLETE = [BtStatusEnum.SUCCESS.value, BtStatusEnum.BTERROR.value, BtStatusEnum.BBGERROR.value]
    STATUS_LIST_INCOMPLETE = [BtStatusEnum.INITIAL.value, BtStatusEnum.PENDING.value]
    TEMPLATE_SECTIONS = struct(OPTIONS='##OPTIONS##',
                               FIELDS='##FIELDS##',
                               DATA='##DATA##')
    TIME_FORMAT = '%a %b %d %H:%M:%S %Z %Y'

    def __init__(self):
        super(BbgConfig, self).__init__()
        self.data = dict()
        [self._set_config_value(i) for i in self.config_repo.query.all()]
        self.opt_config = self.opt_config_repo.query.all()

    def _set_config_value(self, item):
        self.data[item.config_code] = item.config_value

    def hash_exclude_options(self):
        return (i.option_name for i in self.opt_config if bool(i.is_hash_exclude_option))

    def get_file_option_config(self, program_code):
        return (i for i in self.opt_config if i.bbg_program_code == program_code)
