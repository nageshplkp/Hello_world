import csv
import json
from time import sleep

from etl.bbg_transport.dto import RequestDataItem, RequestItem, RequestOptionItem
from etl.core.util import uri_post, uri_get

BASE_URL = 'http://ptp-dev/workshop/service/bbg_transport/'
BT_ERROR_STATUS = ['BBGERROR', 'BTERROR']
BT_COMPLETE_STATUS = ['BBGERROR', 'BTERROR', 'SUCCESS']
SECONDS_TO_SLEEP = 15


def _wait_for_complete(status_svc_response):
    body = dict(status_svc_response['body'])
    status = body['request_status']
    if status in BT_COMPLETE_STATUS:
        return body
    sleep(SECONDS_TO_SLEEP)
    return _wait_for_complete(uri_get(body['progression_url']))


def bt_json_to_obj_list(chk_status_body):
    svc_response = uri_get(chk_status_body['progression_url'])
    return json.loads(svc_response['body'])


def bt_csv_to_obj_list(chk_status_body):
    with open(chk_status_body['data_file_path']) as f:
        return csv.DictReader(f)


def get_data_items():
    return [RequestDataItem(cusip='912828RL6'), RequestDataItem(cusip='912828RC6'), RequestDataItem(cusip='912810QS0')]


def get_fields():
    return ['YLD_YTM_ASK', 'ISSUE_DT', 'MATURITY']


def get_options():
    return [RequestOptionItem('DATERANGE', '20170101|20171231'), RequestOptionItem('RUNDATE', '20180118'),
            RequestOptionItem('PROGRAMFLAG', 'one-shot'), RequestOptionItem('PROGRAMNAME', 'gethistory'),
            RequestOptionItem('FIRMNAME', 'pimco')]


def get_request_item():
    data_items = get_data_items()
    fields = get_fields()
    options = get_options()
    return RequestItem(request_description='Get History Test',
                       requestor_code='BT.DEV',
                       program_code='GETHISTORY',
                       interface_code='DL',
                       response_format_code='CSV',
                       request_data_items=data_items,
                       request_options=options,
                       request_fields=fields).to_json()


def test_get_history():
    payload = get_request_item().to_json()
    response = uri_post(BASE_URL + 'request_data', payload)
    if response is None:
        raise Exception("Response is None")
    while True:
        if response['status'] != 'SUCCESS':
            raise Exception("Service call failed!")
        body = dict(response['body'])
        if body['request_status'] in BT_COMPLETE_STATUS:
            break
        sleep(SECONDS_TO_SLEEP)
        response = uri_get(body['progression_url'])
    if body['request_status'] in BT_ERROR_STATUS:
        errors = '\n'.join([i.error_text for i in body['response_file_info'] if bool(i['is_error_response']) is True])
        error_type = ' Transport' if body['request_status'] == ' BTERROR' else ''
        raise Exception("Bloomberg{} Returned an Error: {}".format(error_type, errors))
        # python_data = bt_json_to_obj_list(body)
        # Do Something with the Python objects here contained in 'python_data'
        # csv_data = bt_csv_to_obj_list(body)
        # pcnt = len(python_data)
        # ccnt = len(csv_data)


if __name__ == "__main__":
    test_get_history()
