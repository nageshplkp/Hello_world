from etl.enum.fnd_cfdw.gen.x_partition_type import XPartitionTypeEnum

from etl.enum.fnd_cfdw.gen.etl_export_type import EtlExportTypeEnum
from etl.enum.fnd_cfdw.gen.etl_export_program import EtlExportProgramEnum