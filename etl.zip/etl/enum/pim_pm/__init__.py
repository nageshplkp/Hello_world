from etl.enum.pim_pm.gen.pl_request_status import PlRequestStatusEnum
