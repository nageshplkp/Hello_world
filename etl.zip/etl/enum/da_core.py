from enum import Enum


class DaSvcStatusEnum(Enum):
    SUCCESS = 'SUCCESS'
    HTTP_ERROR = 'HTTP_ERROR'
    API_ERROR = 'API_ERROR'
