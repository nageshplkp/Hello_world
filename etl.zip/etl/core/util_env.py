from datetime import datetime
from os import environ

import arrow

DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
DATETIME_FORMAT_ARROW = 'YYYY-MM-DD HH:mm:ss'
KEY_AUDIT_ID = 'ETL_AUDIT_ID'
KEY_LOAD_START_DATE = 'ETL_LOAD_START_DATE'
KEY_LOAD_START_DATE_UTC = 'ETL_LOAD_START_DATE_UTC'
KEY_LOAD_END_DATE = 'ETL_LOAD_END_DATE'
KEY_LOAD_END_DATE_UTC = 'ETL_LOAD_END_DATE_UTC'
KEY_WORKFLOW_NAME = 'ETL_WORKFLOW_NAME'
KEY_SERVICE_NAME = 'ETL_SERVICE_NAME'
KEY_LOG_FILE_NAME = 'LOG_FILE_NAME'


def get_env_variable(name, default_value):
    if name in environ:
        return environ[name]
    return default_value


def get_audit_id():
    return get_env_variable(KEY_AUDIT_ID, -998)


def get_workflow_name():
    return get_env_variable(KEY_WORKFLOW_NAME, None)


def get_service_name():
    return get_env_variable(KEY_SERVICE_NAME, None)


def get_load_start_date():
    return arrow.get(get_env_variable(KEY_LOAD_START_DATE, '1900-01-01 01:00:00'), DATETIME_FORMAT_ARROW).naive


def get_load_start_date_utc():
    return arrow.get(get_env_variable(KEY_LOAD_START_DATE_UTC, '1900-01-01 01:00:00'), DATETIME_FORMAT_ARROW).naive


def get_load_end_date():
    val = get_env_variable(KEY_LOAD_END_DATE, None)
    return val and arrow.get(val, DATETIME_FORMAT_ARROW).naive or datetime.now()


def get_load_end_date_utc():
    val = get_env_variable(KEY_LOAD_END_DATE_UTC, None)
    return val and arrow.get(val, DATETIME_FORMAT_ARROW).naive or datetime.utcnow()


def get_log_file_name():
    return get_env_variable(KEY_LOG_FILE_NAME, None)


def get_cdc_info():
    return {
        'LOAD_START_DATE': get_load_start_date(),
        'LOAD_START_DATE_UTC': get_load_start_date_utc(),
        'LOAD_END_DATE': get_load_end_date(),
        'LOAD_END_DATE_UTC': get_load_end_date_utc()
    }
