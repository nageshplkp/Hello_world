"""config wrapper"""
from ConfigParser import SafeConfigParser
from os import environ
from os.path import join

from core.config import config_api
from .util import memoize


def get_env():
    return config_api._env()


def get_etl_cfg(env=None):
    env = env or get_env()
    return read_cfg('etl_%s.conf' % (env,))


def get_db_cfg():
    return read_cfg('da_conn.ini')


@memoize
def read_cfg(cfg_name):
    cfg_path = join(get_config_path(), cfg_name)
    cfg = SafeConfigParser()
    cfg.optionxform = str
    cfg.read(cfg_path)
    return cfg2dict(cfg)


def read_app_cfg(cfg_path):
    cfg = SafeConfigParser()
    cfg.optionxform = str
    cfg.read(cfg_path)
    return cfg2dict(cfg)


def get_config_path():
    return environ.get('DA_CONFIG_DIR')


def cfg2dict(cfg):
    return {section: dict(cfg.items(section)) for section in cfg.sections()}
