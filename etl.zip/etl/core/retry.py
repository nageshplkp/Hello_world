from itertools import chain, repeat
from time import sleep

from etl.core.decorate import decorate

DEFAULT_INTERVAL = 10
DEFAULT_TIMEOUT = 3600


def retry(*args, **kwargs):
    return decorate(retry_call, *args, **kwargs)


def retry_call(fn, interval=DEFAULT_INTERVAL, max_retries=None,
               timeout=DEFAULT_TIMEOUT, retriable_exceptions=None, log=None):
    retriable_exceptions = retriable_exceptions or (Exception,)
    intervals = _intervals(interval, timeout)
    for attempt in range(max_retries) if max_retries else chain([False], repeat(True)):
        if attempt:
            _interval = _next_or_raise(intervals, lambda: RuntimeError(
                '{fn.__name__} timed out after {timeout} seconds'.format(fn=fn, timeout=timeout)))
            sleep(_interval)
        try:
            return fn()
        except retriable_exceptions as e:
            if log:
                log(str(e))
    raise RuntimeError('{fn.__name__} failed after {max_retries} retries'.format(
        fn=fn, max_retries=max_retries))


def _next_or_raise(iterable, e):
    try:
        return next(iterable)
    except StopIteration:
        raise e()


def _intervals(interval, timeout):
    elapsed_time = 0
    while elapsed_time < timeout:
        _interval = min(interval, timeout - elapsed_time)
        yield _interval
        elapsed_time += _interval
