import csv
import getpass
import logging
import os
import re
import shutil
import time
from argparse import ArgumentParser
from collections import Mapping, namedtuple as tpl, Iterable, OrderedDict
from contextlib import contextmanager
from datetime import datetime
from functools import wraps
from itertools import izip
from os import path, makedirs
from string import Template
from types import FunctionType, GeneratorType
from zipfile import ZipFile

import requests

from core.rest import client


# Obsolete. Use sqlalchemy.util.classproperty instead
class classproperty(object):
    def __init__(self, getter):
        self.getter = getter

    def __get__(self, instance, owner):
        return self.getter(owner)


class struct(dict):
    def __init__(self, *args, **kwargs):

        super(struct, self).__init__(*args, **kwargs)
        self.__dict__.update(*args, **kwargs)

    def __getattr__(self, item):
        try:
            return self[item]
        except KeyError:
            raise AttributeError

    def __setattr__(self, key, value):
        self[key] = value

    def __setitem__(self, key, value):
        super(struct, self).__setitem__(key, value)
        self.__dict__.update({key: value})


def vo(mnem='value_object', **kwargs):
    return tpl(mnem, kwargs.keys())(**kwargs)


def clone(value_object, **kwargs):
    return value_object._replace(**kwargs)


def is_list(arg):
    return isinstance(arg, (list, tuple, GeneratorType))


def memoize(fxn):
    memo = {}

    @wraps(fxn)
    def wrapper(*args):
        if args in memo:
            return memo[args]
        rv = fxn(*args)
        memo[args] = rv
        return rv

    return wrapper


DT_FMT = OrderedDict(YYYY='%Y', HH24='%H', MON='%b', DD='%d', DY='%a', MI='%M',
                     MM='%m', SS='%S')


def to_date(fmt, d=None):
    d = d or datetime.now()
    rgx = r'(%s)' % '|'.join(DT_FMT.keys())
    toks = [tok for tok in re.split(rgx, fmt) if tok]
    toks = [d.strftime(DT_FMT[tok]) if tok in DT_FMT else tok for tok in toks]
    return ''.join(toks)


def replace_date(s, d=None):
    return sub_dhash(s, lambda fmt: to_date(fmt, d=d))


def sub_dhash(patt, replace):
    new_s = ''
    for part in filter(None, re.split(r'(##[^#]+##)', patt or '')):
        m = re.match('##([^#]+)##', part)
        if m:
            new_part = (
                replace(m.group(1)) if isinstance(replace, FunctionType) else
                replace.get(m.group(1).lower(), None) or
                replace.get(m.group(1).upper(), m.group(1)))
            part = part if new_part == m.group(1) else new_part
        new_s += part
    return patt if patt is None else new_s


def download_file(url, csv_file, **kwargs):
    r = requests.get(url, stream=True, **kwargs)
    logging.info('Headers:')
    for k, v in r.headers.items():
        logging.info('%s: %s', k, v)
    content_length = r.headers.get('Content-Length', None)
    ensuredir(path.dirname(csv_file))
    logging.info('%s: downloading %s bytes', csv_file, content_length)
    with open(csv_file, "wb") as h:
        r.raw.decode_content = False
        shutil.copyfileobj(r.raw, h)
        h.flush()
        os.fsync(h.fileno())
    time.sleep(5)
    file_size = os.stat(csv_file).st_size
    if content_length is None or file_size == int(content_length):
        return
    raise Exception('Failed to download %s expected %s got %d' % (csv_file, content_length, file_size))


def uri_get(url, use_kerberos=True):
    return uri_method(client.get, url, use_kerberos=use_kerberos)


def uri_post(url, payload, use_kerberos=True, **kwargs):
    return uri_method(client.post, url, payload, use_kerberos=use_kerberos, **kwargs)


def uri_method(method, url, payload=None, use_kerberos=True, **kwargs):
    if use_kerberos:
        from core.opensource.requests_kerberos import MutualAuthenticationError
        try:
            return method(url, payload, **kwargs)
        except MutualAuthenticationError as e:
            logging.info('%s: %s', url, e)
        except Exception as e:
            if 'Unauthorized' in str(e):
                logging.info('%s: %s', url, e)
            else:
                raise
    logging.info('%s: bypassing Kerberos' % url)
    return method(url, payload, {'X-Remote-User': getpass.getuser()},
                  use_kerberos=False)


def ensuredir(dir_):
    try:
        makedirs(dir_)
    except OSError as e:
        if 'exists' not in str(e):
            raise
    else:
        logging.info("%s: folder created", dir_)


@contextmanager
def csv_open(csv_path, mode, **fmtparams):
    with open(csv_path, mode) as f:
        yield csv.reader(f, **fmtparams) if mode == 'r' else csv.writer(f, **fmtparams)


def rows2csv(rows, dst, hdr=None):
    ensuredir(path.dirname(dst))
    with csv_open(dst, 'w') as writer:
        if hdr:
            writer.writerow(hdr)
        linenums, rows = izip(*list(enumerate(rows)))
        writer.writerows(rows)
        logging.info('%s: wrote %d rows', dst, max(linenums) + 1)


def rows2rows(src, mappings, src_hdr_row=None):
    src_hdr = dict(zip(src_hdr_row, range(len(src_hdr_row))))
    remaps = [(m[1], src_hdr[m[0]]) if m[0] else m[1] for m in mappings]
    hdr, adapter = zip(*remaps)
    return hdr, (_remap(adapter, row) for row in src)


def csv2csv(src, dst, mappings):
    with csv_open(src, 'r') as reader:
        src_hdr_row = next(reader)
        hdr, rows = rows2rows(reader, mappings, src_hdr_row)
        rows2csv(rows, dst, hdr=hdr)


def _remap(adapter, from_):
    return [from_[v] if isinstance(v, int) else v for v in adapter]


def parse_args(description=None, *args, **kwargs):
    config = ({'description': description} if isinstance(description, str) else
              description)
    parser_class = kwargs['parser'] if 'parser' in kwargs else ArgumentParser
    parser = parser_class(**config)
    for arg in args:
        if isinstance(arg[0], list):
            parser.add_argument(*arg[0], **arg[1])
        else:
            parser.add_argument(arg[0], **arg[1])
    return parser.parse_args()


def merge(dst, src, greedy=False):
    for k, v in iter(src.items()):
        if k in dst:
            if isinstance(dst[k], list) and greedy:
                if not isinstance(greedy, list) or k in greedy:
                    dst[k].extend(v)
            elif isinstance(dst[k], dict) and isinstance(v, Mapping):
                merge(dst[k], v, greedy)
        else:
            dst[k] = v
    return dst


def chain(*fns, **kwargs):
    params = kwargs['params'] if 'params' in kwargs else []
    last_return = None
    for fn in fns:
        last_return = fn(*params)
        if last_return:
            return last_return
    return last_return


def fail_safe(fxn_generator, log=None, max_fails=None):
    success = True
    n_fails = 0
    fxn_generator = [fxn_generator] if callable(fxn_generator) else fxn_generator
    for fxn in fxn_generator:
        try:
            fxn()
        except Exception as e:
            success = False
            n_fails += 1
            if log:
                log(str(e))
            if n_fails == max_fails:
                raise RuntimeError('Stopping after %d failures' % n_fails)
    return success


def dict_find(d, key):
    for k, v in iter(d.items()):
        if callable(key) and key(k) or k == key:
            yield tpl('found', ['val', 'parent'])(v, d)
        elif isinstance(v, Mapping):
            for d_ in dict_find(v, key):
                yield d_


def dict_visit(d, fn):
    for k, v in iter(d.items()):
        if isinstance(v, Mapping):
            for res in dict_visit(v, fn):
                yield res
        else:
            yield fn(d, k, v)


def struct_merge(structs, overwrite=False):
    d = {}
    structs = structs if overwrite else reversed(structs)
    for t in [s for s in structs if s]:
        d.update(vars(t))
    return struct(**d)


def deep_substitute(o, mappings):
    if isinstance(o, Mapping):
        return dict([(k, _do_sub(o[k], mappings)) for k in o])
    return [_do_sub(e, mappings) for e in o] if o else o


def _do_sub(o, mappings):
    if isinstance(o, str):
        s = Template(o).substitute(mappings)
        return None if s != o and s == 'None' else s
    return deep_substitute(o, mappings) if isinstance(o, Iterable) else o


def snake2camel(name):
    return ''.join([s.capitalize() for s in name.split('_')])


def uncapitalize(name):
    return re.sub(r'[A-Z]+', lambda m: m.group(0).lower(), name, count=1)


def camel2snake(name):
    name = uncapitalize(name)
    return re.sub(r'[A-Z]+', lambda m: '_' + uncapitalize(m.group(0)), name)


# obsolete: use werkzeug.utils.cached_property instead
def lazy_get(obj, attr, fn):
    if not hasattr(obj, attr):
        setattr(obj, attr, fn())
    return getattr(obj, attr)


def select_cols(cols, rows):
    if not is_list(rows):
        rows = [rows]
    return struct(next_attr(rows, col) for col in cols)


def identity(o):
    return o


def next_attr(objects, attr):
    fn = identity
    if not isinstance(attr, str):
        attr, fn = attr  # assume computed column (column/function pair)
    attrs = filter(None, (getattr(o, attr, None) for o in objects))
    return attr, fn(next(iter(attrs), None))


def update(obj, **kwargs):
    for k, v in kwargs.items():
        setattr(obj, k, v)
    return obj


def deep_copy_file(src, dst):
    ensuredir(path.dirname(dst))
    shutil.copy2(src, dst)


def dirtree(base_path):
    rgx = r'%s[/\\]' % re.escape(base_path)
    return (re.sub(rgx, '', path.join(top, f))
            for top, dirs, files in list(os.walk(base_path)) for f in files)


def cp_files(cps):
    for src, dst in cps:
        try:
            deep_copy_file(src, dst)
        except IOError as e:
            if 'No such file' in str(e):
                logging.warning(str(e))
            else:
                raise


def backup_files(src, dst, files):
    cps = [(path.join(src, f), path.join(dst, f)) for f in files]
    cp_files(cps)


@contextmanager
def tmp_dir(dst_dir, stage_dir):
    _tmp_dir = dst_dir + '.tmp'
    ensuredir(_tmp_dir)
    stage_dir(_tmp_dir)
    yield _tmp_dir
    shutil.move(_tmp_dir, dst_dir)


def unzip(zip_file, dst_dir):
    with ZipFile(zip_file, 'r') as z:
        z.extractall(dst_dir)


def rsync_path_delim_insert(_path, pos):
    return _path[:pos] + './' + _path[pos:]


def sanitize_cmd_line(cmd_line):
    # type: (object) -> object
    try:
        t_prev = ''
        for i, t in enumerate(cmd_line):
            tokens = re.split(r'=', t)
            if tokens and len(tokens) > 1 and \
                    'pass' in (tokens[0] or '') or \
                    'pwd' in (tokens[0] or ''):
                cmd_line[i] = t.replace(tokens[1], '*****' if tokens[1] else '')
                break
            elif 'passw' in (t_prev or '') or 'pwd' in (t_prev or ''):
                cmd_line[i] = '*****' if t else ''
                break
            t_prev = t

        return ' '.join(cmd_line)
    except Exception as ex:
        return "Error parsing cmd_line: {}".format(ex)
