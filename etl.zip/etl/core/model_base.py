import abc
import copy
from datetime import datetime, date
from json import JSONEncoder
from sqlalchemy.ext.declarative import  DeclarativeMeta


class RequiredAttribModel(object):
    __metaclass__ = abc.ABCMeta

    class RequiredObjAttrib:
        def __init__(self, name, default):
            self.name = name
            self.default = default

    @staticmethod
    @abc.abstractmethod
    def req_obj_attribs():
        """Return a list of 'RequiredObjAttrib'"""
        return []

    def check_for_req_attrib(self, roa):
        if not isinstance(roa, self.RequiredObjAttrib):
            return
        if not hasattr(self, roa.name):
            setattr(self, roa.name, roa.default)

    def check_for_req_attribs(self):
        [self.check_for_req_attrib(i) for i in self.req_obj_attribs()]


class JSONModelBase(object):
    @staticmethod
    def obj_to_json(obj):
        if isinstance(obj, JSONModelBase):
            return obj.to_json()
        if isinstance(obj, dict):
            return obj
        if isinstance(obj, (bool, int, long, float, dict, str, basestring, complex)):
            return obj
        return obj.__dict__

    def to_dict(self):
        return copy.deepcopy(self.__dict__)

    def to_json(self):
        rtn = self.to_dict()
        for k, v in rtn.items():
            if v is None:
                continue
            if isinstance(v, (bool, int, long, float, dict, str, basestring, complex)):
                continue
            elif isinstance(v, (datetime, date)):
                rtn[k] = v.strftime('%Y-%m-%d %H:%M:%S')
            elif isinstance(v, (tuple, list, set)):
                rtn[k] = [self.obj_to_json(i) for i in v if i is not None]
            else:
                rtn[k] = v.to_json()
        return rtn
