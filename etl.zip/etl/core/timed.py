import functools
import logging
import time
import os


def timed(logger=None, level=None, format=None):
    """
    :param logger: object( import logging,  logging.getLogger() )
    :param level: const int (logging.DEBUG)
    :param format: string( log format string '%s: %s ms' )
    :return: decorator nested function

        #example usage
        import logging, time
        from timer import timed

        logger = logging.getLogger()
        logger.setLevel(logging.DEBUG)

        handler = logging.StreamHandler()
        handler.setLevel(logging.DEBUG)
        logger.addHandler(handler)

        @timed(logger)
        def pow10(x):
            time.sleep(1)
            return x ** 10

        # will log: <function pow10 at 0x107847230>: 1001.08790398 ms
        pow10(100)

    """
    if logger is None:
        logger = logging.getLogger('')

    if format is None:
        format = '%s: %s ms'

    if level is None:
        level = logging.DEBUG

    def decorator(fn):

        if not callable(fn):
            raise Exception("fn should be callable")

        # noinspection PyArgumentList
        @functools.wraps(fn)
        def inner(*args, **kwargs):

            __self = ''
            if fn.__code__.co_varnames[0] == 'self':
                __self = args[0].__class__.__name__

            if fn.__code__.co_varnames[0] == 'cls':
                __self = args[0].__name__

            __representation = "<{}::{}, module: {}, file: {}:{}>".format(
                __self, fn.func_name, fn.__module__,
                os.path.basename(fn.__code__.co_filename),
                fn.__code__.co_firstlineno
            )

            logger.log(level, "%s", __representation )
            start = time.time()
            result = fn(*args, **kwargs)
            duration = time.time() - start
            logger.log(level, format, __representation, duration * 1000)
            return result
        return inner

    return decorator
