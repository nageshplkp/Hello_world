"""db mapper"""
import base64
import getpass
import logging
import os

from sqlalchemy import Table, create_engine, func, exc
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import scoped_session, sessionmaker
from sqlalchemy.sql import text
# from sqlalchemy.orm.session import sessionmaker, scoped_session
from werkzeug.utils import cached_property

from etl.core.da_config import get_db_cfg, get_etl_cfg
from etl.core.util import struct, is_list, snake2camel

logging.getLogger('sqlalchemy.engine').setLevel(
    os.environ.get('SQLALCHEMY_LOG_LEVEL_OVERRIDE', logging.WARN))


def pim_da(server='ORAPIM_DBP'):
    """obsolete"""
    return ora_pim('DA_OWN', server)


def fnd_cfdw(server='ORAFND_DBP'):
    """obsolete"""
    return ora_fnd('CFDW_OWN', server)


def syb_pim(schema, server='SYBPIM_DBP'):
    return syb_xxx(schema, server)


def syb_xxx(schema, server):
    return DbContext(schema, server, 'sybase')


def ora_pim(schema, server='ORAPIM_DBP'):
    return ora_xxx(schema, server)


def ora_fnd(schema, server='ORAFND_DBP'):
    return ora_xxx(schema, server)


def ora_cor(schema, server='ORACOR_DBP'):
    return ora_xxx(schema, server)


def ora_xxx(schema, server):
    return DbContext(schema, server, 'oracle')


def get_db_creds(db_server, vendor, etl_cfg=None):
    creds = struct(vendor=vendor)
    try:
        creds.update(get_da_conn_cfg(db_server, etl_cfg))
        creds.passwd = base64.b64decode(creds.password)
        del creds['password']
    except:
        creds.server = creds.get('server', None) or db_server
    return creds


def get_da_conn_cfg(key, etl_cfg=None):
    (etl_cfg, da_conn_ini) = (etl_cfg or get_etl_cfg(), get_db_cfg())
    return da_conn_ini[etl_cfg['database'][key]]


def get_db_uri(creds, **kwargs):
    uri = creds.vendor + '://'
    if 'user' in creds:
        uri += creds.user
        if 'passwd' in creds:
            uri += ':' + creds.passwd
        uri += '@'
    uri += creds.server
    if 'database' in creds:
        uri += '/' + creds.database
    sep = '?'
    for k, v in kwargs.items():
        uri += sep + k + '=' + v
        sep = '&'
    return uri


def execute_sql(session, sql, params=None):
    log = logging.getLogger(__name__)
    success = False

    if not (session and sql):
        return success, {}

    results = session.execute(text(sql), params)
    session.commit()
    success = True
    log.debug(
        'execute proc:%s, params:%s, results:%s',
        text(sql), params, ['{}={}'.format(
            x, getattr(results, x)
        ) for x in ['is_insert', 'out_parameters', 'rowcount']])

    return struct(success=success, results=results)


def try_execute_sql(session, sql, params=None):
    """
    Tries to execute sql query with optional parameters
    commits upon successful execution aor rolls back on exception

    :param session: SqlAlchemy session object, required
    :param sql: @type str : pl-sql statement to execute, required
    :param params: @type dict : optional parameter dictionary
    :return tuple( success=True|False, results=session.execute(...))
    """
    try:
        esr = execute_sql(session, sql, params)
        return esr
    except exc.SQLAlchemyError as e:
        if session is not None:
            session.rollback()

        log = logging.getLogger(__name__)
        log.exception(
            "Failed to execute sql query %s, params: %s,"
            "with SQLAlchemyError: %s", sql, params, e)
        return struct(success=False, results={}, exception=e)


def execute_proc(session, procedure, params=None):
    log = logging.getLogger(__name__)
    success = False
    if not (session and procedure):
        return success, {}

    def _render_args(args):
        p = ''
        if args:
            p = ','.join([
                ''' {0}  =>  :{0}
                '''.format(k, v) for k, v in args.items()
            ])
            p = '''
                {}
            '''.format(p)
        return p

    # build sql statement for executing procedure
    query = '''
        BEGIN
            {};
        END;
        '''.format('{} ({})'.format(procedure, _render_args(params)))

    results = session.execute(query, params)
    session.commit()
    log.debug(
        'execute proc:%s, params:%s, results:%s',
        query, params, ['{}={}'.format(
            x, getattr(results, x)
        ) for x in ['is_insert', 'out_parameters', 'rowcount']])
    success = True
    return struct(success=success, results=results)


def try_execute_proc(session, procedure, params=None):
    """
    Tries to execute stored procedure with optional parameters
    commits upon successful execution aor rolls back on exception

    :param session: SqlAlchemy session object, required
    :param procedure: @type str : Name of the stored proc to execute, required
    :param params: @type dict : optional parameter dictionary
    :return tuple( success=True|False, results=session.execute(...)[, exc...])
    """
    try:
        epr = execute_proc(session, procedure, params)
        return epr
    except exc.SQLAlchemyError as e:
        if session is not None:
            session.rollback()
        log = logging.getLogger(__name__)
        log.exception(
            "Failed to execute stored procedure %s, params: %s,"
            "with SQLAlchemyError: %s", procedure, params, e)
        return struct(success=False, results={}, exception=e)


class Db(object):
    def __init__(self, server, vendor):
        self.server = server
        self.vendor = vendor
        logging.info('%s instantiated', str(self))

    def __enter__(self):
        logging.info('%s: begin transaction')

    def __exit__(self, exc_type, exc_val, exc_tb):
        logging.info('%s: end transaction')

    def __str__(self):
        return '{}://{}'.format(self.vendor, self.server)

    @cached_property
    def base(self):
        return declarative_base()

    @cached_property
    def creds(self):
        return get_db_creds(self.server, self.vendor)

    @cached_property
    def engine(self):
        logging.info('%s:%s: establishing %s connection..', self.creds.server,
                     self.creds.get('user', getpass.getuser()),
                     '' if 'passwd' in self.creds else 'kerberos')
        return create_engine(get_db_uri(self.creds), label_length =30)

    @cached_property
    def session(self):
        # return sessionmaker(bind=self.engine)()
        # self._session = sessionmaker(bind=self.engine)()
        # The scoped_session object by default uses this object as storage,
        # so that a single Session is maintained for all who call upon
        # the scoped_session registry, but only within the scope
        # of a single thread. Callers who call upon the registry in
        # a different thread get a Session instance that is local to that
        # other thread.
        # http://docs.sqlalchemy.org/en/latest/orm/contextual.html
        return scoped_session(sessionmaker(bind=self.engine))()

    def query(self, *args):
        return self.session.query(*args)

    def save(self, data):
        return self.save_all(data) if is_list(data) else self.save_one(data)

    def save_one(self, row):
        rows = self.save_all([row])
        return next(iter(rows), None)

    def save_all(self, rows):
        try:
            audited_rows = [self.set_audit_cols(row) for row in rows]
            rows = [self.session.merge(row) for row in audited_rows]
            self.session.commit()  # XXX with no_autoflush?
            return rows
        except:
            self.session.rollback()
            raise

    def set_audit_cols(self, row):
        audit_col_action = {
            'dw_insert_by': lambda v: v or self.creds.user,
            'dw_insert_date': lambda v: v or func.sysdate(),
            'dw_update_by': lambda _: self.creds.user,
            'dw_update_date': lambda _: func.sysdate(),
            'row_insert_by': lambda v: v or self.creds.user,
            'row_insert_date': lambda v: v or func.sysdate(),
            'row_update_by': lambda _: self.creds.user,
            'row_update_date': lambda v: v  or func.sysdate(),
        }
        for c in [c for c in audit_col_action.keys() if hasattr(row, c)]:
            setattr(row, c, audit_col_action[c](getattr(row, c)))
        return row

    def create_model(self, schema, table_name, pk=None):
        pk = pk or []
        tbl_name = table_name.lower()
        cls_name = snake2camel(tbl_name)
        tbl = self._get_table(schema, tbl_name)
        pks = [tbl.c[k] for k in pk]
        cls = type(cls_name, (self.base,),
                   {'__table__': tbl,
                    '__mapper_args__': {'primary_key': pks}})
        return cls

    def _get_table(self, schema, table_name):
        return Table(table_name, self.base.metadata, schema=schema,
                     autoload=True, autoload_with=self.engine)


# Obsolete
class DbContext(object):
    @property
    def session(self):
        return self._session

    def __init__(self, schema, server, vendor):
        self.schema = schema
        self.base = declarative_base()
        self.creds = get_db_creds(server, vendor)
        self.engine = create_engine(get_db_uri(self.creds))
        # self._session = sessionmaker(bind=self.engine)()
        # The scoped_session object by default uses this object as storage,
        # so that a single Session is maintained for all who call upon
        # the scoped_session registry, but only within the scope
        # of a single thread. Callers who call upon the registry in
        # a different thread get a Session instance that is local to that
        # other thread.
        # http://docs.sqlalchemy.org/en/latest/orm/contextual.html
        self._session = scoped_session(sessionmaker(bind=self.engine))()

    def __str__(self):
        return "{}.{}, <{}.{} object at {}>".format(
            self.creds.server, self.schema,
            self.__class__.__module__, self.__class__.__name__, hex(id(self)))

    def __repr__(self):
        return '<%s.%s object at %s>' % (
            self.__class__.__module__,
            self.__class__.__name__,
            hex(id(self))
        )

    def __enter__(self):
        # make a database connection and return it

        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        try:
            if exc_type is None:
                # No exception, so commit
                if self.session is not None:
                    self.session.commit()
            else:
                # Exception occurred, so rollback.
                if self.session is not None:
                    self.session.rollback()

            if self.session is not None:
                self.session.close()

            if self.engine:
                self.engine.dispose()

        finally:
            self._session = None
            self.engine = None

    def release(self):
        self.__exit__(None, None, None)

    def create_model(self, table_name, pk=None):
        pk = pk or []
        tbl_name = table_name.lower()
        cls_name = snake2camel(tbl_name)
        tbl = self._get_table(tbl_name)
        pks = [tbl.c[k] for k in pk]
        cls = type(cls_name, (self.base,),
                   {'__table__': tbl,
                    '__mapper_args__': {'primary_key': pks}})
        cls.query = self.session.query(cls)
        return cls

    def _get_table(self, table_name):
        return Table(table_name, self.base.metadata, schema=self.schema,
                     autoload=True, autoload_with=self.engine)

    def save(self, data):
        return self.save_all(data) if is_list(data) else self.save_one(data)

    def save_one(self, row):
        return self.save_all([row])

    def save_all(self, rows):
        try:
            audited_rows = (self.set_audit_cols(row) for row in rows)
            rows = [self.session.merge(row) for row in audited_rows]
            self.session.commit()
            return rows
        except:
            self.session.rollback()
            raise

    def set_audit_cols(self, row):
        audit_cols = ['row_insert_by', 'row_insert_date',
                      'row_update_by', 'row_update_date']
        if [c for c in audit_cols if hasattr(row, c)]:
            if row.row_insert_by is None:
                row.row_insert_by = row.row_insert_by or self.creds.user
            if row.row_insert_date is None:
                row.row_insert_date = func.sysdate()
            row.row_update_by = self.creds.user
            row.row_update_date = func.sysdate()
        return row

    def execute_sql(self, sql, params=None):
        """
        Wrapper around module function, see above
        Tries to execute pl-sql statement with optional parameters
        commits upon successful execution or rolls back on exception

        :param procedure: @type str : The stored proc to execute, required
        :param params: @type dict : optional parameter dictionary
        :return tuple( success=True|False, results=session.execute(...))
        """
        return execute_sql(self.session, sql, params)

    def try_execute_sql(self, sql, params=None):
        """
        Wrapper around module function, see above
        Tries to execute pl-sql statement with optional parameters
        commits upon successful execution or rolls back on exception

        :param procedure: @type str : The stored proc to execute, required
        :param params: @type dict : optional parameter dictionary
        :return tuple( success=True|False, results=session.execute(...)
                    [, exception])
        """
        return try_execute_sql(self.session, sql, params)

    def execute_proc(self, procedure, params=None):
        """
        Wrapper around module function, see above
        Tries to execute stored procedure with optional parameters
        commits upon successful execution or rolls back on exception

        :param procedure: @type str : The stored proc to execute, required
        :param params: @type dict : optional parameter dictionary
        :return tuple( success=True|False, results=session.execute(...))
        """
        return execute_proc(self.session, procedure, params)

    def try_execute_proc(self, procedure, params=None):
        """
        Wrapper around module function, see above
        Tries to execute stored procedure with optional parameters
        commits upon successful execution or rolls back on exception

        :param procedure: @type str : The stored proc to execute, required
        :param params: @type dict : optional parameter dictionary
        :return tuple( success=True|False, results=session.execute(...)
                    [, exception]))
        """
        return try_execute_proc(self.session, procedure, params)

    def bulk_insert(self, entity, data):
        """
        Bulk inserts a collection of data for a specific entity. Using the
        sqlalchemy core approach below is approximately 40% faster than using
        session.bulk_save_objects().

        Args:
            entity (obj): entity to be inserted
            data (list of dict): list of dictionaries containing entity values
        """

        try:
            # Insert using sqlalchemy core
            self.engine.execute(entity.__table__.insert(), data)

        except exc.SQLAlchemyError as e:
            log = logging.getLogger(__name__)
            log.exception(
                "Failed to execute bulk insert. SQLAlchemyError:"
                "%s Entity: %s Data: %s", e, entity, data)
            raise
