from etl.core import db


class BaseMapperWithPK(object):
    """Base mapper class with some utility functions
       Todo: check with Brian on Primary keys
    """
    def __init__(self, schema, table, pk_list):
        pk_list = [pk.lower() for pk in pk_list]
        self.db_context = db.ora_pim(schema)
        self.model = self.db_context.create_model(table, pk_list)
        self._pk = pk_list

    def get_single_primary_key_list(self):
        """For tables with a single column as primary key
           Returns a list of all the primary keys
        """
        assert len(self._pk) == 1
        pk_col = getattr(self.model, self._pk[0])
        result = self.model.query.values(pk_col)
        list = [str(x[0]) for x in result]
        return list
