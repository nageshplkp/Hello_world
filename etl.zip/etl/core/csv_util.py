import csv


def csv_to_dict_list(file_path):
    with open(file_path, 'r') as f:
        header = [h.strip().replace('"', '') for h in f.next().split(',')]
        reader = csv.DictReader(f, fieldnames=header)
        return list(reader)
