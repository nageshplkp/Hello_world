from __future__ import absolute_import, print_function

import traceback
from functools import wraps

from flask import request
from six.moves.http_client import OK, BAD_REQUEST, INTERNAL_SERVER_ERROR
from werkzeug.exceptions import HTTPException

from etl.core.dto import DaSvcResponseDto
from etl.enum.da_core import DaSvcStatusEnum

HTTP2STATUS = {
    OK: DaSvcStatusEnum.SUCCESS.value,
    BAD_REQUEST: DaSvcStatusEnum.HTTP_ERROR.value,
    INTERNAL_SERVER_ERROR: DaSvcStatusEnum.API_ERROR.value}


def decorate(decorator, *decorator_args, **decorator_kwargs):
    def decorator_wrapper(fn):
        @wraps(fn)
        def fn_wrapper_wrapper(*args, **kwargs):
            def fn_wrapper():
                return fn(*args, **kwargs)

            return decorator(fn_wrapper, *decorator_args, **decorator_kwargs)

        return fn_wrapper_wrapper

    if len(decorator_args) == 1 and callable(decorator_args[0]):
        implied_fn, decorator_args = decorator_args[0], decorator_args[1:]
        decorator_wrapper = decorator_wrapper(implied_fn)
    return decorator_wrapper


def da_flask_api(*args, **kwargs):
    return decorate(compose_return_payload, *args, **kwargs)


def compose_return_payload(f, include_stacktrace=None):
    status = OK
    try:
        payload = f()
    except Exception as e:
        payload = e.__dict__
        payload['message'] = e.message
        payload['args'] = e.args
        if include_stacktrace:
            payload['stacktrace'] = filter(
                lambda line: 'site-packages' not in line,
                traceback.format_stack())
        status = (BAD_REQUEST if isinstance(e, HTTPException) else
                  INTERNAL_SERVER_ERROR)
    env = {k: request.environ[k]
           for k in request.environ
           if isinstance(request.environ[k], (str, int, bool))
           and k != 'HTTP_AUTHORIZATION'}
    rtn = DaSvcResponseDto(HTTP2STATUS[status], env, payload).to_json()
    return rtn, status
