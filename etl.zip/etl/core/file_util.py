import os

import shutil

from etl.core.util import fail_safe


def file_stream(filename):
    with open(filename, 'rb') as f:
        for line in f:
            yield line


def force_copy(src_path, dst_path):
    fail_safe(lambda: os.remove(dst_path))
    shutil.copy2(src_path, dst_path)
