from etl.core.model_base import JSONModelBase


class DaSvcResponseDto(JSONModelBase):
    def __init__(self, status, env, body):
        self.status = status
        self.env = env
        self.body = body
