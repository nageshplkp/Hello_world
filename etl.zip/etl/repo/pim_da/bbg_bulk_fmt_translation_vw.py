import logging

from werkzeug.utils import cached_property

from etl.repo import OraPimRepo


class BbgBulkFmtTranslationVwRepo(OraPimRepo):
    @property
    def log(self):
        return logging.getLogger(__name__)

    @cached_property
    def BbgBulkFmtTranslationVw(self):
        return self.db.create_model('DA_OWN', 'BBG_BULK_FMT_TRANSLATION_VW', ['bulk_format_mnemonic',
                                                                              'mnemonic',
                                                                              'column_display_order'])

    @property
    def model(self):
        return self.BbgBulkFmtTranslationVw

    def list_by_bulk_format_mnemonic(self, bulk_format_mnemonic):
        return self.query.filter(self.model.bulk_format_mnemonic == bulk_format_mnemonic).all()
