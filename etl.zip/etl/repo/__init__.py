from sqlalchemy import create_engine
from sqlalchemy.util import classproperty
from werkzeug.utils import cached_property

from etl.core.db import Db, get_db_uri


class DbRepo(object):
    _instances = {}

    def __init__(self, db=None):
        self.db = db or self.db  # Inject over cached_property

    @cached_property
    def db(self):
        return Db(self.server, self.vendor)

    @classproperty
    def instance(cls):
        return cls.instance_for_db(db=None)

    @classmethod
    def instance_for_db(cls, db):
        k = db or cls
        cls._instances[k] = cls._instances.get(k, None) or cls(db)
        return cls._instances[k]

    @property
    def query(self):
        return self.db.query(self.model)

    @property
    def model(self):
        raise NotImplemented

    @property
    def server(self):
        raise NotImplemented

    @property
    def vendor(self):
        raise NotImplemented


class MssqlRepo(DbRepo):
    @cached_property
    def db(self):
        _db = super(MssqlRepo, self).db
        dburi = get_db_uri(_db.creds, driver='ODBC Driver 11 for SQL Server')
        _db.engine = create_engine(dburi, legacy_schema_aliasing=False)
        return _db

    @property
    def vendor(self):
        return 'mssql'


class OracleRepo(DbRepo):
    @property
    def vendor(self):
        return 'oracle'


class SybIqRepo(DbRepo):
    @cached_property
    def db(self):
        _db = super(SybIqRepo, self).db
        host, port = _db.creds.host.split(':')
        dburi = get_db_uri(_db.creds, driver='Sybase IQ',
                           CommLinks=('SharedMemory,'
                                      'TCPIP{host=%s;port=%s}' % (host, port)))
        _db.engine = create_engine(dburi)
        return _db

    @property
    def vendor(self):
        return 'sybase'


class SybRepo(DbRepo):
    @property
    def vendor(self):
        return 'sybase+pysybase'


class MsWebDmRepo(MssqlRepo):
    @property
    def server(self):
        return 'MSWEBDM_DBP'


class OraAnaRepo(OracleRepo):
    @property
    def server(self):
        return 'ORAANA_DBP'


class OraCorRepo(OracleRepo):
    @property
    def server(self):
        return 'ORACOR_DBP'


class OraFndRepo(OracleRepo):
    @property
    def server(self):
        return 'ORAFND_DBP'


class OraMtgRepo(OracleRepo):
    @property
    def server(self):
        return 'ORAMTG_DBP'


class OraPimRepo(OracleRepo):
    @property
    def server(self):
        # return 'ORAPIM_DBP'
        return 'oradevpim'



class OraPimCapIqRepo(OracleRepo):
    @property
    def server(self):
        return 'ORAPIMCAPIQ_DBP'


class IqPimRepo(SybIqRepo):
    @property
    def server(self):
        return 'IQPIM_DBP'


class SybPimRepo(SybRepo):
    @property
    def server(self):
        return 'SYBPIM_DBP'
