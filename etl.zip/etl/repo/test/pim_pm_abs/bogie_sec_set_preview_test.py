"""===========================================================================
DESCRIPTION:  Created Unit Test for BOGIE_SEC_SET_PREVIEW

AUTHOR:       Created by (PIMCO\zgalfaya)

DATE:         Dec 22 2017  9:24AM
===========================================================================
"""
import pytest
from etl.repo.pim_pm_abs import BogieSecSetPreviewRepo

pytestmark = pytest.mark.integration

def test_bogie_sec_set_preview_repo_methods(test_ora_pim):
    repo = BogieSecSetPreviewRepo(test_ora_pim)
    repo.get_by_ssm_id('777')
    repo.list_by_ssm_id('777')
    assert True


@pytest.mark.parametrize('x_attr', ['bogie_no', 'ssm_id', 'quantity',
                                    'base_mkt_value', 'position_key','de'])
def test_bogie_sec_set_preview_row_has_expected_attrs(x_attr, test_ora_pim):
    repo = BogieSecSetPreviewRepo(test_ora_pim)
    assert hasattr(repo.model, x_attr)
