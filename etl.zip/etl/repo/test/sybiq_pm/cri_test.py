import pytest

pytestmark = pytest.mark.integration


@pytest.mark.skip
def test_cri_row():
    from etl.repo.sybiq_pm import CriRepo
    cri_repo = CriRepo.instance
    cri_repo.get_by_mtg_id('MK768JYYYYY7UOUI6L')
    for attr in ['mtg_id', 'borrower_id', 'loan_id', 'zip', 'zip2', 'acct_open',
                 'acct_good', 'acct_maxage', 'acct_newage', 'acct_limit',
                 'acct_bal', 'dq_newage', 'acct_dq', 'acct_sch_pay',
                 'atr1_open_date', 'atr1_mtg_id', 'atr1_high', 'atr1_date',
                 'atr1_curr', 'atr1_disp_code', 'atr1_sch_pay',
                 'atr2_open_date', 'atr2_close_date', 'atr2_mtg_id',
                 'atr2_high', 'atr2_date', 'atr2_curr', 'atr2_disp_code',
                 'atr2_sch_pay_nbr', 'atr2_pay_freq', 'atr2_sch_pay',
                 'atr2_bal', 'atr2_2lien', 'atr2_flag', 'atr3_open_date',
                 'atr3_close_date', 'atr3_mtg_id', 'atr3_high', 'atr3_date',
                 'atr3_curr', 'atr3_disp_code', 'atr3_sch_pay_nbr',
                 'atr3_pay_freq', 'atr3_sch_pay', 'atr3_bal', 'atr3_2lien',
                 'atr3_flag', 'mtg_prop_sc', 'he_prop_sc', 'fico', 'fico_mtg',
                 'cri_fdate', 'fdate', 'dq_120d', 'dq_6m', 'dq_2m', 'inq_nbr',
                 'inq_nbr_6m', 'he_acct', 'he_newage', 'he_bal', 'he_dq',
                 'hele_open', 'hele_maxage', 'hele_newage', 'hele_limit',
                 'hele_balance', 'hele_dq', 'install_open', 'install_limit',
                 'install_bal', 'install_dq', 'mtg_inq_3m', 'mtg_inq_6m',
                 'mtg_acct', 'mtg_open', 'mtg_good', 'mtg_newage', 'mtg_limit',
                 'mtg_bal', 'mtg_dq_newage', 'mtg_dq_6m', 'mtg_dq', 'rev_acct',
                 'rev_open', 'rev_newage', 'rev_limit', 'rev_max', 'rev_bal',
                 'rev_dq', 'rev_sch_pay', 'acct_avg_open', 'tu_mtg_sc',
                 'tu_bkrpt_model', 'tu_id', 'vantage_sc', 'vantage',
                 'vantage_12m', 'vantage_3m', 'vantage_6m', 'vantage_9m',
                 'vantage2_sc', 'vantage2', 'filename', 'last_change_date',
                 'cri_primary']:
        assert hasattr(cri_repo.model, attr)
