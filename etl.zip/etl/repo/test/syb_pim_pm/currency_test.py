import pytest

from etl.repo.syb_pim_pm import CurrencyRepo

pytestmark = pytest.mark.integration


def test_currency_row(test_syb_pm_db):
    print("using %s" % str(test_syb_pm_db.engine))
    repo = CurrencyRepo(test_syb_pm_db)
    repo.get_by_iso_currency_code('AED')
    assert True


@pytest.mark.parametrize('x_attr', [
    'iso_currency_code', 'last_chg_date', 'currency_name', 'iso_country_code',
    'last_chg_user'])
def test_bt_request_batch_row_has_expected_attrs(x_attr, test_syb_pm_db):
    repo = CurrencyRepo(test_syb_pm_db)
    assert hasattr(repo.model, x_attr)
