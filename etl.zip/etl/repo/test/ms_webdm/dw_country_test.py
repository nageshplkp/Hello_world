import pytest

from etl.repo.ms_webdm import DwCountryRepo

pytestmark = pytest.mark.integration


@pytest.mark.parametrize('x_method,x_args', [
    ('get_by_country_code', ['US'])])
def test_repo_method_is_callable(x_method, x_args, x_repo):
    getattr(x_repo, x_method)(*x_args)
    assert True


@pytest.mark.parametrize('x_attr', [
    'COUNTRY_DESC', 'ROW_INSERT_BY', 'IS_EM', 'CR_COUNTRY_ISSUER_CODE',
    'ROW_UPDATE_BY', 'COUNTRY_CODE', 'ROW_INSERT_DATE', 'ROW_UPDATE_DATE',
    'WEB_GEO_REGION_CODE', 'COUNTRY_NAME', 'COUNTRY_NO',
    'CR_COUNTRY_SETTLEMENT_CODE', 'IS_PM_EMERG_MKT', 'IS_RPT_ONLY'])
def test_repo_model_has_expected_attr(x_attr, x_model):
    assert hasattr(x_model, x_attr)


@pytest.fixture(scope="module")
def x_repo(test_ms_webdm_db):
    return DwCountryRepo(test_ms_webdm_db)


@pytest.fixture(scope="module")
def x_model(x_repo):
    return x_repo.model
