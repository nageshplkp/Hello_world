"""===========================================================================
DESCRIPTION:  Created Unit Test for BOGIE_SEC_SET

AUTHOR:       Created by (PIMCO\zgalfaya)

DATE:         Dec 22 2017  9:24AM
===========================================================================
"""
import pytest
from etl.repo.pim_pm import SsmIdXrefRepo

pytestmark = pytest.mark.integration


@pytest.mark.parametrize('x_attr', ['ssm_id', 'source_sec_id', 'source_key',
                                    'pricing_date', 'validated_sw'])
def test_ssm_id_xref_row_has_expected_attrs(x_attr, test_ora_pim):
    repo = SsmIdXrefRepo(test_ora_pim)
    assert hasattr(repo.model, x_attr)


def test_ssm_id_xref_repo_methods(test_ora_pim):
    repo = SsmIdXrefRepo(test_ora_pim)
    repo.get_by(source_key='777', source_sec_id='777', ssm_id='777')
    repo.list_by_ssm_id('777')
    # [TODO] Not sure if we should do this
    # repo.save(repo.model(
    #     ssm_id='-777', source_sec_id='-777', source_key='-777',
    #     pricing_date='Dec 22 2017', validated_sw='Y'
    # ))
    # repo.delete_by(source_key='-777', source_sec_id='-777')
    assert True
