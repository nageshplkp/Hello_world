import logging
import os
from contextlib import contextmanager

from pytest import fixture

from etl.repo import OraFndRepo, OraPimRepo, SybPimRepo, MsWebDmRepo

logging.disable('CRITICAL')


if not os.environ.get('DA_CONFIG_DIR'):
    cfg_dirs = ['C:\\Data\\Development\\etl_batch\\config',
                '/appl/pimdev/pimco_common/etl/batch/config']
    d = next((d for d in cfg_dirs if os.path.exists(d)), None)
    if not d:
        raise KeyError('DA_CONFIG_DIR must be set!')
    os.environ['DA_CONFIG_DIR'] = d


@contextmanager
def fake_db_session(db):
    from sqlalchemy.orm import sessionmaker
    from sqlalchemy import event
    Session = sessionmaker()
    conn = db.engine.connect()
    txn = conn.begin()
    db.session = Session(bind=conn)
    db.session.begin_nested()

    @event.listens_for(db.session, "after_transaction_end")
    def restart_savepoint(session, transaction):
        if transaction.nested and not transaction._parent.nested:
            session.expire_all()
            session.begin_nested()

    yield db
    db.session.close()
    txn.rollback()
    conn.close()


@fixture(scope="session")
def test_ora_fnd():
    class FakeOraFndRepo(OraFndRepo):
        def model(self): pass
    with fake_db_session(FakeOraFndRepo().db) as x:
        yield x


@fixture(scope="session")
def test_ora_pim():
    class FakeOraPimRepo(OraPimRepo):
        def model(self): pass
    with fake_db_session(FakeOraPimRepo().db) as x:
        yield x


@fixture(scope="session")
def test_syb_pm_db():
    return SybPimRepo.instance.db


@fixture(scope="session")
def test_ms_webdm_db():
    return MsWebDmRepo.instance.db
