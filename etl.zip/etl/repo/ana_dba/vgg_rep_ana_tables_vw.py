from werkzeug.utils import cached_property

from etl.repo import OraAnaRepo


class VGgRepAnaTablesRepo(OraAnaRepo):
    @cached_property
    def VGgRepAnaStatus(self):
        return self.db.create_model('DBA_OWN', 'GG_REP_ANA_TABLES_VW', ['rep_group'])

    @property
    def model(self):
        return self.VGgRepAnaStatus

    def get_stream_by_table_name(self, table_name):
        return self.query.filter(self.model.table_name == table_name).first()
