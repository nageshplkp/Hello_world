"""===========================================================================
DESCRIPTION:  Repo for SSM_COMMON

AUTHOR:       Created by: PIMCO\zgalfaya

DATE:         Dec 19 2017 10:32AM
===========================================================================
"""
from werkzeug.utils import cached_property
from etl.repo import OraPimRepo


class SsmCommon(OraPimRepo):

    @cached_property
    def SsmCommon(self):
        return self.db.create_model(
            schema='TAPS_OWN', table_name='SSM_COMMON', pk=['ssm_id'])

    @property
    def model(self):
        return self.SsmCommon

    def get_by(self, ssm_id):
        return self.query.filter(
            self.model.ssm_id == ssm_id
        ).first()
