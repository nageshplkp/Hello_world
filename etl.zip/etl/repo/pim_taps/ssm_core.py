"""===========================================================================
DESCRIPTION:  Repo for SSM_CORE

AUTHOR:       Created by: PIMCO\zgalfaya

DATE:         Dec 19 2017 10:32AM
===========================================================================
"""
from werkzeug.utils import cached_property
from etl.repo import OraPimRepo


class SsmCore(OraPimRepo):

    @cached_property
    def SsmCore(self):
        return self.db.create_model(
            schema='TAPS_OWN', table_name='SSM_CORE', pk=['ssm_id'])

    @property
    def model(self):
        return self.SsmCore

    def get_by(self, ssm_id):
        return self.query.filter(
            self.model.ssm_id == ssm_id
        ).first()
