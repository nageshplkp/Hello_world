from etl.repo.sybiq_pm.cri import CriRepo
