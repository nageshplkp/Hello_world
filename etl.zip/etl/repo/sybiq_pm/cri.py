from werkzeug.utils import cached_property

from etl.repo import IqPimRepo


class CriRepo(IqPimRepo):
    @cached_property
    def Cri(self):
        return self.db.create_model('dbo', 'cri')

    @property
    def model(self):
        return self.Cri

    def get_by_mtg_id(self, mtg_id):
        return self.query.filter(self.model.mtg_id == mtg_id).first()
