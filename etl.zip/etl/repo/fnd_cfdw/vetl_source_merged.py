from werkzeug.utils import cached_property

from etl.repo import OraFndRepo


class VEtlSourceMergedRepo(OraFndRepo):
    @cached_property
    def VEtlSourceMerged(self):
        return self.db.create_model('CFDW_OWN', 'VETL_SOURCE_MERGED',
                                    ['source_code'])

    @property
    def model(self):
        return self.VEtlSourceMerged

    def get_by_source_code(self, source_code):
        return self.query.filter(self.model.source_code == source_code).first()
