from datetime import datetime, timedelta

from etl.core.util import sub_dhash
from .gen.etl_file import EtlFileRepo as GenEtlFileRepo
from .vetl_file_source_default import VetlFileSourceDefaultRepo


class EtlFileRepo(GenEtlFileRepo):
    def is_new_file(self, file_source, file_name):
        etl_file = self.get_by_file_source_local_file_name(file_source,
                                                           file_name)
        return etl_file is None

    def new_row(self, file_source, local_file_name, is_enabled, file_yyyymmdd,
                file_frequency, action_on_error=None, dw_insert_by=None,
                file_cutoff_date=None, ftp_file_folder=None, ftp_file_name=None,
                ftp_password=None, ftp_server_name=None, ftp_user_name=None,
                is_etl_done=None, is_ftp_done=None, local_file_folder=None,
                log_file_path=None, port_no=None, scheduled_pickup_date=None,
                supplier_email_address=None, pre_ftp_cmd=None, ftp_cmd=None,
                post_ftp_cmd=None):
        def lazy_subst(cmd, tmpl):
            return sub_dhash(tmpl, vars(row)) if not cmd and tmpl else cmd

        defaults_repo = VetlFileSourceDefaultRepo.instance_for_db(self.db)
        defaults = defaults_repo.get_by_file_source_code(file_source)
        now = datetime.now()
        row = (self.get_by_file_source_local_file_name(file_source,
                                                       local_file_name) or
               self.EtlFile())
        row.file_cutoff_date = file_cutoff_date or now + timedelta(minutes=60)
        row.file_source = file_source
        row.file_frequency = file_frequency
        row.file_yyyymmdd = file_yyyymmdd
        row.action_on_error = action_on_error or defaults.action_on_error
        row.dw_insert_by = dw_insert_by
        row.is_enabled = is_enabled
        row.is_etl_done = is_etl_done or defaults.is_etl_done
        row.is_ftp_done = is_ftp_done or defaults.is_ftp_done
        row.ftp_file_folder = ftp_file_folder or defaults.ftp_file_folder
        row.ftp_file_name = ftp_file_name or local_file_name
        row.ftp_password = ftp_password or defaults.ftp_password
        row.ftp_server_name = ftp_server_name or defaults.ftp_server_name
        row.ftp_user_name = ftp_user_name or defaults.ftp_user_name
        row.local_file_folder = local_file_folder or defaults.local_file_folder
        row.local_file_name = local_file_name
        row.log_file_path = log_file_path or defaults.log_file_path_template
        row.port_no = port_no or defaults.port_no
        row.scheduled_pickup_date = (scheduled_pickup_date or
                                     now + timedelta(minutes=-30))
        row.supplier_email_address = (supplier_email_address or
                                      defaults.supplier_email_address)
        row.pre_ftp_cmd = lazy_subst(pre_ftp_cmd, defaults.pre_ftp_cmd_template)
        row.ftp_cmd = lazy_subst(ftp_cmd, defaults.ftp_cmd_template)
        row.post_ftp_cmd = lazy_subst(post_ftp_cmd,
                                      defaults.post_ftp_cmd_template)
        return row

    def check_for_new_files_to_etl(self, file_source):
        return self.query.filter(self.model.file_source == file_source,
                                 self.model.is_enabled == 1,
                                 self.model.is_etl_done == 0,
                                 self.model.scheduled_pickup_date < datetime.now()).order_by(
            self.model.scheduled_pickup_date).first()
