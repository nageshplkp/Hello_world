from werkzeug.utils import cached_property

from etl.repo import OraFndRepo


class VetlFileSourceDefaultRepo(OraFndRepo):

    @cached_property
    def VetlFileSourceDefault(self):
        return self.db.create_model('CFDW_OWN', 'VETL_FILE_SOURCE_DEFAULT',
                                    ['file_source_code'])

    @property
    def model(self):
        return self.VetlFileSourceDefault

    def get_by_file_source_code(self, file_source_code):
        return self.query.filter(
            self.model.file_source_code == file_source_code).first()

    def list_by_source_group_code(self, source_group_code):
        return self.query.filter(
            self.model.source_group_code == source_group_code
        ).all()
