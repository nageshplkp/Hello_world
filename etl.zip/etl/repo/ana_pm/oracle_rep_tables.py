from werkzeug.utils import cached_property

from etl.repo import OraAnaRepo


class QueriesForOraRepTables(object):
    @property
    def model(self):
        raise NotImplemented

    @property
    def query(self):
        raise NotImplemented

    def get_by_audit_id(self, audit_id):
        return self.query.filter(self.model.audit_id == audit_id).first()

    def get_by_composite_pk(self, job_name, audit_id, asof_date):
        return self.query.filter(self.model.job_name == job_name,
                                 self.model.audit_id == audit_id,
                                 self.model.asof_date == asof_date).first()


# Replication Tables Below
class VRepPmRepo(OraAnaRepo, QueriesForOraRepTables):
    @cached_property
    def VRepPm(self):
        return self.db.create_model('PM_OWN', 'DA_REP_PM_VW',
                                    ['job_name', 'audit_id', 'asof_date'])

    @property
    def model(self):
        return self.VRepPm


class VRepPm1Repo(OraAnaRepo, QueriesForOraRepTables):
    @cached_property
    def VRepPm1(self):
        return self.db.create_model('PM_OWN', 'DA_REP_PM1_VW',
                                    ['job_name', 'audit_id', 'asof_date'])

    @property
    def model(self):
        return self.VRepPm1


class VRepPm2Repo(OraAnaRepo, QueriesForOraRepTables):
    @cached_property
    def VRepPm2(self):
        return self.db.create_model('PM_OWN', 'DA_REP_PM2_VW',
                                    ['job_name', 'audit_id', 'asof_date'])

    @property
    def model(self):
        return self.VRepPm2


class VRepPm3Repo(OraAnaRepo, QueriesForOraRepTables):
    @cached_property
    def VRepPm3(self):
        return self.db.create_model('PM_OWN', 'DA_REP_PM3_VW',
                                    ['job_name', 'audit_id', 'asof_date'])

    @property
    def model(self):
        return self.VRepPm3


class VRepPm4Repo(OraAnaRepo, QueriesForOraRepTables):
    @cached_property
    def VRepPm4(self):
        return self.db.create_model('PM_OWN', 'DA_REP_PM4_VW',
                                    ['job_name', 'audit_id', 'asof_date'])

    @property
    def model(self):
        return self.VRepPm4


class VRepPm5Repo(OraAnaRepo, QueriesForOraRepTables):
    @cached_property
    def VRepPm5(self):
        return self.db.create_model('PM_OWN', 'DA_REP_PM5_VW',
                                    ['job_name', 'audit_id', 'asof_date'])

    @property
    def model(self):
        return self.VRepPm5


class VRepPmPbRptRepo(OraAnaRepo, QueriesForOraRepTables):
    @cached_property
    def VRepPmPbRpt(self):
        return self.db.create_model('PM_PB_RPT_OWN', 'DA_REP_PM_PB_RPT_VW',
                                    ['job_name', 'audit_id', 'asof_date'])

    @property
    def model(self):
        return self.VRepPmPbRpt


class VRepPmHistRepo(OraAnaRepo, QueriesForOraRepTables):
    @cached_property
    def VRepPmHist(self):
        return self.db.create_model('PM_HIST_OWN', 'DA_REP_PM_HIST_VW',
                                    ['job_name', 'audit_id', 'asof_date'])

    @property
    def model(self):
        return self.VRepPmHist


class VRepPmAbsRepo(OraAnaRepo, QueriesForOraRepTables):
    @cached_property
    def VRepPmAbs(self):
        return self.db.create_model('PM_ABS_OWN', 'DA_REP_PM_ABS_VW',
                                    ['job_name', 'audit_id', 'asof_date'])

    @property
    def model(self):
        return self.VRepPmAbs


class VRepMbsRepo(OraAnaRepo, QueriesForOraRepTables):
    @cached_property
    def VRepMbs(self):
        return self.db.create_model('MBS_OWN', 'DA_REP_MBS_VW',
                                    ['job_name', 'audit_id', 'asof_date'])

    @property
    def model(self):
        return self.VRepMbs


class VRepTapsRepo(OraAnaRepo, QueriesForOraRepTables):
    @cached_property
    def VRepTaps(self):
        return self.db.create_model('TAPS_OWN', 'REP_TAPS_VW',
                                    ['job_name', 'audit_id', 'asof_date'])

    @property
    def model(self):
        return self.VRepTaps


class VRepPimcoRepo(OraAnaRepo, QueriesForOraRepTables):
    @cached_property
    def VRepPimco(self):
        return self.db.create_model('PIMCO_OWN', 'REP_PIMCO_VW',
                                    ['job_name', 'audit_id', 'asof_date'])

    @property
    def model(self):
        return self.VRepPimco


class VRepHistoryRepo(OraAnaRepo, QueriesForOraRepTables):
    @cached_property
    def VRepHistory(self):
        return self.db.create_model('HISTORY_OWN', 'REP_HISTORY_VW',
                                    ['job_name', 'audit_id', 'asof_date'])

    @property
    def model(self):
        return self.VRepHistory
