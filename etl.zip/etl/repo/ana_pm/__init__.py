from etl.repo.ana_pm.oracle_rep_tables import VRepPm1Repo, VRepPm2Repo, VRepPmRepo, VRepPm3Repo, VRepPm4Repo, \
    VRepPm5Repo, VRepPimcoRepo, VRepHistoryRepo, VRepMbsRepo, VRepPmAbsRepo, VRepPmHistRepo, VRepTapsRepo, VRepPmPbRptRepo
