"""===========================================================================
DESCRIPTION:  Repo for BOGIE_SEC_SET_PREVIEW

AUTHOR:       Created by: PIMCO\zgalfaya

DATE:         Dec 05 2017 10:32AM
===========================================================================
"""
from werkzeug.utils import cached_property
from etl.repo import OraPimRepo


class BogieSecSetPreviewRepo(OraPimRepo):

    @cached_property
    def BogieSecSetPreview(self):
        return self.db.create_model(
            schema='PM_ABS_OWN', table_name='BOGIE_SEC_SET_PREVIEW',
            pk=['ssm_id'])

    @property
    def model(self):
        return self.BogieSecSetPreview

    def get_by_ssm_id(self, ssm_id):
        return self.query.filter(
            self.model.ssm_id == ssm_id
        ).first()

    def list_by_ssm_id(self, ssm_id):
        return self.query.filter(self.model.ssm_id == ssm_id).all()

