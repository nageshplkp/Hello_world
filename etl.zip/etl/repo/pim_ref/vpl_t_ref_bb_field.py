from werkzeug.utils import cached_property

from etl.repo import OraPimRepo


class VplTRefBbFieldRepo(OraPimRepo):
    @cached_property
    def VplTRefBbField(self):
        return self.db.create_model('REF_OWN', 'VPL_T_REF_BB_FIELD', ['field_mnemonic'])

    @property
    def model(self):
        return self.VplTRefBbField

    def get_by_field_mnemonic(self, field_mnemonic):
        return self.query.filter(self.model.field_mnemonic == field_mnemonic).first()
