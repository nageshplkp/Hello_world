from werkzeug.utils import cached_property

from etl.repo import SybPimRepo


class CurrencyRepo(SybPimRepo):
    @cached_property
    def Currency(self):
        return self.db.create_model('dbo', 'currency')

    @property
    def model(self):
        return self.Currency

    def get_by_iso_currency_code(self, iso_currency_code):
        return self.query.filter(self.model.iso_currency_code ==
                                 iso_currency_code).first()
