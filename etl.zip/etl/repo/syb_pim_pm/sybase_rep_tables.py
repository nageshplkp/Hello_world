from werkzeug.utils import cached_property

from etl.repo import SybPimRepo


class QueriesForSybRepTables(object):
    @property
    def query(self):
        raise NotImplemented

    @property
    def db(self):
        raise NotImplemented

    @property
    def model(self):
        raise NotImplemented

    def insert(self, row):
        self.db.save(row)

    def get_by_audit_id(self, audit_id):
        return self.query.filter(self.model.audit_id == audit_id).first()


class RepPmRepo(SybPimRepo, QueriesForSybRepTables):
    @cached_property
    def RepPm(self):
        return self.db.create_model('dbo', 'da_rep_pm')

    @property
    def model(self):
        return self.RepPm


class RepPm1Repo(SybPimRepo, QueriesForSybRepTables):
    @cached_property
    def RepPm1(self):
        return self.db.create_model('dbo', 'da_rep_pm1')

    @property
    def model(self):
        return self.RepPm1


class RepPm2Repo(SybPimRepo, QueriesForSybRepTables):
    @cached_property
    def RepPm2(self):
        return self.db.create_model('dbo', 'da_rep_pm2')

    @property
    def model(self):
        return self.RepPm2


class RepPm3Repo(SybPimRepo, QueriesForSybRepTables):
    @cached_property
    def RepPm3(self):
        return self.db.create_model('dbo', 'da_rep_pm3')

    @property
    def model(self):
        return self.RepPm3


class RepPm4Repo(SybPimRepo, QueriesForSybRepTables):
    @cached_property
    def RepPm4(self):
        return self.db.create_model('dbo', 'rep_pm4')

    @property
    def model(self):
        return self.RepPm4


class RepPm5Repo(SybPimRepo, QueriesForSybRepTables):
    @cached_property
    def RepPm5(self):
        return self.db.create_model('dbo', 'da_rep_pm5')

    @property
    def model(self):
        return self.RepPm5


class RepPmAbsRepo(SybPimRepo, QueriesForSybRepTables):
    @cached_property
    def RepPmAbs(self):
        return self.db.create_model('pm_abs', 'da_rep_pm_abs')

    @property
    def model(self):
        return self.RepPmAbs


class RepPmPbRptRepo(SybPimRepo, QueriesForSybRepTables):
    @cached_property
    def RepPmPbRpt(self):
        return self.db.create_model('pm_pb_rpt', 'da_rep_pm_pb_rpt')

    @property
    def model(self):
        return self.RepPmPbRpt


class RepPmHistRepo(SybPimRepo, QueriesForSybRepTables):
    @cached_property
    def RepPmHist(self):
        return self.db.create_model('pm_hist', 'da_rep_pm_hist')

    @property
    def model(self):
        return self.RepPmHist


class RepTapsRepo(SybPimRepo, QueriesForSybRepTables):
    @cached_property
    def RepTaps(self):
        return self.db.create_model('taps', 'da_rep_taps')

    @property
    def model(self):
        return self.RepTaps


class RepHistoryRepo(SybPimRepo, QueriesForSybRepTables):
    @cached_property
    def RepHistory(self):
        return self.db.create_model('history', 'da_rep_history')

    @property
    def model(self):
        return self.RepHistory


class RepPimcoRepo(SybPimRepo, QueriesForSybRepTables):
    @cached_property
    def RepPimco(self):
        return self.db.create_model('pimco', 'da_rep_pimco')

    @property
    def model(self):
        return self.RepPimco


class RepMbsRepo(SybPimRepo, QueriesForSybRepTables):
    @cached_property
    def RepMbs(self):
        return self.db.create_model('mbs', 'da_rep_mbs')

    @property
    def model(self):
        return self.RepMbs

