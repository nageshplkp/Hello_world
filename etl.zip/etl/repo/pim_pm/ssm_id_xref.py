"""===========================================================================
DESCRIPTION:  Repo for SSM_ID_XREF

AUTHOR:       Created by: PIMCO\zgalfaya

DATE:         Dec 05 2017 10:32AM
===========================================================================
"""
from werkzeug.utils import cached_property
from etl.repo import OraPimRepo


class SsmIdXrefRepo(OraPimRepo):
    
    @cached_property
    def SsmIdXref(self):
        return self.db.create_model(
            schema='PM_OWN', table_name='SSM_ID_XREF',
            pk=['ssm_id', 'source_sec_id', 'source_key'])

    @property
    def model(self):
        return self.SsmIdXref

    @model.setter
    def model(self, value):
        setattr(self, '_model', value)

    def get_by(self, source_key, source_sec_id, ssm_id):
        return self.query.filter(
            self.model.ssm_id == ssm_id,
            self.model.source_sec_id == source_sec_id,
            self.model.source_key == source_key
        ).first()

    def list_by_ssm_id(self, ssm_id):
        return self.query.filter(self.model.ssm_id == ssm_id).all()

    def save(self, ssm_id_xref):
        return self.db.save(ssm_id_xref)

    def delete_by(self, source_key, source_sec_id):
        try:
            results = self.query.filter(
                self.model.source_key == source_key,
                self.model.source_sec_id == source_sec_id,
            ).delete(synchronize_session='evaluate')
            self.db.session.commit()
            return results
        except:
            self.db.session.rollback()
            raise

