from etl.core.db import Db
from etl.core.util import lazy_get, classproperty
from .pl_request import PlRequestRepo
from .pl_mnemonic_lookup import PlMnemonicLookupRepo


class PlBenchmarkDriverVwRepo(object):
    def __init__(self, db=None):
        self.db = db or Db('ORAPIM_DBP', 'oracle')

    @classproperty
    def instance(cls):
        return lazy_get(cls, '_instance', lambda: PlBenchmarkDriverVwRepo())

    @property
    def PlBenchmarkDriverVw(self):
        return lazy_get(self, '_PlBenchmarkDriverVw', lambda:
                        self.db.create_model('PM_OWN', 'PL_BENCHMARK_DRIVER_VW',
                                             pk=['pim_ticker', 'pim_mnemonic']))

    @property
    def model(self):
        return self.PlBenchmarkDriverVw

    @property
    def query(self):
        return lazy_get(self, '_query', lambda: self.db.query(self.model))

    def get_by_pim_ticker_pim_mnemonic(self, pim_ticker, pim_mnemonic):
        return self.query.filter(
            self.model.pim_ticker == pim_ticker,
            self.model.pim_mnemonic == pim_mnemonic).first()

    def get_unregistered_tss_series(self):
        PlRequest = PlRequestRepo(self.db).PlRequest
        PlMnemonicLookup = PlMnemonicLookupRepo(self.db).PlMnemonicLookup
        return self.db.query(self.model, PlMnemonicLookup, PlRequest) \
            .join(PlMnemonicLookup,
                  self.model.pim_mnemonic ==
                  PlMnemonicLookup.mnemonic) \
            .outerjoin(PlRequest,
                       self.model.pl_request_id ==
                       PlRequest.pl_request_id) \
            .filter(self.model.is_registered_in_tss == 0,
                    self.model.is_tss_enabled == 1) \
            .all()
