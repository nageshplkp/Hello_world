"""===========================================================================
DESCRIPTION:  Repo for BOGIE_SEC_SET

AUTHOR:       Created by: PIMCO\zgalfaya

DATE:         Dec 05 2017 10:32AM
===========================================================================
"""
from werkzeug.utils import cached_property
from etl.repo import OraPimRepo


class BogieSecSetRepo(OraPimRepo):
    
    @cached_property
    def BogieSecSet(self):
        return self.db.create_model(
            schema='PM_OWN', table_name='BOGIE_SEC_SET',
            pk=['ssm_id'])

    @property
    def model(self):
        return self.BogieSecSet

    def get_by_ssm_id(self, ssm_id):
        return self.query.filter(
            self.model.ssm_id == ssm_id
        ).first()

    def list_by_ssm_id(self, ssm_id):
        return self.query.filter(self.model.ssm_id == ssm_id).all()
