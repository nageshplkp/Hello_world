"""===========================================================================
DESCRIPTION:  Repo for SSM_ID_XREF

AUTHOR:       Created by: PIMCO\zgalfaya

DATE:         Dec 05 2017 10:32AM
===========================================================================
"""
import logging
from sqlalchemy import exc
from werkzeug.utils import cached_property
from etl.repo import OraPimRepo


class SecPricesRepo(OraPimRepo):
    
    @cached_property
    def SecPrices(self):
        return self.db.create_model('PM_OWN', 'SEC_PRICES')

    @property
    def model(self):
        return self.SecPrices

    def get_by(self, source_key, source_sec_id, ssm_id):
        return self.query.filter(
            self.model.ssm_id == ssm_id,
            self.model.source_sec_id == source_sec_id,
            self.model.source_key == source_key
        ).first()

    def list_by_ssm_id(self, ssm_id):
        return self.query.filter(self.model.ssm_id == ssm_id).all()

    def save(self, ssm_id_xref):
        return self.db.save(ssm_id_xref)

    def delete_by(self, source_key, source_sec_id):
        try:
            results = self.query.filter(
                self.model.source_key == source_key,
                self.model.source_sec_id == source_sec_id,
            ).delete(synchronize_session='fetch')
            self.db.session.commit()
            return results
        except:
            self.db.session.rollback()
            raise

    def load_sec_prices(self, audit_id, start_date, end_date):
        params = {}
        procedure = ''
        try:
            params = {
                'i_etl_audit_job_id': audit_id,
                'i_etl_load_start_date': start_date,
                'i_etl_load_end_date': end_date,
                'i_is_in_debug': 0
            }

            # build sql statement for executing procedure
            procedure = '''
            BEGIN
                {0};
            END;
            '''.format('''DAIS_OWN.SP_LOAD_PM_SEC_PRICES(
                     {0}
            )'''.format('       ,'.join([''' {0}  =>  :{0}
            '''.format(k, v) for k, v in params.items()
                ]))
            )

            results = self.db.session.execute(procedure, params)
            self.db.session.commit()

            logging.info(
                'execute proc:%s, params:%s, results:%s',
                procedure, params, ['{}={}'.format(
                    x, getattr(results, x)
                ) for x in ['is_insert', 'out_parameters', 'rowcount']])

            return results

        except exc.SQLAlchemyError as e:
            if self.db.session is not None:
                self.db.session.rollback()
            logger = logging.getLogger(__name__)
            logger.exception(
                "Failed to execute stored procedure %s, params: %s,"
                "with SQLAlchemyError: %s", procedure, params, e)

            raise
