from werkzeug.utils import cached_property

from etl.repo import MsWebDmRepo


class DwCountryRepo(MsWebDmRepo):
    @cached_property
    def DwCountry(self):
        return self.db.create_model('dbo', 'DW_COUNTRY')

    @property
    def model(self):
        return self.DwCountry

    def get_by_country_code(self, country_code):
        return self.query.filter(self.model.COUNTRY_CODE ==
                                 country_code).first()
