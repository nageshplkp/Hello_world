import ast
import datetime
import getpass
import json
import logging
import os
import queue
import threading
import time

from core.common import mail
from core.rest.client import ClientException
from core.services.timeseries.ts_proxy import TsProxy
from etl.core.da_config import get_env
from etl.core.util import parse_args
from etl.repo.fnd_cfdw.d_ts_series import DTsSeriesRepo
from etl.repo.fnd_cfdw.stgp_f_ts_series import StgpFTsSeriesRepo
from sqlalchemy import or_


USAGE = ['EDW TSS Submit Agent',
         ['action', {'help': 'TSS_SUBMIT'}],
         ['--worker_pool_size', dict(type=int, default=15, help='Number of parallel workers for data transfer')],
         ['--audit_id', dict(type=int, default=0, help='The ETL_AUDIT_ID to use for this job')],
         ]

DEFAULT_AUDIT_ID = -999
DEFAULT_QUEUE_SIZE_PER_THREAD = 20
DEFAULT_SAVE_RETRY_MAX = 5
DEFAULT_SAVE_RETRY_TIMEOUT = 10


def _build_worker_log_message(thread_id, status_code, row_id=None, log_message=None):
    log_message = ', message: %s' % log_message if log_message else ''
    row_id = ', row id: %s' % row_id if row_id else ''
    return 'Thread: %s%s, status: %s%s' % (thread_id, row_id, status_code, log_message)


def _get_tss_base_url():

    # for testing purposes, lets stick to the same server. When committing, comment out the below line
    # return 'http://devpmwsv7:61000/timeseries/v1'

    return get_env()


class EdwTssSubmitAgent(object):
    agent_name = 'EdwTssSubmitAgent'
    audit_id = 0
    current_row_id = 0
    env = get_env()
    mail_from = None
    mail_to = None
    mode = None
    queue = queue.Queue(maxsize=0)
    queue_max_size = 0
    svc_request_status_code_exclusions = ['NOT_FOUND']
    ts_proxy = TsProxy(base_url=_get_tss_base_url())
    username = getpass.getuser()
    workers = {}
    workers_lock = threading.Lock()
    workers_max_size = 0

    def __init__(self, mode, pool_size, audit_id):
        self.audit_id = audit_id if audit_id != 0 else os.environ.get('ETL_AUDIT_ID', DEFAULT_AUDIT_ID)
        self.mail_from = self.username
        self.mail_to = 'DAAlert-%s@pimco.com' % self.env
        self.mode = mode
        self.queue_max_size = pool_size * DEFAULT_QUEUE_SIZE_PER_THREAD
        self.workers_max_size = pool_size

        self.mail_to = self.username

    def _db_save_with_retry(self, thread_id, item, repo, retry_count):
        if retry_count > 0:
            self._log_worker_warn(thread_id, 'RETRY_SAVE', item.dw_row_id, 'retry %s' % retry_count)

        def save():
            repo.save(item)
            self._log_worker_info(thread_id, 'SAVED', item.dw_row_id, 'retry %s' % retry_count)

        t = threading.Thread(target=save)
        t.start()

        if t.is_alive():
            def cancel():
                pass

            timer = threading.Timer(DEFAULT_SAVE_RETRY_TIMEOUT, cancel)
            timer.start()

            while t.is_alive() and timer.is_alive():
                pass

            if not t.is_alive():
                timer.cancel()
            else:
                threading.Thread(target=lambda: t.join).start()
                if retry_count < DEFAULT_SAVE_RETRY_MAX:
                    repo.db.session.expire_all()
                    return self._db_save_with_retry(thread_id, item, repo, retry_count + 1)

        return repo

    def _dequeue(self):
        # Allow time for the queue to populate if it's empty
        i = 1
        while self.queue.empty():
            time.sleep(0.5)
            i += 1
            if i == 10:
                return None

        item = self.queue.get()
        self.queue.task_done()
        return item

    def _email_error(self, subject, message):
        mail.send_mail(self.mail_from,
                       self.mail_to,
                       subj='(%s)%s - %s error' % (self.env, self.agent_name, subject),
                       msg=message)

    def _log_error(self, log_message):
        logging.error('%s - %s' % (self.agent_name, log_message))

    def _log_info(self, log_message):
        logging.info('%s - %s' % (self.agent_name, log_message))

    def _log_warn(self, log_message):
        logging.warn('%s - %s' % (self.agent_name, log_message))

    def _log_worker_error(self, thread_id, status_code, row_id=None, log_message=None):
        self._log_error(_build_worker_log_message(thread_id, status_code, row_id, log_message))

    def _log_worker_info(self, thread_id, status_code, row_id=None, log_message=None):
        self._log_info(_build_worker_log_message(thread_id, status_code, row_id, log_message))

    def _log_worker_warn(self, thread_id, status_code, row_id=None, log_message=None):
        self._log_warn(_build_worker_log_message(thread_id, status_code, row_id, log_message))

    def _queue_worker(self, repo):
        if self.queue.qsize() < self.queue_max_size:
            self._log_info('populate_queue, status: STARTED, current size: %s' % self.queue.qsize())

            # Get records that:
            # 1)  Has not completed the svc call (is_svc_call_done = 0)
            # 2a) Row Id is greater than the max row id from the last pull
            #     Or
            # 2b) Update date is older than the retry date
            # 3)  Not in the exclusion status codes

            model = repo.model
            retry_datetime = datetime.datetime.now() - datetime.timedelta(minutes=30)

            items = repo.query\
                .filter(model.is_svc_call_done == 0,
                        or_(model.dw_row_id > self.current_row_id,
                            model.dw_update_date <= retry_datetime),
                        model.svc_request_status_code.notin_(self.svc_request_status_code_exclusions)) \
                .order_by(model.dw_row_id) \
                .limit(self.queue_max_size)\
                .all()

            count = items.__len__()

            if count <= 0:
                self._log_info('populate_queue, status: FOUND %s' % count)

            else:
                for o in items:
                    self.queue.put(o)

                old_row_id = self.current_row_id
                self.current_row_id = max(o.dw_row_id for o in items)

                self._log_info('populate_queue, status: FOUND %s, current size: %s, old row id: %s, new row id: %s'
                               % (count, self.queue.qsize(), old_row_id, self.current_row_id))

        if not self.queue.empty():
            # Create a queue worker to continuously try to ensure the queue has items
            threading.Timer(self.workers_max_size, self._queue_worker, args=[repo]).start()

    def _worker(self, thread_id):
        self._log_worker_info(thread_id, 'STARTED')
        repo = StgpFTsSeriesRepo()
        series_key_repo = DTsSeriesRepo()

        while 1:
            item = self._dequeue()
            if not item:
                break

            self._log_worker_info(thread_id, 'STARTED', item.dw_row_id)
            repo = self._worker_work(thread_id, item, repo, series_key_repo)

        self._log_worker_info(thread_id, 'ENDED')
        self.workers_lock.acquire()
        self.workers.pop(thread_id)
        self.workers_lock.release()

    def _worker_work(self, thread_id, item, repo, series_key_repo):
        email_subject = None
        error_message = None
        log_error_message = None

        try:
            self._worker_work_tss_post(thread_id, item, series_key_repo)

        except ClientException as e:
            status_code = 'HTTP_EXCEPTION %s' % e.detail_json['status']
            email_subject = status_code
            error_message = e.detail_json['reason']

            item.svc_request_status_code = 'RESPONSE'
            item.svc_response = json.dumps(ast.literal_eval(str(e.detail_json)))

        except ValueError as e:
            status_code = 'INVALID_JSON'
            error_message = e.message
            log_error_message = ', field: SVC_BODY' % error_message

            item.is_svc_call_done = 2
            item.svc_request_status_code = 'FAILURE'
            item.svc_response = json.dumps({'status:': status_code, 'field:': 'SVC_BODY',
                                            'reason': error_message})

        except Exception as e:
            status_code = 'EXCEPTION'
            error_message = e.message

            item.svc_request_status_code = 'FAILURE'
            item.svc_response = json.dumps({'status:': status_code, 'reason': error_message})

        try:
            item.request_etl_audit_id = self.audit_id
            item.dw_update_by = self.username
            item.dw_update_date = datetime.datetime.now()

            repo = self._db_save_with_retry(thread_id, item, repo, 0)

        except Exception as e:
            status_code = 'SAVE_DB_EXCEPTION'
            error_message = e.message
            log_error_message = error_message

        if error_message:
            self._log_worker_error(thread_id, status_code, item.dw_row_id,
                                   log_error_message if log_error_message else error_message)
            self._email_error(email_subject, error_message)

        return repo

    def _worker_work_tss_post(self, thread_id, item, series_key_repo):
        obj = json.loads(item.svc_body)

        resp = self.ts_proxy.post_obj('/series/update', obj)
        status_code = resp.update_code

        item.svc_request_status_code = status_code
        item.svc_response = json.dumps(ast.literal_eval(str(resp)))

        self._log_worker_info(thread_id, 'TSS_POST_%s' % status_code, item.dw_row_id)

        update_detail = resp.update_details[0]

        if status_code == 'SUCCESS':
            item.is_svc_call_done = 1

        if item.series_key <= 0:
            series_key = series_key_repo.get_by_series_code(update_detail.request_id)
            if series_key:
                item.series_key = series_key.series_key

    def run(self):
        self._log_info('status: STARTED')

        # Load the initial queue
        self._queue_worker(StgpFTsSeriesRepo())

        # Create the workers if there are items in the queue
        if self.queue.qsize() > 0:
            self.workers_lock.acquire()
            for i in range(self.workers_max_size):
                worker = threading.Thread(target=self._worker, args=(i,))
                # worker.setDaemon(True)
                worker.start()
                self.workers[i] = worker
            self.workers_lock.release()

            while self.workers.__len__() > 0:
                pass

        self._log_info('status: ENDED')


if __name__ == '__main__':
    args = parse_args(*USAGE)
    action = args.action.upper()
    if action in 'TSS_SUBMIT':
        agent = EdwTssSubmitAgent(action, args.worker_pool_size, args.audit_id)
    else:
        raise RuntimeError('Unknown action specified: {}'.format(action))

    agent.run()
