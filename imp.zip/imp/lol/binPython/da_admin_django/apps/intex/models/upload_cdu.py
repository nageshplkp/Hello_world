# coding=utf-8

from __future__ import unicode_literals
from datetime import datetime

from ..app_config import AppConfig
from model_base import *
from helpers.upload_cdu import ModelFieldHelper


modelFieldHelper = ModelFieldHelper()


class UploadCdu(ClientSideFormModelBase):
    file = modelFieldHelper.file()
    month = modelFieldHelper.month()
    year = modelFieldHelper.year()

    help_texts = modelFieldHelper.field_help_texts
    verbose_names = modelFieldHelper.field_verbose_names

    def get_unicode(self):
        return modelFieldHelper.get_unicode(self)

    def log_insert(self, by):
        self.log_update(by)

    def log_update(self, by):
        pass

    class Meta:
        abstract = False
        app_label = AppConfig.name
        managed = False
        verbose_name = modelFieldHelper.model_verbose_name
        verbose_name_plural = modelFieldHelper.model_verbose_plural
