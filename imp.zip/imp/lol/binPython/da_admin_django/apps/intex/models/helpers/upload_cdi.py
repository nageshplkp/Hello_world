# coding=utf-8

from __future__ import unicode_literals
from core.django.models import *
from core.helpers import OverridableBase


class FieldNames():
    file='file'


class ModelFieldHelper(OverridableBase):
    model_verbose_name = 'Upload CDI File'
    model_verbose_plural = 'Upload CDI File'

    # field_help_texts = {'field_name': 'Help text for field'}
    field_help_texts = {}
    # field_verbose_names = {'field_name': 'Displayed name for field'}
    field_verbose_names = {}

    foreign_fields = []
    form_fields = [FieldNames.file]
    indexed_fields = []
    list_display_fields = []
    raw_id_fields = foreign_fields
    readonly_fields = []
    to_string_fields = []

    def get_unicode(self, modelInstance):
        return ' - '.join([unicode(getattr(modelInstance, o))
                           for o in self.to_string_fields
                           if o not in self.foreign_fields])

    def file(self):
        return FileField(verbose_name=u'File', help_text='', editable=True)
