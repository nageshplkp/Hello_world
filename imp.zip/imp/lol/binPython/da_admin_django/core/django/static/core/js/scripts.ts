var scripts = document.getElementsByTagName('script');
requirejs.config({
    baseUrl: scripts[scripts.length - 1].src.split('?')[0].split('/').slice(0, -3).join('/')+'/'
});


var loadedCss = [];
var styleAppendBefore = document.getElementsByTagName('link');
function loadCss(urls) {
    if (!(urls instanceof Array)) {
        urls = [urls];
    }

    var head = document.getElementsByTagName('head')[0];
    var jHead = $(head);

    for (var i = 0; i < urls.length; i++) {
        var url = requirejs.toUrl(urls[i]);
        if (loadedCss.indexOf(url) >= 0) {
            continue;
        }
        loadedCss.push(url);

        var link = document.createElement('link');
        link.type = 'text/css';
        link.rel = 'stylesheet';
        link.href = url;
        head.insertBefore(link, styleAppendBefore[styleAppendBefore.length - 1]);
    }
}

class CodeHighlight {
    private static formatCode = (code: string, code_mode: string) => {
        try {
            switch (code_mode) {
                case 'javascript':
                case 'json':
                    if (typeof code === 'string') { code = JSON.parse(code); }
                    code = JSON.stringify(code, null, 4);
                    break;
            }
        } catch { }

        return code;
    }

    public static fromFieldNameCodeMode = (fieldName: string, code_mode: string) => {
        $('div.control-group.field-' + fieldName + ' div.controls span.readonly')
            .each((i: number, item: Element) => CodeHighlight.toReadOnly(item, code_mode));
    }

    public static toReadOnly(control: Element, code_mode: string) {
        var c = $(control);
        var code = c.text();
        c.html('').html(CodeHighlight.toReadOnlyCode(code, code_mode, true));
    };

    public static toReadOnlyCode = function(code: string, code_mode: string, showLineNumber: boolean) {
        loadCss('prism/prism.css');
        requirejs(['prism/prism']);

        code = CodeHighlight.formatCode(code, code_mode);

        if (typeof Prism !== 'undefined') {
            code = Prism.highlight(code, Prism.languages[code_mode]);
        }

        var css = 'language-' + code_mode;
        if (showLineNumber) {
            css += ' line-numbers'
        }

        return '<pre><code class="' + css + '">' + code + '</code></pre>';
    };

    public static toWriteableCode = (controls: JQuery) => {
        if (controls.length <= 0) { return; }

        loadCss([
            'codemirror/doc/docs.css',
            'codemirror/lib/codemirror.css',
            'codemirror/addon/fold/foldgutter.css',
            'codemirror/addon/hint/show-hint.css'
        ]);

        requirejs([
            'codemirror/lib/codemirror',
            'codemirror/mode/meta',
            'codemirror/addon/fold/foldcode',
            'codemirror/addon/fold/foldgutter',
            'codemirror/addon/fold/brace-fold',
            'codemirror/addon/fold/xml-fold',
            'codemirror/addon/fold/indent-fold',
            'codemirror/addon/fold/markdown-fold',
            'codemirror/addon/fold/comment-fold',
            'codemirror/addon/hint/show-hint',
            'codemirror/addon/hint/sql-hint'
        ], function (CodeMirror) {
            controls.each((i: number, item: Element) => {
                var c = $(item);
                var code_mode = item.getAttribute('data-code-area');
                var code = CodeHighlight.formatCode(c.val(), code_mode);
                c.val(code);

                var modeInfo = CodeMirror.findModeByName(code_mode);
                requirejs(['codemirror/mode/' + modeInfo.mode + '/' + modeInfo.mode],
                    function () {
                        CodeMirror.fromTextArea(
                            item,
                            {
                                mode: modeInfo.mime,
                                lineNumbers: true,
                                smartIndent: true,
                                matchBrackets: true,
                                foldGutter: true,
                                gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
                            });
                    });
            });
        });
    };
}

function autoRefresh(delay) {
    if (delay == null) { delay = 6000; }

    var mouseIdleCounter = 0;
    var mouseIdleTimer = null;
    var refreshTimer = null;

    function startMouseIdleTimer() {
        // Stop the refresh timer
        if (refreshTimer !== null) {
            clearTimeout(refreshTimer);
            refreshTimer = null;
        }

        // Create mouse idle timer
        mouseIdleTimer = setTimeout(function(){
            mouseIdleCounter++;

            if (mouseIdleCounter <= 2) {
                startMouseIdleTimer();
            } else {
                clearTimeout(mouseIdleTimer);
                mouseIdleTimer = null;

                startRefreshTimer();
            }
        }, 1000);
    }

    function startRefreshTimer() {
        refreshTimer = setTimeout(function(){
          window.location.reload(1);
        }, delay);
    }

    $(document).mousemove(function(event){
        // Reset the counter because the mouse is moving
        mouseIdleCounter = 0;
        if (mouseIdleTimer === null) { startMouseIdleTimer(); }
    });

    startRefreshTimer();
}

$(() => {
    $('div[data-code-area]')
        .each((i: number, item: Element) => CodeHighlight.toReadOnly(item, item.getAttribute('data-code-area')));

    CodeHighlight.toWriteableCode($('textarea[data-code-area]'))

    // Hide submit box
    var saveBox = $('.box.save-box');
    if (saveBox.find('.submit-row').find('button[name=_save]').length === 0) {
        saveBox.hide();
    }

    // Hide Add another link
    $('.inline-group').each((i: number, item: Element) => {
        var id = item.id;
        var prefix = id.substr(0, id.length - 6);
        var minForms = $("#id_" + prefix + "-MIN_NUM_FORMS");
        if (minForms.val() === '-1') {
            var maxForms = $("#id_" + prefix + "-MAX_NUM_FORMS");
            maxForms.val(0);
        }
    });
});
