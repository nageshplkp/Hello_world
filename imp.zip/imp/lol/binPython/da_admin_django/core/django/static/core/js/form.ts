var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
module Django {
    export abstract class AdminForm {
        protected actionName: string;
        protected actionToExecute: (inputValues: Object, errors: Array<string>) => boolean;
        protected form: any;
        private httpRequestControl;
        private httpResponseControl;
        private httpStatusControl;
        private submitButton: any;

        constructor(el: Element) {
            this.submitButton = $(el);
            var form = this.submitButton.closest('form');

            this.form = form;
            this.actionName = form.attr('id').toLowerCase().split('_')[0];
            this.httpRequestControl = form.find('div.field-http_request div.controls span.readonly').html('');
            this.httpResponseControl = form.find('div.field-http_response div.controls span.readonly').html('');
            this.httpStatusControl = form.find('div.field-http_status div.controls span.readonly').html('');
        }

        protected ajax = (settings: any): any => {
            this.printHttpRequest(settings);
            return $.ajax(settings)
                .done((data, status, xhr) => {
                    this.printHttpResponse(data);
                    this.onAjaxSuccess(data, status, xhr);
                })
                .fail((xhr, status, errorThrown) => {
                    xhr.responseJSON ?
                        this.printHttpResponse(xhr.responseJSON) :
                        this.printHttpStatus(status, errorThrown);

                    this.onAjaxError(xhr, status, errorThrown);
                })
                .always((xhr, status, errorThrown) => {
                    this.onAjaxComplete();
                    this.toggleFormDisable(false);
                });
        }

        protected ajaxGet = (url: string): any => {
            var settings = this.buildAjaxGetSettings(url);
            this.printHttpRequest(settings);
            return this.ajax(settings);
        }

        protected ajaxPost = (url: string, data: {} | FormData): any => {
            var settings = this.buildAjaxPostSettings(url, data);
            this.printHttpRequest(settings);
            return this.ajax(settings);
        }

        private buildAjaxSettings = (url: string, httpMethod: string): any => {
            return {
                url: url,
                type: httpMethod,
                crossDomain: true,
                xhrFields: { withCredentials: true },
                headers: { 'Access-Control-Allow-Origin': '*' },
                accept: 'application/json'
            };
        }

        private buildAjaxGetSettings = (url: string): any => {
            var settings: any = this.buildAjaxSettings(url, 'GET');
            settings.contentType = 'application/json; charset=utf-8';
            settings.dataType = 'json';

            return settings;
        }

        private buildAjaxPostSettings = (url: string, data: {} | FormData): any => {
            var settings: any = this.buildAjaxSettings(url, 'POST');

            if (data instanceof FormData) {
                settings.data = data;
                settings.contentType = false;  // tell jQuery not to set contentType
                settings.processData = false;  // tell jQuery not to process the data

                // Upload progress status
                //xhr: function () {
                //    var myXhr = $.ajaxSettings.xhr();
                //    if (myXhr.upload) {
                //        myXhr.upload.addEventListener('progress', that.progressHandling, false);
                //    }
                //    return myXhr;
                //},

            } else {
                settings.contentType = 'application/json; charset=utf-8';
                settings.data = JSON.stringify(data);
                settings.dataType = 'json';
            }

            return settings;
        }

        protected onAjaxComplete = (): void => { }

        protected onAjaxError = (xhr, status, errorThrown): void => { }

        protected onAjaxSuccess = (data, status, xhr): void => { }

        protected printHttpRequest = (settings: any): void => {
            this.httpRequestControl.html(CodeHighlight.toReadOnlyCode(settings, 'json', false));
            this.printHttpStatus('pending');
        }

        private printHttpResponse = (data: any): void => {
            this.httpResponseControl.html(CodeHighlight.toReadOnlyCode(data, 'json', false));
            this.printHttpStatus(data.status, data.body && data.body.message ? data.body.message : data.message);
        }

        protected printHttpStatus = (status: string, message?: any): void => {
            this.httpStatusControl.html(CodeHighlight.toReadOnlyCode({ status: status, message: message }, 'json', false));
        }

        protected toggleFormDisable = (disable: boolean): void => {
            this.submitButton.prop('disabled', disable);
        }

        protected toFormData = (file: File, expectedExtension: string): FormData => {
            var fileNameParts = file.name.split('.');
            if (fileNameParts.length < 2 || fileNameParts[1].toLowerCase() !== expectedExtension) {
                this.printHttpStatus('Invalid file', 'Invalid file. Expected: ' + expectedExtension);
                return null;
            } else {
                var formData = new FormData();
                formData.append("file", file);
                //formData.append("upload_file", true);
                return formData;
            }
        }

        public submit(): void {
            this.httpRequestControl.html('');
            this.httpResponseControl.html('');
            this.httpStatusControl.html('');

            this.toggleFormDisable(true);

            if (this.actionToExecute) {
                var errors: Array<string> = [];
                var values = new Object();

                var getValue = (id: string, jQ: any): string => {
                    var val = jQ.prop('type') === 'checkbox' ? jQ.prop('checked') : jQ.val();

                    if (val === '' && jQ.prop('required')) {
                        var label = jQ.closest('.control-group').find('label').text();
                        if (label === '') {
                            label = id;
                        } else {
                            var col = label.lastIndexOf(':');
                            label = (col < 0) ? label : label.substr(0, col);
                        }

                        errors.push('Invalid value for \'' + label + '\'.');
                    }

                    return val;
                };

                this.form
                    .find('div.controls :input')
                    .each((i: number, el: Element) => {
                        var jQ = $(el);
                        var id = jQ.prop('id').substr(3);
                        values[id] = getValue(id, jQ);
                    })
                    .end()
                    .find('div.inline-group')
                    .each((i: number, el: Element) => {
                        var groupId = el.id.split('-')[0];
                        var groupValues = [];
                        values[groupId] = groupValues;

                        $(el)
                            .find('tr.form-row:not(tr.empty-form)')
                            .each((i: number, el: Element) => {
                                var rowValues = new Object();
                                $(el)
                                    .find(':input')
                                    .each((i: number, el: Element) => {
                                        var jQ = $(el);
                                        var id = jQ.prop('id').substr(3 + groupId.length + 3);
                                        rowValues[id] = getValue(id, jQ);
                                    });
                                groupValues.push(rowValues);
                            });
                    });

                if (errors.length === 0 && this.actionToExecute(values, errors)) { return; }

                if (errors.length > 0) {
                    this.printHttpRequest(values);
                    this.printHttpStatus('Validation Error', errors);
                }
            }

            this.toggleFormDisable(false);
        }
    }
}
