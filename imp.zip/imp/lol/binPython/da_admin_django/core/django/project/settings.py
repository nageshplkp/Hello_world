import base64
import importlib
import os
import sys
import da_config
import core.django.signals.db_signal_receivers      # don't remove it. needed for wiring signals
from core.helpers.oracle_introspection_patch import apply_patch

apps_dir = './apps'
sys.path.insert(0, apps_dir)

ADMIN_TOOLS_MENU = 'core.django.menus.AdminToolsMenu'

APP_DATABASE_MAPPINGS = {}

DATABASE_ROUTERS = ['core.django.project.app_database_router.AppDatabaseRouter']

# Database
# https://docs.djangoproject.com/en/1.10/ref/settings/#databases

# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.sqlite3',
#         'NAME': os.path.join('.', 'db.sqlite3'),
#     }
# }
DATABASES = {}

INSTALLED_APPS = ['core.django']

app_env = da_config.get_env()
etl_cfg = da_config.get_etl_cfg()
db_cfg = da_config.get_db_cfg()


def get_database(conn_variable, engine, schema=None):
    etl_cfg_db = etl_cfg['database']
    if not etl_cfg_db.has_key(conn_variable):
        return

    db_cfg_variable = etl_cfg_db[conn_variable]
    db_conn = db_cfg[db_cfg_variable]

    if engine == 'Oracle':
        engine = 'django.db.backends.oracle'
    elif engine == 'SqlServer':
        # engine = ''
        return
    elif engine == 'Sybase':
        # engine = ''
        return

    if not db_conn.has_key('user'):
        # Kerberos
        return {
            'ENGINE': engine,
            'NAME': db_conn['server'],
            'SCHEMA': schema,
        }
    else:
        password = db_conn['password']
        try:
            password = base64.b64decode(password)
        except TypeError:
            pass

        return {
            'ENGINE': engine,
            'NAME': db_conn['server'],
            'USER': db_conn['user'],
            'PASSWORD': password,
            'SCHEMA': schema,
        }


def _set_database(app_dir, mod):
    if not hasattr(mod, 'database'):
        return

    db_settings = mod.database
    conn_variable = db_settings['conn_variable']
    engine = db_settings['engine']

    db_setting = get_database(conn_variable, engine)
    if db_setting:
        DATABASES[app_dir + '_db'] = db_setting


for f in os.listdir(apps_dir):
    if not os.path.isdir(os.path.join(apps_dir, f)):
        continue

    APP_DATABASE_MAPPINGS[f] = f + '_db'
    INSTALLED_APPS.append(f)

    try:
        mod = importlib.import_module('apps.%s.settings' % (f,))
    except ImportError:
        raise ImportError(
            'No settings.py file found for ' + f
        )
        continue

    _set_database(f, mod)

apply_patch()
