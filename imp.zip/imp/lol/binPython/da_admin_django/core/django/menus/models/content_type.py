class ContentType(object):

    def __init__(self):
        self.id = 0
        self.app = None
        self.model = None

    def __unicode__(self):
        return self.title