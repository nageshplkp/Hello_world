from django.conf import settings
from django.contrib.auth.models import User 
from django.contrib.auth.models import Group

PIMCO_DOMAIN = 'pimco.imswest.sscims.com'
PIMCO_CLOUD_DOMAIN = 'core.pimcocloud.net'

__LDAP_FIELDS = ['cn', 'co', 'company', 'department', 'displayName', 'employeeID', 'givenName', 'mail',
                         'manager', 'name', 'sAMAccountName', 'sn', 'telephoneNumber', 'ADsPath']

__LDAP_FIELDS_STR = ','.join(__LDAP_FIELDS)


def lx_verify_credentials(username, password):
    try:
        import ldap
        ldap_server = 'LDAP://10.140.144.10:389'
        l = ldap.initialize(ldap_server, trace_level=0)
        l.protocol_version = 3
        l.set_option(ldap.OPT_REFERRALS, 0)

        l.simple_bind_s(username, password)
        l.unbind_s()

        return True
    except:
        import traceback
        print traceback.format_exc()
        return False



class AuthenticationBackend(object):
    """
    Authenticate against the settings ADMIN_LOGIN and ADMIN_PASSWORD.

    Use the login name, and a hash of the password. For example:

    ADMIN_LOGIN = 'admin'
    ADMIN_PASSWORD = 'sha1$4e987$afbcf42e21bd417fb71db8c66b321e9fc33051de'
    """
    # Method to authenticate the current user using LDAP if the user is not an Admin user
    # If the user is Admin,authenticate using the
    def authenticate(self, username=None, password=None):
        if username != "admin" and username != 'Test':
            username = username + '@PIMCO.IMSWEST.SSCIMS.COM'
            chk_credentials = lx_verify_credentials(username,password)
            username = username.replace('@PIMCO.IMSWEST.SSCIMS.COM', '')
            if chk_credentials:
                try:
                    user = User.objects.get(username=username)
                except User.DoesNotExist:
                    # Create a new user. Note that we can set password
                    # to anything, because it won't be checked; the password
                    # from settings.py will.
                    user = User(username=username, password=password)
                    user.is_staff = True
                    # user.is_superuser = True
                    # Adding the First Time user to a default Test Group
                    #default_group = Group.objects.get(name='TEST')
                    #default_group.user_set.add(user)
                    user.save()
                return user
            #return None
        else:
            try:
                user = User.objects.get(username=username)
                if user.check_password(password):
                    return user
            except User.DoesNotExist:
                return None

    def get_user(self, user_id):
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None
