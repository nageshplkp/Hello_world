from __future__ import unicode_literals
from django.db import models as md
from django.forms import widgets


class PasswordWidget(widgets.TextInput):
    input_type = 'password'


class PasswordField(md.CharField):

    def formfield(self, **kwargs):
        defaults = {}
        defaults.update(kwargs)
        form = super(PasswordField, self).formfield(**defaults)
        form.widget = PasswordWidget()
        return form
