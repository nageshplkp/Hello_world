from django.dispatch import receiver
from django.db.backends.signals import connection_created


@receiver(connection_created)
def on_connection_created_set_default_schema(connection, **kwargs):
    schema = connection.settings_dict.get('SCHEMA')
    if schema:
        connection.connection.current_schema = schema
