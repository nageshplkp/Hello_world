import sys
import re
import xlrd
import csv
from datetime import datetime

headers_dict = {
    'Implied Lognormal Volatilities (%)': None,
    'Implied Normal Volatilities (%)': None,
    'At-the-Money Forward Curve': None,
    'Payer / Receiver Price (upfront basis points)': None,
    'Payer Swaption Breakeven Rate': None,
    'Receiver Swaption Breakeven Rate': None
}


def block_already_seen(seen_dict, blocks_to_test):
    """
    Checks whether a particular block has already been visited,
    if not, set it to seen here; if yes, raise an error
    :param seen_dict: dictionary which stores whether a block has been seen or not
    :param blocks_to_test: Block name which needs to be tested
    """
    for header in blocks_to_test:
        if seen_dict[header] == 1:
            raise
        seen_dict[header] = 1


def define_header(block_name, header_row):
    """
    Massages the header: sometimes header may contain 'y' at the end to represent years and sometimes not,
    so removing 'y' for uniformity. Also removing trailing decimal point and 0 and converting to integer
    :param block_name: Name of the block
    :param header_row: Header row (list)
    :return: modified header (list)
    """
    global headers_dict
    for header in header_row:
        header = re.sub('y\s*$', '', str(header), flags=re.IGNORECASE)
        header = re.sub('\.\d+$', '', str(header), flags=re.IGNORECASE)
        headers_dict[block_name][int(header)] = dict()
    return headers_dict[block_name].keys()


def define_data(block_name, header_row, data_row):
    """
    For each element in a row in a block, assign it to its corresponding header
    and store in dictionary
    :param block_name: Block name from the vendor excel sheet
    :param header_row: The list of headers
    :param data_row: List of data points which need to be assigned to the header and stored
    """
    global headers_dict
    for i in range(len(header_row)):
        headers_dict[block_name][header_row[i]][data_row[0]] = data_row[i+1]


def parse_block(block_name, row_list):
    """
    Parses the data block in the vendor excel file.
    Traverses through the row list, identifies header and data and stores it in headers_dict
    :param block_name: Block of data in vendor excel
    :param row_list: List of all rows (rows are a list too) for the given block
    :return: Nothing
    """
    global headers_dict
    found_header_row = False
    header = list()
    print "Parsing block {}".format(block_name)
    if headers_dict[block_name] is None:
        headers_dict[block_name] = dict()
    for row in row_list:
        if not found_header_row and re.match('\s*expiry\s*', row[0], flags=re.IGNORECASE):
            header = define_header(block_name, row[1:])
            found_header_row = True
            continue
        elif found_header_row is True:
            define_data(block_name, header, row)


def parse_worksheet(ws):
    """
    This function parses the xlrd.Sheet object of the xlrd module.
    Traverses row by row, identifies different blocks and processes them
    :param ws: xlrd.Sheet object
    :return: Nothing
    """
    # Defining dictionaries for internal processing
    seen_blocks_dict = {elem: 0 for elem in headers_dict.keys()}
    data_dict = {elem: [] for elem in headers_dict.keys()}
    # Variable to store the position of the right side blocks of the sheet
    second_vertical_index = None
    seen_blocks = list()

    # Iterate over the rows
    for i in range(ws.nrows):
        row = ws.row_values(i)
        # Applying str function in list comprehension since a row can contain non-string
        # and can cause issues with join function
        if re.match('^\s*$', ''.join([str(elem) for elem in row])):
            continue
        
        # We are assuming the contacts section come at the bottom of the file
        # in the first cell
        if re.match('contacts', row[0], flags=re.IGNORECASE):
            break

        block_check_str = filter(lambda x: x in headers_dict.keys(), row)
        if len(block_check_str) == 2:
            seen_blocks = block_check_str
            block_already_seen(seen_blocks_dict, seen_blocks)
            second_vertical_index = row.index(seen_blocks[-1])
        else:
            if second_vertical_index is None:
                continue
            # Assuming there is a single empty cell between the 2 verticals
            data_dict[seen_blocks[0]].append(row[0:second_vertical_index-2])
            data_dict[seen_blocks[1]].append(row[second_vertical_index:ws.ncols])
    for block in data_dict.keys():
        parse_block(block, data_dict[block])


def create_csv(block_name, input_file, output_file):
    """
    Function to create a csv file for the given block name from headers_dict
    """
    price_date = get_date(input_file)
    with open(output_file, 'wb') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(['PRICE_DATE', 'EXPIRATION_YEAR', 'EXPIRATION_MONTH',
                         'TENOR_YEAR', 'TENOR_MONTH', 'NORMAL_VOL'])
        for tenor_year in headers_dict[block_name].keys():
            for expiry in headers_dict[block_name][tenor_year].keys():
                value = headers_dict[block_name][tenor_year][expiry]
                tenor_month = '0'
                m = re.search('(\d+)([ym])', expiry)
                if m:
                    exp_year, exp_month = None, None
                    if m.group(2) == 'y':
                        exp_year = m.group(1)
                        exp_month = '0'
                    if m.group(2) == 'm':
                        exp_year = '0'
                        exp_month = m.group(1)
                    writer.writerow([price_date, exp_year, exp_month, tenor_year, tenor_month, value])


# Function to get date mention in the excel sheet
# Takes argument of object of worksheet
def get_date(filename):
    book = xlrd.open_workbook(filename)
    date_cell = book.name_map['voldate'][0]
    data_date = float(str(date_cell.cell()).split(':')[1])
    real_date_tuple = xlrd.xldate_as_tuple(data_date, book.datemode)
    real_date = datetime(*real_date_tuple).strftime("%Y-%m-%d")
    return real_date


def validate_args(args):
    if len(args) < 3:
        raise
    (input_file, output_file) = args[1:3]
    return input_file, output_file

 
def main(command_line_args):
    """
    Main function
    """
    (input_file, output_file) = validate_args(command_line_args)
    # Initialize workbook and worksheet objects
    wb_obj = xlrd.open_workbook(input_file)
    ws_obj = wb_obj.sheet_by_name('Cda Implieds')
    parse_worksheet(ws_obj)
    create_csv('Implied Normal Volatilities (%)', input_file, output_file)
if __name__ == '__main__':
    main(sys.argv)
