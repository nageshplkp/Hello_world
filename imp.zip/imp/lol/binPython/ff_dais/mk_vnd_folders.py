import sys, os
from etl.core.db import ora_xxx

#USAGE = [
#    'To create the VND related Folders for DAIS IDS Project',
#    ['--vnd_code', {'help': 'Vendor code from vnd_file table'}]
#]

if len(sys.argv) > 1:
    vnd_code=sys.argv[1]
else:
    raise ValueError('Need to pass a valid vendor code as a parameter.')

env = os.environ.get('ETL_ENV')
if env is None:
    env = 'dev'

cfdw_own = ora_xxx('CFDW_OWN', 'ORAFND_DBP')
etl_source = cfdw_own.create_model('ETL_SOURCE')
etl_source_provider = cfdw_own.create_model('ETL_SOURCE_PROVIDER')

local_path = os.path.abspath ("/appl/da_" + env + "/da_data/")
#print ('Local path is ' + local_path)

#print ('Vendor is ' + vnd_code)

etl_source_dataset = cfdw_own.session.query(etl_source)\
    .join (etl_source_provider, etl_source.source_provider_code == etl_source_provider.source_provider_code)\
    .filter(etl_source.source_provider_code == vnd_code)

if etl_source_dataset.count() > 0:
    for etl_source in etl_source_dataset:
        source_folder = local_path + "/" + etl_source.source_code.lower()
        if not os.path.exists(source_folder):
            print ( 'The folder to be created is ' + source_folder)
            os.makedirs(source_folder)
            os.makedirs(source_folder + "/in")
            os.makedirs(source_folder + "/in/logs")
