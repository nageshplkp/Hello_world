"""
    Rds Asset API client
"""
from ff_dais.proxies.asset import RdsAssetClient


# noinspection PyArgumentList
class AssetManager(object):
    """
    Asset manager - orchestrates creation and management of securities
    """

    def __init__(self, context):
        """
        Manager constructor

        param:context (PipelineContext): Instance containing pipeline execution
                        context.
        """
        self.context = context

    def create(self, **instrument):
        """
        :param instrument:
        :return:
        """
        return self.get_proxy_instance().create(**instrument)

    def create_all(self, instruments):
        """
        Submits request to create instruments and returns request id

        param: instruments = Array of objects:
                request_id      (str): Instrument Request ID - Unique Id, this
                                        can be a GUID or some id unique to you
                asof_date       (str): As of Date
                requestor       (str): Security requestor
                req_type        (str): Security req_type, Yellow Key, Equity
                source_sec_id   (str): Security source_sec_id
                sec_id          (str): Security sec_id
                id_type         (str): Security id_type
                sector          (str): Security sector
        """

        return self.get_proxy_instance().create_all(instruments=instruments)

    def update(self, **instrument):
        """
        :type instrument: dict[str, int]
        :rtype dict[bool, list[object]]
        """
        return self.get_proxy_instance().update(**instrument)

    def update_all(self, instruments):
        """

        :param instruments:
        :return:
        """
        return self.get_proxy_instance().update_all(instruments)

    def unindex(self, **instrument):
        """
        Unindexes instrument (index_constituent_sw = 'N')
        @type instrument: dict : dictionary with keys('idx_const_sw',
                                 'request_id')
        param: client_app (str): required, client application making the request
        param: ssm_id     (str): required, Internal security id
        param: request_id (str): Instrument Request ID - this can be a GUID or
                                 some id unique to you. e.g.,
                                 your AppName-someuniqueid for tracking the
                                 status of this instrument update request.
        """
        return self.get_proxy_instance().unindex(**instrument)

    def unindex_all(self, instruments):
        """
        Unindexes instrument (index_constituent_sw = 'N')

        param: instruments = Array of objects:
               client_app (str): required, client application making the request
               ssm_id     (str): required, Internal security id
               request_id (str): Instrument Request ID - this can be a GUID or
                                 some id unique to you. e.g.,
                                 your AppName-someuniqueid for tracking the
                                 status of this instrument update request.
        """
        return self.get_proxy_instance().unindex_all(instruments)

    def reindex(self, **instrument):
        """
        Reindexes instrument (index_constituent_sw = 'Y')
        @type instrument: dict : dictionary with keys('idx_const_sw',
                                 'request_id')

        param: client_app (str): required, client application making the request
        param: ssm_id     (str): required, Internal security id
        param: request_id (str): Instrument Request ID - this can be a GUID or
                                 some id unique to you. e.g., your
                                 AppName-someuniqueid  for tracking the status
                                 of this instrument update request.
        """
        return self.get_proxy_instance().reindex(**instrument)

    def reindex_all(self, instruments):
        """
        Reindexes instrument (index_constituent_sw = 'Y')

        param: instruments = Array of objects:
               client_app (str): required, client application making the request
               ssm_id     (str): required, Internal security id
               request_id (str): Instrument Request ID - this can be a GUID or
                                 some id unique to you. e.g.,
                                 your AppName-someuniqueid for tracking the
                                 status of this instrument update request.
        """
        return self.get_proxy_instance().reindex_all(instruments)

    def get_status(self, request_id):
        """
        Retrieves status of a previously submitted request.

        param: for_items = Array of ids(int), instrument_request_id
        """
        return self.get_proxy_instance().get_status(request_id)

    def get_status_for_all(self, request_ids):
        """
        :param request_ids:
        :return:
        """
        return self.get_proxy_instance().get_status_for_all(request_ids)

    def get_proxy_instance(self):
        """
        Proxy factory method - determines which proxy to use, currently always
        uses RDS implementation
        """
        return RdsAssetClient(self.context.config, self.context.logger)
