from ..config import config
#import cx_Oracle
#import platform
import os
import sys
from timeit import default_timer as timer

class OracleDb:
    DEFAULT_DATABASE_KEY = "ORAPIM_DBP"
    DEFAULT_ORACLE_HOME = r"W:\pm\vendor\oracle\win64\client_11.2.0"
    CONTROL_FILE_PATH = "./config/da_conn.ini"

    def __init__(self, database_key = DEFAULT_DATABASE_KEY):
        # load config and control files
        self.config = config.Config()
        self.control = config.Config(OracleDb.CONTROL_FILE_PATH)
        
        # get connection name based on db key
        connection_name = self.config.get("database", database_key)

        # get database details
        self.database_key = database_key
        self.conn = None
        self.version = ""
        self.server = self.control.get(connection_name, "server")
        self.user_id = self.control.get(connection_name, "user")
        self.password = self.control.get(connection_name, "password")

        # get connection
        self.connect()

    def connect(self):
        """
        Establishes a connection to an Oracle database.
        """
        try:
            if sys.platform == 'win32':
                oracle_home = os.environ.get('PYPIMLIB_ORACLE_HOME', self.DEFAULT_ORACLE_HOME)
                path = os.environ.get('PATH')

                os.environ['ORACLE_HOME'] = oracle_home
                os.environ['PATH'] = '{0};{1}'.format(oracle_home, path)

            import cx_Oracle

            # release any prior connections
            self.disconnect()

            # Connect to db
            print("Connecting to {0}@{1}...".format(self.user_id, self.server))
            begin_time = timer()
            self.conn = cx_Oracle.connect(self.user_id, self.password, self.server)
            end_time = timer()
            elapsed_time = end_time - begin_time

            # Capture version info
            self.version = self.conn.version

            print("-" * 80)
            print("Oracle {0} connected to {1}@{2}".format(self.version, self.user_id, self.server))
            print("{0:.0f} ms to establish connection".format(elapsed_time * 1000))
            print("-" * 80)

        except cx_Oracle.DatabaseError as e:
            (error,) = e
            print("Failed to connect to {0}. DatabaseError: {1}".format(self.server, error.message))
            raise

    def disconnect(self):
        """
        Releases the Oracle connection.
        """
        if self.conn is not None:
            self.conn.close()

    def open_cursor(self, sql):
        """
        Executes the sql query and returns the raw cursor. Consider using get_resultset instead. 

        Args:
            sql (str): statement to be executed 
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute(sql)
            return cursor
        except cx_Oracle.DatabaseError as e:
            (error,) = e
            print("Failed to open cursor. DatabaseError: {0}".format(error.message))
            raise

    def get_resultset(self, sql):
        """
        Executes the sql query and returns resultset as a dict

        Args:
            sql (str): statement to be executed 
        """
        data = []

        try:
            cursor = self.open_cursor(sql)

            columns = [col_metadata[0] for col_metadata in cursor.description]

            for row in cursor:
                row_dict = dict()
                for col in columns:
                    row_dict[col] = row[columns.index(col)]
                data.append(row_dict)

            cursor.close()
            return data
        except cx_Oracle.DatabaseError as e:
            (error,) = e
            print("Failed to get resultset. DatabaseError: {0}".format(error.message))
            raise

    def execute(self, sql, data):
        """
        Submits a single insert/update/delete statement.

        Args:
            sql (str): statement to be executed (containing bind vars, i.e. :parm1, :parm2)
            data (tuple): tuple containing values to be bound to vars in sql statement
        """
        try:
            cursor = self.conn.cursor()

            cursor.prepare(sql)
            cursor.execute(None, data)
            affected_rows = cursor.rowcount

            self.conn.commit()

            return affected_rows
        except cx_Oracle.DatabaseError as e:
            (error,) = e
            print("Failed to execute sql statement. DatabaseError: {0} Sql: {1}".format(error.message, sql))
            self.conn.rollback()
            raise

    def executemany(self, sql, data):
        """
        Submits an insert/update/delete statement multiple times using the list of data items.

        Args:
            sql (str): statement to be executed (containing bind vars, i.e. :parm1, :parm2)
            data (list[tuple]): list of tuples, each of which contain values to be bound 
                to vars in sql statement
        """
        try:
            cursor = self.conn.cursor()

            cursor.prepare(sql)
            cursor.executemany(None, data)
            affected_rows = cursor.rowcount

            self.conn.commit()

            return affected_rows
        except cx_Oracle.DatabaseError as e:
            (error,) = e
            print("Failed to execute sql statement. DatabaseError: {0} Sql: {1}".format(error.message, sql))
            self.conn.rollback()
            raise

