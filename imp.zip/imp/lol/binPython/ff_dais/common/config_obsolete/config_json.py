import json
import os

class ConfigError(ValueError):
    pass

def load():
    config = {}

    # Get env and config file path
    env = os.environ.get("appenv") if os.environ.get("appenv") else "dev" 
    config_file = os.path.abspath("./config." + env + ".json")

    # Make sure config file exists
    if not os.path.exists(config_file):
        raise ConfigError(config_file + " config file not found")

    with open(config_file, "r") as f:
        config = json.load(f)
    
    return config

