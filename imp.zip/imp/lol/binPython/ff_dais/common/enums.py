from enum import Enum


class EnumBase(Enum):
    def __str__(self):
        return str(self.value)
    
    def __repr__(self):
        return str(self.value)

class VndFileInstStatus(EnumBase):
    FAILED = 'FAILED'
    NEW = 'NEW'
    PROCESSING = 'PROC'
    SKIP = 'SKIP'
    SUCCEEDED = 'SUCCEEDED'



class BbgRequestType(EnumBase):
    STAGE = 'STG'
    PRICING = 'PRC'


class RdsApiStatus(EnumBase):
    IN_PROGRESS = 'IN_PROGRESS'
    NOT_SUPPORTED = 'NOT_SUPPORTED'
    PENDING_REVIEW = 'PENDING_REVIEW'
    BAD_IDENTIFIER = 'BAD_IDENTIFIER'
    BAD_REQUEST = 'BAD_REQUEST'
    UNKNOWN_APPLICATION = 'UNKNOWN_APP'
    SUCCESS = 'SUCCESS'
    FAILED = 'FAILED'


class RdsStatus(Enum):
    NEW = 'NEW'
    ON_BBG = 'ON_BBG'
    DONE_BBG = 'DONE_BBG'
    ON_RDS = 'ON_RDS'
    DONE_RDS = 'DONE_RDS'
    DONE = 'DONE'
    FAILED = 'FAILED'
