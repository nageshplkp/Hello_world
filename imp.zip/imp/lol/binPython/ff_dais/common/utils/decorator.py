#!/usr/bin/env python

import time


def timeout(func):

    def _timeout(*args, **kwargs):

        interval = 1
        t = 300

        if 'interval' in kwargs:
            interval = kwargs['interval']

        if 'timeout' in kwargs:
            t = kwargs['timeout']

        start = time.time()

        while True:
            result = func(*args, **kwargs)
            if result:
                return result

            time.sleep(interval)

            if t:
                if time.time() - start > t:
                    return result

    return _timeout
