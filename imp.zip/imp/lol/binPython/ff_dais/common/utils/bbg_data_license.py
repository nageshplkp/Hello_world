"""

bbg_data_license.py - Module for interfacing with bloomberg data license
10/18/2017 Z.G. - Moved the original class from pimco_live module to etl/bbg

"""

import logging
import os
import shutil
import collections
import re
import time
import datetime

from enum import Enum
from etl.core import util

# ------------------------------------------


def wait_with_timeout(func):
    def _timeout(*args, **kwargs):

        wait_interval = 1
        timeout_threshold = 300

        if 'interval' in kwargs:
            wait_interval = kwargs['interval']

        if 'timeout' in kwargs:
            timeout_threshold = kwargs['timeout']

        start = time.time()

        while True:
            if func(*args, **kwargs):
                return True

            time.sleep(wait_interval)

            if timeout_threshold:
                if time.time() - start > timeout_threshold:
                    return False

    return _timeout


def size(path):
    return os.stat(path)[6]


# noinspection PyUnusedLocal
@wait_with_timeout
def exists(path_list, timeout=300, interval=30):
    return any(os.path.exists(path) for path in path_list)


def tail(path, seek=None):
    """
    Implements file tailing as a generator.  Yields line content or None.
    """
    with open(path) as f:
        if seek is None:
            # Seek to the end of the file
            seek = size(path)

        f.seek(seek)

        while True:
            where = f.tell()
            line = f.readline()

            if not line:
                # Reset position if line was empty
                f.seek(where)
                time.sleep(1)
                yield None

            else:
                yield line


def pattern(path, patterns, run=True, seek=None, timeout=300):
    """
    Wait until pattern(s) are detected by tailing a file.  Returns True when
    complete.
    If optional timeout is set and exceed then it returns False.
    """

    if isinstance(patterns, str):
        patterns = [patterns]
    elif isinstance(patterns, tuple):
        patterns = list(patterns)

    if seek is None and os.path.exists(path):
        seek = size(path)
        # make sure to check the last line for patterns first.
        seek = (seek - len(max(patterns, key=len)) - 2)

    def check():
        start = time.time()

        if not exists(path, timeout=timeout):
            return False

        for line in tail(path, seek):
            if line is not None:
                for p in patterns:
                    if re.search(p, line):
                        patterns.remove(p)

            if not len(patterns):
                # Stop looping when all patterns have been matched
                break

            if timeout:
                if time.time() - start > timeout:
                    return False

        return True

    if run:
        return check()

    return check


# -----------------------------------------


def update(orig_dict, new_dict):
    for key, val in new_dict.items():
        if isinstance(val, collections.Mapping):
            tmp = update(orig_dict.get(key, {}), val)
            orig_dict[key] = tmp
        elif isinstance(val, list):
            orig_dict[key] = (orig_dict.get(key, []) + val)
        elif key in new_dict:
            orig_dict[key] = new_dict[key]
    return orig_dict


def is_eof(f):
    current_pos = f.tell()
    file_size = os.fstat(f.fileno()).st_size
    return current_pos >= file_size


def _convert_to_iso_if_dt(param):
    try:
        dt = datetime.datetime.strptime(param, "%m/%d/%Y")
        return dt.strftime('%Y-%m-%d')
    except ValueError:
        return param


class BbgStatus(Enum):
    
    UNKNOWN = -1
    SUCCESS = 0
    TIMEOUT = 1
    FAIL = 2


class Reader(object):

    @staticmethod
    def create(name):

        class BbgRawLineReader(object):

            @staticmethod
            def parse_line(line, fields):
                if fields is None:
                    pass
                row = dict()
                row['RAW_LINE'] = line
                return row

        class BbgSecurityLineReader(object):

            @staticmethod
            def parse_line(line, fields):
                row_values = line.split('|')
                row = BbgRawLineReader.parse_line(line, fields)
                # regular getdata call for securities
                # req sec id|status|count|fields...|extra pipe
                # len(fields) + 4
                if len(row_values) == len(fields) + 4:
                    row['RAW_LINE'] = line
                    row['SECURITY'] = row_values.pop(0)

                    row['RETURN_STATUS'] = int(row_values.pop(0))
                    row['NUM_OF_FIELDS'] = int(row_values.pop(0))
                    # This means there is some error, no need to
                    # return more values
                    if row['RETURN_STATUS'] != 0:
                        return row

                    for field in fields:
                        val = _convert_to_iso_if_dt(row_values.pop(0))
                        row[field] = val
                return row

        class BbgIndexWeightReader(object):

            @staticmethod
            def parse_line(line, fields):
                row_values = line.split('|')
                row = BbgRawLineReader.parse_line(line, fields)
                row['QUERY'] = row_values.pop(0).strip()
                row['SEC_ID'] = row_values.pop(0).strip()
                row['WEIGHT'] = row_values.pop(0).strip()

                return row

        if name == "security":
            return BbgSecurityLineReader()
        if name == "index_weight":
            return BbgIndexWeightReader()

        return BbgRawLineReader()


class BbgDL:
    _opening_stanza = 'START-OF-FILE\n'
    _closing_stanza = 'END-OF-FILE\n'
    _start_of_fields = '\nSTART-OF-FIELDS\n'
    _end_of_fields = 'END-OF-FIELDS\n\n'
    _start_of_data = 'START-OF-DATA\n'
    _end_of_data = 'END-OF-DATA\n\n'

    def __init__(self, staging_dir, req_dir, res_dir, archive_dir='.'):

        self.staging_dir = staging_dir
        self.req_dir = req_dir
        self.res_dir = res_dir
        self.archive_dir = archive_dir
        self.req_file_name = None
        self.resp_file_name = None
        self.error_file_name = None
        self.log_file_name = None
        self.__file_handle = None
        self.log = logging.getLogger(__name__)

    def copy_file(self, src, dst):
        if os.path.isdir(dst):
            dst = os.path.join(dst, os.path.basename(src))
            shutil.copyfile(src, dst)
            self.log.info("Copying {0} to {1}".format(src, dst))
        else:
            self.log.info("Can't copy {0} to destination: {1}".format(src, dst))

    def move_file(self, src, dst):
        if os.path.isdir(dst):
            dst = os.path.join(dst, os.path.basename(src))
            shutil.move(src, dst)
            self.log.info("Moving {0} to {1}".format(src, dst))
        else:
            self.log.info("Can't move {0} to destination: {1}".format(src, dst))

    @staticmethod
    def _normalize_path(d, f):
        if not os.path.isabs(f) and os.path.isdir(d) and os.path.exists(d):
            f = os.path.join(d, f)
        return f

    @staticmethod
    def _write_header_section(handle, headers):

        if type(headers) is list:
            headers = sorted(headers)
            for header_line in headers:
                handle.write("{}\n".format(header_line))

        if type(headers) is dict:
            handle.write(
                "\n".join(
                    '{}={}'.format(key, val) for key, val in headers.items()
                )
            )

    @staticmethod
    def _convert_to_iso_if_dt(param):
        try:
            dt = datetime.datetime.strptime(param, "%m/%d/%Y")
            return dt.strftime('%Y-%m-%d')
        except ValueError:
            return param
        
    def _init_file_names(self, req_name, resp_name=None):
        self.req_file_name = "{}.req".format(req_name)
        self.resp_file_name = "{}.txt".format(resp_name or req_name)
        self.error_file_name = "{}.err".format(req_name)
        self.log_file_name = "{}.log".format(req_name)

    def _write_field_names_section(self, handle, field_names):
        handle.write(self._start_of_fields)
        for field in field_names:
            handle.write("{}\n".format(field))
        handle.write(self._end_of_fields)

    def _write_data_section(self, handle, data):
        handle.write(self._start_of_data)
        for row in data:
            handle.write("{}\n".format(row))
        handle.write(self._end_of_data)

    def _move_to_data_section(self, handle):
        found = False
        sod = self._start_of_data.strip()
        eod = self._end_of_data.strip()
        eof = self._closing_stanza.strip()
        handle.seek(0)
        
        while not found:
            line = handle.readline()
            line = line.strip()
            found = sod in line

            if found:
                break
                
            if eod in line or eof in line:
                found = False
                return found

        return found

    def _parse_file(self, resp_file, reader):

        rows = []
        self.__file_handle = open(resp_file, 'r')
        fields = self._read_fields(self.__file_handle)
        if len(fields) < 1:
            self.log.error(
                "empty field names in response file: {}".format(resp_file)
            )
            return rows
        if self._move_to_data_section(self.__file_handle):
            rows = self._read_data_section(self.__file_handle, fields, reader)
        else:
            self.log.error(
                "unable to read data section from response file: {}".format(
                    resp_file))
        return rows

    def _read_fields(self, handle):

        field_names = []
        read_field_names = False
        # move to the beginning of the file
        handle.seek(0)

        for line in handle.readlines():
            line = line.strip()
            # ignore comment and empty rows
            if line.startswith('#') or not line:
                continue

            if not read_field_names and self._start_of_fields.strip() in line:
                read_field_names = True
                continue

            if read_field_names and self._end_of_fields.strip() in line:
                # noinspection PyUnusedLocal
                read_field_names = False
                break

            if read_field_names:
                field_names.append(line)

        return field_names

    def _read_data_section(self, handle, fields, reader):

        if handle and handle.closed:
            self.log.error("cannot operate on closed file")

        eod = self._end_of_data.strip()
        eof = self._closing_stanza.strip()
        data_reader = Reader.create(reader)

        for line in handle.readlines():
            line = line.strip()

            if eod in line or eof in line:
                handle.close()
                break

            if line.startswith('#') or not line:
                continue

            # row = self._read_data_line(line, fields, reader)
            row = data_reader.parse_line(line, fields)
            yield row

        if handle and not handle.closed:
            handle.close()

    def wait(self, name, timeout=300, interval=30):

        self._init_file_names(name)

        rf = self._normalize_path(self.res_dir, self.resp_file_name)
        ef = self._normalize_path(self.res_dir, self.error_file_name)
        lf = self._normalize_path(self.res_dir, self.log_file_name)
        p = self._closing_stanza.strip('\n')

        if exists([rf, ef], timeout=timeout, interval=interval):

            if os.path.exists(rf):
                self.copy_file(rf, self.archive_dir)

            if os.path.exists(lf):
                self.copy_file(lf, self.archive_dir)

            if os.path.exists(ef):
                self.copy_file(ef, self.archive_dir)

            if os.path.exists(rf) and pattern(rf, p, run=True):
                return util.struct(status=BbgStatus.SUCCESS, resp_file=rf)
            elif os.path.exists(ef):
                return util.struct(status=BbgStatus.FAIL, error_file=ef)
            else:
                return util.struct(status=BbgStatus.TIMEOUT)
        else:
            return util.struct(status=BbgStatus.TIMEOUT)

    def data_request(self, req_name, res_name, headers, field_names,
                     securities):

        self._init_file_names(req_name, res_name)

        headers["REPLYFILENAME"] = self.resp_file_name

        # create file in staging location
        req_file = self._normalize_path(self.staging_dir, self.req_file_name)

        with open(req_file, 'w') as handle:
            handle.write(self._opening_stanza)
            self._write_header_section(handle, headers)
            self._write_field_names_section(handle, field_names)
            self._write_data_section(handle, securities)
            handle.write(self._closing_stanza)

        # archive file if needed
        self.copy_file(req_file, self.archive_dir)
        # copy staged file to request dir if specified
        self.move_file(req_file, self.req_dir)

        return BbgStatus.SUCCESS

    def has_response(self, name):
        arrived = False
        self._init_file_names(name)

        resp_file = self._normalize_path(self.res_dir, self.resp_file_name)

        if self.__file_handle and not self.__file_handle.closed:
            self.__file_handle.close()

        if os.path.exists(resp_file) and os.path.isfile(resp_file):
            arrived = True

        return arrived

    def data_rows(self, name, reader='security'):

        arrived = False
        rows = []
        self._init_file_names(name)

        resp_file = self._normalize_path(self.res_dir, self.resp_file_name)

        if self.__file_handle and not self.__file_handle.closed:
            self.__file_handle.close()

        if os.path.exists(resp_file) and os.path.isfile(resp_file):
            arrived = True
            # archive file if needed
            self.copy_file(resp_file, self.archive_dir)
            rows = self._parse_file(resp_file, reader)

        return arrived, rows

    def err_response(self, name):
        self.error_file_name = "{}.err".format(name)
        error_file = self._normalize_path(self.res_dir, self.error_file_name)
        response = ""
        error = os.path.exists(error_file)
        if error:
            # archive file if needed
            self.copy_file(error_file, self.archive_dir)
            with open(error_file, 'r') as handle:
                for line in handle.readlines():
                    if not line or not line.startswith('#'):
                        return response
                    else:
                        response = ''.join([response, line])
        return error, response
