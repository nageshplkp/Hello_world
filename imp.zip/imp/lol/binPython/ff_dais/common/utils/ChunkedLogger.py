import datetime
import sys
import logging
import json
import struct
import random
import math

WAN_CHUNK, LAN_CHUNK = 1420, 8154


class ChunkedLogger(object):
    def __init__(self, message, logger=None, size=LAN_CHUNK):
        self.message = message
        self.size = size
        self.pieces = struct.pack('B', int(math.ceil(len(message) * 1.0/size)))
        self.id = struct.pack('Q', random.randint(0, 0xFFFFFFFFFFFFFFFF))
        self.logger = logger if logger else logging.getLogger('')

    def message_chunks(self):
        return (self.message[i:i + self.size] for i
                    in range(0, len(self.message), self.size))

    def encode(self, sequence, chunk):
        return b''.join([
            b'\x1e\x0f',
            self.id,
            struct.pack('B', sequence),
            self.pieces,
            chunk
        ])

    def __iter__(self):
        for sequence, chunk in enumerate(self.message_chunks()):
            yield self.encode(sequence, chunk)

    def debug(self, msg):
        """
        Log 'msg % args' with severity 'DEBUG'.

        To pass exception information, use the keyword argument exc_info with
        a true value, e.g.

        logger.debug("Houston, we have a %s", "thorny problem", exc_info=1)
        """
        if len(msg) < self.chunk_size:
            self.logger.debug(msg)
        else:
            for chunk in ChunkedLogger(msg, self.chunk_size):
                self.logger.debug(chunk)

    def info(self, msg):
        """
        Log 'msg % args' with severity 'INFO'.

        To pass exception information, use the keyword argument exc_info with
        a true value, e.g.

        logger.info("Houston, we have a %s", "interesting problem", exc_info=1)
        """
        if len(msg) < self.chunk_size:
            self.logger.info(msg)
        else:
            for chunk in ChunkedLogger(msg, self.chunk_size):
                self.logger.info(chunk)

    def warning(self, msg):
        """
        Log 'msg % args' with severity 'WARNING'.

        To pass exception information, use the keyword argument exc_info with
        a true value, e.g.

        logger.warning("Houston, we have a %s", "bit of a problem", exc_info=1)
        """
        if len(msg) < self.chunk_size:
            self.logger.warning(msg)
        else:
            for chunk in ChunkedLogger(msg, self.chunk_size):
                self.logger.warning(chunk)

    warn = warning

    def error(self, msg):
        """
        Log 'msg % args' with severity 'ERROR'.

        To pass exception information, use the keyword argument exc_info with
        a true value, e.g.

        logger.error("Houston, we have a %s", "major problem", exc_info=1)
        """
        if len(msg) < self.chunk_size:
            self.logger.error(msg)
        else:
            for chunk in ChunkedLogger(msg, self.chunk_size):
                self.logger.error(chunk)

    def exception(self, msg):
        """
        Convenience method for logging an ERROR with exception information.
        """
        if len(msg) < self.chunk_size:
            self.logger.exception(msg)
        else:
            for chunk in ChunkedLogger(msg, self.chunk_size):
                self.logger.exception(chunk)

    def critical(self, msg):
        """
        Log 'msg % args' with severity 'CRITICAL'.

        To pass exception information, use the keyword argument exc_info with
        a true value, e.g.

        logger.critical("Houston, we have a %s", "major disaster", exc_info=1)
        """
        if len(msg) < self.chunk_size:
            self.logger.critical(msg)
        else:
            for chunk in ChunkedLogger(msg, self.chunk_size):
                self.logger.critical(chunk)

    def log(self, level, msg):
        """
        Log 'msg % args' with the integer severity 'level'.

        To pass exception information, use the keyword argument exc_info with
        a true value, e.g.

        logger.log(level, "We have a %s", "mysterious problem", exc_info=1)
        """
        if len(msg) < self.chunk_size:
            self.logger.log(level, msg)
        else:
            for chunk in ChunkedLogger(msg, self.chunk_size):
                self.logger.log(level, chunk)
