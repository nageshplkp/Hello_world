#!/usr/bin/python

#===============================================================================
# SUMMARY
#   
#   Name:        call_bbg.py
#   
#   Summary:     Makes a call to Bloomberg to get security information by
#                calling the bb_from_nt.csh script used by DTS.
#                
#
#   Created By   Kevin Collins
#   Created Date 02/13/2017
#
#-------------------------------------------------------------------------------
# CHANGE HISTORY
#
#  By         Date       Description
#  ---------- ---------- -------------------------------------------------------
#  kcollins   02/13/2017 Initial version
#
#-------------------------------------------------------------------------------
# OPTIONS
#
#  Opt Name            Description
#  --- ------------    ---------------------------------------------------------
#  -t  request_type    Values:
#                        STG    - Staging request (new securities)
#                        TBD    - TBD
#
#-------------------------------------------------------------------------------
# DEPENDENCIES
# 
#  Name                Description
#  ------------------- ---------------------------------------------------------
#  bb_from_nt.csh      Unix script used to call Bloomberg, wait for response
#                      and copy output file to destination directory
#
#-------------------------------------------------------------------------------
# ADDITIONAL INFORMATION
#
#  Use the help option for example usage and additional details
#  ./call_bbg.py --help
#
#===============================================================================

#-------------------------------------------------------------------------------
# Imports
#-------------------------------------------------------------------------------

# module not installed on dev
#Traceback (most recent call last):
#  File "./call_bbg.py", line 52, in <module>
#      import cx_Oracle
#      ImportError: No module named cx_Oracle
#import cx_Oracle

import os
import sys

from optparse import OptionParser

#-------------------------------------------------------------------------------
# Help text
#-------------------------------------------------------------------------------
EPILOG_HELP_TEXT="""
------------------------------------------------------------------------------
NOTE:                                                                                 
TODO
------------------------------------------------------------------------------
Examples:                                                                       
1. TODO
------------------------------------------------------------------------------
"""
T_HELP_TEXT="""Bloomberg request type - used to determine which mnemonics to send
       Valid values:                              
        STG    - Staging request (new securities)
        TBD    - TBD
"""

#-------------------------------------------------------------------------------
#Validation errors
#-------------------------------------------------------------------------------
REQUIRED_PARM_ERROR="""The following parameters are required:
   -tTYPE - request type
"""

#-------------------------------------------------------------------------------
# Variables
#-------------------------------------------------------------------------------
SCRIPT_NAME = os.path.basename(__file__)
USAGE_TEXT = "Usage: {0} [options]".format(SCRIPT_NAME)

# Uncomment to enable debugging
#import pdb
#pdb.set_trace()

#-------------------------------------------------------------------------------
# Main function
#-------------------------------------------------------------------------------
def main():
    # Parse options
    options = parse_options()

    # Initialize
    init(options)

    # Process file
    process_request(options)

    # Return success
    sys.exit(0)

#-------------------------------------------------------------------------------
# Parse, validate and return command line arguments
#-------------------------------------------------------------------------------
def parse_options():
    # Add valid options to parser
    parser = OptionParser(usage=USAGE_TEXT, epilog=EPILOG_HELP_TEXT)
    parser.add_option("-t", "--request_type", 
                      dest="request_type", metavar="TYPE", help=T_HELP_TEXT)

    # Parse command line
    (options, args) =  parser.parse_args()

    # Validate before returning
    validate_options(options)

    return options

#-------------------------------------------------------------------------------
# validate command line arguments
#-------------------------------------------------------------------------------
def validate_options(options):
    # Verify required parameters were provided
    if options.request_type is None:
        print(USAGE_TEXT)
        print(REQUIRED_PARM_ERROR)
        sys.exit(1)

#-------------------------------------------------------------------------------
# Initialize
#-------------------------------------------------------------------------------
def init(options):
    # reserved for future use
    pass

#-------------------------------------------------------------------------------
# Process request to call Bloomberg
#-------------------------------------------------------------------------------
def process_request(options):
    print("request type: " + options.request_type)
#-------------------------------------------------------------------------------
# Execute main
#-------------------------------------------------------------------------------
if __name__ == "__main__":
    main()
