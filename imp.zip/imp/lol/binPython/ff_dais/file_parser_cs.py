import os
import sys
import logging
import copy
import csv

import pandas as pd
from datetime import datetime

from etl.core import util
from etl.core.timed import timed
from etl.core import da_config
from core.log import log_config


class DataFileExtracter(object):
    """
    """

    # region private methods
    def __init__(self, logger=None, options=None):

        self.log = logger or logging.getLogger("{}".format(
            os.path.splitext(os.path.basename(__file__))[0]))

        try:

            self.start_time = datetime.now()
            self.end_time = None

            self.options = copy.deepcopy(
                vars(options) if options is not None else dict())
            self.default_config = da_config.get_etl_cfg()
            self.config = copy.deepcopy(self.default_config)
            self.config.update(self.options)

            level_name = self.config.get('log_level')
            if not level_name:
                level_name = self.config.get('dais').get('log_level', 'INFO')

            level = logging.getLevelName(level_name)
            os.environ['PYPIMCO_LOG_LEVEL_OVERRIDE'] = level_name

            log_config.init_logging(None, True)
            self.log.setLevel(level)

            formatter = logging.Formatter(
                '%(asctime)s %(threadName)s:%(thread)d %(name)s %(levelname)s %(message)s')

            logger = logging.getLogger('')
            for handler in logger.handlers:
                handler.setFormatter(formatter)

            # Try command line argument first --audit-id
            self.etl_audit_id = self.options.get('etl_audit_id')

            # Use environment variable param if command line
            # for audit id is not set
            if not self.etl_audit_id:
                # Capture etl audit id. This id is created by etl wrapper script
                # and saved to the ETL_AUDIT_ID environment variable
                # make sure audit id type is int
                self.etl_audit_id = int(os.environ.get('ETL_AUDIT_ID'))

            self.log.info("ETL_AUDIT_ID: %s", self.etl_audit_id)

            self.input1 = self.options.get('input_one')
            self.one_skip_top_rows = self.options.get('one_skip_top_rows')
            self.one_sep = self.options.get('one_sep')
            self.sheet = self.options.get('one_sheet')
            self.sheet = int(self.sheet) if unicode(
                self.sheet).isnumeric() else str(self.sheet)
            self.one_encoding = self.options.get('one_encoding')

            self.input2 = self.options.get('input_two')
            self.two_skip_top_rows = self.options.get('two_skip_top_rows')
            self.two_sep = self.options.get('two_sep')
            self.two_sheet = self.options.get('two_sheet')
            self.two_sheet = int(self.two_sheet) if unicode(
                self.two_sheet).isnumeric() else str(self.two_sheet)
            self.two_encoding = self.options.get('two_encoding')

            self.col1 = self.options.get('col_one')
            self.col2 = self.options.get('col_two')
            self.col3 = self.options.get('col_three')
            self.date = self.options.get('date')

            self.out_file = self.options.get('out_file')
            self.out_sep = self.options.get('out_sep')
            self.out_encoding = self.options.get('out_encoding')

            self.work_dir = self.options.get('work_dir')

            self.float_format = self.options.get('float_format')
            self.date_format = self.options.get('date_format')

            self.dais_own = None
            self.cfdw_own = None

            self.ctx = util.struct(**self.options)

            self.log.info("Agent started at %s", self.start_time)

        except Exception as e:
            self.log.critical(
                "Unable to initialize TabularFileMerger: %s", e)
            raise

    def __enter__(self):
        # make a database connection and return it
        # self.dais_own = ora_xxx('DAIS_OWN', 'ORAPIM_DBP')
        # # make a database connection and return it
        # self.cfdw_own = ora_xxx('CFDW_OWN', 'ORAFND_DBP')
        #
        # self.ctx = util.struct(dais_own=self.dais_own,
        #                        cfdw_own=self.cfdw_own, **self.ctx)

        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources
        try:
            if self.dais_own is not None:
                self.dais_own.release()

            if self.cfdw_own is not None:
                self.cfdw_own.release()
        finally:
            self.dais_own = None
            self.cfdw_own = None

        # Release resources
        if self.config is not None:
            self.config = None

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("Agent completed at %s", self.end_time)
        self.log = None

    # endregion

    # region public methods
    def validate(self):
        """
        Executes validation logic upon start up of the driver.
        """
        if not self.etl_audit_id:
            raise ValueError(
                'Required audit job id not found in '
                'environment var:ETL_AUDIT_ID or cmd line params.')

        if not self.input1:
            raise ValueError(
                'Required input1 argument not found.'
            )

        if not self.input2:
            raise ValueError(
                'Required input2 argument not found.'
            )

        if self.sheet is None:
            raise ValueError(
                'Required sheet argument not found.'
            )

        if self.work_dir and not os.path.isdir(self.work_dir):
            raise ValueError(
                ('--work-dir=%s invalid directory.' % self.work_dir)
            )

    @staticmethod
    def normalize(path, work_dir):
        normalized_path = path if os.path.isabs(
            path
        ) else os.path.join(work_dir, path)
        return normalized_path

    @staticmethod
    def load_file(path, skip_top=0, sep=",", encoding='utf8', sheet=None):
        _, ext = os.path.splitext(path)
        if ext in ['.xls', '.xlsx']:
            df = pd.read_excel(
                path,
                skiprows=skip_top,
                skip_blank_lines=True,
                warn_bad_lines=True,
                dtype=None if ext in ['.xls', '.xlsx'] else 'str',
                sheetname=sheet if ext in ['.xls', '.xlsx'] else None,
                encoding=encoding,
                index_col=0
            )
        else:
            df = pd.read_csv(
                path,
                skiprows=skip_top,
                sep=sep,
                skip_blank_lines=True,
                warn_bad_lines=True,
                dtype=None if ext in ['.xls', '.xlsx'] else 'str',
                encoding=encoding,
                index_col=0
            )
        return df

    def handle_extract(self, df_one, df_two):
        df_one.index = pd.Series(df_one.index).apply(lambda x: str(x).strip())
        two_count = df_two.index.size

        # the function to get the value from input1
        def value(date, col):
            origin = df_one[date][col]
            if isinstance(origin, pd.Series):
                return '' if pd.isnull(origin.iloc[0]) else origin.iloc[0]
            else:
                return '' if pd.isnull(origin) else origin

        if not self.date:

            def b_search(index):
                low = 0
                height = index.size - 1

                if isinstance(index[height], datetime):
                    return index[height]

                while low < height:
                    mid = (low + height) / 2
                    if isinstance(index[mid], datetime):
                        if not isinstance(index[mid+1], datetime):
                            return index[mid]
                        else:
                            low = mid + 1
                    else:
                        height = mid
                else:
                    self.log.info("--date argument is not assigned and %s has no valid date",
                                  self.input1)
                    return -1

            self.date = b_search(df_one.columns)

        value_one = value(self.date, self.col1)
        value_two = value(self.date, self.col2)

        if self.col3:
            value_three = value(self.date, self.col3)
            values = [value_one, value_two, value_three]
            col_names = [self.col1, self.col2, self.col3]
        else:
            values = [value_one, value_two]
            col_names = [self.col1, self.col2]
        # cols is used to add to the input2 file
        cols = pd.DataFrame(columns=col_names,
                            data=[values]*two_count,
                            index=df_two.index)

        df_new = pd.concat([df_two, cols], axis=1)
        # check the column names of the ouput file in case duplicate column names occur
        new_cols = list(df_new.columns)
        temp = new_cols[:]
        for i, element in enumerate(new_cols):
            if new_cols.count(element) > 1:
                temp[i] = str(temp[i]) + '_' + str(new_cols[:i+1].count(element))
        df_new.columns = temp

        return df_new

    @staticmethod
    def save_output(
            data_frame, out_path, sep=',', encoding='utf8',
            float_format=None, date_format=None):
        data_frame.to_csv(
            out_path,
            sep=sep,
            header=True,
            quoting=csv.QUOTE_ALL,
            index=True,
            encoding=encoding,
            float_format=float_format,
            date_format=date_format
        )

    @timed()
    def run(self):
        """
        """
        try:
            one_path = self.normalize(self.input1, self.work_dir)
            self.log.info("left file: %s", one_path)

            two_path = self.normalize(self.input2, self.work_dir)
            self.log.info("right file: %s", two_path)

            out_path = self.normalize(self.out_file, self.work_dir)
            self.log.info("output file: %s", out_path)
            df_one = self.load_file(
                path=one_path, skip_top=self.one_skip_top_rows,
                sep=self.one_sep, sheet=self.sheet,
                encoding=self.one_encoding)

            df_two = self.load_file(
                path=two_path, skip_top=self.two_skip_top_rows, sep=self.two_sep,
                sheet=self.two_sheet, encoding=self.two_encoding)
            df_out = self.handle_extract(df_one, df_two)

            self.save_output(data_frame=df_out, out_path=out_path,
                             sep=self.out_sep, encoding=self.out_encoding,
                             float_format=self.float_format, date_format=self.date_format)

        except Exception as e:
            self.log.critical(
                "{}: {} completed with error: {}".format(
                    os.path.splitext(os.path.basename(__file__))[0],
                    self.etl_audit_id, e), exc_info=1
            )
            raise

    # endregion


USAGE = [
    'Excel/Csv (Data) file merger',
    [['-l', '--log-level'],
     {'choices': ['DEBUG', 'INFO', 'WARN', 'ERROR', 'CRITICAL']}],
    [['-e', '--etl-audit-id'],
     {'help': 'Etl audit id for etl jobs max-len(10)', 'type': int}],

    [['-input1', '--input-one'],
     {'help': 'first input file name', 'required': True}],

    [['-input2', '--input-two'],
     {'help': 'second input file name', 'required': True}],

    [['--one-skip-top-rows'],
     {'help': 'Number of lines to skip in left file',
      'type': int, 'default': 0}],

    [['-sheet', '--one-sheet'],
     {'help': 'Worksheet name or index(0 based) for first excel file, '
              '--one-sheet="name"|0', 'default': 0}],

    [['--one-encoding'], {'help': 'Encoding for first file.', 'default': 'utf8'}],

    [['--two-skip-top-rows'], {'help': 'Number of lines to skip in the second file',
                                 'type': int, 'default': 0}],

    [['--two-sheet'], {'help': 'Worksheet name or index(0 based) for second'
                                 'excel file, --right-sheet="name"|0', 'default': 0}],

    [['--two-encoding'], {'help': 'Encoding for second file.', 'default': 'utf8'}],

    [['-o', '--out-file'],
     {'help': 'Output file name or path', 'required': True}],

    [['--out-sep'],
     {'help': 'Delimiter for output file (",","\\t","|")', 'default': ','}],

    [['--out-encoding'], {'help': 'Encoding for output file.', 'default': 'utf8'}],

    [['-d', '--work-dir'],
     {'help': 'Working directory for input/output files'}],

    [['--one-sep'], {'help': 'Delimiter for left input file (",","\\t","|")',
                      'default': ','}],

    [['--two-sep'], {'help': 'Delimiter for right input file (",","\\t","|")',
                       'default': ','}],

    [['-col1', '--col-one'], {'help': 'the first column to add to the second file',
                       'required': True }],

    [['-col2', '--col-two'], {'help': 'the second column to add to the second file',
                       'required': True }],

    [['-col3', '--col-three'], {'help': 'the third column to add to the second file',
                       'default': None}],

    [['-date', '--date'], {'help': 'date used to extract data from the first file'}],

    [['-f', '--float-format'],
     {'help': 'float format for output file. "%.6f")', 'default': '%.6f'}],

    [['--date-format'],
     {'help': 'date format for output file. "%m/%d/%Y" works for csv" ',
      'default': None}]
]

# noinspection PyBroadException
def main():
    """
    Delegates all processing to Agent instance.
    """
    logger = logging.getLogger("{}".format(
        os.path.splitext(os.path.basename(__file__))[0]))

    try:
        cmd_line = util.sanitize_cmd_line(copy.copy(sys.argv))
        logging.info(cmd_line)
        args = util.parse_args(*USAGE)
        with DataFileExtracter(logger=logger, options=args) as agent:
            agent.validate()
            agent.run()
    except Exception:
        logger.critical(
            "critical error in {}::".format(
                os.path.splitext(os.path.basename(__file__))[0]), exc_info=1)
        logger.critical("Agent exited with error.")
        return -1
    else:
        logger.info("Agent completed successfully.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
