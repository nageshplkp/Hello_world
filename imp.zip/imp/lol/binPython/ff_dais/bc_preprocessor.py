import pandas as pd
import sys, getopt
from os import path
#===============================================================================
#  merge_files : Generic Script to merge data from 2 input files. First
# input file passed is the base file. Output data to a new file.
# to be used for BC
#-------------------------------------------------------------------------------
def get_file(folder_name,file_name):
    file_name = path.join(folder_name, file_name)
    file_df = read_file(file_name)
    return file_df

def read_file(file_name):
    file_df = pd.read_csv(file_name)
    return file_df

def merge(df1, df2 ,merge_column):
    df1.sort_values(merge_column)
    df2.sort_values(merge_column)

    return pd.merge(df1, df2, on=[merge_column], how='left')

folder_name=sys.argv[1]
input_file1=sys.argv[2]
input_file2=sys.argv[3]
merge_column=sys.argv[4]
output_file=sys.argv[5]

file1 = get_file(folder_name, input_file1)
file2 = get_file(folder_name, input_file2)
out_file = merge(file1, file2, merge_column)
out_file.to_csv(folder_name + output_file, index=False)
