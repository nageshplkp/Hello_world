from sqlalchemy import Column, DateTime, String, Integer, ForeignKey, func
from sqlalchemy.orm import relationship, backref
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class EtlFile(Base):

    __table_args__ = {u'schema': 'cfdw_own'}
    __tablename__ = 'etl_file'

    etl_file_id = Column(Integer, primary_key=True)
    is_enabled = Column(Integer)
    scheduled_pickup_date = Column(DateTime)
    is_ftp_done = Column(Integer)
    is_etl_done = Column(Integer)
    file_source = Column(String, ForeignKey('cfdw_own.etl_source.source_code'))
    etl_source = relationship('EtlSource', primaryjoin='EtlFile.file_source == EtlSource.source_code', remote_side='EtlSource.source_code')
    etl_audit_job_id = Column(Integer)
    file_yyyymmdd = Column(Integer)
    file_frequency = Column(String)
    ftp_server_name = Column(String)
    ftp_user_name = Column(String)
    ftp_password = Column(String)
    ftp_file_folder = Column(String)
    ftp_file_name = Column(String)
    local_file_folder = Column(String)
    local_file_name = Column(String)
    supplier_email_address = Column(String)
    last_is_ftp_done_update_date = Column(DateTime)
    log_file_path = Column(String)
    action_on_error = Column(String)
    dw_insert_by = Column(String)
    dw_insert_date = Column(DateTime)
    dw_update_by = Column(String)
    dw_update_date = Column(DateTime)
    port_no = Column(Integer)
    file_type_code = Column(String)
    post_ftp_cmd = Column(String)
    stg_file_name = Column(String)
    pre_ftp_cmd = Column(String)
    ftp_cmd = Column(String)
    file_cutoff_date = Column(DateTime)
    custom_field_1 = Column(String)
    custom_field_2 = Column(String)
    custom_field_3 = Column(String)
    custom_field_4 = Column(String)
    custom_field_5 = Column(String)
    parent_etl_file_id = Column(Integer)
    ftp_error_notified_date = Column(DateTime)

class EtlSource(Base):

    __table_args__ = {u'schema': 'cfdw_own'}
    __tablename__ = 'etl_source'

    source_code = Column(String, primary_key=True)
    source_descr = Column(String)
    dev_team_code = Column(String)
    is_active = Column(Integer)
    biz_contact_email = Column(String)
    supplier_name = Column(String)
    supplier_phone = Column(String)
    is_paid_feed = Column(Integer)
    data_flow_direction = Column(String)
    local_file_folder = Column(String)
    is_auto_feed = Column(Integer)
    autosys_box_name = Column(String)
    autosys_job_name = Column(String)
    action_on_error = Column(String)
    file_frequency = Column(String)
    file_names = Column(String)
    table_names = Column(String)
    row_insert_by = Column(String)
    row_insert_date = Column(DateTime)
    row_update_by = Column(String)
    row_update_date = Column(DateTime)
    retention_interval = Column(Integer)
    retention_interval_date_part = Column(String)
    output_file_folder = Column(String)
    notify_email_dl = Column(String)
    failure_email_dl = Column(String)
    job_criticality_code = Column(String)
    source_provider_code = Column(String)
    source_group_code = Column(String)
    file_password = Column(String)

