import logging

import requests
import uuid

class BbgProxyBase:
    def __init__(self):
        pass
    
    def get_securities(self, securities, mnemonics):
        pass


class DataLicenseBbgProxy(BbgProxyBase):

    def __init__(self, config, logger=None):

        self.config = config
        self.logger = logger or logging.getLogger(__name__)

    def get_securities(self, securities, mnemonics):
        pass

        # {root_name}: bb_stage_dts

        # create request files
        #   securities file: {root_name}.sec
        #   fields file: {root_name}.field

        # log request

        # execute perl script
        #   op@trfsserver
        #   /home/wsuser/shells/bb_from_nt.csh {root_name}

        # read response
        #   response file: {root_name}.txt

        # log response
        # return data

