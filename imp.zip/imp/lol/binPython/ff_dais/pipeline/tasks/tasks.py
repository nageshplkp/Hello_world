import csv
import os
import logging

from itertools import groupby
from datetime import datetime
from ff_dais.common import enums
from ff_dais.dbmodels import dais_own
from ff_dais.managers.asset import AssetManager
from etl.core import util
from etl.repo.pim_dais import *
from etl.enum.pim_dais import *


class PipelineTaskBase:

    def __init__(self, context):
        """
        PipelineTaskBase constructor.

        args:
            context (PipelineContext): Instance containing pipeline execution
                                        context.
        """
        self.context = context
        self.log = context.log if hasattr(context, 'log') else \
            logging.getLogger(__name__)
        self.log.debug("creating::%s, with: etl_audit_job_id:%s "
                       "thread_name:%s, session_pim: %s, session_fnd:%s, "
                       "oradb_pim:%s, oradb_fnd:%s ",
                       "<{}.{} object at {}>".format(
                           self.__class__.__module__,
                           self.__class__.__name__,
                           hex(id(self))
                       ),
                       self.context.etl_audit_job_id,
                       self.context.thread_name,
                       self.context.session_pim,
                       self.context.session_fnd,
                       self.context.oradb_pim,
                       self.context.oradb_fnd)

    def update_item_status(self, item, status_code=None):
        if status_code is not None:
            item.vnd_file_inst_status_code = status_code
        self.context.oradb_pim.set_audit_cols(item)
        self.context.session_pim.commit()

    def handle_task_exception(self, item, ex):
        self.log.exception('Unable to process task with error: %s', ex)
        status_code = enums.VndFileInstStatus.FAILED.value
        self.update_item_status(item, status_code)

    @staticmethod
    def safe_print(message):
        """
        Prints messages to sysout in a thread safe manner.

        args:
         message (str): message to be printed
        """
        print "{0}\n".format(message)

    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.  This base
        class method will be implemented in the child task classes.

        args:
            item (dais_own.VndFileInst): Pipeline item that should be checked
                for readiness.
        """
        pass

    def process(self, item):
        """
        Process pipeline item. This base class method will be implemented in
            the child task classes.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        pass


class RawPreTask(PipelineTaskBase):
    """
    RawPre task - pass through task.
    """
    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_raw_pre_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        self.safe_print("{} - RawPreTask processing: {}".format(
            self.context.thread_name, item.vnd_file_inst_id))

        # Set instance status and appropriate done flag
        item.is_raw_pre_done = 1
        status_code = enums.VndFileInstStatus.PROCESSING.value
        self.update_item_status(item, status_code)


class RawCoreTask(PipelineTaskBase):
    """
    RawCore task - load vendor raw data.
    """
    RAW_FILE_BATCH_SIZE = 1000

    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_raw_pre_done == 1 and item.is_raw_core_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        self.safe_print("{} - RawCoreTask processing: {}".format(
            self.context.thread_name, item.vnd_file_inst_id))

        try:
            # Clean up records from prior runs
            self.pre_load_clean_up(item)

            # Load VND_DATA_RAW
            self.load_raw_file(item)

            # Set appropriate done flag
            item.is_raw_core_done = 1
            self.update_item_status(item)

        except Exception as ex:
            # Set done flag to error
            item.is_raw_core_done = -1
            self.handle_task_exception(item, ex)
            raise

    def pre_load_clean_up(self, item):
        """
        Clean up data tables from prior executions.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """

        # Find and delete VND_DATA_RAW_ERROR records
        result = self.context.session_pim.query(
            dais_own.VndDataRawError
        ).join(
            dais_own.VndDataRawError.vnd_data_raw
        ).filter(
            dais_own.VndDataRaw.vnd_file_inst_id == item.vnd_file_inst_id
        )

        if result.count() > 0:
            ids = []
            for vnd_data_raw_error in result:
                ids.append(vnd_data_raw_error.vnd_data_raw_error_id)

            # print "ids: {0}".format(ids)
                if len(ids) == 1000:

                    self.context.session_pim.query(
                        dais_own.VndDataRawError
                    ).filter(
                        dais_own.VndDataRawError.vnd_data_raw_error_id.in_(ids)
                    ).delete(synchronize_session='fetch')

                    ids = []

            if len(ids) > 0:
                self.context.session_pim.query(
                    dais_own.VndDataRawError
                ).filter(
                    dais_own.VndDataRawError.vnd_data_raw_error_id.in_(ids)
                ).delete(synchronize_session='fetch')

            self.context.session_pim.commit()

        # Find and delete VND_MEASURE_ERROR records
        result = self.context.session_pim.query(
            dais_own.VndMeasureError
        ).join(
            dais_own.VndMeasureError.vnd_measure
        ).filter(
            dais_own.VndMeasure.vnd_file_inst_id == item.vnd_file_inst_id
        )

        if result.count() > 0:
            ids = []
            for vnd_measure_error in result:
                ids.append(vnd_measure_error.vnd_measure_error_id)

            # print "ids: {0}".format(ids)
                if len(ids) == 1000:

                    self.context.session_pim.query(
                        dais_own.VndMeasureError
                    ).filter(
                        dais_own.VndMeasureError.vnd_measure_error_id.in_(ids)
                    ).delete(synchronize_session='fetch')

                    ids = []

            if len(ids) > 0:
                self.context.session_pim.query(
                    dais_own.VndMeasureError
                ).filter(
                    dais_own.VndMeasureError.vnd_measure_error_id.in_(ids)
                ).delete(synchronize_session='fetch')

            self.context.session_pim.commit()

        # Find and delete PORT_INDEX records
        self.context.session_pim.query(
            dais_own.PortIndex
        ).filter(
            dais_own.PortIndex.vnd_file_inst_id == item.vnd_file_inst_id
        ).delete(synchronize_session='fetch')
        self.context.session_pim.commit()

        # Find and delete VND_MEASURE records
        self.context.session_pim.query(
            dais_own.VndMeasure
        ).filter(
            dais_own.VndMeasure.vnd_file_inst_id == item.vnd_file_inst_id
        ).delete(synchronize_session='fetch')
        self.context.session_pim.commit()

        # Find and delete VND_DATA_FMT_ERROR records
        result = self.context.session_pim.query(
            dais_own.VndDataFmtError
        ).join(
            dais_own.VndDataFmtError.vnd_data_fmt
        ).filter(
            dais_own.VndDataFmt.vnd_file_inst_id == item.vnd_file_inst_id
        )

        if result.count() > 0:
            ids = []
            for vnd_data_fmt_error in result:
                ids.append(vnd_data_fmt_error.vnd_data_fmt_error_id)

            # print "ids: {0}".format(ids)
                if len(ids) == 1000:
                    self.context.session_pim.query(
                        dais_own.VndDataFmtError
                    ).filter(
                        dais_own.VndDataFmtError.vnd_data_fmt_error_id.in_(ids)
                    ).delete(synchronize_session='fetch')
                    ids = []

            if len(ids) > 0:
                self.context.session_pim.query(
                    dais_own.VndDataFmtError
                ).filter(
                    dais_own.VndDataFmtError.vnd_data_fmt_error_id.in_(ids)
                ).delete(synchronize_session='fetch')
            self.context.session_pim.commit()

        # Find and delete VND_DATA_FMT_XX records
        params = {
            "i_vnd_file_inst_id": item.vnd_file_inst_id,
            "i_is_in_debug": 0,
            "i_etl_audit_job_id": self.context.etl_audit_job_id
        }
        
        # self.context.oradb_pim.execute_proc(
        #     "DAIS_OWN.SP_IDS_VND_DATA_FMT_XX_DEL ("
        #     ":i_vnd_file_inst_id, :i_is_in_debug, :i_audit_id)", params)

        self.context.oradb_pim.execute_proc(
            "DAIS_OWN.SP_IDS_VND_DATA_FMT_XX_DEL", params)

        # Cleanup  vnd_data_fmt and vnd_data_fmt_ext
        params = {
            "i_vnd_file_inst_id": item.vnd_file_inst_id,
            "i_is_in_debug": 0,
            "i_etl_audit_job_id": self.context.etl_audit_job_id
        }

        self.context.oradb_pim.execute_proc(
            "DAIS_OWN.SP_IDS_VND_DATA_FMT_DEL", params)

        # Find and delete VND_DATA_RAW records
        self.context.session_pim.query(
            dais_own.VndDataRaw
        ).filter(
            dais_own.VndDataRaw.vnd_file_inst_id == item.vnd_file_inst_id
        ).delete(synchronize_session='fetch')
        self.context.session_pim.commit()

    def load_raw_file(self, item):
        """
        Load VND_DATA_RAW table from vendor flat file

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        data = []
        total_columns = 0
        row_number = 0

        # \\nasclusdev\da_dev\da_data\
        # '/appl/da_dev/da_data/ids/sb/in/'
        vendor_file_name = os.path.join(item.folder_name, item.file_name)

        # print '{0} file: {1}'.format(item.vnd_file_inst_id, vendor_file_name)

        if not os.path.exists(vendor_file_name):
            raise ValueError(
                'Vendor file not found: {}'.format(vendor_file_name))

        with open(vendor_file_name, 'rb') as vendor_file:
            reader = csv.reader(vendor_file)

            for row in reader:
                row_number += 1
                total_columns = max(total_columns, len(row))

                record = self.build_raw_record(
                    item.vnd_file_inst_id, row_number, total_columns, row)
                data.append(record)

                if len(data) % RawCoreTask.RAW_FILE_BATCH_SIZE == 0:
                    self.context.oradb_pim.bulk_insert(dais_own.VndDataRaw, data)
                    data = []
                    total_columns = 0

            if len(data) > 0:
                # self.context.session_pim.bulk_save_objects(data)
                # self.context.session_pim.commit()
                self.context.oradb_pim.bulk_insert(dais_own.VndDataRaw, data)
                del data

    @staticmethod
    def build_raw_record(vnd_file_inst_id, row_number, total_columns, row):
        """
        Builds VND_DATA_RAW records dynamically based on the vendor file columns

        args:
            vnd_file_inst_id (int): Unique identifier for the vendor file
                                    instance
            row_number (int): Row number identifying position within the
                                vendor file
            total_columns (int):
            row (obj): Row of data from vendor file 
        """ 
        total_raw_columns = 250
        record = {
            "vnd_file_inst_id": vnd_file_inst_id,
            "row_number": row_number,
            "skip_row": 0,
            "validation_error": 0
        }

        # Allow for variable length rows in vendor file, while maintaining
        # consistent number of column values for database inserts
        for i in range(total_raw_columns):
            if i < len(row):
                val = row[i]
                record['field{0}'.format(i + 1)] = val[0:2000]
            else:
                record['field{0}'.format(i + 1)] = ''

        return record


class RawPostTask(PipelineTaskBase):
    """
    RawPost task - validate vendor raw data.
    """
    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_raw_core_done == 1 and item.is_raw_post_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        self.safe_print("{} - RawPostTask processing: {}".format(
            self.context.thread_name, item.vnd_file_inst_id))

        try:
            params = {
                "i_vnd_file_inst_id": item.vnd_file_inst_id,
                "i_is_in_debug": 0,
                "i_etl_audit_job_id": self.context.etl_audit_job_id
            }

            # Calculate VND_DATA_RAW.SKIP_ROWS
            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_VND_DATA_RAW_SKIP_ROW ("
            #     ":i_vnd_file_inst_id, :i_is_in_debug, :i_audit_id)", params)

            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_VND_DATA_RAW_SKIP_ROW", params)

            # Calculate VND_FILE_INST.ASOF_DATE
            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_VND_FILE_INST_ASOF_DT ("
            #     ":i_vnd_file_inst_id, :i_is_in_debug, :i_audit_id)", params)

            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_VND_FILE_INST_ASOF_DT", params)

            # Run VND_DATA_RAW validation rules
            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_VND_DATA_RAW_VAL ("
            #     ":i_vnd_file_inst_id, :i_is_in_debug, :i_audit_id)", params)
            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_VND_DATA_RAW_VAL", params)

            # Set appropriate done flag
            item.is_raw_post_done = 1
            self.update_item_status(item)

        except Exception as ex:
            # Set done flag to error
            item.is_raw_post_done = -1
            self.handle_task_exception(item, ex)
            raise


class FmtPreTask(PipelineTaskBase):
    """
    FmtPre task - pass through task.
    """
    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_raw_post_done == 1 and item.is_fmt_pre_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        self.safe_print("{} - FmtPreTask processing: {}".format(
            self.context.thread_name, item.vnd_file_inst_id))

        try:
            # Load VND_DATA_FMT
            check_value = 1
            params = {
                "i_vnd_file_inst_id": item.vnd_file_inst_id,
                "i_is_in_debug": 0,
                "i_etl_audit_job_id": self.context.etl_audit_job_id,
                "o_check": check_value
            }
            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_VND_DATA_FMT_CHECK (:i_vnd_file_inst_id, "
            #     ":i_is_in_debug, :i_audit_id, :o_check)",
            #     params)

            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_VND_DATA_FMT_CHECK", params)

            # Set appropriate done flag
            if check_value == 1:
                item.is_fmt_pre_done = 1
                self.update_item_status(item)

            self.context.session_pim.commit()

        except Exception as ex:
            item.is_fmt_pre_done = -1
            self.handle_task_exception(item, ex)
            raise

        # Pass through task - set appropriate done flag
        item.is_fmt_pre_done = 1
        self.update_item_status(item)


class FmtCoreTask(PipelineTaskBase):
    """
    FmtCore task - load format table data.
    """
    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_fmt_pre_done == 1 and item.is_fmt_core_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        self.safe_print("{} - FmtCoreTask processing: {}".format(
            self.context.thread_name, item.vnd_file_inst_id))

        try:
            # Clean up records from prior runs
            self.pre_load_clean_up(item)

            # Load VND_DATA_FMT
            params = {
                "i_vnd_file_inst_id": item.vnd_file_inst_id,
                "i_is_in_debug": 0,
                "i_etl_audit_job_id": self.context.etl_audit_job_id
            }
            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_VND_DATA_FMT_INS ("
            #     ":i_vnd_file_inst_id, :i_is_in_debug, :i_audit_id)", params)
            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_VND_DATA_FMT_INS", params)

            # Set appropriate done flag
            item.is_fmt_core_done = 1
            self.update_item_status(item)

        except Exception as ex:
            # Set done flag to error
            item.is_fmt_core_done = -1
            self.handle_task_exception(item, ex)
            raise

    def pre_load_clean_up(self, item):
        """
        Clean up data tables from prior executions.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        # Find and delete PORT_INDEX records
        self.context.session_pim.query(
            dais_own.PortIndex
        ).filter(
            dais_own.PortIndex.vnd_file_inst_id == item.vnd_file_inst_id
        ).delete(synchronize_session='fetch')
        self.context.session_pim.commit()

        # Find and delete VND_MEASURE_ERROR records
        result = self.context.session_pim.query(
            dais_own.VndMeasureError
        ).join(
            dais_own.VndMeasureError.vnd_measure
        ).filter(
            dais_own.VndMeasure.vnd_file_inst_id == item.vnd_file_inst_id
        )

        if result.count() > 0:
            ids = []
            for vnd_measure_error in result:
                ids.append(vnd_measure_error.vnd_measure_error_id)

            # print "ids: {0}".format(ids)
                if len(ids) == 1000:

                    self.context.session_pim.query(
                        dais_own.VndMeasureError
                    ).filter(
                        dais_own.VndMeasureError.vnd_measure_error_id.in_(ids)
                    ).delete(synchronize_session='fetch')

                    ids = []

            if len(ids) > 0:
                self.context.session_pim.query(
                    dais_own.VndMeasureError
                ).filter(
                    dais_own.VndMeasureError.vnd_measure_error_id.in_(ids)
                ).delete(synchronize_session='fetch')

            self.context.session_pim.commit()

        # Find and delete VND_MEASURE records
        self.context.session_pim.query(
            dais_own.VndMeasure
        ).filter(
            dais_own.VndMeasure.vnd_file_inst_id == item.vnd_file_inst_id
        ).delete(synchronize_session='fetch')
        self.context.session_pim.commit()

        # Find and delete VND_DATA_FMT_ERROR records
        result = self.context.session_pim.query(
            dais_own.VndDataFmtError
        ).join(
            dais_own.VndDataFmtError.vnd_data_fmt
        ).filter(
            dais_own.VndDataFmt.vnd_file_inst_id == item.vnd_file_inst_id
        )

        if result.count() > 0:
            ids = []
            for vnd_data_fmt_error in result:
                ids.append(vnd_data_fmt_error.vnd_data_fmt_error_id)

            # print "ids: {0}".format(ids)
            self.context.session_pim.query(
                dais_own.VndDataFmtError
            ).filter(
                dais_own.VndDataFmtError.vnd_data_fmt_error_id.in_(ids)
            ).delete(synchronize_session='fetch')
            self.context.session_pim.commit()

        # Find and delete VND_DATA_FMT_EXT records
        result = self.context.session_pim.query(
            dais_own.VndDataFmtExt
        ).join(
            dais_own.VndDataFmtExt.vnd_data_fmt
        ).filter(
            dais_own.VndDataFmt.vnd_file_inst_id == item.vnd_file_inst_id
        )

        if result.count() > 0:
            ids = []
            for vnd_data_fmt_ext in result:
                ids.append(vnd_data_fmt_ext.vnd_data_fmt_id)

                if len(ids) == 1000:
                    self.context.session_pim.query(
                        dais_own.VndDataFmtExt
                    ).filter(
                        dais_own.VndDataFmtExt.vnd_data_fmt_id.in_(ids)
                    ).delete(synchronize_session='fetch')
                    ids = []

            if len(ids) > 0:
                self.context.session_pim.query(
                    dais_own.VndDataFmtExt
                ).filter(
                    dais_own.VndDataFmtExt.vnd_data_fmt_id.in_(ids)
                ).delete(synchronize_session='fetch')
            self.context.session_pim.commit()

        # Find and delete VND_DATA_FMT_XX records
        params = {
            "i_vnd_file_inst_id": item.vnd_file_inst_id,
            "i_is_in_debug": 0,
            "i_etl_audit_job_id": self.context.etl_audit_job_id
        }
        
        # self.context.oradb_pim.execute_proc(
        #     "DAIS_OWN.SP_IDS_VND_DATA_FMT_XX_DEL ("
        #     ":i_vnd_file_inst_id, :i_is_in_debug, :i_audit_id)", params)
        self.context.oradb_pim.execute_proc(
            "DAIS_OWN.SP_IDS_VND_DATA_FMT_XX_DEL", params)

        # Find and delete VND_DATA_FMT records
        self.context.session_pim.query(
            dais_own.VndDataFmt
        ).filter(
            dais_own.VndDataFmt.vnd_file_inst_id == item.vnd_file_inst_id
        ).delete(synchronize_session='fetch')
        self.context.session_pim.commit()


class FmtPostTask(PipelineTaskBase):
    """
    FmtPost task - map and validate formatted vendor data.
    """
    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_fmt_core_done == 1 and item.is_fmt_post_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        self.safe_print("{} - FmtPostTask processing: {}".format(
            self.context.thread_name, item.vnd_file_inst_id))

        try:
            # Apply mapping rules
            params = {
                "i_vnd_file_inst_id": item.vnd_file_inst_id,
                "i_is_in_debug": 0,
                "i_etl_audit_job_id": self.context.etl_audit_job_id
            }

            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_VND_DATA_FMT_MAP ("
            #     ":i_vnd_file_inst_id, :i_is_in_debug, :i_audit_id)", params)
            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_VND_DATA_FMT_MAP", params)

            # Apply custom  rules
            params = {
                "i_vnd_file_inst_id": item.vnd_file_inst_id,
                # "i_rule_type_code": "CFMT",
                "i_is_in_debug": 0,
                "i_etl_audit_job_id": self.context.etl_audit_job_id
            }

            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_VND_DATA_FMT_RULE ("
            #     ":i_vnd_file_inst_id, :i_rule_type, "
            #     ":i_is_in_debug, :i_audit_id)", params)

            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_VND_DATA_FMT_RULE", params)

            # Run VND_DATA_FMT validation rules
            params = {
                "i_vnd_file_inst_id": item.vnd_file_inst_id,
                "i_is_in_debug": 0,
                "i_etl_audit_job_id": self.context.etl_audit_job_id
            }

            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_VND_DATA_FMT_VAL ("
            #     ":i_vnd_file_inst_id, :i_is_in_debug, :i_audit_id)", params)

            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_VND_DATA_FMT_VAL", params)

            # Set appropriate done flag
            item.is_fmt_post_done = 1
            self.update_item_status(item)

        except Exception as ex:
            # Set done flag to error
            item.is_fmt_post_done = -1
            self.handle_task_exception(item, ex)
            raise


class NrmPreTask(PipelineTaskBase):
    """
    NrmPre task - pass through task.
    """
    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_fmt_post_done == 1 and item.is_nrm_pre_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        self.safe_print("{} - NrmPreTask processing: {}".format(
            self.context.thread_name, item.vnd_file_inst_id))

        # Pass through task - set appropriate done flag
        item.is_nrm_pre_done = 1
        self.update_item_status(item)


class NrmCoreTask(PipelineTaskBase):
    """
    NrmCore task - load normalized tables.
    """
    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_nrm_pre_done == 1 and item.is_nrm_core_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        self.safe_print("{} - NrmCoreTask processing: {}".format(
            self.context.thread_name, item.vnd_file_inst_id))

        try:
            # Clean up records from prior runs
            self.pre_load_clean_up(item)

            # Update VND_SEC_SET
            params = {
                "i_vnd_file_inst_id": item.vnd_file_inst_id,
                "i_is_in_debug": 0,
                "i_etl_audit_job_id": self.context.etl_audit_job_id
            }
            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_LOAD_VND_SEC_SET (:i_vnd_file_inst_id, "
            #     ":i_is_in_debug, :i_audit_id)", params)

            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_VND_SEC_SET_UPDATE", params)

            # Load VND_SEC_SET
            params = {
                "i_vnd_file_inst_id": item.vnd_file_inst_id,
                "i_is_in_debug": 0,
                "i_etl_audit_job_id": self.context.etl_audit_job_id
            }
            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_LOAD_VND_SEC_SET (:i_vnd_file_inst_id, "
            #     ":i_is_in_debug, :i_audit_id)", params)

            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_LOAD_VND_SEC_SET", params)

            # Load VND_MEASURE
            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_LOAD_VND_MEASURE (:i_vnd_file_inst_id, "
            #     ":i_is_in_debug, :i_audit_id)", params)
            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_LOAD_VND_MEASURE", params)

            # Set appropriate done flag
            item.is_nrm_core_done = 1
            self.update_item_status(item)

        except Exception as ex:
            # Set done flag to error
            item.is_nrm_core_done = -1
            self.handle_task_exception(item, ex)
            raise

    def pre_load_clean_up(self, item):
        """
        Clean up data tables from prior executions.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """

        # Find and delete PORT_INDEX records
        self.context.session_pim.query(
            dais_own.PortIndex
        ).filter(
            dais_own.PortIndex.vnd_file_inst_id == item.vnd_file_inst_id
        ).delete(synchronize_session='fetch')
        self.context.session_pim.commit()

        # Find and delete VND_MEASURE_ERROR records
        result = self.context.session_pim.query(
            dais_own.VndMeasureError
        ).join(
            dais_own.VndMeasureError.vnd_measure
        ).filter(
            dais_own.VndMeasure.vnd_file_inst_id == item.vnd_file_inst_id
        )

        if result.count() > 0:
            ids = []
            for vnd_measure_error in result:
                ids.append(vnd_measure_error.vnd_measure_error_id)

            # print "ids: {0}".format(ids)
                if len(ids) == 1000:

                    self.context.session_pim.query(
                        dais_own.VndMeasureError
                    ).filter(
                        dais_own.VndMeasureError.vnd_measure_error_id.in_(ids)
                    ).delete(synchronize_session='fetch')

                    ids = []

            if len(ids) > 0:
                self.context.session_pim.query(
                    dais_own.VndMeasureError
                ).filter(
                    dais_own.VndMeasureError.vnd_measure_error_id.in_(ids)
                ).delete(synchronize_session='fetch')

            self.context.session_pim.commit()

        # Find and delete VND_MEASURE records
        self.context.session_pim.query(
            dais_own.VndMeasure
        ).filter(
            dais_own.VndMeasure.vnd_file_inst_id == item.vnd_file_inst_id
        ).delete(synchronize_session='fetch')
        self.context.session_pim.commit()


class NrmPostTask(PipelineTaskBase):
    """
    NrmPost task - pass through task.
    """
    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_nrm_core_done == 1 and item.is_nrm_post_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        self.safe_print("{} - NrmPostTask processing: {}".format(
            self.context.thread_name, item.vnd_file_inst_id))

        # Pass through task - set appropriate done flag
        item.is_nrm_post_done = 1
        self.update_item_status(item)


class EnrPreTask(PipelineTaskBase):
    """
    NrmPre task - pass through task.
    """
    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_nrm_post_done == 1 and item.is_enr_pre_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        self.safe_print("{} - EnrPreTask processing: {}".format(
            self.context.thread_name, item.vnd_file_inst_id))

        # Pass through task - set appropriate done flag
        item.is_enr_pre_done = 1
        self.update_item_status(item)


class EnrCoreTask(PipelineTaskBase):
    """
    EnrCore task - load Enrichment data.
    """
    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_enr_pre_done == 1 and item.is_enr_core_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        self.safe_print("{} - EnrCoreTask processing: {}".format(
            self.context.thread_name, item.vnd_file_inst_id))

        try:
            # There is no clean up for Enrichment phase

            # Identify the new records that need a BBG resolution

            # When all the records from the file are
            # resolved at BBG, call the proc
            params = {
                "i_vnd_file_inst_id": item.vnd_file_inst_id,
                "i_is_in_debug": 0,
                "i_etl_audit_job_id": self.context.etl_audit_job_id
            }
            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_GET_SEC_ID(:i_vnd_file_inst_id, "
            #     ":i_is_in_debug, :i_audit_id)", params)

            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_GET_SEC_ID", params)

            result = self.context.session_pim.query(
                dais_own.VndMeasure
            ).filter(
                dais_own.VndMeasure.vnd_file_inst_id == item.vnd_file_inst_id
            ).filter(
                dais_own.VndMeasure.bb_id.is_(None)
                | dais_own.VndMeasure.ssm_id.is_(None)
            ).count()

            if result == 0:
                # self.context.oradb_pim.execute_proc(
                #     "DAIS_OWN.SP_IDS_BACKFILL_BBG_DATA (:i_vnd_file_inst_id, "
                #     ":i_is_in_debug, :i_audit_id)", params)

                self.context.oradb_pim.execute_proc(
                    "DAIS_OWN.SP_IDS_BACKFILL_BBG_DATA", params)

                # self.context.oradb_pim.execute_proc(
                #     "DAIS_OWN.SP_IDS_BACKFILL_SSM_ID_DATA (:i_vnd_file_inst_id,"
                #     " :i_is_in_debug, :i_audit_id)", params)
                self.context.oradb_pim.execute_proc(
                    "DAIS_OWN.SP_IDS_BACKFILL_SSM_ID_DATA", params)

                self.context.oradb_pim.execute_proc(
                    "DAIS_OWN.SP_IDS_MTGE_SEC_ADJUST", params)

                self.context.oradb_pim.execute_proc(
                    "DAIS_OWN.SP_IDS_BASE_CRNCY_BOND_ADJST", params)

                # Set appropriate done flag
                item.is_enr_core_done = 1

            self.update_item_status(item)

        except Exception as ex:
            # Set done flag to error
            item.is_enr_core_done = -1
            self.handle_task_exception(item, ex)
            raise


class EnrPostTask(PipelineTaskBase):
    """
    EnrPost task - pass through task.
    """
    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_enr_core_done == 1 and item.is_enr_post_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        self.safe_print("{0} - EnrPostTask processing: {1}".format(
            self.context.thread_name, item.vnd_file_inst_id))

        try:
            # Run VND_MEASURE validation rules
            params = {
                "i_vnd_file_inst_id": item.vnd_file_inst_id,
                "i_is_in_debug": 0,
                "i_etl_audit_job_id": self.context.etl_audit_job_id
            }

            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_VND_DATA_FMT_VAL ("
            #     ":i_vnd_file_inst_id, :i_is_in_debug, :i_audit_id)", params)

            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_VND_MEASURE_VAL", params)

            # Pass through task - set appropriate done flag
            item.is_enr_post_done = 1
            self.update_item_status(item)

        except Exception as ex:
            # Set done flag to error
            item.is_enr_post_done = -1
            self.handle_task_exception(item, ex)
            raise


class PubPreTask(PipelineTaskBase):
    """
    PubPre task - pass through task.
    """

    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_enr_post_done == 1 and item.is_pub_pre_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        self.safe_print(
            "{0} - PubPreTask processing: {1}".format(self.context.thread_name,
                                                      item.vnd_file_inst_id))

        # Pass through task - set appropriate done flag
        item.is_pub_pre_done = 1
        self.update_item_status(item)


class PubCoreTask(PipelineTaskBase):
    """
    PubCore task - load port index.
    """

    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_pub_pre_done == 1 and item.is_pub_core_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """
        self.safe_print(
            "{0} - PubCoreTask processing: {1}".format(self.context.thread_name,
                                                       item.vnd_file_inst_id))

        try:
            # Clean up records from prior runs
            self.pre_load_clean_up(item)

            # Load port_index
            params = {
                "i_vnd_file_inst_id": item.vnd_file_inst_id,
                "i_is_in_debug": 0,
                "i_etl_audit_job_id": self.context.etl_audit_job_id
            }
            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_LOAD_PORT_INDEX(:i_vnd_file_inst_id, "
            #     ":i_is_in_debug, :i_audit_id)", params)

            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_LOAD_PORT_INDEX", params)

            # Set appropriate done flag
            item.is_pub_core_done = 1
            self.update_item_status(item)

        except Exception as ex:
            # Set done flag to error
            item.is_pub_core_done = -1
            self.handle_task_exception(item, ex)
            raise

    def pre_load_clean_up(self, item):
        """
        Clean up data tables from prior executions.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """

        # Find and delete PORT_INDEX records
        self.context.session_pim.query(
            dais_own.PortIndex
        ).filter(
            dais_own.PortIndex.vnd_file_inst_id == item.vnd_file_inst_id
        ).delete(synchronize_session='fetch')
        self.context.session_pim.commit()


class PubPostTask(PipelineTaskBase):
    """
    PubPost task - pass through task.
    """

    @staticmethod
    def _get_sec_ident_status(rds_status_code):
        # IN_PROGRESS, PENDING_REVIEW, BAD_IDENTIFIER, BAD_REQUEST,
        # UNKNOWN_APP, SUCCESS, FAILED
        switch = {
            "IN_PROGRESS": lambda: SecIdentityStatusEnum.PEND_RDS.value,
            "PENDING_REVIEW": lambda: SecIdentityStatusEnum.DONE_RDS.value,
            "SUCCESS": lambda: SecIdentityStatusEnum.DONE_RDS.value,
            "BAD_REQUEST": lambda: SecIdentityStatusEnum.FAILED.value,
            "BAD_IDENTIFIER": lambda: SecIdentityStatusEnum.FAILED.value,
            "UNKNOWN_APP": lambda: SecIdentityStatusEnum.FAILED.value,
            "FAILED": lambda: SecIdentityStatusEnum.FAILED.value,
            # [TODO] remove this after RDS is fixed
            "NOT_SUPPORTED": lambda: SecIdentityStatusEnum.PEND_RDS.value,
            "INVALID requestId": lambda: SecIdentityStatusEnum.FAILED.value,
        }

        return switch.get(rds_status_code, SecIdentityStatusEnum.FAILED.value)()

    # region RDS re-index
    def _get_rds_idx_const_sw_requests(self, vnd_file_inst_id, batch_size):
        """
        :param: int(batch_size)
        :return: list
        :rtype: list
        """
        repo = RdsRequestIdxConstSwRepo(self.context.ora_pim_db)
        iteration = 0
        condition = True

        while condition:
            # offset = iteration * batch_size
            offset = 0
            rows = repo.list_new_rds_idx_reindex_requests(
                vnd_file_inst_id=vnd_file_inst_id,
                offset=offset, limit=batch_size)
            self.log.info(
                "found %d new rds_idx_const_sw_request records.", len(rows))
            condition = len(rows) > 0
            if condition:
                yield rows
                iteration += 1
            else:
                break

    def _update_rds_idx_const_sw_request_status(self, request, response):

        try:
            repo = RdsRequestIdxConstSwRepo(self.context.ora_pim_db)
            # update database
            for i, d in enumerate(response or []):
                row = next((r for idx, r in enumerate(
                    request or []
                ) if self.context.req_idx_tpl.format(
                    r.rds_request_idx_const_sw_id
                ) == d['instrument_request_id']))

                if row is not None:
                    row.request_date = datetime.now()
                    row.response_date = datetime.now()
                    row.response_status = d.get('status', '')
                    row.response_status_message = d.get('status_msg', '')
                else:
                    # we received an item that we haven't sent a request for
                    self.log.warning(
                        "Unknown record, this should "
                        "not happen:\r\nat index: {}\r\n"
                        "data: {}".format(i, d)
                    )
            repo.save(request)

        except Exception as e:
            self._try_update_current_status(request, 'FAILED')
            self.log.exception(
                "Unable to update response_status of rds_request_idx_consts "
                "records: %s, with error: %s.",
                len(request or []),
                e
            )
            raise

    def _submit_rds_reindex_request(self, item):

        cfg = self.context.config
        batch_size = int(cfg.get('dais_rds_sec').get('batch_size'))
        vnd_file_inst_id = item.vnd_file_inst_id
        repo = RdsRequestIdxConstSwRepo(self.context.ora_pim_db)
        repo.create_new_rds_reindex_request_records(
            audit_id=self.context.etl_audit_job_id,
            vnd_file_inst_id=item.vnd_file_inst_id,
            requestor=self.context.requestor
        )

        manager = AssetManager(self.context)

        for batch in self._get_rds_idx_const_sw_requests(
                vnd_file_inst_id, batch_size):
            if len(batch) == 0:
                self.log.info("There is no pending idx constituent sw "
                              "items to process")
                continue

            batch = [sorted(
                list(v),
                key=lambda r: getattr(r, 'row_insert_date'),
                reverse=True)[0] for k, v in groupby(
                batch, key=lambda r: getattr(r, 'ssm_id'))]

            req_data = map(
                lambda o: util.struct(
                    ssm_id=o.ssm_id,
                    request_id=self.context.req_idx_tpl.format(
                        o.rds_request_idx_const_sw_id
                    )
                ), batch)

            response = manager.reindex_all(req_data)
            if response.status and isinstance(response.data, list):
                data = response.data
                self._update_rds_idx_const_sw_request_status(batch, data)
            else:
                self.log.error(
                    "Error while making reindex instrument request "
                    "to RDS API, with status: %s", str(response.status))

                self._try_update_response_status(batch, 'FAILED')
                raise SystemError(response.status)
        return
    # endregion

    # region RDS re-index - status

    def _try_update_current_status(self, batch, status):

        try:
            repo = RdsRequestIdxConstSwRepo(self.context.ora_pim_db)
            for rds_idx_req in batch:
                rds_idx_req.current_status = str(status)
                rds_idx_req.current_status_date = datetime.now()
            repo.save(batch)
        except Exception as e:
            self.log.exception(
                "Unable to update status of rds_request_idx_consts records: %s"
                ", with error: %s.",
                len(batch or []),
                e
            )

    def _try_update_response_status(self, batch, status):

        try:
            repo = RdsRequestIdxConstSwRepo(self.context.ora_pim_db)
            for rds_idx_req in batch:
                rds_idx_req.response_status = str(status)
                rds_idx_req.response_date = datetime.now()
                rds_idx_req.response_date = \
                    rds_idx_req.response_date or datetime.now()
            repo.save(batch)
        except Exception as e:
            self.log.exception(
                "Unable to update status of rds_request_idx_consts records: %s"
                ", with error: %s.",
                len(batch or []),
                e
            )

    def _retrieve_and_update_rds_reindex_request_status(self, item):

        cfg = self.context.config
        batch_size = int(cfg.get('dais_rds_sec').get('batch_size'))
        vnd_file_inst_id = item.vnd_file_inst_id
        batches = self._get_rds_idx_reindex_pending_requests(
            vnd_file_inst_id, batch_size
        )

        for batch in batches:
            response = self._get_status_from_rds(batch)
            data = response.data
            if response.status and isinstance(data, list):
                self._update_pending_rds_idx_const_sw_request_status(
                    request=batch, response=data)
            else:
                self.log.error(
                    "Error while retrieving reindex instrument status "
                    "from RDS API, with response: %s", str(data))
                self._try_update_current_status(batch, 'FAILED')
                raise SystemError(data)
        batches.close()

    def _get_rds_idx_reindex_pending_requests(
            self, vnd_file_inst_id, batch_size):

        rds_retry_delta = int(
            self.context.config.get('dais_rds_sec').get('rds_retry_delta'))
        repo = RdsRequestIdxConstSwRepo(self.context.ora_pim_db)
        condition = True
        while condition:
            rows = repo.list_pending_rds_idx_reindex_requests(
                vnd_file_inst_id, 0, batch_size, rds_retry_delta)
            self.log.info(
                "found %d pending rds_idx_const_sw_request records.", len(rows))
            condition = bool(rows)
            if condition:
                yield rows
            else:
                break

    def _get_status_from_rds(self, requests):
        manager = AssetManager(self.context)
        request_data = map(lambda o: self.context.req_idx_tpl.format(
            o.rds_request_idx_const_sw_id), requests)
        response = manager.get_status_for_all(request_data)
        return response

    def _update_pending_rds_idx_const_sw_request_status(
            self, request, response):

        try:
            repo = RdsRequestIdxConstSwRepo(self.context.ora_pim_db)

            # update database
            for i, d in enumerate(response or []):
                row = next((r for idx, r in enumerate(
                    request or []
                ) if self.context.req_idx_tpl.format(
                    r.rds_request_idx_const_sw_id
                ) == d['instrument_request_id']))

                if row is not None:
                    row.current_status_date = datetime.now()
                    row.current_status = d.get('status', '')
                    row.current_status_message = d.get('status_msg', '')
                    row.tries = (row.tries or 0) + 1
                else:
                    # we received an item that we haven't sent a request for
                    self.log.warning(
                        "Unknown record, this should "
                        "not happen:\r\nat index: %i\r\n"
                        "data: %s", i, d)

            repo.save(request)

        except Exception as e:
            self._try_update_current_status(request, 'FAILED')
            raise
    # endregion

    def is_ready(self, item):
        """
        Determines if item is ready to be processed by this task.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        returns:
            True if item is ready to be processed and false otherwise.
        """
        return item.is_pub_core_done == 1 and item.is_pub_post_done == 0

    def process(self, item):
        """
        Process pipeline item.

        args:
            item (dais_own.VndFileInst): Pipeline item to be processed.
        """

        self.log.info("%s - PubPostTask processing: %s",
                      self.context.thread_name, item.vnd_file_inst_id)

        try:
            #self._submit_rds_reindex_request(item)
            #self._retrieve_and_update_rds_reindex_request_status(item)
            # Load port_index
            params = {
                "i_vnd_file_inst_id": item.vnd_file_inst_id,
                "i_is_in_debug": 0,
                "i_etl_audit_job_id": self.context.etl_audit_job_id
            }
            # self.context.oradb_pim.execute_proc(
            #     "DAIS_OWN.SP_IDS_LOAD_PORT_INDEX(:i_vnd_file_inst_id, "
            #     ":i_is_in_debug, :i_audit_id)", params)

            self.context.oradb_pim.execute_proc(
                "DAIS_OWN.SP_IDS_PORT_INDEX_CLEANUP", params)

            # Pass through task - set appropriate done flag
            item.is_pub_post_done = 1
            status_code = enums.VndFileInstStatus.SUCCEEDED.value
            self.update_item_status(item, status_code)

        except Exception as ex:
            item.is_pub_post_done = -1
            self.handle_task_exception(item, ex)
            raise
