
class PipelineStageBase():
    def process(self, vendor_file_instance):
        pass
