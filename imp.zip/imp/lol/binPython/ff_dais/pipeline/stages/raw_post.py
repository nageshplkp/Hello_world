from base import PipelineStageBase

class RawPostStage(PipelineStageBase):
    def process_stage(self, vendor_file_instance):
        pass

