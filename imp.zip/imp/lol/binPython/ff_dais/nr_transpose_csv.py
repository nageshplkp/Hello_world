import os
import sys
import logging
import copy
import csv
from datetime import datetime

from etl.core import util
from etl.core.timed import timed
from etl.core import da_config


def coroutine(func):
    """
    A decorator function that takes care of starting a co-routine
    automatically on call.
    :param func:
    :return: coroutine
    """
    def start(*args, **kwargs):
        cr = func(*args, **kwargs)
        cr.next()
        return cr
    return start


def produce(reader):
    for row in reader:
        for d in row:
            d.decode('unicode_escape').encode('utf-8')
        yield row


@coroutine
def consume(writer):
    try:
        while True:
            row = (yield)
            writer.writerow(row)
            # logging.info(row)
    except GeneratorExit:
        logging.info("Done with writing!")


def sanitize(text, sanitizer):
    return sanitizer.sub("", text).strip()


class NrDataFeedTransposer(object):
    """
    """
    # region private methods
    def __init__(self, logger=None, options=None):

        self.log = logger or logging.getLogger("{}".format(
            os.path.splitext(os.path.basename(__file__))[0]))

        try:

            self.start_time = datetime.now()
            self.end_time = None

            self.options = copy.deepcopy(
                vars(options) if options is not None else dict())
            self.default_config = da_config.get_etl_cfg()
            self.config = copy.deepcopy(self.default_config)
            self.config.update(self.options)

            level_name = self.config.get('log_level')
            if not level_name:
                level_name = self.config.get('dais').get('log_level', 'INFO')

            level = logging.getLevelName(level_name)
            os.environ['PYPIMCO_LOG_LEVEL_OVERRIDE'] = level_name
            from core.log import log_config
            log_config.init_logging(None, True)
            self.log.setLevel(level)

            formatter = logging.Formatter(
                '%(asctime)s %(threadName)s:%(thread)d %(name)s %(levelname)s %(message)s')

            logger = logging.getLogger('')
            for handler in logger.handlers:
                handler.setFormatter(formatter)

            # Try command line argument first --audit-id
            self.etl_audit_id = self.options.get('etl_audit_id')

            # Use environment variable param if command line
            # for audit id is not set
            if not self.etl_audit_id:
                # Capture etl audit id. This id is created by etl wrapper script
                # and saved to the ETL_AUDIT_ID environment variable
                self.etl_audit_id = os.environ.get('ETL_AUDIT_ID')

            # make sure audit id type is int
            # make sure audit id type is int
            self.etl_audit_id = int(self.etl_audit_id) if self.etl_audit_id \
                else self.etl_audit_id
            self.log.info("ETL_AUDIT_ID: %s", self.etl_audit_id)

            self.in_file = self.options.get('in_file')

            self.in_separator = self.options.get('in_separator')

            self.in_encoding = self.options.get('in_encoding')

            self.out_file = self.options.get('out_file')

            self.out_separator = self.options.get('out_separator')

            self.out_encoding = self.options.get('out_encoding')

            self.work_dir = self.options.get('work_dir')

            self.date_col_idx = 0

            self.id_col_inx = 1

            self.dais_own = None

            self.cfdw_own = None

            # self.fields = self.fields()

            self.ctx = util.struct(etl_audit_id=self.etl_audit_id,
                                   in_file=self.in_file, out_file=self.out_file)

            self.log.info("Agent started at %s", self.start_time)

        except Exception as e:
            self.log.critical(
                "Unable to initialize RgsDataFeedParser: %s", e)
            raise

    def __enter__(self):
        # make a database connection and return it
        # self.dais_own = ora_xxx('DAIS_OWN', 'ORAPIM_DBP')
        # # make a database connection and return it
        # self.cfdw_own = ora_xxx('CFDW_OWN', 'ORAFND_DBP')
        #
        # self.ctx = util.struct(dais_own=self.dais_own,
        #                        cfdw_own=self.cfdw_own, **self.ctx)

        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources
        try:
            if self.dais_own is not None:
                self.dais_own.release()

            if self.cfdw_own is not None:
                self.cfdw_own.release()
        finally:
            self.dais_own = None
            self.cfdw_own = None

        # Release resources
        if self.config is not None:
            self.config = None

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("Agent completed at %s", self.end_time)
        self.log = None
    # endregion

    # region public methods
    def validate(self):
        """
        Executes validation logic upon start up of the driver.
        """

        if not self.in_file:
            raise ValueError(
                'Required --in-file cmd line argument was not found.')

        if not self.etl_audit_id:
            raise ValueError(
                'Required audit job id not found in '
                'environment var:ETL_AUDIT_ID or cmd line params.')

        if not self.out_file:
            raise ValueError(
                'Required --out-file cmd line argument was not found.')

        if self.work_dir and not os.path.isdir(self.work_dir):
            raise ValueError(
                ('--work-dir=%s invalid directory.' % self.work_dir)
            )

    @staticmethod
    def normalize(path, work_dir):
        normalized_path = path if os.path.isabs(
            path
        ) else os.path.join(work_dir, path)
        return os.path.normpath(
            os.path.expandvars(os.path.expanduser(normalized_path))
        )

    def extract_metadata(self, producer):
        meta = dict()
        meta['headers'] = ['Date', 'ID']
        # first pass
        for row in producer:
            meta['index'] = row[self.id_col_inx]
            for it in range(self.id_col_inx + 1, len(row), 2):
                if row[it] not in meta['headers']:
                    meta['headers'].append(row[it])
        return meta

    def produce_file(self, out_file, meta, producer):
        current_id = None
        prev_id = None
        with open(out_file, 'wb') as ws:
            writer = csv.DictWriter(
                ws, fieldnames=meta['headers'],
                quoting=csv.QUOTE_ALL, lineterminator="\n")
            self.log.info(
                "count extracted headers :%d", len(meta['headers']))
            writer.writeheader()
            self.log.info(
                "writing headers:\r\n%s", meta['headers'])

            consumer = consume(writer)
            current_row = dict()
            prev_row = None
            for row in producer:
                if not row[self.id_col_inx] in current_row:
                    prev_row = current_row
                    current_row = dict()

                    prev_id = current_id
                    current_id = row[self.id_col_inx]

                    current_row[current_id] = dict()
                    current_row[current_id]['Date'] = row[self.date_col_idx]
                    current_row[current_id]['ID'] = current_id

                    for it in range(self.id_col_inx + 1, len(row), 2):
                        current_row[current_id][row[it]] = row[it + 1]

                elif current_id == row[1]:
                    for it in range(self.id_col_inx + 1, len(row), 2):
                        current_row[current_id][row[it]] = row[it + 1]

                if prev_id and current_id != prev_id:
                    consumer.send(prev_row[prev_id])
                    prev_id = None
                    prev_row = None

            consumer.send(current_row[current_id])
            consumer.close()

    @timed()
    def run(self):
        """
        Delegates processing to NsDataFeedTransposer instance.
        """
        try:
            in_file = self.normalize(self.in_file, self.work_dir)
            self.log.info("input file: %s", in_file)
            out_file = self.normalize(self.out_file, self.work_dir)
            self.log.info("output file: %s", out_file)
            with open(in_file, 'rb') as rs:

                csv_reader = csv.reader(rs, delimiter='|')
                producer = produce(csv_reader)
                meta = self.extract_metadata(producer)

                producer.close()
                rs.seek(0)

                producer = produce(csv_reader)
                self.produce_file(out_file, meta, producer)
                producer.close()

        except Exception as e:
            self.log.critical(
                "{}: {} completed with error: {}".format(
                    os.path.splitext(os.path.basename(__file__))[0],
                    self.etl_audit_id, e), exc_info=1
            )
            raise

    # endregion


USAGE = [
    'Nr CSV file Transposer',
    [['-l', '--log-level', '--log_level'],
        {'help': 'DEBUG, INFO, WARN, ERROR, CRITICAL',
         'choices': ['DEBUG', 'INFO', 'WARN', 'ERROR', 'CRITICAL']}],
    [['-e', '--etl-audit-id', '--etl_audit_id'],
        {'help': 'Etl audit id for etl jobs max-len(10)', 'type': int}],

    [['-if', '--in-file', '--in_file'],
        {'help': 'Etl input file name', 'required': True}],
    [['-is', '--in-separator', '--in_separator'],
        {'help': 'Etl input file name', 'default': '|'}],
    [['-ie', '--in-encoding', '--in_encoding'],
     {'help': 'Encoding for input file', 'default': 'utf8'}],

    [['-of', '--out-file', '--out_file'],
        {'help': 'Etl output file name', 'required': True}],
    [['-os', '--out-separator', '--out_separator'],
        {'help': 'Separator used in the output csv file', 'default': ','}],
    [['-oe', '--out-encoding', '--out_encoding'],
        {'help': 'Encoding for output file', 'default': 'utf8'}],

    [['-d', '--work-dir'],
        {'help': 'Working directory for input/output files', 'default': ''}]
]


# noinspection PyBroadException
def main():
    """
    Delegates all processing to Agent instance.
    """
    logger = logging.getLogger("{}".format(
        os.path.splitext(os.path.basename(__file__))[0]))

    try:
        cmd_line = util.sanitize_cmd_line(copy.copy(sys.argv))
        logging.info(cmd_line)
        args = util.parse_args(*USAGE)
        with NrDataFeedTransposer(logger=logger, options=args) as agent:
            agent.validate()
            agent.run()
    except Exception:
        logger.critical(
            "critical error in {}::".format(
                os.path.splitext(os.path.basename(__file__))[0]), exc_info=1)
        logger.critical("Agent exited with error.")
        return -1
    else:
        logger.info("Agent completed successfully.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
