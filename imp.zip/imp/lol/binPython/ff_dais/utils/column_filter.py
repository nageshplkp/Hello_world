#!/usr/bin/env python

import csv
import json
import os
import requests
import sys
from requests.auth import HTTPBasicAuth

from optparse import OptionParser

# Test files
#

USAGE = "USAGE: python column_filter.py -i {input_file} -o {output_file} -c {control_file}"

def main():

    #Debug 
    #print "audit id: {0}".format(os.environ["ETL_AUDIT_ID"])
    #print "audit id: {0}".format(os.environ.get("ETL_AUDIT_ID", -999))

    # Get and validate command line args
    parser = OptionParser()
    parser.add_option("-i", "--input_file", dest="input_file")
    parser.add_option("-o", "--output_file", dest="output_file")
    parser.add_option("-c", "--control_file", dest="control_file")
    (options, args) = parser.parse_args()

    if options.input_file is None:
        print "Input file is a required parameter."
        print USAGE
        sys.exit(1)

    if options.output_file is None:
        print "Output file is a required parameter."
        print USAGE
        sys.exit(1)

    if options.control_file is None:
        print "Control file is a required parameter."
        print USAGE
        sys.exit(1)

    # Construct full file name
    path = os.path.dirname(os.path.realpath(__file__))

    input_file_name = os.path.join(path, options.input_file)
    output_file_name = os.path.join(path, options.output_file)
    control_file_name = os.path.join(path, options.control_file)

    # Validate file names
    if not os.path.exists(input_file_name):
        print "Input file not found: {0}".format(input_file_name)
        sys.exit(1)

    if not os.path.exists(control_file_name):
        print "Control file not found: {0}".format(control_file_name)
        sys.exit(1)

    # Debug
    #print "Python version: {0}.{1}.{2}".format(sys.version_info[0], sys.version_info[1], sys.version_info[2])
    #print "input_file: {0}".format(options.input_file)
    #print "control_file: {0}".format(options.control_file)

    # Read control file and extract columns
    with open(control_file_name, 'rb') as ctl_file:
        ctl_data = json.load(ctl_file)
        ctl_headers = ctl_data['output_headers']

    # Read csv and extract columns
    with open(input_file_name, 'rb') as in_file:
        in_reader = csv.DictReader(in_file)
        file_headers = in_reader.fieldnames

    ctl_header_idx = []

    # Validate control file headers
    for hdr in ctl_headers:
        if hdr not in file_headers:
            print "Output header {0} not contained in input file: {1}".format(hdr, input_file_name)
            sys.exit(1)

        ctl_header_idx.append(file_headers.index(hdr))

    # Write requested columns to output file
    with open(input_file_name, 'rb') as in_file:
        with open(output_file_name, 'wb') as out_file:
            in_reader = csv.reader(in_file)
            out_writer = csv.writer(out_file)

            for row in in_reader:
                data = [row[idx] for idx in ctl_header_idx]
                out_writer.writerow(data)

if __name__ == '__main__':
    main()
