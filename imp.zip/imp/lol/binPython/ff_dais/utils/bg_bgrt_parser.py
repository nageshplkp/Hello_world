#!/usr/bin/env python

import csv
import os
import sys

from optparse import OptionParser

USAGE = "USAGE: python bg_bgrt_parser.py -i {input_file_name} -o {output_file_name}"

def main():
    # Get and validate arguments
    (options, args) = get_commandline_args()

    # Build and validate file names
    path = os.path.dirname(os.path.realpath(__file__))
    input_file_name = os.path.join(path, options.input_file)
    output_file_name = os.path.join(path, options.output_file)

    if not os.path.exists(input_file_name):
        print "Input file not found: {0}".format(input_file_name)
        sys.exit(1)

    # Read html and parse data
    html = get_html_content(input_file_name)
    data = parse_data(html)

    # Write parsed data to output file
    with open(output_file_name, 'wb') as output_file:
        output_csv = csv.writer(output_file, quoting = csv.QUOTE_ALL)

        for row in data:
            output_csv.writerow(row)

def get_commandline_args():
    parser = OptionParser()
    parser.add_option("-i", "--input-file", dest="input_file")
    parser.add_option("-o", "--output-file", dest="output_file")
    (options, args) = parser.parse_args()

    if options.input_file is None:
        print "Input file is a required parameter."
        print USAGE
        sys.exit(1)

    if options.output_file is None:
        print "Output file is a required parameter."
        print USAGE
        sys.exit(1)

    return (options, args)

def get_html_content(input_file_name):
    # Extract contents of html document
    with open(input_file_name, 'r') as input_file:
        html = input_file.read()
    
    # Find start of data table
    idx1 = html.find('"table1"')
    if idx1 >= 0:
        idx2 = html.rfind('<table', 0, idx1)
        if idx2 >= 0:
            html = html[idx2:]
        else:
            html = html[idx1:]

    # Find end of data table
    idx1 = html.find('</table>')
    if idx1 >= 0:
        html = html[:idx1 + 8]
    
    # Find first data row
    idx1 = html.find('<tr>')
    if idx1 >= 0:
        html = html[idx1:]

    # Find last data row
    idx1 = html.rfind('</tr>')
    if idx1 >= 0:
        html = html[:idx1+5]

    # Replace html entities
    html = html.replace('&quot;', '"')
    html = html.replace('&nbsp;', ' ')
    
    return html

def parse_data(html):
    data = []
    table_header_token = '</th>'
    table_cell_token = '</td>'

    for row_idx, table_row in enumerate(html.split('</tr>')):
        data_row = []
        row_num = row_idx + 1

        if table_row.find(table_header_token) >= 0:
            data_row = parse_row(table_row, row_num, table_header_token)
        elif table_row.find(table_cell_token) >= 0:
            data_row = parse_row(table_row, row_num, table_cell_token)

        if len(data_row) > 0:
            data.append(data_row)

    return data

def parse_row(table_row, row_num, token):
    data_row = []

    for column_idx,column_data in enumerate(table_row.split(token)):
        column_num = column_idx + 1

        pos = column_data.rfind('>')
        if pos >= 0:
            cell_value = column_data[pos+1:].strip()
            if row_num == 1:
                cell_value = clean_header_value(cell_value, column_num)
            else:
                cell_value = clean_cell_value(cell_value, column_num)

            data_row.append(cell_value)

    return data_row

def clean_header_value(cell_value, column_num):
    val = cell_value
    # Remove leading and trailing whitespace
    val = val.strip()

    return val

def clean_cell_value(cell_value, column_num):
    val = cell_value
    # Remove spaces from issued shares column
    if column_num == 4:
        val = val.replace(' ', '')

    # Remove percent sign from free float factor column
    elif column_num == 5:
        val = val.replace('%', '')

    # Change comma to decimal point for restricting coefficient column 
    elif column_num == 6:
        val = val.replace(',', '.')

    # Change comma to decimal point for restricting coefficient column 
    # and remove percent sign from weight column
    elif column_num == 7:
        val = val.replace(',', '.')
        val = val.replace('%', '')

    return val

if __name__ == '__main__':
    main()
