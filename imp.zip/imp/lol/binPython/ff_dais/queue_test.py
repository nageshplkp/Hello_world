#!/usr/bin/env python

import time
from Queue import Queue
from threading import Thread

QUEUE_SIZE = 10
THREAD_POOL_SIZE = 2
PROCESS_DELAY_SECONDS = 3

def initialize_queue():
    queue = Queue()
    return queue

def populate_queue(queue):
    for i in range(QUEUE_SIZE):
        queue.put(i)

def create_thread_pool(queue):
    thread_pool = []

    for i in range(THREAD_POOL_SIZE):
        # Create worker thread 
        thread_name = "Thread{0}".format(i)
        thread = Thread(target=process_item, args=(thread_name, queue))
        thread.setDaemon(True)
        thread.start()

        # Add thread to pool
        thread_pool.append(thread)

    return thread_pool

def process_item(thread_name, queue):
    while True:
        print "{0} checking queue...".format(thread_name)
        item = queue.get()
        print "{0} processing item {1}".format(thread_name, item)
        time.sleep(PROCESS_DELAY_SECONDS)
        
        # indicate that dequeued item has been processed
        queue.task_done()

def main():
    # Initialize queue
    queue = initialize_queue()
    print "queue initialized"

    # Create thread pool
    thread_pool = create_thread_pool(queue)
    print "thread pool created"

    # Populate queue items
    populate_queue(queue)
    print "queue populated"

    # Wait for items in queue to be processed
    print "waiting for items to be processed"
    queue.join()

    print "Done"

if __name__ == "__main__":
    main()
