import os
import sys
import logging
import copy
import csv
import re
from datetime import datetime
from dateutil.relativedelta import relativedelta

from etl.core import util
from etl.core.timed import timed
from etl.core import da_config


def coroutine(func):
    """
    A decorator function that takes care of starting a co-routine
    automatically on call.
    :param func:
    :return: coroutine
    """
    def start(*args, **kwargs):
        cr = func(*args, **kwargs)
        cr.next()
        return cr
    return start


def produce(reader):
    for row in reader:
        yield row


FIELDS = [
    'Index Name', 'As of Date', 'Cusip', 'ISIN number', 'Description', 'Ticker',
    'Par Wtd Coupon', 'Maturity Date', 'Yrs To Worst', 'Rating', 'ISO Currency',
    'ISO Country', 'ML Industry Lvl 1', 'ML Industry Lvl 2', 'ML Industry Lvl 3',
    'ML Industry Lvl 4', 'Mkt % Index Wght', 'PrevMend Mkt % Index Wght',
    'Par % Index Wght', 'Cash', 'Maturity / WAL', 'Eff Dur', 'PrevMend Eff Dur',
    'Mod Dur To Worst', 'PrevMend Mod Dur To Worst', 'Modified Dur', 'Macaulay Dur',
    'Strip Spread Dur', 'Convexity', 'Convexity To Worst', 'Eff Convexity', 'Factor',
    'Face Value LOC', 'Full Market Value LOC', 'OAS', 'PrevMend OAS',
    'OAS 1-Day Change', 'OAS 1-Week Change', 'OAS 1-Mo Change',
    'OAS 3-Mo Change', 'OAS 12-Mo Change', 'OAS MTD Change', 'OAS QTD Change',
    'OAS YTD Change', 'Effective Yield', 'PrevMend Eff Yield',
    'Semi Yld To Worst', 'Yld to Worst', 'PrevMend Yld To Worst', 'Strip Yld',
    'Yld to Maturity', 'Bond Equiv YTM', 'Price', 'PrevMend Price',
    'Stripped Price', 'Accrued Interest', 'PrevMend Accrued Interest',
    'Blended Spread', 'Excess Rtn % MTD', 'PRR Index Val LOC', 'PRR % MTD LOC',
    'TRR Index Val LOC', 'TRR % MTD LOC', 'Type', 'SWAP_WEIGHT', 'MATURITY'
]


@coroutine
def consume(writer):
    try:
        while True:
            row = (yield)
            writer.writerow(row)
            logging.info(row)
    except GeneratorExit:
        logging.info("Done with writing!")


def sanitize(text, sanitizer):
    return sanitizer.sub("", text).strip()


class FieldCalculator(object):

    @staticmethod
    def index_name(row):
        return 'Q876'

    @staticmethod
    def as_of_date(row):
        r_date = row.get('date', '')
        if '.' in r_date:
            r_date = r_date.split('.')[0]
        return datetime.strptime(r_date, '%Y%m%d').strftime('%m/%d/%Y') if r_date else ''

    @staticmethod
    def cusip(row):
        maturity = row.get('maturity', '')
        if maturity.find('year') >= 0:
            return 'BGUSSWP' + maturity[0: maturity.find(' ')].zfill(2)
        elif maturity.find('6 month') >= 0:
            return 'BGUSSWPP5'
        elif maturity.find('Cash') >= 0:
            return 'CASH US'
        else:
            return ''

    @staticmethod
    def description(row):
        maturity = row.get('maturity', '')
        if maturity.find('year') >= 0:
            return 'US SWAP PAR  ' + maturity[0: maturity.find(' ')].zfill(2)
        elif maturity.find('6 month') >= 0:
            return 'US SWAP PAR  6M'
        elif maturity.find('Cash') >= 0:
            return 'CASH Uninvested USD'
        else:
            return ''

    @staticmethod
    def ticker(row):
        maturity = row.get('maturity', '')
        return 'CASH' if (maturity or '').strip().lower() == 'cash' else ''

    @staticmethod
    def maturity_date(row):
        maturity = row.get('maturity', '')
        if maturity.find('year') >= 0:
            num_str = maturity[0: maturity.find(' ')]
            if num_str.isalnum():
                years = int(num_str)
                return (
                    datetime.strptime(row['date'], '%Y%m%d') + relativedelta(years=years)
                ).strftime('%m/%d/%Y')
            else:
                return ''
        elif maturity.find('month') >= 0:
            num_str = maturity[0: maturity.find(' ')]
            if num_str.isalnum():
                months = int(num_str)
                return (
                    datetime.strptime(row['date'], '%Y%m%d') + relativedelta(months=months)
                ).strftime('%m/%d/%Y')
            else:
                return ''
        else:
            return ''

    @staticmethod
    def rating(row):
        maturity = row.get('maturity', '')
        return 'NR' if maturity.find('Cash') >= 0 else 'AA3'

    @staticmethod
    def iso_currency(row):
        return 'USD'

    @staticmethod
    def iso_country(row):
        return 'US'

    @staticmethod
    def ml_industry_lvl_4(row):
        return 'Interest Rate Swap'

    @staticmethod
    def maturity_wal(row):
        maturity = row.get('maturity', '')
        if maturity.find('6 month') >= 0:
            return 0.5
        elif maturity.find('year') >= 0:
            num_str = maturity[0: maturity.find(' ')]
            return int(num_str) if num_str.isalnum() else ''
        else:
            return ''

    @staticmethod
    def price(row):
        return 100

    @staticmethod
    def accrued_interest(row):
        return 0

    @staticmethod
    def swap_weight(row):
        return row.get('swap_wght', '')

    @staticmethod
    def maturity(row):
        return row.get('maturity', '')

    @staticmethod
    def default_value(row):
        return ''

    @staticmethod
    def f_name(field):
        return re.sub(r'[^a-zA-Z\d]+', '_', field).lower()

    @classmethod
    def value(cls, field):
        return getattr(cls, cls.f_name(field), cls.default_value)


class MlDataFeedGenerator(object):
    """
    """

    # region private methods
    def __init__(self, logger=None, options=None):

        self.log = logger or logging.getLogger("{}".format(
            os.path.splitext(os.path.basename(__file__))[0]))

        try:

            self.start_time = datetime.now()
            self.end_time = None

            self.options = copy.deepcopy(
                vars(options) if options is not None else dict())
            self.default_config = da_config.get_etl_cfg()
            self.config = copy.deepcopy(self.default_config)
            self.config.update(self.options)

            level_name = self.config.get('log_level')
            if not level_name:
                level_name = self.config.get('dais').get('log_level', 'INFO')

            level = logging.getLevelName(level_name)
            os.environ['PYPIMCO_LOG_LEVEL_OVERRIDE'] = level_name
            from core.log import log_config
            log_config.init_logging(None, True)
            self.log.setLevel(level)

            formatter = logging.Formatter(
                '%(asctime)s %(threadName)s:%(thread)d %(name)s %(levelname)s %(message)s')

            logger = logging.getLogger('')
            for handler in logger.handlers:
                handler.setFormatter(formatter)

            # Try command line argument first --audit-id
            self.etl_audit_id = self.options.get('etl_audit_id')

            # Use environment variable param if command line
            # for audit id is not set
            if not self.etl_audit_id:
                # Capture etl audit id. This id is created by etl wrapper script
                # and saved to the ETL_AUDIT_ID environment variable
                self.etl_audit_id = os.environ.get('ETL_AUDIT_ID')

            # make sure audit id type is int
            # make sure audit id type is int
            self.etl_audit_id = int(self.etl_audit_id) if self.etl_audit_id \
                else self.etl_audit_id
            self.log.info("ETL_AUDIT_ID: %s", self.etl_audit_id)

            self.in_file = self.options.get('in_file')
            self.out_file = self.options.get('out_file')

            self.ctx = util.struct(etl_audit_id=self.etl_audit_id,
                                   in_file=self.in_file)

            self.log.info("Agent started at %s", self.start_time)

        except Exception as e:
            self.log.critical(
                "Unable to initialize BbgRequestFlow: %s", e)
            raise

    def __enter__(self):
        # make a database connection and return it
        # self.dais_own = ora_xxx('DAIS_OWN', 'ORAPIM_DBP')
        # # make a database connection and return it
        # self.cfdw_own = ora_xxx('CFDW_OWN', 'ORAFND_DBP')
        #
        # self.ctx = util.struct(dais_own=self.dais_own,
        #                        cfdw_own=self.cfdw_own, **self.ctx)

        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources

        if self.config is not None:
            self.config = None

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("Agent completed at %s", self.end_time)
        self.log = None
    # endregion

    # region public methods
    def validate(self):
        """
        Executes validation logic upon start up of the driver.
        """
        if not self.etl_audit_id:
            raise ValueError(
                'Required audit job id not found in '
                'environment var:ETL_AUDIT_ID or cmd line params.')

        if not self.in_file:
            raise ValueError(
                'Required --in-file cmd line argument was not found.')

        if not self.out_file:
            raise ValueError(
                '--out-file should be specified or derived from ')

    @timed()
    def run(self):
        """
        Delegates processing to BbgIndexFlow instance.
        """
        try:

            if self.out_file:
                d, f = os.path.split(os.path.abspath(self.out_file))
                if not os.path.exists(d):
                    os.makedirs(d)

            with open(self.in_file, 'rb') as in_file:
                csv_reader = csv.DictReader(in_file, fieldnames=['maturity', 'date', 'swap_wght'])
                producer = produce(csv_reader)
                with open(self.out_file, 'wb') as out_file:
                    csv_writer = csv.DictWriter(
                        out_file, fieldnames=FIELDS,
                        quoting=csv.QUOTE_ALL, lineterminator="\n")
                    csv_writer.writeheader()
                    consumer = consume(csv_writer)
                    producer.next()
                    for row in producer:
                        out_row = {field: FieldCalculator.value(field)(row) for field in FIELDS}
                        consumer.send(out_row)
                        self.log.info("processing row: %s", out_row)
                    consumer.close()
                producer.close()
        except Exception as e:
            self.log.critical(
                "{}: {} completed with error: {}".format(
                    os.path.splitext(os.path.basename(__file__))[0],
                    self.etl_audit_id, e), exc_info=1
            )
            raise

    # endregion


USAGE = [
    'ML CSV file generator',
    [['-l', '--log-level', '--log_level'],
        {'help': 'DEBUG, INFO, WARN, ERROR, CRITICAL',
         'choices': ['DEBUG', 'INFO', 'WARN', 'ERROR', 'CRITICAL']}],
    [['-e', '--etl-audit-id', '--etl_audit_id'],
        {'help': 'Etl audit id for etl jobs max-len(10)', 'type': int}],
    [['-if', '--in-file', '--in_file'],
        {'help': 'Etl input file name', 'required': True}],
    [['-of', '--out-file', '--out_file'],
        {'help': 'Etl output file name', 'required': True}]
]


# noinspection PyBroadException
def main():
    """
    Delegates all processing to Agent instance.
    """
    logger = logging.getLogger("{}".format(
        os.path.splitext(os.path.basename(__file__))[0]))

    try:
        cmd_line = util.sanitize_cmd_line(copy.copy(sys.argv))
        logging.info(cmd_line)

        args = util.parse_args(*USAGE)
        with MlDataFeedGenerator(logger=logger, options=args) as agent:
            agent.validate()
            agent.run()
    except Exception:
        logger.critical(
            "critical error in {}::".format(
                os.path.splitext(os.path.basename(__file__))[0]), exc_info=1)
        logger.critical("Agent exited with error.")
        return -1
    else:
        logger.info("Agent completed successfully.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
