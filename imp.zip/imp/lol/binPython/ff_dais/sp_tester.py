#!/usr/bin/env python

import sys
from etl.core.db import ora_xxx

USAGE = "USAGE: ./sp_tester.py {procedure_name} [{arg1} {arg2} {arg3}]"

def main():
    oradb_pim = None

    try:
        procedure_call, params = get_procedure_details()

        oradb_pim = ora_xxx('DAIS_OWN', 'ORAPIM_DBP') # OracleDb("ORAPIM_DBP")
        print "Connected to {0}".format(oradb_pim.database_name)

        print "procedure_call: {0}".format(procedure_call)
        print "params: {0}".format(params)

        #params = {
        #    "i_vnd_file_inst_id": item.vnd_file_inst_id,
        #    "i_is_in_debug": 1,
        #    "i_audit_id": self.context.etl_audit_job_id
        #}
        
        #self.context.oradb_pim.execute_proc("DAIS_OWN.SP_IDS_VND_DATA_FMT_XX_DEL (:i_vnd_file_inst_id, :i_is_in_debug, :    i_audit_id)", params)
        oradb_pim.execute_proc(procedure_call, params)
        oradb_pim.try_execute_proc(procedure_call, params)
        print "Procedure completed successfully."

    except Exception as e:
        print "Error running stored procedure: {0}".format(e)
        sys.exit(1)
    finally:
        if oradb_pim is not None:
            oradb_pim.release()
            oradb_pim = None

def get_procedure_details():
    procedure_call = None
    params = {}

    if len(sys.argv) <= 1:
        print USAGE
        raise Exception("Procedure name required.")

    procedure_call = sys.argv[1]

    for i in range(2, len(sys.argv)):
        params["b{0}".format(i-1)] = sys.argv[i]

    param_names = [":{0}".format(key) for key in params.iterkeys()]

    if len(param_names) > 0:
        procedure_call = "{0}({1})".format(procedure_call, ",".join(param_names))

    return procedure_call, params

if __name__ == '__main__':
    main()
