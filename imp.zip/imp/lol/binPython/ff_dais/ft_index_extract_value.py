import os
import sys
import logging
import copy
import csv
import re
from datetime import datetime

from etl.core import util
from etl.core.timed import timed
from etl.core import da_config
from core.log import log_config


def coroutine(func):
    """
    A decorator function that takes care of starting a co-routine
    automatically on call.
    :param func:
    :return: co-routine
    """
    def start(*args, **kwargs):
        cr = func(*args, **kwargs)
        cr.next()
        return cr
    return start


def produce(reader):
    for row in reader:
        yield row


@coroutine
def consume(writer):
    try:
        while True:
            line = (yield)
            writer.writerow(line)
            logging.info(line)
    except GeneratorExit:
        logging.info("Done with writing!")


def sanitize(text, sanitizer):
    return sanitizer.sub("", text).strip()


class FtDataExtractor(object):
    """
    """

    # region private methods
    def __init__(self, logger=None, options=None):

        self.log = logger or logging.getLogger("{}".format(
            os.path.splitext(os.path.basename(__file__))[0]))

        try:

            self.start_time = datetime.now()
            self.end_time = None

            self.options = copy.deepcopy(
                vars(options) if options is not None else dict())
            self.default_config = da_config.get_etl_cfg()
            self.config = copy.deepcopy(self.default_config)
            self.config.update(self.options)

            level_name = self.config.get('log_level')
            if not level_name:
                level_name = self.config.get('dais').get('log_level', 'INFO')

            level = logging.getLevelName(level_name)
            os.environ['PYPIMCO_LOG_LEVEL_OVERRIDE'] = level_name

            log_config.init_logging(None, True)
            self.log.setLevel(level)

            formatter = logging.Formatter(
                '%(asctime)s %(threadName)s:%(thread)d %(name)s %(levelname)s %(message)s')

            logger = logging.getLogger('')
            for handler in logger.handlers:
                handler.setFormatter(formatter)

            # Try command line argument first --audit-id
            self.etl_audit_id = self.options.get('etl_audit_id')

            # Use environment variable param if command line
            # for audit id is not set
            if not self.etl_audit_id:
                # Capture etl audit id. This id is created by etl wrapper script
                # and saved to the ETL_AUDIT_ID environment variable
                self.etl_audit_id = os.environ.get('ETL_AUDIT_ID')

            # make sure audit id type is int
            # make sure audit id type is int
            self.etl_audit_id = int(self.etl_audit_id) if self.etl_audit_id \
                else self.etl_audit_id
            self.log.info("ETL_AUDIT_ID: %s", self.etl_audit_id)

            self.value_to_filter = self.options.get('value_to_filter')

            self.in_file = self.options.get('in_file')

            self.out_file = self.options.get('out_file')

            self.dais_own = None

            self.cfdw_own = None

            self.ctx = util.struct(etl_audit_id=self.etl_audit_id,
                                   in_file=self.in_file, out_file=self.out_file)

            self.log.info("Agent started at %s", self.start_time)

        except Exception as e:
            self.log.critical(
                "Unable to initialize RgsDataFeedParser: %s", e)
            raise

    def __enter__(self):
        # make a database  connection and return it
        # self.dais_own = ora_xxx('DAIS_OWN', 'ORAPIM_DBP')
        # # make a database connection and return it
        # self.cfdw_own = ora_xxx('CFDW_OWN', 'ORAFND_DBP')
        #
        # self.ctx = util.struct(dais_own=self.dais_own,
        #                        cfdw_own=self.cfdw_own, **self.ctx)

        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources
        try:
            if self.dais_own is not None:
                self.dais_own.release()

            if self.cfdw_own is not None:
                self.cfdw_own.release()
        finally:
            self.dais_own = None
            self.cfdw_own = None

        # Release resources
        if self.config is not None:
            self.config = None

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("Agent completed at %s", self.end_time)
        self.log = None
    # endregion

    # region public methods
    def validate(self):
        """
        Executes validation logic upon start up of the driver.
        """
        if not self.value_to_filter:
            raise ValueError(
                'Required --value-to-filter cmd line argument was not found')

        if not self.in_file:
            raise ValueError(
                'Required --in-file cmd line argument was not found.')

        if not self.etl_audit_id:
            raise ValueError(
                'Required audit job id not found in '
                'environment var:ETL_AUDIT_ID or cmd line params.')

        if not self.out_file:
            raise ValueError(
                'Required --out-file cmd line argument was not found.')

    @timed()
    def run(self):
        """
        Delegates processing to BbgIndexFlow instance.
        """
        try:
            if self.out_file:
                d, f = os.path.split(os.path.abspath(self.out_file))
                if not os.path.exists(d):
                    os.makedirs(d)

            with open(self.in_file, 'r') as reader:

                date_line = reader.readline()
                # date = re.findall(r'(\d+/\d+/\d+)', date_line)[0]
                matches = re.findall(
                    r'((?:\d{1,2})(?:-|/)(?:\d{1,2})(?:-|/)(?:\d{4}|\d{2}))\s',
                    date_line)

                if not matches:
                    raise ValueError(
                        "Unable to extract date value, from input file.")

                date = matches[0]

                reader.readline()
                reader.readline()

                header_line = reader.readline()
                headers = [field.strip() for field in header_line.split(',')]

                csv_reader = csv.DictReader(reader, fieldnames=headers)
                headers.append('Date')
                producer = produce(csv_reader)

                with open(self.out_file, 'w') as writer:
                    csv_writer = csv.DictWriter(
                        writer, fieldnames=headers,
                        quoting=csv.QUOTE_ALL, lineterminator="\n")
                    csv_writer.writeheader()
                    consumer = consume(csv_writer)
                    for row in producer:
                        if row.get('Band') == self.value_to_filter:
                            row['Date'] = date
                            consumer.send(row)
                            self.log.info("processing row: %s", row)
                    consumer.close()
                producer.close()

        except Exception as e:
            self.log.critical(
                "{}: {} completed with error: {}".format(
                    os.path.splitext(os.path.basename(__file__))[0],
                    self.etl_audit_id, e), exc_info=1
            )
            raise

    # endregion


USAGE = [
    'FT CSV file Filter',
    [['-l', '--log-level', '--log_level'],
        {'help': 'DEBUG, INFO, WARN, ERROR, CRITICAL',
         'choices': ['DEBUG', 'INFO', 'WARN', 'ERROR', 'CRITICAL']}],
    [['-e', '--etl-audit-id', '--etl_audit_id'],
        {'help': 'Etl audit id for etl jobs max-len(10)', 'type': int}],
    [['-if', '--in-file', '--in_file'],
        {'help': 'Etl input file name', 'required': True}],
    [['-of', '--out-file', '--out_file'],
        {'help': 'Etl output file name', 'required': True}],
    [['-v', '--value-to-filter', '--value_to_filter'],
        {'help': 'Etl value used to filter', 'required': True}]
]


# noinspection PyBroadException
def main():
    """
    Delegates all processing to Agent instance.
    """
    logger = logging.getLogger("{}".format(
        os.path.splitext(os.path.basename(__file__))[0]))

    try:
        cmd_line = util.sanitize_cmd_line(copy.copy(sys.argv))
        logging.info(cmd_line)
        args = util.parse_args(*USAGE)
        with FtDataExtractor(logger=logger, options=args) as agent:
            agent.validate()
            agent.run()
    except Exception:
        logger.critical(
            "critical error in {}::".format(
                os.path.splitext(os.path.basename(__file__))[0]), exc_info=1)
        logger.critical("Agent exited with error.")
        return -1
    else:
        logger.info("Agent completed successfully.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
