#!/usr/bin/env python

import os
#import core # requires /appl/pimprod/pimco_common/pypimco to be added to PYTHONPATH
import cx_Oracle

def main():
    print("Hello from Python.")

if __name__ == "__main__":
    main()
