import os
import sys
import logging
import copy
import csv
import re
from datetime import datetime

from etl.core import util
from etl.core.timed import timed
from etl.core import da_config


def coroutine(func):
    """
    A  decorator  function that takes care of starting a co-routine
    automatically on call.
    :param func:
    :return: coroutine
    """
    def start(*args, **kwargs):
        cr = func(*args, **kwargs)
        cr.next()
        return cr
    return start


def producer(reader):
    while True:
        line = reader.readline()
        yield line.strip()


@coroutine
def consumer(writer, headers):
    try:
        while True:
            line = (yield)
            row = parse_data_line(headers, line)
            writer.writerow(row)
            logging.info(line)
    except GeneratorExit:
        logging.info("Done with writing!")


def parse_header(header_line, length_line):

    length_tokens = length_line.split(' ')

    headers = []
    index = 0
    offset = 0
    delimiter_length = 1

    for lt in length_tokens:
        length = len(lt.strip())
        if not length:
            delimiter_length += 1
            continue

        name = header_line[offset:offset + length].strip()
        header = dict(name=name, offset=offset, index=index, length=length,
                      sanitizer=re.compile(r"\.{" + str(length) + "}"))
        headers.append(header)
        index += 1
        offset += length + delimiter_length
        delimiter_length = 1
    return headers


def parse_data_line(headers, line):
    row = dict()
    for h in headers:
        cell = line[h.get('offset'):h.get('offset') + h.get('length')]
        sanitizer = h.get('sanitizer')
        text = sanitize(cell, sanitizer)
        row[h.get('name')] = text
    return row


def sanitize(text, sanitizer):
    return sanitizer.sub("", text).strip()


class RgsDataFeedParser(object):
    """
    """

    # region private methods
    def __init__(self, logger=None, options=None):

        self.log = logger or logging.getLogger("{}".format(
            os.path.splitext(os.path.basename(__file__))[0]))

        try:

            self.start_time = datetime.now()
            self.end_time = None

            self.options = copy.deepcopy(
                vars(options) if options is not None else dict())
            self.default_config = da_config.get_etl_cfg()
            self.config = copy.deepcopy(self.default_config)
            self.config.update(self.options)

            level_name = self.config.get('log_level')
            if not level_name:
                level_name = self.config.get('dais').get('log_level', 'INFO')

            level = logging.getLevelName(level_name)
            os.environ['PYPIMCO_LOG_LEVEL_OVERRIDE'] = level_name
            from core.log import log_config
            log_config.init_logging(None, True)
            self.log.setLevel(level)

            formatter = logging.Formatter(
                '%(asctime)s %(threadName)s:%(thread)d %(name)s %(levelname)s %(message)s')

            logger = logging.getLogger('')
            for handler in logger.handlers:
                handler.setFormatter(formatter)

            # Try command line argument first --audit-id
            self.etl_audit_id = self.options.get('etl_audit_id')

            # Use environment variable param if command line
            # for audit id is not set
            if not self.etl_audit_id:
                # Capture etl audit id. This id is created by etl wrapper script
                # and saved to the ETL_AUDIT_ID environment variable
                self.etl_audit_id = os.environ.get('ETL_AUDIT_ID')

            # make sure audit id type is int
            # make sure audit id type is int
            self.etl_audit_id = int(self.etl_audit_id) if self.etl_audit_id \
                else self.etl_audit_id
            self.log.info("ETL_AUDIT_ID: %s", self.etl_audit_id)

            self.in_file = self.options.get('in_file')

            self.out_file = self.options.get('out_file')

            self.dais_own = None
            self.cfdw_own = None

            self.ctx = util.struct(etl_audit_id=self.etl_audit_id,
                                   in_file=self.in_file, out_file=self.out_file)

            self.log.info("Agent started at %s", self.start_time)

        except Exception as e:
            self.log.critical(
                "Unable to initialize RgsDataFeedParser: %s", e)
            raise

    def __enter__(self):
        # make a database connection and return it
        # self.dais_own = ora_xxx('DAIS_OWN', 'ORAPIM_DBP')
        # # make a database connection and return it
        # self.cfdw_own = ora_xxx('CFDW_OWN', 'ORAFND_DBP')
        #
        # self.ctx = util.struct(dais_own=self.dais_own,
        #                        cfdw_own=self.cfdw_own, **self.ctx)

        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):

        if exc_type is None:
            # No exception
            pass

        # make sure the db connection gets closed
        # Release resources
        try:
            if self.dais_own is not None:
                self.dais_own.release()

            if self.cfdw_own is not None:
                self.cfdw_own.release()
        finally:
            self.dais_own = None
            self.cfdw_own = None

        # Release resources
        if self.config is not None:
            self.config = None

        # Display auditing details
        self.end_time = datetime.now()
        elapsed_time = self.end_time - self.start_time
        self.log.info("Overall time elapsed: %ss", elapsed_time)
        self.log.info("Agent completed at %s", self.end_time)
        self.log = None
    # endregion

    # region public methods
    def validate(self):
        """
        Executes validation logic upon start up of the driver.
        """
        if not self.etl_audit_id:
            raise ValueError(
                'Required audit job id not found in '
                'environment var:ETL_AUDIT_ID or cmd line params.')

        if not self.in_file:
            raise ValueError(
                'Required --in-file cmd line argument was not found.')

        if not self.out_file:
            raise ValueError(
                'Required --out-file cmd line argument was not found.')

    @timed()
    def run(self):
        """
        Delegates processing to BbgIndexFlow instance.
        """
        try:
            with open(self.in_file, 'r') as reader:

                publisher = producer(reader)
                header_line = publisher.next()
                length_line = publisher.next()
                headers = parse_header(header_line, length_line)

                with open(self.out_file, 'w') as csvfile:
                    field_names = map(lambda f: f.get('name'), headers)
                    writer = csv.DictWriter(
                        csvfile, fieldnames=field_names,
                        quoting=csv.QUOTE_ALL, lineterminator="\n")
                    writer.writeheader()
                    subscriber = consumer(writer, headers)
                    for line in publisher:
                        if line:
                            subscriber.send(line)
                        else:
                            break
                    subscriber.close()
                publisher.close()

        except Exception as e:
            self.log.critical(
                "{}: {} completed with error: {}".format(
                    os.path.splitext(os.path.basename(__file__))[0],
                    self.etl_audit_id, e), exc_info=1
            )
            raise

    # endregion


USAGE = [
    'RGS Flat file parser',
    ['--log-level', {'help': 'DEBUG, INFO, WARN, ERROR, CRITICAL'}],
    ['--etl-audit-id', {'help': 'Etl audit id for etl jobs max-len(10)'}],
    ['--in-file', {'help': 'Etl input file name', 'required': True}],
    ['--out-file', {'help': 'Etl output file name', 'required': True}]
]


# noinspection PyBroadException
def main():
    """
    Delegates all processing to Agent instance.
    """
    logger = logging.getLogger("{}".format(
        os.path.splitext(os.path.basename(__file__))[0]))

    try:
        cmd_line = util.sanitize_cmd_line(copy.copy(sys.argv))
        logging.info(cmd_line)
        args = util.parse_args(*USAGE)
        with RgsDataFeedParser(logger=logger, options=args) as agent:
            agent.validate()
            agent.run()
    except Exception:
        logger.critical(
            "critical error in {}::".format(
                os.path.splitext(os.path.basename(__file__))[0]), exc_info=1)
        logger.critical("Agent exited with error.")
        return -1
    else:
        logger.info("Agent completed successfully.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
